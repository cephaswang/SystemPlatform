#!/bin/bash
#
# voice.sh - 切換到「聽喇叭聲音做語音輸入」模式，然後啟動語音辨識工具
#
# 使用前請先確認：
#   1. 已在 Audio MIDI 設定 建立好「多重輸出裝置」(Multi-Output Device)，
#      裡面同時勾選了「實體喇叭/耳機」+「BlackHole 2ch」
#   2. 執行 `SwitchAudioSource -a -t output` 確認下面的裝置名稱是否正確
#
# 用法 (Usage)：
#   ./voice.sh              使用預設語系（繁體中文 zh-TW）
#   ./voice.sh zh-TW         繁體中文
#   ./voice.sh zh-CN         簡體中文
#   ./voice.sh en-US         英文（美國）
#   ./voice.sh en-GB         英文（英國）
#   ./voice.sh ja-JP         日文
#   ./voice.sh --help        顯示 voice_dictation 內建的語系說明
#

# ====== 請依實際情況修改以下兩個名稱 ======
OUTPUT_DEVICE="Multi-Output Device"   # 你建立的多重輸出裝置名稱
INPUT_DEVICE="BlackHole 2ch"          # 虛擬輸入裝置名稱
# ==========================================

# 若只是要看語系說明，不需要切換音訊裝置
if [ "$1" == "-h" ] || [ "$1" == "--help" ]; then
    cd ~/voicetool || { echo "❌ 找不到 ~/voicetool 資料夾"; exit 1; }
    ./voice_dictation --help
    exit 0
fi

echo "🔍 檢查裝置是否存在..."

if ! SwitchAudioSource -a -t output | grep -qx "$OUTPUT_DEVICE"; then
    echo "❌ 找不到輸出裝置「$OUTPUT_DEVICE」"
    echo "目前可用的輸出裝置有："
    SwitchAudioSource -a -t output
    echo ""
    echo "👉 請先到「Audio MIDI 設定」建立多重輸出裝置，或修改本腳本中的 OUTPUT_DEVICE 名稱"
    exit 1
fi

if ! SwitchAudioSource -a -t input | grep -qx "$INPUT_DEVICE"; then
    echo "❌ 找不到輸入裝置「$INPUT_DEVICE」"
    echo "目前可用的輸入裝置有："
    SwitchAudioSource -a -t input
    exit 1
fi

echo "✅ 切換輸出 → $OUTPUT_DEVICE"
SwitchAudioSource -t output -s "$OUTPUT_DEVICE"

echo "✅ 切換輸入 → $INPUT_DEVICE"
SwitchAudioSource -t input -s "$INPUT_DEVICE"

echo ""
echo "目前輸出裝置：$(SwitchAudioSource -c -t output)"
echo "目前輸入裝置：$(SwitchAudioSource -c -t input)"
echo ""

# 啟動語音辨識工具
cd ~/voicetool || { echo "❌ 找不到 ~/voicetool 資料夾"; exit 1; }

if [ ! -f "./voice_dictation" ]; then
    echo "⚙️  找不到編譯好的執行檔，開始編譯..."
    swiftc voice_dictation.swift -o voice_dictation \
        -Xlinker -sectcreate -Xlinker __TEXT -Xlinker __info_plist -Xlinker Info.plist
fi

# 可傳入語系參數，例如: ./voice.sh en-US
LOCALE_TO_USE="${1:-zh-TW（預設）}"
echo "🌐 本次使用語系：$LOCALE_TO_USE"
echo ""

./voice_dictation "$1"

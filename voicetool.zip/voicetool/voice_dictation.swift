#!/usr/bin/swift
//
// voice_dictation.swift
// 用 Apple Speech Framework 做即時語音轉文字（可搭配 BlackHole 收「喇叭」的聲音）
//
// 編譯方式：
//   swiftc voice_dictation.swift -o voice_dictation \
//     -Xlinker -sectcreate -Xlinker __TEXT -Xlinker __info_plist -Xlinker Info.plist
//
// 執行方式：
//   1. 先把系統「輸入裝置」切成 BlackHole 2ch（可用 SwitchAudioSource）
//   2. ./voice_dictation
//   3. 第一次執行會跳出「麥克風」「語音辨識」權限請求，請允許
//   4. 播放聲音，畫面會即時印出辨識文字
//   5. 按 Ctrl+C 結束
//

import Foundation
import AVFoundation
import Speech

// MARK: - 可調整設定

// 語系：可用命令列參數指定，例如 ./voice_dictation en-US
// 未指定時預設使用 zh-TW
let defaultLocale = "zh-TW"
let localeIdentifier: String = {
    let args = CommandLine.arguments
    if args.count > 1, !args[1].isEmpty, !args[1].hasPrefix("-") {
        return args[1]
    }
    return defaultLocale
}()

// MARK: - 全域物件

guard let recognizer = SFSpeechRecognizer(locale: Locale(identifier: localeIdentifier)) else {
    print("❌ 無法建立語音辨識器，請確認語系代碼「\(localeIdentifier)」是否正確")
    exit(1)
}

let audioEngine = AVAudioEngine()
var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?
var recognitionTask: SFSpeechRecognitionTask?
var latestText: String = ""   // 持續記錄目前這一段辨識到的最新內容（不論是否為 final）

// MARK: - 輸出檔案（以程式啟動時間命名）

let fileNameFormatter = DateFormatter()
fileNameFormatter.dateFormat = "yyyy-MM-dd_HHmmss"
let startTimestamp = fileNameFormatter.string(from: Date())
let outputFileName = "transcript_\(startTimestamp).txt"
let outputFileURL = URL(fileURLWithPath: FileManager.default.currentDirectoryPath)
    .appendingPathComponent(outputFileName)

// 建立空檔案
FileManager.default.createFile(atPath: outputFileURL.path, contents: nil)

guard let outputFileHandle = try? FileHandle(forWritingTo: outputFileURL) else {
    print("❌ 無法建立輸出檔案：\(outputFileURL.path)")
    exit(1)
}

let lineTimeFormatter = DateFormatter()
lineTimeFormatter.dateFormat = "HH:mm:ss"

func appendToFile(_ text: String) {
    guard !text.isEmpty else { return }
    let timePrefix = lineTimeFormatter.string(from: Date())
    let line = "[\(timePrefix)] \(text)\n"
    if let data = line.data(using: .utf8) {
        outputFileHandle.seekToEndOfFile()
        outputFileHandle.write(data)
    }
}

// MARK: - 開始聆聽 / 辨識

func startTranscribing() {
    guard recognizer.isAvailable else {
        print("❌ 語音辨識目前無法使用（可能沒有網路，或該語系不支援）")
        exit(1)
    }

    let request = SFSpeechAudioBufferRecognitionRequest()
    request.shouldReportPartialResults = true
    recognitionRequest = request

    let inputNode = audioEngine.inputNode
    let recordingFormat = inputNode.outputFormat(forBus: 0)

    print("🎙️  目前輸入裝置取樣率：\(recordingFormat.sampleRate) Hz")
    print("👉 請確認系統設定 > 聲音 > 輸入 已經切到「BlackHole 2ch」")
    print("開始聆聽中... 按 Ctrl+C 結束")
    print("📄 逐字稿將寫入檔案：\(outputFileURL.path)\n")

    var bufferCount = 0
    inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { buffer, _ in
        recognitionRequest?.append(buffer)

        // --- 除錯用：每 20 個 buffer 印一次音量表，確認 BlackHole 是否真的收到聲音 ---
        bufferCount += 1
        if bufferCount % 20 == 0 {
            guard let channelData = buffer.floatChannelData?[0] else { return }
            let frameLength = Int(buffer.frameLength)
            var sum: Float = 0
            for i in 0..<frameLength {
                let sample = channelData[i]
                sum += sample * sample
            }
            let rms = sqrt(sum / Float(frameLength))
            let level = min(Int(rms * 500), 40) // 簡單縮放成 0~40 的長度
            let bar = String(repeating: "█", count: level)
            print("\r🔊 [\(bar.padding(toLength: 40, withPad: " ", startingAt: 0))] RMS=\(String(format: "%.4f", rms))", terminator: "")
            fflush(stdout)
        }
    }

    audioEngine.prepare()
    do {
        try audioEngine.start()
    } catch {
        print("❌ 音訊引擎啟動失敗：\(error.localizedDescription)")
        exit(1)
    }

    recognitionTask = recognizer.recognitionTask(with: request) { result, error in
        if let result = result {
            let text = result.bestTranscription.formattedString
            latestText = text
            // 用 \r 覆蓋同一行，模擬即時聽寫效果
            print("\r\u{1B}[K📝 \(text)", terminator: "")
            fflush(stdout)

            if result.isFinal {
                print("")
                appendToFile(text)
                latestText = ""
            }
        }

        if let error = error {
            let nsError = error as NSError
            // 1110 = 沒有語音輸入的逾時，不算真正的錯誤，忽略即可
            if nsError.code != 1110 {
                print("\n⚠️  辨識發生問題：\(error.localizedDescription)")
            }
        }
    }
}

// MARK: - 結束時清理資源

func stopTranscribing() {
    audioEngine.stop()
    audioEngine.inputNode.removeTap(onBus: 0)
    recognitionRequest?.endAudio()
    recognitionTask?.cancel()

    // 不管有沒有等到 isFinal，只要還有內容就強制寫入，避免檔案是空的
    if !latestText.isEmpty {
        appendToFile(latestText)
        latestText = ""
    }

    outputFileHandle.closeFile()
    print("📄 逐字稿已儲存至：\(outputFileURL.path)")
}

// 忽略預設的 SIGINT 行為，改用 DispatchSource 接管（頂層腳本模式下 signal() 無法使用會捕捉外部變數的 closure）
signal(SIGINT, SIG_IGN)
let sigintSource = DispatchSource.makeSignalSource(signal: SIGINT, queue: .main)
sigintSource.setEventHandler {
    print("\n\n🛑 偵測到 Ctrl+C，結束程式...")
    stopTranscribing()
    exit(0)
}
sigintSource.resume()

// MARK: - 權限請求 + 主流程

func requestPermissions(completion: @escaping (Bool) -> Void) {
    SFSpeechRecognizer.requestAuthorization { authStatus in
        guard authStatus == .authorized else {
            print("❌ 語音辨識權限被拒絕。請至：系統設定 > 隱私權與安全性 > 語音辨識，允許此程式（或 Terminal）")
            completion(false)
            return
        }
        AVCaptureDevice.requestAccess(for: .audio) { granted in
            if !granted {
                print("❌ 麥克風權限被拒絕。請至：系統設定 > 隱私權與安全性 > 麥克風，允許此程式（或 Terminal）")
            }
            completion(granted)
        }
    }
}

// MARK: - 說明訊息

if CommandLine.arguments.contains("-h") || CommandLine.arguments.contains("--help") {
    print("""
    用法：./voice_dictation [語系代碼]

    範例：
      ./voice_dictation            使用預設語系 \(defaultLocale)
      ./voice_dictation en-US      使用英文（美國）
      ./voice_dictation ja-JP      使用日文
      ./voice_dictation zh-CN      使用簡體中文

    """)
    exit(0)
}

print("=== 語音轉文字工具（Speech Framework） ===")
print("🌐 使用語系：\(localeIdentifier)\n")

requestPermissions { granted in
    if granted {
        DispatchQueue.main.async {
            startTranscribing()
        }
    } else {
        exit(1)
    }
}

RunLoop.main.run()

//
//  HelpCenter.swift
//  ScreenRecorder  (org.share35app.ScreenRecorder)
//
//  說明文件中心。
//  - helpdocs.zip 需加入 App Bundle（Copy Bundle Resources）。
//  - 第一次開啟「說明文件」時，把 zip 解壓縮到
//    FileManager.default.temporaryDirectory 底下的專屬子資料夾，
//    然後用系統預設瀏覽器開啟其中的 helpdoc.html。
//  - helpdoc.html 在 zip 裡的實際位置不保證是解壓根目錄
//    （目前的 helpdocs.zip 解壓後會多一層 helpdocs/ 資料夾，
//    變成 helpdocs/helpdoc.html），所以解壓完後改用遞迴搜尋
//    整個暫存資料夾找出 helpdoc.html，不寫死路徑。
//  - 會在暫存區寫一份「來源指紋」（zip 的路徑 + 檔案大小 + 修改時間），
//    下次開啟時如果指紋沒變、且能重新搜尋到 helpdoc.html，就直接重用、
//    不重新解壓。
//  - 解壓縮使用系統內建的 /usr/bin/ditto（macOS 內建，不需額外第三方函式庫）。
//    若專案有加入解壓縮 sandbox 相關 entitlement 限制，請確認
//    「App Sandbox → Outgoing Connections」或改用純 Swift 的解壓方案。
//

import AppKit
import Foundation

enum HelpCenterError: LocalizedError {
    case zipNotFound
    case extractionFailed(String)
    case htmlNotFound

    var errorDescription: String? {
        switch self {
        case .zipNotFound:
            return "在 App 內找不到說明文件（helpdocs.zip）。"
        case .extractionFailed(let message):
            return "說明文件解壓縮失敗：\(message)"
        case .htmlNotFound:
            return "解壓縮完成，但找不到 helpdoc.html。"
        }
    }
}

final class HelpCenter {
    static let shared = HelpCenter()
    private init() {}

    // MARK: - 可調整的常數

    private let zipResourceName = "helpdocs"
    private let zipResourceExtension = "zip"
    private let extractedHTMLName = "helpdoc.html"
    private let tempSubfolderName = "ScreenRecorderHelp"

    // MARK: - 路徑

    private var tempFolderURL: URL {
        FileManager.default.temporaryDirectory
            .appendingPathComponent(tempSubfolderName, isDirectory: true)
    }

    private var markerFileURL: URL {
        tempFolderURL.appendingPathComponent(".source-signature")
    }

    // MARK: - 對外入口

    /// 準備好說明文件（必要時解壓縮）並用預設瀏覽器開啟。
    /// 失敗時跳出警示框，不會拋出例外給呼叫端。
    func openHelp() {
        do {
            let htmlURL = try prepareHelpDocs()
            NSWorkspace.shared.open(htmlURL)
        } catch {
            presentError(error)
        }
    }

    // MARK: - 準備文件（解壓縮 / 重用快取）

    @discardableResult
    private func prepareHelpDocs() throws -> URL {
        guard let zipURL = Bundle.main.url(
            forResource: zipResourceName,
            withExtension: zipResourceExtension
        ) else {
            throw HelpCenterError.zipNotFound
        }

        if canReuseExtractedDocs(zipURL: zipURL), let cachedHTML = locateExtractedHTML() {
            return cachedHTML
        }

        try extract(zipURL: zipURL)
        try writeMarker(for: zipURL)

        guard let htmlURL = locateExtractedHTML() else {
            throw HelpCenterError.htmlNotFound
        }
        return htmlURL
    }

    /// 暫存區已經解過、且來源 zip 沒變 → 可以重用（實際檔案存不存在另外用
    /// `locateExtractedHTML()` 確認，這裡只檢查「來源沒變」）。
    private func canReuseExtractedDocs(zipURL: URL) -> Bool {
        guard let savedSignature = try? String(contentsOf: markerFileURL, encoding: .utf8),
              let currentSignature = try? signature(for: zipURL)
        else {
            return false
        }
        return savedSignature == currentSignature
    }

    /// 在暫存資料夾底下遞迴搜尋 helpdoc.html，不假設它一定在解壓根目錄
    /// （例如 zip 裡多包一層 helpdocs/ 子資料夾的情況）。
    private func locateExtractedHTML() -> URL? {
        let fileManager = FileManager.default
        guard let enumerator = fileManager.enumerator(
            at: tempFolderURL,
            includingPropertiesForKeys: [.isRegularFileKey],
            options: [.skipsHiddenFiles]
        ) else {
            return nil
        }

        for case let fileURL as URL in enumerator {
            if fileURL.lastPathComponent == extractedHTMLName {
                return fileURL
            }
        }
        return nil
    }

    /// 用「路徑 + 檔案大小 + 修改時間」當作來源是否改變的簡易指紋。
    private func signature(for zipURL: URL) throws -> String {
        let attributes = try FileManager.default.attributesOfItem(atPath: zipURL.path)
        let size = (attributes[.size] as? NSNumber)?.int64Value ?? 0
        let modifiedAt = (attributes[.modificationDate] as? Date)?.timeIntervalSince1970 ?? 0
        return "\(zipURL.path)|\(size)|\(modifiedAt)"
    }

    private func writeMarker(for zipURL: URL) throws {
        let signatureText = try signature(for: zipURL)
        try signatureText.write(to: markerFileURL, atomically: true, encoding: .utf8)
    }

    // MARK: - 實際解壓縮

    private func extract(zipURL: URL) throws {
        let fileManager = FileManager.default

        // 每次重新解壓前先清空舊資料夾，避免殘留上一版的檔案。
        if fileManager.fileExists(atPath: tempFolderURL.path) {
            try? fileManager.removeItem(at: tempFolderURL)
        }
        try fileManager.createDirectory(at: tempFolderURL, withIntermediateDirectories: true)

        let process = Process()
        process.executableURL = URL(fileURLWithPath: "/usr/bin/ditto")
        process.arguments = ["-xk", zipURL.path, tempFolderURL.path]

        let errorPipe = Pipe()
        process.standardError = errorPipe
        process.standardOutput = Pipe()

        do {
            try process.run()
        } catch {
            throw HelpCenterError.extractionFailed(
                "無法啟動解壓縮程序（\(error.localizedDescription)）"
            )
        }
        process.waitUntilExit()

        guard process.terminationStatus == 0 else {
            let errorData = errorPipe.fileHandleForReading.readDataToEndOfFile()
            let message = String(data: errorData, encoding: .utf8)?
                .trimmingCharacters(in: .whitespacesAndNewlines)
            throw HelpCenterError.extractionFailed(message?.isEmpty == false ? message! : "未知錯誤")
        }
    }

    // MARK: - 錯誤呈現

    /// 目前用系統警示框呈現錯誤；若 RecorderManager 有提供
    /// 類似 `lastError` 的可觀察屬性，也可以改成寫回該屬性，
    /// 讓錯誤顯示在主視窗內，而不是額外跳出一個對話框。
    private func presentError(_ error: Error) {
        let alert = NSAlert()
        alert.alertStyle = .warning
        alert.messageText = "無法開啟說明文件"
        alert.informativeText = error.localizedDescription
        alert.addButton(withTitle: "確定")
        alert.runModal()
    }
}

//
//  MenuBarContentView.swift
//  ScreenRecorder
//
//  狀態列選單內容：錄影時頁面會被隱藏，改由這裡顯示狀態、
//  暫停 / 繼續 / 停止，以及查看輸出檔案的按鈕。
//
//  每個動作旁邊附上的「⌃⌥⌘R」等文字，是 HotKeyManager.swift 裡註冊的
//  全域快捷鍵（純文字提示，不是真正綁在這個選單項目上的 keyEquivalent；
//  就算選單沒打開，按下組合鍵一樣會觸發，這裡只是讓使用者知道有這回事）。
//

import SwiftUI
import AppKit

struct MenuBarContentView: View {
    @EnvironmentObject private var recorder: RecorderManager
    @Environment(\.openWindow) private var openWindow

    var body: some View {
        Group {
            statusLine

            Divider()

            switch recorder.state {
            case .idle:
                Button("開始錄影（\(HotKeyManager.Action.start.displaySymbol)）") {
                    Task { await recorder.start() }
                }

            case .recording:
                Button("暫停（\(HotKeyManager.Action.pause.displaySymbol)）") {
                    recorder.pause()
                }
                Button("停止並輸出 MP4（\(HotKeyManager.Action.stop.displaySymbol)）") {
                    Task {
                        await recorder.stop()
                        bringMainWindowToFront()
                    }
                }

            case .paused:
                Button("繼續（\(HotKeyManager.Action.resume.displaySymbol)）") {
                    recorder.resume()
                }
                Button("停止並輸出 MP4（\(HotKeyManager.Action.stop.displaySymbol)）") {
                    Task {
                        await recorder.stop()
                        bringMainWindowToFront()
                    }
                }
            }

            Divider()

            Button("開啟主視窗") {
                bringMainWindowToFront()
            }

            if let url = recorder.lastOutputURL {
                Button("查看上次輸出的影片") {
                    NSWorkspace.shared.open(url)
                }
                Button("在 Finder 中顯示") {
                    NSWorkspace.shared.activateFileViewerSelecting([url])
                }
            }

            Divider()

            Button("結束 ScreenRecorder") {
                NSApp.terminate(nil)
            }
        }
    }

    /// 開啟（或叫回）主視窗，並確保它出現在最上面。
    /// 主視窗是 `Window` 單例場景，所以無論呼叫幾次都只會有一個視窗實例。
    private func bringMainWindowToFront() {
        openWindow(id: "main")
        NSApp.activate(ignoringOtherApps: true)
    }

    // MARK: - 狀態文字（含計時）

    private var statusLine: some View {
        let text: String
        switch recorder.state {
        case .idle:
            text = "尚未開始錄影"
        case .recording:
            text = "🔴 錄影中　\(RecorderManager.formattedTime(recorder.elapsedTime))"
        case .paused:
            text = "⏸️ 已暫停　\(RecorderManager.formattedTime(recorder.elapsedTime))"
        }
        return Text(text)
    }
}

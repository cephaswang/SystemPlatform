//
//  HotKeyManager.swift
//  ScreenRecorder  (org.share35app.ScreenRecorder)
//
//  全域快捷鍵：開始 / 暫停 / 停止 / 繼續錄影。
//
//  用的是 Carbon 的 RegisterEventHotKey（不是 CGEventTap）：
//  - 全域生效：不管目前最前景的是哪個 App，按下組合鍵都能觸發，
//    這樣錄影期間（主視窗會自動隱藏、使用者通常切去別的 App 操作）
//    才有實際用處。
//  - 不需要「輔助使用」或「輸入監控」權限，App Sandbox 底下也能直接註冊，
//    不需要額外 entitlement，也不用在 Info.plist 加任何使用說明字串。
//  - 缺點：只能「監聽」組合鍵，沒辦法把按鍵事件吃掉，所以如果選到的組合鍵
//    剛好跟其他 App／系統快捷鍵一樣，兩邊可能會同時觸發、或這裡搶不到。
//    這也是為什麼下面預設選了 Control+Option+Command 這種比較少見的組合。
//
//  注意：跟 RecorderManager.swift 裡其他輔助型別一樣標了 `nonisolated`，
//  是因為 Xcode 26 新專案預設把整個 target 設成 MainActor 隔離；
//  這裡的 C function pointer（給 InstallEventHandler 用）本來就不能是
//  MainActor-isolated，所以整個 class 需要維持非隔離狀態。
//  若你的 Xcode 版本較舊、專案沒有這個預設值，把 `nonisolated` 關鍵字
//  刪掉也完全不影響行為。
//

import Carbon.HIToolbox
import AppKit

nonisolated final class HotKeyManager {

    /// 四個可以用全域快捷鍵觸發的動作。
    enum Action: CaseIterable {
        case start
        case pause
        case stop
        case resume

        /// 目前的預設按鍵組合。之後如果要做「使用者自訂快捷鍵」的設定畫面，
        /// 就是把這裡改成從 UserDefaults 讀取，其他地方都不用動。
        fileprivate var defaultKeyCombo: (keyCode: UInt32, modifiers: UInt32) {
            let mods = UInt32(controlKey | optionKey | cmdKey)
            switch self {
            case .start:  return (UInt32(kVK_ANSI_R), mods)
            case .pause:  return (UInt32(kVK_ANSI_P), mods)
            case .stop:   return (UInt32(kVK_ANSI_S), mods)
            case .resume: return (UInt32(kVK_ANSI_C), mods)
            }
        }

        /// 給介面顯示用的文字（選單、按鈕旁的小提示）。
        var displaySymbol: String {
            switch self {
            case .start:  return "⌃⌥⌘R"
            case .pause:  return "⌃⌥⌘P"
            case .stop:   return "⌃⌥⌘S"
            case .resume: return "⌃⌥⌘C"
            }
        }

        /// Carbon 熱鍵的 id 欄位（跟 signature 合起來唯一識別一組熱鍵）。
        fileprivate var hotKeyIDValue: UInt32 {
            switch self {
            case .start:  return 1
            case .pause:  return 2
            case .stop:   return 3
            case .resume: return 4
            }
        }
    }

    /// 觸發時要執行的動作；固定跑在 MainActor 上，因為背後都是呼叫
    /// RecorderManager（一個 @MainActor 的 class）的方法。
    typealias Handler = @MainActor () -> Void

    private var eventHandlerRef: EventHandlerRef?
    private var hotKeyRefs: [UInt32: EventHotKeyRef] = [:]
    private var handlers: [UInt32: Handler] = [:]

    /// 4 個字元的簽章，讓這個 App 註冊的熱鍵 id 命名空間跟其他 App 不會混在一起
    /// （Carbon 的 hot key id 是整個系統共用的）。任取 4 個字元即可。
    fileprivate static let signature: OSType = {
        var result: OSType = 0
        for byte in "SRPR".utf8 {
            result = (result << 8) + OSType(byte)
        }
        return result
    }()

    init() {
        installEventHandler()
    }

    deinit {
        for (_, ref) in hotKeyRefs {
            UnregisterEventHotKey(ref)
        }
        if let eventHandlerRef {
            RemoveEventHandler(eventHandlerRef)
        }
    }

    /// 一次註冊四個動作對應的全域快捷鍵。
    /// 建議只呼叫一次（例如放在 App 啟動流程裡）；重複呼叫也安全，
    /// 會先解除舊的註冊再重新註冊一次。
    func registerAll(
        onStart: @escaping Handler,
        onPause: @escaping Handler,
        onStop: @escaping Handler,
        onResume: @escaping Handler
    ) {
        register(.start, handler: onStart)
        register(.pause, handler: onPause)
        register(.stop, handler: onStop)
        register(.resume, handler: onResume)
    }

    func unregisterAll() {
        for (_, ref) in hotKeyRefs {
            UnregisterEventHotKey(ref)
        }
        hotKeyRefs.removeAll()
        handlers.removeAll()
    }

    // MARK: - 私有

    private func register(_ action: Action, handler: @escaping Handler) {
        let id = action.hotKeyIDValue
        handlers[id] = handler

        // 重複註冊前先解除舊的，避免同一個動作留下兩組互相干擾的熱鍵。
        if let existing = hotKeyRefs[id] {
            UnregisterEventHotKey(existing)
            hotKeyRefs[id] = nil
        }

        let combo = action.defaultKeyCombo
        let hotKeyID = EventHotKeyID(signature: Self.signature, id: id)
        var hotKeyRef: EventHotKeyRef?

        let status = RegisterEventHotKey(
            combo.keyCode,
            combo.modifiers,
            hotKeyID,
            GetEventDispatcherTarget(),
            0,
            &hotKeyRef
        )

        if status == noErr, let hotKeyRef {
            hotKeyRefs[id] = hotKeyRef
        } else {
            // 最常見的原因：組合鍵已經被系統或其他 App 佔用。
            print("[HotKey] ⚠️ 註冊「\(action)」快捷鍵（\(action.displaySymbol)）失敗，status=\(status)，可能與其他快捷鍵衝突")
        }
    }

    private func installEventHandler() {
        guard eventHandlerRef == nil else { return }

        var eventType = EventTypeSpec(
            eventClass: OSType(kEventClassKeyboard),
            eventKind: UInt32(kEventHotKeyPressed)
        )

        let selfPtr = Unmanaged.passUnretained(self).toOpaque()

        let status = InstallEventHandler(
            GetEventDispatcherTarget(),
            { (_, event, userData) -> OSStatus in
                guard let event, let userData else { return noErr }

                var hotKeyID = EventHotKeyID()
                let paramStatus = GetEventParameter(
                    event,
                    EventParamName(kEventParamDirectObject),
                    EventParamType(typeEventHotKeyID),
                    nil,
                    MemoryLayout<EventHotKeyID>.size,
                    nil,
                    &hotKeyID
                )
                guard paramStatus == noErr, hotKeyID.signature == HotKeyManager.signature else {
                    return noErr
                }

                let manager = Unmanaged<HotKeyManager>.fromOpaque(userData).takeUnretainedValue()
                if let handler = manager.handlers[hotKeyID.id] {
                    Task { @MainActor in
                        handler()
                    }
                }
                return noErr
            },
            1,
            &eventType,
            selfPtr,
            &eventHandlerRef
        )

        if status != noErr {
            print("[HotKey] ⚠️ InstallEventHandler 失敗，status=\(status)，全域快捷鍵將無法使用")
        }
    }
}

//
//  RecorderManager.swift
//  ScreenRecorder
//
//  核心錄影邏輯：
//  - ScreenCaptureKit 擷取畫面（支援多螢幕擇一、支援自訂矩形範圍）
//  - 系統聲音（喇叭播放的聲音）：ScreenCaptureKit 內建擷取
//  - 麥克風：AVCaptureSession 擷取
//  - 兩路聲音在 AudioMixer 內混成「一條」48kHz 立體聲 PCM，再交給 AVAssetWriter
//    編成單一 AAC 音軌（避免多音軌在部分播放器只播第一軌）
//  - AVAssetWriter 即時編碼並直接輸出 .mp4（H.264 + AAC）
//  - 暫停 / 續錄：暫停期間捨棄畫面與聲音，續錄後以「時間戳位移演算法」
//    將後續樣本的 presentationTimeStamp 往前平移，扣除暫停時長。
//
//  執行緒模型：
//  - RecorderManager 本身在 MainActor（負責 UI 狀態）。
//  - 所有 writer / 混音邏輯都集中在 CapturePipeline，且只在它自己的序列佇列
//    (queue) 上執行，畫面、系統聲音、麥克風的 callback 也都送到同一條佇列，
//    因此樣本順序固定、不需要再跳回 MainActor。
//
//  注意：下方輔助型別（AudioSource / AudioMixer / PCMNormalizer / CapturePipeline /
//  CaptureError）都標了 `nonisolated`，是因為 Xcode 26 新專案預設把整個 target
//  設成 MainActor 隔離。若你的 Xcode 版本較舊（< 16.3）不認得型別層級的
//  `nonisolated`，把這個關鍵字刪掉即可。
//

import Foundation
@preconcurrency import ScreenCaptureKit
import AVFoundation
import CoreMedia
import AppKit
import Combine

@MainActor
final class RecorderManager: NSObject, ObservableObject {

    enum RecordingState: Equatable {
        case idle
        case recording
        case paused
    }

    // MARK: - Published 狀態（供 ContentView / MenuBarContentView 顯示）

    @Published private(set) var state: RecordingState = .idle
    @Published private(set) var elapsedTime: TimeInterval = 0
    @Published var lastError: String?
    @Published private(set) var lastOutputURL: URL?

    /// 目前系統上所有可錄製的螢幕（支援多螢幕時使用者可擇一）
    @Published private(set) var availableDisplays: [SCDisplay] = []

    /// 是否錄製系統聲音（喇叭播放出來的聲音）。預設開啟。
    @Published var recordsSystemAudio = true
    /// 是否錄製麥克風。預設開啟。
    @Published var recordsMicrophone = true

    // MARK: - Capture

    private var stream: SCStream?
    private var pipeline: CapturePipeline?
    private var outputURL: URL?

    // MARK: - 錄影計時（畫面用，與編碼時間軸分開）

    private var timer: Timer?
    private var recordingStartDate: Date?
    private var pausedWallClockInterval: TimeInterval = 0
    private var pauseStartDate: Date?

    private let regionIndicator = RecordingRegionIndicator()

    /// 共用的 mm:ss 時間格式化（視窗與選單列都會用到）
    static func formattedTime(_ interval: TimeInterval) -> String {
        let total = Int(interval.rounded())
        let minutes = total / 60
        let seconds = total % 60
        return String(format: "%02d:%02d", minutes, seconds)
    }

    // MARK: - 取得可用螢幕清單（多螢幕支援）

    /// 重新列出目前系統可錄製的螢幕，供介面上的「選擇螢幕」下拉選單使用。
    func loadAvailableDisplays() async {
        do {
            let content = try await SCShareableContent.excludingDesktopWindows(
                false, onScreenWindowsOnly: true
            )
            availableDisplays = content.displays
        } catch {
            lastError = "無法取得螢幕清單：\(error.localizedDescription)"
        }
    }

    // MARK: - 麥克風權限

    private static func requestMicrophoneAccess() async -> Bool {
        let status = AVCaptureDevice.authorizationStatus(for: .audio)
        print("[Mic][RecorderManager] requestMicrophoneAccess() 目前狀態 = \(status.rawValue)")
        switch status {
        case .authorized:
            print("[Mic][RecorderManager] 已授權，直接回傳 true")
            return true
        case .notDetermined:
            let granted = await AVCaptureDevice.requestAccess(for: .audio)
            print("[Mic][RecorderManager] requestAccess 結果 = \(granted)")
            return granted
        default:
            print("[Mic][RecorderManager] 狀態非 authorized/notDetermined（denied 或 restricted），回傳 false")
            return false
        }
    }

    // MARK: - 開始錄影

    /// - Parameters:
    ///   - display: 要錄製的螢幕；未指定時預設使用 `availableDisplays` 第一個（多螢幕時建議由呼叫端明確指定）。
    ///   - region: 自訂錄製範圍（該螢幕座標系統下的矩形，單位為「點」、原點在左上角）。
    ///             傳 nil 表示錄製整個螢幕。
    func start(display: SCDisplay? = nil, region: CGRect? = nil) async {
        guard state == .idle else { return }
        lastError = nil

        do {
            var targetDisplay = display
            if targetDisplay == nil {
                if availableDisplays.isEmpty {
                    await loadAvailableDisplays()
                }
                targetDisplay = availableDisplays.first
            }
            guard let targetDisplay else {
                lastError = "找不到可用的螢幕畫面"
                return
            }

            // 麥克風權限：沒拿到就退回「只錄系統聲音」，並提示使用者
            var micEnabled = recordsMicrophone
            var notice: String?
            print("[Mic][start] recordsMicrophone(使用者設定) = \(recordsMicrophone)，recordsSystemAudio = \(recordsSystemAudio)")
            if micEnabled {
                let granted = await Self.requestMicrophoneAccess()
                print("[Mic][start] 麥克風權限 granted = \(granted)")
                if !granted {
                    micEnabled = false
                    notice = "沒有麥克風權限，這次只錄系統聲音。請到「系統設定 → 隱私權與安全性 → 麥克風」開啟本 App。"
                }
            }
            print("[Mic][start] 最終 micEnabled = \(micEnabled)")

            let filter = SCContentFilter(display: targetDisplay, excludingWindows: [])
            let matchedScreen = Self.nsScreen(for: targetDisplay.displayID)
            let scale = matchedScreen?.backingScaleFactor ?? 2

            let config = SCStreamConfiguration()
            config.minimumFrameInterval = CMTime(value: 1, timescale: 30) // 30fps
            config.pixelFormat = kCVPixelFormatType_32BGRA
            config.showsCursor = true
            config.queueDepth = 5

            // 系統音訊：與螢幕錄製同一個授權，不需要麥克風權限
            config.capturesAudio = recordsSystemAudio
            config.excludesCurrentProcessAudio = true   // 避免錄到 App 自己（例如提示音）
            config.sampleRate = 48_000
            config.channelCount = 2

            if let region {
                // 自訂範圍：只擷取畫面中的這塊矩形
                config.sourceRect = region
                config.width = Self.evenPixelValue(region.width * scale)
                config.height = Self.evenPixelValue(region.height * scale)
            } else {
                // 整個螢幕
                config.width = Self.evenPixelValue(CGFloat(targetDisplay.width) * scale)
                config.height = Self.evenPixelValue(CGFloat(targetDisplay.height) * scale)
            }

            let url = Self.makeOutputURL()
            let pipelineRecordsAudio = recordsSystemAudio || micEnabled
            print("[Mic][start] CapturePipeline recordsAudio(是否建立音訊軌) = \(pipelineRecordsAudio)，輸出路徑 = \(url.path)")
            let pipeline = try CapturePipeline(
                url: url,
                width: config.width,
                height: config.height,
                recordsAudio: pipelineRecordsAudio
            )
            pipeline.onFailure = { [weak self] message in
                Task { @MainActor in
                    await self?.handlePipelineFailure(message)
                }
            }

            let stream = SCStream(filter: filter, configuration: config, delegate: nil)
            try stream.addStreamOutput(pipeline, type: .screen, sampleHandlerQueue: pipeline.queue)
            if recordsSystemAudio {
                try stream.addStreamOutput(pipeline, type: .audio, sampleHandlerQueue: pipeline.queue)
            }
            try await stream.startCapture()

            if micEnabled {
                print("[Mic][start] 準備呼叫 pipeline.startMicrophone() …")
                do {
                    try await pipeline.startMicrophone()
                    print("[Mic][start] pipeline.startMicrophone() 成功，AVCaptureSession 已啟動")
                } catch {
                    print("[Mic][start] pipeline.startMicrophone() 失敗：\(error)")
                    notice = "麥克風啟動失敗（\(error.localizedDescription)），這次只錄系統聲音。"
                }
            } else {
                print("[Mic][start] micEnabled = false，跳過 startMicrophone()")
            }

            // reset 狀態
            self.stream = stream
            self.pipeline = pipeline
            self.outputURL = url

            self.recordingStartDate = Date()
            self.pausedWallClockInterval = 0
            self.pauseStartDate = nil
            self.elapsedTime = 0
            self.state = .recording
            startTimer()

            if let notice { lastError = notice }

            // 自訂範圍：在錄影期間持續顯示邊框，提醒目前正在錄製的區域。
            // 這個覆蓋層不接收滑鼠事件，不會擋住畫面上任何按鍵或操作。
            if let region, let matchedScreen {
                regionIndicator.show(screen: matchedScreen, region: region)
            }
        } catch {
            lastError = "開始錄影失敗：\(error.localizedDescription)"
        }
    }

    // MARK: - 暫停

    func pause() {
        guard state == .recording else { return }
        state = .paused
        pipeline?.pause()
        pauseStartDate = Date()
        stopTimer()
    }

    // MARK: - 繼續

    func resume() {
        guard state == .paused else { return }
        if let pauseStart = pauseStartDate {
            pausedWallClockInterval += Date().timeIntervalSince(pauseStart)
        }
        pauseStartDate = nil
        pipeline?.resume()
        state = .recording
        startTimer()
    }

    // MARK: - 停止並輸出 MP4

    func stop() async {
        guard state != .idle else { return }
        stopTimer()
        regionIndicator.hide()

        let pipeline = self.pipeline
        let url = outputURL

        await pipeline?.stopMicrophone()

        do {
            try await stream?.stopCapture()
        } catch {
            lastError = "停止擷取時發生錯誤：\(error.localizedDescription)"
        }
        stream = nil

        let ok = await pipeline?.finish() ?? false
        if ok {
            lastOutputURL = url
        } else if lastError == nil {
            lastError = "影片寫入失敗或沒有錄到任何畫面，未產生檔案"
        }

        resetSession()
    }

    /// writer 寫入失敗時的清理路徑：停止擷取、捨棄檔案、回到閒置狀態。
    private func handlePipelineFailure(_ message: String) async {
        guard state != .idle else { return }
        lastError = message
        stopTimer()
        regionIndicator.hide()

        let pipeline = self.pipeline
        await pipeline?.stopMicrophone()
        try? await stream?.stopCapture()
        stream = nil
        pipeline?.cancel()

        resetSession()
    }

    private func resetSession() {
        pipeline = nil
        outputURL = nil
        recordingStartDate = nil
        pausedWallClockInterval = 0
        pauseStartDate = nil
        elapsedTime = 0
        state = .idle
    }

    // MARK: - 計時器（僅供 UI 顯示已錄製時長）

    private func startTimer() {
        timer?.invalidate()
        timer = Timer.scheduledTimer(withTimeInterval: 0.2, repeats: true) { [weak self] _ in
            guard let self else { return }
            Task { @MainActor in
                guard let start = self.recordingStartDate else { return }
                self.elapsedTime = Date().timeIntervalSince(start) - self.pausedWallClockInterval
            }
        }
    }

    private func stopTimer() {
        timer?.invalidate()
        timer = nil
    }

    /// H.264 編碼要求寬高必須是偶數；把計算出來的像素尺寸無條件進位到最近的偶數。
    private static func evenPixelValue(_ value: CGFloat) -> Int {
        let rounded = Int(value.rounded(.up))
        return rounded % 2 == 0 ? max(2, rounded) : max(2, rounded + 1)
    }

    private static func makeOutputURL() -> URL {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyyMMdd_HHmmss"
        let name = "ScreenRecorder_\(formatter.string(from: Date())).mp4"
        let dir = FileManager.default.urls(for: .moviesDirectory, in: .userDomainMask).first
            ?? FileManager.default.temporaryDirectory
        return dir.appendingPathComponent(name)
    }

    /// 依 CGDirectDisplayID 找出對應的 NSScreen（自訂範圍選取、螢幕編號提示都會用到）
    static func nsScreen(for displayID: CGDirectDisplayID) -> NSScreen? {
        NSScreen.screens.first { screen in
            guard let number = screen.deviceDescription[NSDeviceDescriptionKey("NSScreenNumber")] as? NSNumber else {
                return false
            }
            return CGDirectDisplayID(number.uint32Value) == displayID
        }
    }
}

// MARK: - 錯誤型別

nonisolated enum CaptureError: LocalizedError {
    case cannotAddInput(String)
    case noMicrophone
    case cannotConfigureMicrophone

    var errorDescription: String? {
        switch self {
        case .cannotAddInput(let name): return "無法建立\(name)輸出串流"
        case .noMicrophone: return "找不到可用的麥克風"
        case .cannotConfigureMicrophone: return "無法設定麥克風擷取"
        }
    }
}

// MARK: - 聲音來源

nonisolated enum AudioSource: Int {
    case system = 0
    case microphone = 1
}

// MARK: - PCM 正規化（任何輸入格式 → 48kHz 立體聲 Float32 interleaved）

/// 系統聲音是 Float32 non-interleaved，麥克風可能是 44.1k/48k、單聲道/立體聲、
/// Int16/Float32…。這裡統一轉成同一種格式，後面的混音與編碼就不用管來源格式。
nonisolated final class PCMNormalizer {
    private let outputFormat = AVAudioFormat(
        commonFormat: .pcmFormatFloat32, sampleRate: 48_000, channels: 2, interleaved: true
    )!
    private var converter: AVAudioConverter?
    private var inputFormat: AVAudioFormat?

    /// 回傳 interleaved 立體聲 Float32 樣本（L R L R …）
    func normalize(_ sampleBuffer: CMSampleBuffer) -> [Float]? {
        guard let desc = CMSampleBufferGetFormatDescription(sampleBuffer),
              let asbdPtr = CMAudioFormatDescriptionGetStreamBasicDescription(desc) else { return nil }

        let frameCount = AVAudioFrameCount(CMSampleBufferGetNumSamples(sampleBuffer))
        guard frameCount > 0 else { return nil }

        var asbd = asbdPtr.pointee
        guard let inFormat = AVAudioFormat(streamDescription: &asbd) else { return nil }

        if converter == nil || inputFormat != inFormat {
            converter = AVAudioConverter(from: inFormat, to: outputFormat)
            inputFormat = inFormat
        }
        guard let converter,
              let inBuffer = AVAudioPCMBuffer(pcmFormat: inFormat, frameCapacity: frameCount) else { return nil }

        inBuffer.frameLength = frameCount
        let copyStatus = CMSampleBufferCopyPCMDataIntoAudioBufferList(
            sampleBuffer, at: 0, frameCount: Int32(frameCount), into: inBuffer.mutableAudioBufferList
        )
        guard copyStatus == noErr else { return nil }

        let ratio = outputFormat.sampleRate / inFormat.sampleRate
        let capacity = AVAudioFrameCount(Double(frameCount) * ratio) + 512
        guard let outBuffer = AVAudioPCMBuffer(pcmFormat: outputFormat, frameCapacity: capacity) else { return nil }

        var supplied = false
        var convertError: NSError?
        let status = converter.convert(to: outBuffer, error: &convertError) { _, outStatus in
            if supplied {
                outStatus.pointee = .noDataNow
                return nil
            }
            supplied = true
            outStatus.pointee = .haveData
            return inBuffer
        }
        guard status != .error, outBuffer.frameLength > 0,
              let channelData = outBuffer.floatChannelData else { return nil }

        let sampleCount = Int(outBuffer.frameLength) * 2
        return Array(UnsafeBufferPointer(start: channelData[0], count: sampleCount))
    }
}

// MARK: - 混音器

/// 依「時間戳」把系統聲音與麥克風擺到同一條 48kHz 立體聲時間軸上相加，
/// 再以固定大小的 CMSampleBuffer 吐給 AVAssetWriter。
///
/// - 每個來源各有一個緩衝區，內容代表「尚未送出」的樣本，起點 = emittedFrames。
/// - 來源時間戳與預期位置差 ≤ 20ms 視為連續（避免時間戳抖動造成破音）；
///   差更多就依時間戳重新對位（中間補靜音）。
/// - 平時保留 150ms 緩衝再送出，讓比較晚到的另一路聲音來得及混進去。
nonisolated final class AudioMixer {
    private let sampleRate = 48_000.0
    private let latencyFrames: Int64 = 7_200        // 150ms
    private let jitterFrames: Int64 = 960           // 20ms
    private let minChunkFrames: Int64 = 1_024
    private let maxGapFrames: Int64 = 48_000 * 30

    private let origin: CMTime
    private var emittedFrames: Int64 = 0
    private var pending: [[Float]] = [[], []]
    private var nextFrame: [Int64?] = [nil, nil]
    private let formatDescription: CMAudioFormatDescription

    init?(origin: CMTime) {
        var asbd = AudioStreamBasicDescription(
            mSampleRate: 48_000,
            mFormatID: kAudioFormatLinearPCM,
            mFormatFlags: kAudioFormatFlagIsFloat | kAudioFormatFlagIsPacked,
            mBytesPerPacket: 8,
            mFramesPerPacket: 1,
            mBytesPerFrame: 8,
            mChannelsPerFrame: 2,
            mBitsPerChannel: 32,
            mReserved: 0
        )
        var desc: CMAudioFormatDescription?
        let status = CMAudioFormatDescriptionCreate(
            allocator: kCFAllocatorDefault, asbd: &asbd,
            layoutSize: 0, layout: nil,
            magicCookieSize: 0, magicCookie: nil,
            extensions: nil, formatDescriptionOut: &desc
        )
        guard status == noErr, let desc else { return nil }
        self.origin = origin
        self.formatDescription = desc
    }

    /// 把一段（已正規化的）樣本放進對應來源的緩衝區。`time` 是這段樣本第一個 frame 的時間（已扣除暫停位移）。
    func write(_ source: AudioSource, samples: [Float], at time: CMTime) {
        let totalFrames = Int64(samples.count / 2)
        guard totalFrames > 0 else { return }
        let s = source.rawValue

        let seconds = CMTimeSubtract(time, origin).seconds
        guard seconds.isFinite else { return }

        var startFrame = Int64((seconds * sampleRate).rounded())
        if let expected = nextFrame[s], abs(startFrame - expected) <= jitterFrames {
            startFrame = expected
        }
        nextFrame[s] = startFrame + totalFrames

        var skip: Int64 = 0
        var rel = startFrame - emittedFrames
        if rel < 0 {           // 這段樣本有一部分已經過了送出點，丟掉那部分
            skip = -rel
            rel = 0
        }
        guard skip < totalFrames, rel < maxGapFrames else { return }

        let firstSample = Int(skip) * 2
        let destStart = Int(rel) * 2
        let destEnd = destStart + (samples.count - firstSample)
        if pending[s].count < destEnd {
            pending[s].append(contentsOf: repeatElement(0, count: destEnd - pending[s].count))
        }
        pending[s].replaceSubrange(destStart..<destEnd, with: samples[firstSample...])
    }

    /// 取出可以送給 writer 的混音結果。`final == true` 時把所有剩餘樣本全部送出（暫停 / 停止時用）。
    func drain(final: Bool) -> [CMSampleBuffer] {
        let newest = max(endFrame(0), endFrame(1))
        let target = final ? newest : newest - latencyFrames
        let frames = target - emittedFrames
        guard frames >= (final ? 1 : minChunkFrames) else { return [] }

        let count = Int(frames) * 2
        var mixed = [Float](repeating: 0, count: count)
        for s in 0..<2 {
            let take = min(count, pending[s].count)
            if take > 0 {
                for i in 0..<take { mixed[i] += pending[s][i] }
                pending[s].removeFirst(take)
            }
        }
        for i in 0..<count { mixed[i] = max(-1, min(1, mixed[i])) }   // 防爆音

        let pts = CMTimeAdd(origin, CMTime(value: emittedFrames, timescale: 48_000))
        emittedFrames += frames

        if let buffer = makeSampleBuffer(mixed, frames: Int(frames), pts: pts) {
            return [buffer]
        }
        return []
    }

    private func endFrame(_ s: Int) -> Int64 {
        emittedFrames + Int64(pending[s].count / 2)
    }

    private func makeSampleBuffer(_ samples: [Float], frames: Int, pts: CMTime) -> CMSampleBuffer? {
        let byteCount = samples.count * MemoryLayout<Float>.size

        var block: CMBlockBuffer?
        let blockStatus = CMBlockBufferCreateWithMemoryBlock(
            allocator: kCFAllocatorDefault, memoryBlock: nil, blockLength: byteCount,
            blockAllocator: kCFAllocatorDefault, customBlockSource: nil,
            offsetToData: 0, dataLength: byteCount,
            flags: kCMBlockBufferAssureMemoryNowFlag, blockBufferOut: &block
        )
        guard blockStatus == kCMBlockBufferNoErr, let block else { return nil }

        let copyStatus = samples.withUnsafeBytes { raw in
            CMBlockBufferReplaceDataBytes(
                with: raw.baseAddress!, blockBuffer: block,
                offsetIntoDestination: 0, dataLength: byteCount
            )
        }
        guard copyStatus == kCMBlockBufferNoErr else { return nil }

        var sampleBuffer: CMSampleBuffer?
        let status = CMAudioSampleBufferCreateReadyWithPacketDescriptions(
            allocator: kCFAllocatorDefault, dataBuffer: block,
            formatDescription: formatDescription, sampleCount: frames,
            presentationTimeStamp: pts, packetDescriptions: nil,
            sampleBufferOut: &sampleBuffer
        )
        return status == noErr ? sampleBuffer : nil
    }
}

// MARK: - 擷取 / 寫入管線

nonisolated final class CapturePipeline: NSObject, @unchecked Sendable,
                                          SCStreamOutput, AVCaptureAudioDataOutputSampleBufferDelegate {

    /// 畫面、系統聲音、麥克風的 callback 都送到這條序列佇列；所有可變狀態只在這條佇列上讀寫。
    let queue = DispatchQueue(label: "com.share35app.screenrecorder.capture", qos: .userInteractive)
    private let micSessionQueue = DispatchQueue(label: "com.share35app.screenrecorder.mic-session")

    /// writer 發生無法恢復的錯誤時呼叫（可能在任意執行緒）
    var onFailure: (@Sendable (String) -> Void)?

    private let writer: AVAssetWriter
    private let videoInput: AVAssetWriterInput
    private let audioInput: AVAssetWriterInput?
    private var micSession: AVCaptureSession?      // 只在 micSessionQueue 上存取

    // 除錯用計數器（只在 queue 上讀寫，不需要額外加鎖）
    private var micSampleCount = 0
    private var micNormalizeFailCount = 0
    private var systemSampleCount = 0
    private var mixedBufferCount = 0

    private var mixer: AudioMixer?
    private let normalizers = [PCMNormalizer(), PCMNormalizer()]

    private var sessionStarted = false
    private var finished = false

    // 暫停 / 續錄
    private var isPaused = false
    private var awaitingResumeAnchor = false
    private var accumulatedOffset: CMTime = .zero   // 累計已扣除的暫停時長
    private var lastEndPTS: CMTime = .zero          // 暫停前，所有來源中最晚的樣本結束時間

    init(url: URL, width: Int, height: Int, recordsAudio: Bool) throws {
        let writer = try AVAssetWriter(outputURL: url, fileType: .mp4)

        let videoSettings: [String: Any] = [
            AVVideoCodecKey: AVVideoCodecType.h264,
            AVVideoWidthKey: width,
            AVVideoHeightKey: height,
            AVVideoCompressionPropertiesKey: [
                AVVideoAverageBitRateKey: 8_000_000,
                AVVideoProfileLevelKey: AVVideoProfileLevelH264HighAutoLevel,
                AVVideoExpectedSourceFrameRateKey: 30
            ]
        ]
        let video = AVAssetWriterInput(mediaType: .video, outputSettings: videoSettings)
        video.expectsMediaDataInRealTime = true
        guard writer.canAdd(video) else { throw CaptureError.cannotAddInput("影片") }
        writer.add(video)

        var audio: AVAssetWriterInput?
        if recordsAudio {
            let audioSettings: [String: Any] = [
                AVFormatIDKey: kAudioFormatMPEG4AAC,
                AVNumberOfChannelsKey: 2,
                AVSampleRateKey: 48_000,
                AVEncoderBitRateKey: 192_000
            ]
            let input = AVAssetWriterInput(mediaType: .audio, outputSettings: audioSettings)
            input.expectsMediaDataInRealTime = true
            guard writer.canAdd(input) else { throw CaptureError.cannotAddInput("音訊") }
            writer.add(input)
            audio = input
        }

        self.writer = writer
        self.videoInput = video
        self.audioInput = audio
        super.init()
    }

    // MARK: 麥克風

    func startMicrophone() async throws {
        try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
            micSessionQueue.async {
                do {
                    try self.configureAndStartMicrophone()
                    continuation.resume()
                } catch {
                    continuation.resume(throwing: error)
                }
            }
        }
    }

    /// 已知的虛擬迴路/系統音訊裝置關鍵字（例如 BlackHole、Soundflower、
    /// Loopback…），這類裝置本身不會真的收音，若被系統設成「預設輸入」，
    /// 用 AVCaptureDevice.default(for: .audio) 抓到的會是它們而不是實體麥克風，
    /// 錄出來的麥克風音軌就會是全靜音。
    private static let virtualAudioDeviceNameKeywords: [String] = [
        "blackhole",
        "soundflower",
        "loopback",
        "ishowu audio",
        "virtual audio",
        "背景音樂",
    ]

    private func isVirtualAudioDevice(_ device: AVCaptureDevice) -> Bool {
        let name = device.localizedName.lowercased()
        return Self.virtualAudioDeviceNameKeywords.contains { name.contains($0) }
    }

    /// 挑選一顆「真的能收音」的麥克風裝置：
    /// 1. 先列出所有可用的音訊輸入裝置
    /// 2. 濾掉已知的虛擬迴路裝置（BlackHole 等）
    /// 3. 剩下的裝置優先選內建麥克風，其次選系統目前的預設裝置，最後隨便選第一顆
    /// 4. 如果濾掉之後什麼都不剩，才退回用系統預設裝置（避免完全錄不到聲音）
    private func selectPreferredMicrophoneDevice() -> AVCaptureDevice? {
        // AVCaptureDevice.devices(for:) 會列出「所有」符合該 mediaType 的裝置，
        // 不像 .default(for:) 只回傳系統目前設定的預設裝置，
        // 也不需要指定特定 macOS 版本才有的 deviceType 列舉值。
        let allDevices = AVCaptureDevice.devices(for: .audio)
        print("[Mic][Pipeline] 可用音訊輸入裝置清單：\(allDevices.map { "\($0.localizedName)(\($0.uniqueID))" })")

        let realDevices = allDevices.filter { !isVirtualAudioDevice($0) }
        if realDevices.isEmpty {
            print("[Mic][Pipeline] ⚠️ 篩選後沒有非虛擬裝置，退回使用系統預設輸入裝置")
            return AVCaptureDevice.default(for: .audio)
        }

        if let builtIn = realDevices.first(where: { $0.localizedName.lowercased().contains("built-in") || $0.localizedName.contains("內建") }) {
            print("[Mic][Pipeline] 選用內建麥克風：\(builtIn.localizedName)")
            return builtIn
        }

        if let systemDefault = AVCaptureDevice.default(for: .audio),
           realDevices.contains(where: { $0.uniqueID == systemDefault.uniqueID }) {
            print("[Mic][Pipeline] 系統預設輸入裝置不是虛擬裝置，選用：\(systemDefault.localizedName)")
            return systemDefault
        }

        print("[Mic][Pipeline] 選用清單中第一顆非虛擬裝置：\(realDevices[0].localizedName)")
        return realDevices.first
    }

    private func configureAndStartMicrophone() throws {
        print("[Mic][Pipeline] configureAndStartMicrophone() 開始（在 micSessionQueue 上執行）")

        guard let device = selectPreferredMicrophoneDevice() else {
            print("[Mic][Pipeline] ❌ 找不到任何可用的麥克風裝置")
            throw CaptureError.noMicrophone
        }
        print("[Mic][Pipeline] 最終選用麥克風裝置：\(device.localizedName)（uniqueID=\(device.uniqueID)）")

        let session = AVCaptureSession()

        let input: AVCaptureDeviceInput
        do {
            input = try AVCaptureDeviceInput(device: device)
        } catch {
            // 這裡最常見的原因是 App Sandbox 的 entitlements 缺少
            // com.apple.security.device.audio-input，跟系統設定裡的
            // 隱私權授權是兩回事，就算隱私權那邊已經打勾，這裡還是會失敗。
            print("[Mic][Pipeline] ❌ AVCaptureDeviceInput(device:) 失敗：\(error)")
            print("[Mic][Pipeline]    → 如果隱私權設定已授權但仍失敗，請檢查 .entitlements 是否有 com.apple.security.device.audio-input")
            throw error
        }

        let output = AVCaptureAudioDataOutput()
        output.setSampleBufferDelegate(self, queue: queue)

        guard session.canAddInput(input) else {
            print("[Mic][Pipeline] ❌ session.canAddInput(input) = false")
            throw CaptureError.cannotConfigureMicrophone
        }
        guard session.canAddOutput(output) else {
            print("[Mic][Pipeline] ❌ session.canAddOutput(output) = false")
            throw CaptureError.cannotConfigureMicrophone
        }
        session.addInput(input)
        session.addOutput(output)
        print("[Mic][Pipeline] input/output 已加入 session，呼叫 session.startRunning() …")
        session.startRunning()      // 會阻塞一小段時間，所以放在專用佇列
        print("[Mic][Pipeline] session.startRunning() 回傳，session.isRunning = \(session.isRunning)")
        micSession = session
    }

    func stopMicrophone() async {
        await withCheckedContinuation { (continuation: CheckedContinuation<Void, Never>) in
            micSessionQueue.async {
                print("[Mic][Pipeline] stopMicrophone()，本次錄影共收到麥克風樣本 \(self.micSampleCount) 次（normalize 失敗 \(self.micNormalizeFailCount) 次）")
                self.micSession?.stopRunning()
                self.micSession = nil
                continuation.resume()
            }
        }
    }

    // MARK: 暫停 / 續錄 / 結束

    func pause() {
        queue.async {
            guard !self.isPaused else { return }
            self.appendMixed(final: true)      // 暫停前先把緩衝中的聲音全部寫出
            self.isPaused = true
        }
    }

    func resume() {
        queue.async {
            guard self.isPaused else { return }
            self.isPaused = false
            self.awaitingResumeAnchor = true    // 下一顆有效樣本用來計算暫停時長
        }
    }

    /// 結束寫入。回傳 true 代表檔案完整輸出。
    func finish() async -> Bool {
        await withCheckedContinuation { (continuation: CheckedContinuation<Bool, Never>) in
            queue.async {
                self.finished = true
                guard self.sessionStarted, self.writer.status == .writing else {
                    if self.writer.status == .writing { self.writer.cancelWriting() }
                    continuation.resume(returning: false)
                    return
                }
                self.appendMixed(final: true)
                self.videoInput.markAsFinished()
                self.audioInput?.markAsFinished()
                self.writer.finishWriting {
                    continuation.resume(returning: self.writer.status == .completed)
                }
            }
        }
    }

    /// 放棄輸出（失敗時的清理路徑）
    func cancel() {
        queue.async {
            self.finished = true
            if self.writer.status == .writing { self.writer.cancelWriting() }
        }
    }

    // MARK: SCStreamOutput（畫面 + 系統聲音）

    func stream(
        _ stream: SCStream,
        didOutputSampleBuffer sampleBuffer: CMSampleBuffer,
        of type: SCStreamOutputType
    ) {
        guard sampleBuffer.isValid, !finished else { return }
        switch type {
        case .screen:
            handleVideo(sampleBuffer)
        case .audio:
            systemSampleCount += 1
            if systemSampleCount == 1 {
                print("[Mic][Delegate] ✅ 收到第 1 顆系統聲音 sample buffer")
            } else if systemSampleCount % 100 == 0 {
                print("[Mic][Delegate] 已收到 \(systemSampleCount) 顆系統聲音 sample buffer")
            }
            handleAudio(sampleBuffer, source: .system, pts: sampleBuffer.presentationTimeStamp)
        default:
            break
        }
    }

    // MARK: AVCaptureAudioDataOutputSampleBufferDelegate（麥克風）

    func captureOutput(
        _ output: AVCaptureOutput,
        didOutput sampleBuffer: CMSampleBuffer,
        from connection: AVCaptureConnection
    ) {
        guard sampleBuffer.isValid, !finished else {
            print("[Mic][Delegate] captureOutput 收到無效 sampleBuffer 或已 finished，丟棄")
            return
        }
        micSampleCount += 1
        if micSampleCount == 1 {
            print("[Mic][Delegate] ✅ 收到第 1 顆麥克風 sample buffer（代表 AVCaptureSession 確實有在送資料）")
        } else if micSampleCount % 100 == 0 {
            print("[Mic][Delegate] 已收到 \(micSampleCount) 顆麥克風 sample buffer")
        }
        handleAudio(sampleBuffer, source: .microphone, pts: hostAlignedTime(sampleBuffer))
    }

    /// 麥克風時間戳理論上與畫面同屬 host time clock；若差超過 1 秒（裝置時鐘異常），
    /// 就改用「現在時間 - 這段長度」，避免整段聲音被錯位甚至被丟棄。
    private func hostAlignedTime(_ sampleBuffer: CMSampleBuffer) -> CMTime {
        let pts = sampleBuffer.presentationTimeStamp
        let duration = CMSampleBufferGetDuration(sampleBuffer)
        let safeDuration = duration.isValid ? duration : CMTime.zero
        let now = CMClockGetTime(CMClockGetHostTimeClock())
        let end = CMTimeAdd(pts, safeDuration)
        if abs(CMTimeSubtract(now, end).seconds) > 1.0 {
            return CMTimeSubtract(now, safeDuration)
        }
        return pts
    }

    // MARK: 樣本處理（都在 queue 上執行）

    private func handleVideo(_ sampleBuffer: CMSampleBuffer) {
        guard CMSampleBufferGetImageBuffer(sampleBuffer) != nil,
              Self.isCompleteFrame(sampleBuffer) else { return }

        let pts = sampleBuffer.presentationTimeStamp
        guard let adjusted = adjustedTime(pts: pts, end: pts) else { return }

        // session 一律由「畫面」樣本開啟；此前的聲音樣本會被捨棄，
        // 避免音軌時間戳早於 session 起點。
        if !sessionStarted {
            guard writer.startWriting() else {
                fail("無法開始寫入影片：\(writer.error?.localizedDescription ?? "未知錯誤")")
                return
            }
            writer.startSession(atSourceTime: adjusted)
            sessionStarted = true
            if audioInput != nil { mixer = AudioMixer(origin: adjusted) }
        }

        guard videoInput.isReadyForMoreMediaData,
              let retimed = Self.retimedSampleBuffer(sampleBuffer, newTime: adjusted) else { return }
        if !videoInput.append(retimed) { failIfWriterBroke() }
    }

    private func handleAudio(_ sampleBuffer: CMSampleBuffer, source: AudioSource, pts: CMTime) {
        guard sessionStarted, let mixer, audioInput != nil else {
            if source == .microphone {
                print("[Mic][handleAudio] 麥克風樣本被丟棄：sessionStarted=\(sessionStarted)，mixer存在=\(mixer != nil)，audioInput存在=\(audioInput != nil)（通常是還沒收到第一顆畫面 frame，session 還沒開始）")
            }
            return
        }

        let duration = CMSampleBufferGetDuration(sampleBuffer)
        let end = duration.isValid ? CMTimeAdd(pts, duration) : pts
        guard let adjusted = adjustedTime(pts: pts, end: end) else {
            if source == .microphone {
                print("[Mic][handleAudio] 麥克風樣本被 adjustedTime 丟棄（可能正在暫停，或時間戳落在已送出範圍之前）")
            }
            return
        }

        guard let samples = normalizers[source.rawValue].normalize(sampleBuffer) else {
            if source == .microphone {
                micNormalizeFailCount += 1
                print("[Mic][handleAudio] ❌ 麥克風樣本 normalize 失敗（第 \(micNormalizeFailCount) 次），格式轉換有問題，這顆樣本會被丟棄")
            }
            return
        }
        mixer.write(source, samples: samples, at: adjusted)
        appendMixed(final: false)
    }

    /// 統一處理暫停與時間戳位移。回傳 nil 代表這顆樣本應該丟掉。
    private func adjustedTime(pts: CMTime, end: CMTime) -> CMTime? {
        if isPaused { return nil }

        if awaitingResumeAnchor {
            // 用續錄後第一顆「比暫停前最後一顆更晚」的樣本，算出這段暫停經過的時長。
            let gap = CMTimeSubtract(pts, lastEndPTS)
            guard gap.isValid, gap.seconds > 0 else { return nil }   // 暫停期間遺留的舊樣本
            accumulatedOffset = CMTimeAdd(accumulatedOffset, gap)
            awaitingResumeAnchor = false
        }

        if CMTimeCompare(end, lastEndPTS) > 0 { lastEndPTS = end }
        return CMTimeSubtract(pts, accumulatedOffset)
    }

    private func appendMixed(final: Bool) {
        guard let mixer, let audioInput, writer.status == .writing else {
            print("[Mic][appendMixed] 跳過：mixer存在=\(mixer != nil)，audioInput存在=\(audioInput != nil)，writer.status=\(writer.status.rawValue)")
            return
        }
        for buffer in mixer.drain(final: final) {
            guard audioInput.isReadyForMoreMediaData else {
                print("[Mic][appendMixed] audioInput 還沒準備好接收更多資料，這批混音先跳過")
                continue
            }
            mixedBufferCount += 1
            if mixedBufferCount == 1 {
                print("[Mic][appendMixed] ✅ 第 1 顆混音後的音訊 buffer 已寫入 audioInput")
            } else if mixedBufferCount % 50 == 0 {
                print("[Mic][appendMixed] 已寫入 \(mixedBufferCount) 顆混音後的音訊 buffer")
            }
            if !audioInput.append(buffer) {
                print("[Mic][appendMixed] ❌ audioInput.append(buffer) 回傳 false")
                failIfWriterBroke()
                return
            }
        }
    }

    private func failIfWriterBroke() {
        if writer.status == .failed {
            fail("影片寫入失敗：\(writer.error?.localizedDescription ?? "未知錯誤")")
        }
    }

    private func fail(_ message: String) {
        guard !finished else { return }
        finished = true
        onFailure?(message)
    }

    // MARK: 工具

    /// ScreenCaptureKit 在畫面沒變動時會送 idle/blank 之類的 frame，只收 .complete。
    private static func isCompleteFrame(_ sampleBuffer: CMSampleBuffer) -> Bool {
        guard let attachments = CMSampleBufferGetSampleAttachmentsArray(
                sampleBuffer, createIfNecessary: false
              ) as? [[SCStreamFrameInfo: Any]],
              let raw = attachments.first?[.status] as? Int,
              let status = SCFrameStatus(rawValue: raw) else { return true }
        return status == .complete
    }

    /// 複製一顆 sample buffer，並將其 presentationTimeStamp 換成 newTime（畫面用）
    private static func retimedSampleBuffer(_ sampleBuffer: CMSampleBuffer, newTime: CMTime) -> CMSampleBuffer? {
        var timingInfo = CMSampleTimingInfo()
        guard CMSampleBufferGetSampleTimingInfo(sampleBuffer, at: 0, timingInfoOut: &timingInfo) == noErr else {
            return nil
        }
        timingInfo.presentationTimeStamp = newTime

        var newBuffer: CMSampleBuffer?
        let status = CMSampleBufferCreateCopyWithNewTiming(
            allocator: kCFAllocatorDefault,
            sampleBuffer: sampleBuffer,
            sampleTimingEntryCount: 1,
            sampleTimingArray: &timingInfo,
            sampleBufferOut: &newBuffer
        )
        return status == noErr ? newBuffer : nil
    }
}

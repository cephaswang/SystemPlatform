# ScreenRecorder

支援「暫停 / 繼續」的 macOS 螢幕錄影工具，錄製時即時編碼，停止後直接得到 `.mp4`（H.264），不需要額外轉檔。

對應企劃書 v1.0，Phase 1（MVP）原型程式碼。

## 系統需求

- macOS 13 Ventura 以上（ScreenCaptureKit 最低需求）
- Xcode 14 以上

## 專案結構

```
ScreenRecorder/
├── ScreenRecorderApp.swift   # App 進入點 (@main)，管理主視窗（單例）+ 選單列
├── ContentView.swift            # 主視窗：選螢幕/選範圍、開始錄影、查看上次輸出
├── MenuBarContentView.swift     # 選單列（狀態列）選單：暫停/繼續/停止、查看輸出
├── RecorderManager.swift        # 核心錄影邏輯（多螢幕、自訂範圍、暫停位移演算法）
├── RegionSelector.swift         # 自訂範圍選取的拖曳遮罩視窗
├── ScreenOverlays.swift         # 螢幕編號提示 (1/2)、錄影中持續顯示的範圍邊框
├── HotKeyManager.swift          # 全域快捷鍵（開始/暫停/停止/繼續錄影）
└── README.md
```

## 多螢幕 / 自訂錄製範圍

- 開啟 App 時會自動列出目前系統的所有螢幕；若偵測到多台螢幕，主視窗會出現
  「錄製螢幕」下拉選單，可指定要錄哪一台（只有一台螢幕時不會顯示，直接用
  該螢幕）。
- **螢幕編號提示**：偵測到多台螢幕時，會自動在每台螢幕正中央短暫顯示大大
  的數字（1、2…），對應下拉選單裡「螢幕 1」「螢幕 2」的順序，方便對照實體
  上哪一台是哪一台。旁邊也有一個小按鈕（🔢）可以隨時再顯示一次。
- 「錄製範圍」可切換「全螢幕」或「自訂範圍」：
  - 選「自訂範圍」按下「開始錄影」後，主視窗會先隱藏，被選定的那台螢幕
    會出現半透明遮罩，用滑鼠拖曳出想錄製的矩形範圍即可開始錄影
    （範圍太小或按 **Esc** 會取消，回到主視窗）。
  - **錄影期間會持續在該範圍畫一圈紅色邊框**，提醒目前正在錄製的區域；
    這個邊框視窗設定為完全不接收滑鼠事件（click-through），純粹用來顯示，
    不會擋住範圍內或其他地方的任何按鍵、視窗操作。停止錄影後邊框會自動
    消失。
  - 輸出的 MP4 解析度會依所選範圍（或整個螢幕）與該螢幕的 Retina 縮放倍率
    自動計算，不需另外裁切。

## 主視窗只有一個、且永遠在最上層

主視窗（`ScreenRecorderApp.swift` 裡的 `Window("ScreenRecorder", id: "main")`）
是單例視窗場景，不是 `WindowGroup`：不論從選單列「開啟主視窗」、錄影結束自動
回主頁面、或取消自訂範圍選取等任何路徑叫出主視窗，永遠只會有這一個視窗實例
被帶到最前面，不會開出多個重複視窗。

## 錄影期間的操作方式（選單列模式）

按下「開始錄影」後，主視窗會**自動隱藏**，畫面右上角選單列會出現一個圖示
（🔴 錄影中會顯示已錄製時間）。錄影 / 暫停期間的所有操作都改由這裡完成：

- 點選單列圖示 → 選單顯示目前狀態與已錄製時長
- 「暫停」／「繼續」
- 「停止並輸出 MP4」：停止後主視窗會自動重新開啟，並可在視窗或選單列中
  看到剛輸出的檔案
- 「查看上次輸出的影片」：以預設播放器開啟（例如 QuickTime Player）
- 「在 Finder 中顯示」：於 Finder 中選取該檔案
- 「開啟主視窗」：隨時手動叫回主視窗（例如想在錄影中確認一次設定）

主視窗閒置時（尚未開始錄影 / 已停止）也會顯示相同的「播放影片」「在
Finder 顯示」按鈕，方便直接在視窗上查看上一次的輸出結果。

> 關閉主視窗不會結束 App（選單列圖示仍會留著）；要完全結束 App，請從
> 選單列選單點「結束 ScreenRecorder」，或使用 Dock 選單 / Command+Q。

## 全域快捷鍵

不需要切回這個 App、也不用打開選單列選單，隨時按下組合鍵就能控制錄影：

| 動作 | 快捷鍵 |
|---|---|
| 開始錄影 | `⌃⌥⌘R`同時按住 Control + Option + Command，再按 R 鍵 |
| 暫停 | `⌃⌥⌘P` 同時按住 Control + Option + Command，再按 P 鍵 |
| 繼續 | `⌃⌥⌘C` 同時按住 Control + Option + Command，再按 C 鍵 |
| 停止並輸出 MP4 | `⌃⌥⌘S` 同時按住 Control + Option + Command，再按 S 鍵 |

實作方式（`HotKeyManager.swift`）：

- 用 Carbon 的 `RegisterEventHotKey`，不是 `CGEventTap`：不需要「輔助使用」
  或「輸入監控」權限，App Sandbox 底下也能直接使用，不用改 Info.plist
  或 entitlements。
- 選用 `Control + Option + Command` 這種比較少見的組合鍵，降低跟系統或
  其他 App 快捷鍵衝突的機率；若註冊失敗（通常是被佔用），Console 會印出
  `[HotKey] ⚠️ 註冊「...」快捷鍵失敗` 訊息。
- 主視窗與選單列的按鈕、選單項目旁邊都會附上目前對應的快捷鍵文字，方便對照。

**已知限制**：「開始錄影」快捷鍵目前**固定觸發全螢幕錄製**（跟選單列的
「開始錄影」行為一致），因為「自訂範圍」需要用滑鼠拖曳選取矩形範圍，
無法用快捷鍵自動完成——要錄自訂範圍時，請照原本方式從主視窗操作。

## 音訊錄製（系統聲音 + 麥克風）

輸出的 MP4 會包含**一條** AAC 音軌（48kHz 立體聲），裡面混合了兩路聲音：

- **系統聲音（喇叭）**：ScreenCaptureKit 內建擷取，與「螢幕錄製」同一個授權，
  不需要額外權限。已排除本 App 自己發出的聲音。
- **麥克風**：AVCaptureSession 擷取，使用系統目前的預設輸入裝置，
  首次錄影時會跳出麥克風權限請求。

`RecorderManager` 有兩個開關屬性（預設皆為 `true`），介面上可直接綁定：

```swift
Toggle("錄製系統聲音", isOn: $recorder.recordsSystemAudio)
Toggle("錄製麥克風", isOn: $recorder.recordsMicrophone)
```

實作重點（`RecorderManager.swift`）：

- 兩路聲音先各自轉成 48kHz 立體聲 Float32，再依時間戳在 `AudioMixer` 內相加，
  最後只寫入一條音軌（多音軌 MP4 在部分播放器只會播第一軌）。
- 暫停 / 續錄時，聲音與畫面共用同一個 `accumulatedOffset`，音畫維持同步。
- **建議戴耳機錄影**：不戴耳機時，麥克風會收到喇叭播出來的聲音，
  與系統聲音重疊後會有回音。

### 麥克風相關設定（必做）

1. **Info 設定**：Target → Info（或 Build Settings）加入
   `Privacy - Microphone Usage Description`（`NSMicrophoneUsageDescription`），
   內容例如「錄製影片時需要收錄麥克風聲音」。**沒有這一項，存取麥克風時 App 會直接被系統終止。**
2. **Hardened Runtime / App Sandbox**：到 Signing & Capabilities，
   若有啟用 Hardened Runtime，需勾選 **Audio Input**；若有啟用 App Sandbox，
   需在 Hardware 勾選 **Audio Input**。沒勾的話系統不會跳授權視窗，麥克風也收不到聲音。
3. 第一次錄影時按「允許」；若之前按過「不允許」，到
   **系統設定 → 隱私權與安全性 → 麥克風** 開啟本 App。

## 建置步驟

1. 開啟 Xcode，選擇 **File → New → Project → macOS → App**。
   - Interface：SwiftUI
   - Language：Swift
2. 將本資料夾中的三個 `.swift` 檔案拖入專案，取代 Xcode 自動產生的同名檔案。
3. 在 **Signing & Capabilities** 頁籤：
   - 確認 Team 已設定好簽章身分。
   - 若專案預設開啟 App Sandbox，Phase 1 開發階段建議先關閉（或確認可讀寫
     使用者「影片」資料夾），避免除錯時被沙盒權限干擾；正式上架前再依
     企劃書「風險評估」章節處理沙盒下的檔案存取。
4. Command + R 執行。

## 權限設定（首次執行必做）

macOS 會在第一次呼叫 `SCShareableContent` 時，跳出「螢幕錄製」權限請求：

1. 系統會跳出對話框，選擇「打開系統設定」。
2. 於 **系統設定 → 隱私權與安全性 → 螢幕錄製**，找到本 App 並開啟權限。
3. **回到 App 前，需先重新啟動一次 App**（macOS 對螢幕錄製權限的行為如此，
   屬系統限制），才能正常開始擷取畫面。

若略過授權直接按「開始錄影」，`start()` 會擲出錯誤並顯示在畫面下方的錯誤訊息區。

## 輸出位置

錄影完成後，檔案會自動輸出到：

```
~/Movies/ScreenRecorder_yyyyMMdd_HHmmss.mp4
```

停止錄影後，Finder 會自動開啟該資料夾並選取剛輸出的檔案。

## 暫停 / 續錄運作方式

依企劃書技術架構所述，採「時間戳位移演算法」：

- 錄影中收到的每一顆畫面（sample buffer）都會被寫入 `AVAssetWriter`。
- 按下「暫停」後，之後進來的畫面**完全捨棄、不寫入**。
- 按下「繼續」後，會用**恢復後的第一顆畫面時間戳**，計算剛才這段暫停經過
  的時長，累加進 `accumulatedOffset`。
- 之後每一顆畫面在寫入前，presentationTimeStamp 都會扣掉
  `accumulatedOffset`，讓輸出影片的時間軸自動往前接續、暫停區間不留空白
  或凍結畫面。

## 已知限制（Phase 1 範圍）

- 目前僅支援整台顯示器全螢幕擷取，尚未實作「單一視窗 / 自訂區域」
  （企劃書 P2，Phase 3 項目）。
- 選單列常駐模式已支援；全域快捷鍵目前僅支援固定組合鍵（開始/暫停/繼續/
  停止），尚未做「使用者自訂快捷鍵」的設定畫面（企劃書 P2，Phase 4 項目）。
- 目前僅支援單一內接/主顯示器（`content.displays.first`），多螢幕選擇
  介面待後續加入。

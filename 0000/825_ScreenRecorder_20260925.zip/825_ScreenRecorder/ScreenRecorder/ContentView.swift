//
//  ContentView.swift
//  ScreenRecorder
//
//  主視窗介面：選擇要錄製的螢幕（多螢幕時）、選擇全螢幕或自訂範圍，
//  按下「開始錄影」後視窗會自動隱藏，改由選單列（狀態列）顯示狀態並
//  支援暫停 / 停止；錄影結束後視窗會自動重新開啟，並可查看輸出的影片。
//
//  主視窗是 App 層級的 `Window` 單例場景，因此不論從哪裡叫出
//  （選單列「開啟主視窗」、錄影結束自動回主頁面等），畫面上永遠只有一個
//  主視窗，且會被帶到最上層。
//
//  主視窗開啟時會依序檢查權限：
//  1. 螢幕錄製：先用 CGPreflightScreenCaptureAccess() 檢查；若回傳 false，
//     再實際呼叫 SCShareableContent 試探一次（preflight 偶爾會誤判為 false）。
//     試探也失敗 → 觸發系統授權提示，並直接開啟
//     「系統設定 → 隱私權與安全性 → 螢幕錄製」（此時不再往下執行）。
//  2. 麥克風：尚未決定 → 跳出系統授權視窗；已拒絕 / 受限 → 直接開啟
//     「系統設定 → 隱私權與安全性 → 麥克風」。
//
//  除錯：所有權限相關流程都會在 Xcode Console 印出 [Permission] 開頭的訊息，
//  錄影流程則是 [Record] 開頭。
//

import SwiftUI
import AppKit
import AVFoundation
import ScreenCaptureKit

/// 錄製範圍模式
private enum CaptureMode: String, CaseIterable, Identifiable {
    case fullScreen = "全螢幕"
    case customRegion = "自訂範圍"
    var id: String { rawValue }
}

struct ContentView: View {
    @EnvironmentObject private var recorder: RecorderManager
    @Environment(\.dismissWindow) private var dismissWindow
    @Environment(\.openWindow) private var openWindow

    @State private var captureMode: CaptureMode = .fullScreen
    @State private var selectedDisplayIndex: Int = 0
    @State private var isPreparingRegion = false

    /// 每次啟動 App 只檢查一次，避免每次錄影結束回到主視窗時又重複開啟設定頁。
    /// 若希望「每次主視窗出現都檢查」，把 checkMicrophonePermission() 開頭
    /// 的兩行旗標判斷刪除即可。
    private static var didCheckMicrophone = false

    var body: some View {
        VStack(spacing: 20) {

            Text("ScreenRecorder")
                .font(.title2)
                .fontWeight(.semibold)

            statusIndicator

            Text(RecorderManager.formattedTime(recorder.elapsedTime))
                .font(.system(size: 40, weight: .medium, design: .monospaced))
                .foregroundStyle(recorder.state == .idle ? .secondary : .primary)

            if recorder.state == .idle {
                recordingOptions
            }

            controlButtons

            if let error = recorder.lastError {
                Text(error)
                    .font(.caption)
                    .foregroundStyle(.red)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal)
            }

            if let url = recorder.lastOutputURL, recorder.state == .idle {
                outputSection(url: url)
            }

            if recorder.state != .idle {
                Text("錄影中可從選單列圖示（狀態列）暫停或停止")
                    .font(.caption2)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
            }
        }
        .padding(28)
        .frame(width: 360, height: 420)
        .task {
            print("[Permission] ===== 主視窗 .task 開始 =====")

            // 主視窗開啟時：先檢查螢幕錄製權限，沒有權限就開設定頁並停在這裡
            guard await checkScreenRecordingPermission() else {
                print("[Permission] 螢幕錄製權限未通過，停止後續流程")
                return
            }

            // 再檢查麥克風權限
            await checkMicrophonePermission()

            await recorder.loadAvailableDisplays()
            print("[Permission] loadAvailableDisplays 完成：螢幕數=\(recorder.availableDisplays.count)，lastError=\(recorder.lastError ?? "nil")")
            if recorder.availableDisplays.count > 1 {
                ScreenIdentifierOverlay.shared.show(displays: recorder.availableDisplays)
            }
        }
        // 主視窗的隱藏已經改到 RecorderManager.start() 裡處理（用 AppKit 直接
        // 把視窗藏起來、等畫面真的更新掉之後才開始擷取），這樣不管是從這裡的
        // 按鈕、選單列，還是全域快捷鍵觸發錄影，都會套用到同一個保護，
        // 錄出來的影片才不會在最開頭看到主視窗還沒消失的畫面。
    }

    // MARK: - 錄製選項：選螢幕 / 選範圍

    private var recordingOptions: some View {
        VStack(spacing: 12) {
            if recorder.availableDisplays.count > 1 {
                HStack(spacing: 8) {
                    Picker("錄製螢幕", selection: $selectedDisplayIndex) {
                        ForEach(Array(recorder.availableDisplays.enumerated()), id: \.offset) { index, display in
                            Text(displayLabel(display, index: index)).tag(index)
                        }
                    }
                    .pickerStyle(.menu)
                    .labelsHidden()

                    Button {
                        ScreenIdentifierOverlay.shared.show(displays: recorder.availableDisplays)
                    } label: {
                        Image(systemName: "number.circle")
                    }
                    .buttonStyle(.borderless)
                    .help("在各螢幕上顯示編號，對照哪一台是哪一台")
                }
            }

            Picker("錄製範圍", selection: $captureMode) {
                ForEach(CaptureMode.allCases) { mode in
                    Text(mode.rawValue).tag(mode)
                }
            }
            .pickerStyle(.segmented)

            if captureMode == .customRegion {
                Text("按下開始後，在畫面上拖曳出要錄製的範圍")
                    .font(.caption2)
                    .foregroundStyle(.secondary)
            }

            audioSourceOptions
        }
    }

    // MARK: - 錄製聲音來源：麥克風 / 系統聲音（皆可獨立勾選，或都不勾）

    private var audioSourceOptions: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text("錄製聲音來源")
                .font(.caption)
                .foregroundStyle(.secondary)

            HStack(spacing: 20) {
                Toggle("麥克風", isOn: $recorder.recordsMicrophone)
                    .toggleStyle(.checkbox)
                Toggle("系統聲音", isOn: $recorder.recordsSystemAudio)
                    .toggleStyle(.checkbox)
            }

            if !recorder.recordsMicrophone && !recorder.recordsSystemAudio {
                Text("未勾選任何聲音來源，輸出的影片將沒有聲音")
                    .font(.caption2)
                    .foregroundStyle(.orange)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private func displayLabel(_ display: SCDisplay, index: Int) -> String {
        "螢幕 \(index + 1)　\(display.width) × \(display.height)"
    }

    // MARK: - 狀態指示

    private var statusIndicator: some View {
        HStack(spacing: 6) {
            Circle()
                .fill(indicatorColor)
                .frame(width: 10, height: 10)
            Text(statusText)
                .font(.subheadline)
                .foregroundStyle(.secondary)
        }
    }

    private var indicatorColor: Color {
        switch recorder.state {
        case .idle: return .gray
        case .recording: return .red
        case .paused: return .orange
        }
    }

    private var statusText: String {
        switch recorder.state {
        case .idle: return isPreparingRegion ? "選取範圍中…" : "尚未開始"
        case .recording: return "錄影中"
        case .paused: return "已暫停"
        }
    }

    // MARK: - 控制按鈕

    private var controlButtons: some View {
        VStack(spacing: 6) {
            HStack(spacing: 16) {
                switch recorder.state {
                case .idle:
                    Button {
                        Task { await beginRecording() }
                    } label: {
                        Label("開始錄影", systemImage: "record.circle")
                            .frame(minWidth: 120)
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.red)
                    .disabled(isPreparingRegion)

                case .recording:
                    Button {
                        recorder.pause()
                    } label: {
                        Label("暫停", systemImage: "pause.fill")
                            .frame(minWidth: 90)
                    }
                    .buttonStyle(.bordered)

                    Button {
                        Task {
                            await recorder.stop()
                            bringToFront()
                        }
                    } label: {
                        Label("停止", systemImage: "stop.fill")
                            .frame(minWidth: 90)
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.red)

                case .paused:
                    Button {
                        recorder.resume()
                    } label: {
                        Label("繼續", systemImage: "play.fill")
                            .frame(minWidth: 90)
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.green)

                    Button {
                        Task {
                            await recorder.stop()
                            bringToFront()
                        }
                    } label: {
                        Label("停止", systemImage: "stop.fill")
                            .frame(minWidth: 90)
                    }
                    .buttonStyle(.bordered)
                }
            }

            // 全域快捷鍵提示：不論主視窗有沒有打開都能用這幾組鍵操作。
            Text(hotKeyHintText)
                .font(.caption2)
                .foregroundStyle(.secondary)
        }
    }

    /// 依目前狀態，顯示「這個狀態下可以按哪些快捷鍵」的提示文字。
    private var hotKeyHintText: String {
        switch recorder.state {
        case .idle:
            return "全域快捷鍵：開始 \(HotKeyManager.Action.start.displaySymbol)（僅限全螢幕）"
        case .recording:
            return "全域快捷鍵：暫停 \(HotKeyManager.Action.pause.displaySymbol)　停止 \(HotKeyManager.Action.stop.displaySymbol)"
        case .paused:
            return "全域快捷鍵：繼續 \(HotKeyManager.Action.resume.displaySymbol)　停止 \(HotKeyManager.Action.stop.displaySymbol)"
        }
    }

    // MARK: - 開始錄影流程（含自訂範圍選取）

    private func beginRecording() async {
        print("[Record] 按下開始錄影：模式=\(captureMode.rawValue)，selectedDisplayIndex=\(selectedDisplayIndex)，螢幕數=\(recorder.availableDisplays.count)")

        guard recorder.availableDisplays.indices.contains(selectedDisplayIndex) else {
            print("[Record] selectedDisplayIndex 超出範圍，重新載入螢幕清單")
            await recorder.loadAvailableDisplays()
            print("[Record] 重新載入後：螢幕數=\(recorder.availableDisplays.count)，lastError=\(recorder.lastError ?? "nil")")
            return
        }
        let display = recorder.availableDisplays[selectedDisplayIndex]
        print("[Record] 目標螢幕：displayID=\(display.displayID)，\(display.width)x\(display.height)")

        guard captureMode == .customRegion else {
            await recorder.start(display: display, region: nil)
            print("[Record] start(全螢幕) 回傳：state=\(recorder.state)，lastError=\(recorder.lastError ?? "nil")")
            return
        }

        // 自訂範圍：先隱藏主視窗，讓使用者能看到完整畫面拖曳選取
        guard let screen = RecorderManager.nsScreen(for: display.displayID) else {
            recorder.lastError = "找不到對應的螢幕，無法選取範圍"
            return
        }

        isPreparingRegion = true
        dismissWindow()

        let region = await RegionSelector.selectRegion(on: screen)

        isPreparingRegion = false

        guard let region else {
            // 使用者取消選取，回到主頁面
            print("[Record] 使用者取消範圍選取")
            bringToFront()
            return
        }
        print("[Record] 選取範圍：\(region)")
        await recorder.start(display: display, region: region)
        print("[Record] start(自訂範圍) 回傳：state=\(recorder.state)，lastError=\(recorder.lastError ?? "nil")")
    }

    private func bringToFront() {
        openWindow(id: "main")
        NSApp.activate(ignoringOtherApps: true)
    }

    // MARK: - 螢幕錄製權限檢查

    /// 回傳 true 表示可以繼續載入螢幕清單。
    ///
    /// 流程：
    /// 1. CGPreflightScreenCaptureAccess() 回傳 true → 直接通過。
    /// 2. 回傳 false → 不直接相信，實際呼叫 SCShareableContent 試探；
    ///    試探成功代表權限其實可用（preflight 誤判），照常通過。
    /// 3. 試探也失敗 → 觸發系統授權提示、開啟系統設定頁、顯示提示訊息，回傳 false。
    private func checkScreenRecordingPermission() async -> Bool {
        printEnvironmentDebugInfo()

        let preflight = CGPreflightScreenCaptureAccess()
        print("[Permission] CGPreflightScreenCaptureAccess() = \(preflight)")
        if preflight {
            clearPermissionErrorIfNeeded()
            return true
        }

        print("[Permission] preflight 為 false，改用 SCShareableContent 實際試探…")
        if await probeScreenCaptureKit() {
            print("[Permission] 試探成功 → 視為已有權限（preflight 誤判）")
            clearPermissionErrorIfNeeded()
            return true
        }

        // 第一次呼叫會跳出系統授權提示（之後呼叫不會再跳）
        let requested = CGRequestScreenCaptureAccess()
        print("[Permission] CGRequestScreenCaptureAccess() = \(requested)")

        recorder.lastError = "沒有螢幕錄製權限。請到「系統設定 → 隱私權與安全性 → 螢幕錄製」開啟本 App，授權後請重新啟動 App。"
        print("[Permission] 開啟系統設定 → 螢幕錄製")
        openScreenRecordingSettings()
        return false
    }

    /// 直接向 ScreenCaptureKit 要螢幕清單，用來確認權限「實際上」能不能用。
    private func probeScreenCaptureKit() async -> Bool {
        do {
            let content = try await SCShareableContent.excludingDesktopWindows(
                false, onScreenWindowsOnly: true
            )
            print("[Permission] SCShareableContent 成功：displays=\(content.displays.count)，windows=\(content.windows.count)")
            return !content.displays.isEmpty
        } catch {
            let nsError = error as NSError
            print("[Permission] SCShareableContent 失敗：\(error.localizedDescription)")
            print("[Permission]   domain=\(nsError.domain)，code=\(nsError.code)，userInfo=\(nsError.userInfo)")
            return false
        }
    }

    /// 印出目前執行環境，方便判斷是不是「權限記在別的建置版本上」。
    private func printEnvironmentDebugInfo() {
        let bundle = Bundle.main
        print("[Permission] bundleIdentifier = \(bundle.bundleIdentifier ?? "nil")")
        print("[Permission] bundlePath       = \(bundle.bundlePath)")
        print("[Permission] executablePath   = \(bundle.executablePath ?? "nil")")
        print("[Permission] macOS            = \(ProcessInfo.processInfo.operatingSystemVersionString)")
        print("[Permission] PID              = \(ProcessInfo.processInfo.processIdentifier)")
        print("[Permission] 麥克風狀態       = \(Self.describe(AVCaptureDevice.authorizationStatus(for: .audio)))")
    }

    private static func describe(_ status: AVAuthorizationStatus) -> String {
        switch status {
        case .notDetermined: return "notDetermined"
        case .restricted: return "restricted"
        case .denied: return "denied"
        case .authorized: return "authorized"
        @unknown default: return "unknown(\(status.rawValue))"
        }
    }

    /// 權限已通過時，清掉先前留下的「沒有螢幕錄製權限」紅字。
    private func clearPermissionErrorIfNeeded() {
        if recorder.lastError?.hasPrefix("沒有螢幕錄製權限") == true {
            recorder.lastError = nil
        }
    }

    private func openScreenRecordingSettings() {
        if let url = URL(string: "x-apple.systempreferences:com.apple.preference.security?Privacy_ScreenCapture") {
            NSWorkspace.shared.open(url)
        }
    }

    // MARK: - 麥克風權限檢查

    private func checkMicrophonePermission() async {
        // 每次啟動 App 只檢查一次（想每次開視窗都檢查，刪掉這兩行）
        guard !Self.didCheckMicrophone else {
            print("[Permission] 麥克風：本次啟動已檢查過，略過")
            return
        }
        Self.didCheckMicrophone = true

        let status = AVCaptureDevice.authorizationStatus(for: .audio)
        print("[Permission] 麥克風狀態 = \(Self.describe(status))")

        switch status {
        case .authorized:
            return
        case .notDetermined:
            // 第一次：先跳出系統授權視窗，拒絕才開設定頁
            let granted = await AVCaptureDevice.requestAccess(for: .audio)
            print("[Permission] 麥克風 requestAccess 結果 = \(granted)")
            if !granted { openMicrophoneSettings() }
        case .denied, .restricted:
            // 沒有權限：這次只會錄系統聲音，直接開啟設定頁讓使用者授權
            print("[Permission] 麥克風被拒絕 / 受限，開啟系統設定 → 麥克風")
            openMicrophoneSettings()
        @unknown default:
            break
        }
    }

    private func openMicrophoneSettings() {
        if let url = URL(string: "x-apple.systempreferences:com.apple.preference.security?Privacy_Microphone") {
            NSWorkspace.shared.open(url)
        }
    }

    // MARK: - 查看輸出檔案

    private func outputSection(url: URL) -> some View {
        VStack(spacing: 8) {
            Text("已輸出：\(url.lastPathComponent)")
                .font(.caption)
                .foregroundStyle(.secondary)
                .lineLimit(1)
                .truncationMode(.middle)

            HStack(spacing: 12) {
                Button("播放影片") {
                    NSWorkspace.shared.open(url)
                }
                Button("在 Finder 顯示") {
                    NSWorkspace.shared.activateFileViewerSelecting([url])
                }
            }
            .font(.caption)
        }
    }
}

#Preview {
    ContentView()
        .environmentObject(RecorderManager())
}

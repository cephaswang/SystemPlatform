//
//  RegionSelector.swift
//  ScreenRecorder
//
//  自訂錄製範圍：在指定螢幕上顯示一個全螢幕的半透明遮罩，
//  讓使用者拖曳出想要錄製的矩形範圍。按 Esc 或拖出的範圍過小則視為取消。
//

import AppKit

enum RegionSelector {
    /// 選取流程進行中，保留住 controller 的強參照。
    ///
    /// 這是關鍵修正：先前 `controller` 只是 `selectRegion()` 裡的區域變數，
    /// `show()` 一回傳，沒有任何東西再保留它，ARC 會立刻把它釋放掉；
    /// 而 `RegionSelectorView.onFinish` / `onCancel` 用的是 `[weak self]`，
    /// 並不會保留它。結果就是視窗雖然還在畫面上、滑鼠事件也還收得到，
    /// 但 `self` 已經是 nil，`self?.finish(...)` 變成 no-op，
    /// `completion` 永遠不會被呼叫，continuation 永遠不會 resume，
    /// `await selectRegion(on:)` 就永遠卡住（Xcode 會印出
    /// "leaked its continuation" 就是在講這件事）。
    /// 用這個 static 屬性從 `show()` 呼叫前保留到 `finish()` 呼叫後釋放，
    /// 就能確保整個流程走完之前 controller 都活著。
    @MainActor
    private static var activeController: RegionSelectorWindowController?

    /// 顯示選取畫面，回傳使用者選取的矩形（該螢幕座標系統、單位為點、原點在左上角）。
    /// 使用者取消（Esc 或範圍過小）時回傳 nil。
    @MainActor
    static func selectRegion(on screen: NSScreen) async -> CGRect? {
        print("[Region] selectRegion() 開始，screen.frame=\(screen.frame)")
        let result = await withCheckedContinuation { (continuation: CheckedContinuation<CGRect?, Never>) in
            let controller = RegionSelectorWindowController(screen: screen) { rect in
                print("[Region] continuation 即將 resume，rect=\(String(describing: rect))")
                RegionSelector.activeController = nil // 流程結束，釋放強參照
                continuation.resume(returning: rect)
            }
            RegionSelector.activeController = controller // 保留強參照，直到上面的 completion 被呼叫
            controller.show()
        }
        print("[Region] selectRegion() 回傳：\(String(describing: result))")
        return result
    }
}

/// AppKit 對 `styleMask: [.borderless]` 的視窗，預設 `canBecomeKeyWindow`
/// 會回傳 `false`（Console 會看到 "returned NO from -[NSWindow
/// canBecomeKeyWindow]" 這個警告）。滑鼠事件不受影響，但**鍵盤事件永遠不會
/// 送到這個視窗**，導致「按 Esc 取消」這個功能實際上完全沒有作用。
/// override 這兩個方法回傳 true，讓這個遮罩視窗可以正常成為 key window。
private final class RegionSelectorOverlayWindow: NSWindow {
    override var canBecomeKey: Bool { true }
    override var canBecomeMain: Bool { true }
}

@MainActor
private final class RegionSelectorWindowController: NSObject {
    private var window: NSWindow?
    private let screen: NSScreen
    private let completion: (CGRect?) -> Void

    init(screen: NSScreen, completion: @escaping (CGRect?) -> Void) {
        self.screen = screen
        self.completion = completion
    }

    func show() {
        print("[Region] show() 開始建立遮罩視窗，screen.frame=\(screen.frame)")
        let window = RegionSelectorOverlayWindow(
            contentRect: screen.frame,
            styleMask: [.borderless],
            backing: .buffered,
            defer: false,
            screen: screen
        )
        window.level = .screenSaver
        window.isOpaque = false
        window.backgroundColor = .clear
        window.hasShadow = false
        window.ignoresMouseEvents = false
        window.collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary]

        let view = RegionSelectorView(frame: NSRect(origin: .zero, size: screen.frame.size))
        view.onFinish = { [weak self] localRect in
            print("[Region] view.onFinish 被呼叫，localRect=\(localRect)")
            self?.finish(localRect: localRect)
        }
        view.onCancel = { [weak self] in
            print("[Region] view.onCancel 被呼叫")
            self?.finish(localRect: nil)
        }
        window.contentView = view
        self.window = window

        print("[Region] 呼叫 NSApp.activate(ignoringOtherApps: true)")
        NSApp.activate(ignoringOtherApps: true)
        print("[Region] 呼叫 window.makeKeyAndOrderFront(nil)")
        window.makeKeyAndOrderFront(nil)

        // makeKeyAndOrderFront 之後，key window / first responder 狀態不一定會
        // 立刻反映出來；用非同步方式印出，確認遮罩視窗最後有沒有真的搶到
        // 滑鼠事件該有的狀態。如果這裡印出 isKeyWindow=false 或
        // isFirstResponder=false，代表滑鼠事件很可能根本沒有送到這個視窗，
        // 也就是為什麼拖曳/放開滑鼠後完全沒反應。
        DispatchQueue.main.async { [weak window, weak view] in
            let isKey = window?.isKeyWindow ?? false
            let isVisible = window?.isVisible ?? false
            let isFirstResponder = (window?.firstResponder === view)
            print("[Region] 視窗狀態檢查：isKeyWindow=\(isKey)，isVisible=\(isVisible)，view是否為firstResponder=\(isFirstResponder)")
        }
    }

    private func finish(localRect: CGRect?) {
        print("[Region] finish() 被呼叫，localRect=\(String(describing: localRect))")
        window?.orderOut(nil)
        window = nil

        guard let localRect else {
            print("[Region] 使用者取消（Esc 或範圍過小），回傳 nil 給 completion")
            completion(nil)
            return
        }

        // localRect 是 AppKit 視窗座標（左下角為原點）；
        // ScreenCaptureKit 的 sourceRect 使用左上角為原點，這裡做 Y 軸翻轉。
        let flipped = CGRect(
            x: localRect.origin.x,
            y: screen.frame.height - localRect.origin.y - localRect.height,
            width: localRect.width,
            height: localRect.height
        )
        print("[Region] Y 軸翻轉完成，flipped=\(flipped)，即將呼叫 completion")
        completion(flipped)
    }
}

/// 負責畫出半透明遮罩、拖曳選取框、顯示尺寸、Esc 取消
private final class RegionSelectorView: NSView {
    var onFinish: ((CGRect) -> Void)?
    var onCancel: (() -> Void)?

    private var startPoint: NSPoint?
    private var currentRect: NSRect = .zero
    private var hasLoggedDragStart = false

    override var acceptsFirstResponder: Bool { true }

    override func draw(_ dirtyRect: NSRect) {
        guard let context = NSGraphicsContext.current else { return }

        NSColor.black.withAlphaComponent(0.35).setFill()
        bounds.fill()

        guard currentRect.width > 0, currentRect.height > 0 else { return }

        // 挖空選取範圍，讓使用者看清楚實際會錄到的畫面
        context.compositingOperation = .clear
        currentRect.fill()
        context.compositingOperation = .sourceOver

        NSColor.systemBlue.setStroke()
        let border = NSBezierPath(rect: currentRect)
        border.lineWidth = 2
        border.stroke()

        let sizeText = "\(Int(currentRect.width)) × \(Int(currentRect.height))"
        let attrs: [NSAttributedString.Key: Any] = [
            .font: NSFont.systemFont(ofSize: 12, weight: .medium),
            .foregroundColor: NSColor.white
        ]
        let origin = NSPoint(x: currentRect.minX, y: min(currentRect.maxY + 6, bounds.maxY - 16))
        sizeText.draw(at: origin, withAttributes: attrs)
    }

    override func mouseDown(with event: NSEvent) {
        startPoint = convert(event.locationInWindow, from: nil)
        currentRect = .zero
        hasLoggedDragStart = false
        print("[Region] mouseDown，startPoint=\(startPoint!)")
        needsDisplay = true
    }

    override func mouseDragged(with event: NSEvent) {
        guard let start = startPoint else {
            print("[Region] ⚠️ mouseDragged 收到事件，但 startPoint 是 nil（代表沒收到 mouseDown）")
            return
        }
        if !hasLoggedDragStart {
            print("[Region] 收到第一個 mouseDragged 事件，開始拖曳")
            hasLoggedDragStart = true
        }
        let current = convert(event.locationInWindow, from: nil)
        currentRect = NSRect(
            x: min(start.x, current.x),
            y: min(start.y, current.y),
            width: abs(current.x - start.x),
            height: abs(current.y - start.y)
        )
        needsDisplay = true
    }

    override func mouseUp(with event: NSEvent) {
        print("[Region] mouseUp，currentRect=\(currentRect)")
        guard currentRect.width > 4, currentRect.height > 4 else {
            print("[Region] 範圍寬高其中一邊 <= 4pt，視為取消，呼叫 onCancel")
            onCancel?()
            return
        }
        print("[Region] 範圍有效，呼叫 onFinish")
        onFinish?(currentRect)
    }

    override func keyDown(with event: NSEvent) {
        if event.keyCode == 53 { // Esc
            print("[Region] keyDown 偵測到 Esc，呼叫 onCancel")
            onCancel?()
        } else {
            super.keyDown(with: event)
        }
    }

    override func viewDidMoveToWindow() {
        super.viewDidMoveToWindow()
        let becameFirstResponder = window?.makeFirstResponder(self) ?? false
        print("[Region] viewDidMoveToWindow，window=\(String(describing: window))，makeFirstResponder 結果=\(becameFirstResponder)")
    }
}

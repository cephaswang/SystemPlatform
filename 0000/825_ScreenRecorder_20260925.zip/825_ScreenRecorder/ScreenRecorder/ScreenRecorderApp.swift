//
//  ScreenRecorderApp.swift
//  ScreenRecorder  (org.share35app.ScreenRecorder)
//
//  App 進入點。
//  - recorder 由 App 層級持有並以 environmentObject 分享給主視窗與選單列選單，
//    這樣視窗被隱藏、只剩選單列時，狀態不會遺失。
//  - 主視窗用 `Window`（單例視窗場景）而非 `WindowGroup`：
//    不論呼叫幾次 openWindow(id: "main")，畫面上都只會有一個主視窗，
//    不會開出多個重複視窗。
//  - 選單列（MenuBarExtra）：錄影中／暫停中顯示狀態與控制項，
//    讓使用者不需要開著視窗也能暫停、繼續、停止錄影。
//  - hotKeyManager（HotKeyManager.swift）：全域快捷鍵，讓使用者不用切回
//    這個 App、也不用打開選單列選單，就能開始/暫停/繼續/停止錄影。
//    「開始錄影」的快捷鍵固定錄製全螢幕（跟選單列的「開始錄影」行為一致），
//    自訂範圍需要滑鼠拖曳選取，無法用快捷鍵觸發，仍請從主視窗操作。
//  - Help 選單「ScreenRecorder Help」：呼叫 HelpCenter（HelpCenter.swift）
//    把內建的 helpdocs.zip 解壓縮到暫存區，並用預設瀏覽器開啟 helpdoc.html。
//

import SwiftUI

@main
struct ScreenRecorderApp: App {
    @StateObject private var recorder = RecorderManager()
    private let hotKeyManager = HotKeyManager()

    var body: some Scene {
        Window("ScreenRecorder", id: "main") {
            ContentView()
                .environmentObject(recorder)
                .task { registerHotKeysIfNeeded() }
        }
        .windowResizability(.contentSize)
        .defaultSize(width: 340, height: 380)
        .commands {
            CommandGroup(replacing: .newItem) { } // 單一視窗，移除「新增視窗」選項

            CommandGroup(replacing: .help) {
                Button("ScreenRecorder Help") {
                    HelpCenter.shared.openHelp()
                }
            }
        }

        MenuBarExtra {
            MenuBarContentView()
                .environmentObject(recorder)
        } label: {
            Label {
                if recorder.state != .idle {
                    Text(RecorderManager.formattedTime(recorder.elapsedTime))
                }
            } icon: {
                Image(systemName: menuBarIconName)
            }
        }
        .menuBarExtraStyle(.menu)
    }

    private var menuBarIconName: String {
        switch recorder.state {
        case .idle: return "record.circle"
        case .recording: return "record.circle.fill"
        case .paused: return "pause.circle.fill"
        }
    }

    // MARK: - 全域快捷鍵

    /// `.task` 會在主視窗第一次出現時執行一次；`registerAll` 內部本來就是
    /// 「先解除舊註冊、再重新註冊」，所以就算主視窗被關掉又重新打開，
    /// 這裡被多呼叫幾次也不會註冊出重複的快捷鍵。
    private func registerHotKeysIfNeeded() {
        hotKeyManager.registerAll(
            onStart: {
                guard recorder.state == .idle else { return }
                Task { await recorder.start() }
            },
            onPause: {
                recorder.pause()
            },
            onStop: {
                guard recorder.state != .idle else { return }
                Task { await recorder.stop() }
            },
            onResume: {
                recorder.resume()
            }
        )
    }
}

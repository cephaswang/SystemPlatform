//
//  ScreenOverlays.swift
//  ScreenRecorder
//
//  兩個輔助用的 AppKit 覆蓋層：
//  1. ScreenIdentifierOverlay：在各螢幕正中央短暫顯示編號（1、2…），
//     對應「錄製螢幕」下拉選單的順序，方便使用者對照哪台是哪台。
//  2. RecordingRegionIndicator：自訂範圍錄影期間，持續在該範圍畫一圈邊框，
//     提醒目前正在錄製的區域。這個視窗會設定 ignoresMouseEvents = true，
//     只負責顯示、完全不吃滑鼠事件，底下（包含範圍內）的任何按鍵、視窗
//     都能正常點擊，不會被「蓋住」。
//

import AppKit
import ScreenCaptureKit

// MARK: - 螢幕編號提示（1、2…）

@MainActor
final class ScreenIdentifierOverlay {
    static let shared = ScreenIdentifierOverlay()
    private var windows: [NSWindow] = []
    private var dismissWorkItem: DispatchWorkItem?

    private init() {}

    /// 在每台螢幕中央短暫顯示編號，數字與 `displays` 的順序（index + 1）一致。
    func show(displays: [SCDisplay], duration: TimeInterval = 1.6) {
        dismiss()

        for (index, display) in displays.enumerated() {
            guard let screen = RecorderManager.nsScreen(for: display.displayID) else { continue }
            let window = Self.makeWindow(number: index + 1, screen: screen)
            window.orderFrontRegardless()
            windows.append(window)
        }

        let workItem = DispatchWorkItem { [weak self] in self?.dismiss() }
        dismissWorkItem = workItem
        DispatchQueue.main.asyncAfter(deadline: .now() + duration, execute: workItem)
    }

    func dismiss() {
        dismissWorkItem?.cancel()
        dismissWorkItem = nil
        windows.forEach { $0.orderOut(nil) }
        windows.removeAll()
    }

    private static func makeWindow(number: Int, screen: NSScreen) -> NSWindow {
        let window = NSWindow(
            contentRect: screen.frame,
            styleMask: [.borderless],
            backing: .buffered,
            defer: false,
            screen: screen
        )
        window.level = .screenSaver
        window.isOpaque = false
        window.backgroundColor = .clear
        window.hasShadow = false
        window.ignoresMouseEvents = true // 只顯示、不吃掉滑鼠事件
        window.collectionBehavior = [.canJoinAllSpaces, .stationary, .fullScreenAuxiliary]

        let badgeSize: CGFloat = 160
        let badge = NSView(frame: NSRect(
            x: (screen.frame.width - badgeSize) / 2,
            y: (screen.frame.height - badgeSize) / 2,
            width: badgeSize,
            height: badgeSize
        ))
        badge.wantsLayer = true
        badge.layer?.backgroundColor = NSColor.black.withAlphaComponent(0.65).cgColor
        badge.layer?.cornerRadius = 20

        let label = NSTextField(labelWithString: "\(number)")
        label.font = .systemFont(ofSize: 84, weight: .bold)
        label.textColor = .white
        label.alignment = .center
        label.isBezeled = false
        label.isEditable = false
        label.drawsBackground = false
        label.frame = badge.bounds
        badge.addSubview(label)

        let container = NSView(frame: NSRect(origin: .zero, size: screen.frame.size))
        container.addSubview(badge)
        window.contentView = container
        return window
    }
}

// MARK: - 錄影中持續顯示的自訂範圍邊框

@MainActor
final class RecordingRegionIndicator {
    private var window: NSWindow?

    /// 顯示邊框。`region` 為該螢幕座標系統下的矩形（左上角為原點，與
    /// ScreenCaptureKit 的 sourceRect 一致），內部會轉換成 AppKit 座標。
    func show(screen: NSScreen, region: CGRect) {
        hide()

        let window = NSWindow(
            contentRect: screen.frame,
            styleMask: [.borderless],
            backing: .buffered,
            defer: false,
            screen: screen
        )
        window.level = .statusBar
        window.isOpaque = false
        window.backgroundColor = .clear
        window.hasShadow = false
        window.ignoresMouseEvents = true // 關鍵：完全不攔截滑鼠事件，不遮蔽任何操作
        window.collectionBehavior = [.canJoinAllSpaces, .stationary, .fullScreenAuxiliary]

        let flippedRect = CGRect(
            x: region.origin.x,
            y: screen.frame.height - region.origin.y - region.height,
            width: region.width,
            height: region.height
        )

        let borderView = RegionBorderView(frame: NSRect(origin: .zero, size: screen.frame.size))
        borderView.regionRect = flippedRect
        window.contentView = borderView
        window.orderFrontRegardless()

        self.window = window
    }

    func hide() {
        window?.orderOut(nil)
        window = nil
    }
}

/// 只畫邊框、背景完全透明，且不接收任何滑鼠事件
private final class RegionBorderView: NSView {
    var regionRect: CGRect = .zero {
        didSet { needsDisplay = true }
    }

    // 保險起見再覆寫一次，確保這個 view 本身也不會攔截 hit-test
    override func hitTest(_ point: NSPoint) -> NSView? { nil }

    override func draw(_ dirtyRect: NSRect) {
        guard regionRect.width > 0, regionRect.height > 0 else { return }
        NSColor.systemRed.setStroke()
        let path = NSBezierPath(rect: regionRect.insetBy(dx: -1.5, dy: -1.5))
        path.lineWidth = 3
        path.stroke()
    }
}

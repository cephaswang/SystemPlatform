#!/bin/bash
# generate_csr.sh
# 用途：產生私鑰 (.key) 與 CSR (.certSigningRequest)，供 Apple Developer 網站上傳申請憑證

EMAIL="cephaswangtw@yahoo.com.tw"
COMMON_NAME="Cephas Wang"      # 改成你的姓名或公司名稱
COUNTRY="TW"
KEY_FILE="CertificateSigningRequest.key"
CSR_FILE="CertificateSigningRequest.certSigningRequest"

# 1. 產生 2048-bit RSA 私鑰
openssl genrsa -out "$KEY_FILE" 2048

# 2. 用私鑰產生 CSR
openssl req -new -key "$KEY_FILE" -out "$CSR_FILE" \
  -subj "/emailAddress=${EMAIL}/CN=${COMMON_NAME}/C=${COUNTRY}"

echo "完成！"
echo "私鑰檔案（請妥善保存，之後匯入憑證要用）: $KEY_FILE"
echo "CSR 檔案（上傳到 Apple Developer 網站）: $CSR_FILE"

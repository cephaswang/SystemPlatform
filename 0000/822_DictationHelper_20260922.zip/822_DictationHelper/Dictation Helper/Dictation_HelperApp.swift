import SwiftUI

extension Notification.Name {
    static let showHelpWindow = Notification.Name("showHelpWindow")
}

@main
struct Dictation_HelperApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
        .windowResizability(.contentSize)
        .commands {
            // 這是單一用途的工具，不支援多視窗同時聽寫（會搶佔同一個麥克風輸入），
            // 直接把「開新視窗」選項拿掉，避免使用者不小心開出第二個視窗
            CommandGroup(replacing: .newItem) { }

            CommandGroup(replacing: .help) {
                Button("聽抄小幫手 使用說明") {
                    NotificationCenter.default.post(name: .showHelpWindow, object: nil)
                }
                .keyboardShortcut("?", modifiers: [.command])

                Divider()

                Button("聯絡支援：share35app@gmail.com") {
                    let subject = "聽抄小幫手 - 使用問題".addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
                    if let url = URL(string: "mailto:share35app@gmail.com?subject=\(subject)") {
                        NSWorkspace.shared.open(url)
                    }
                }
            }
        }
    }
}

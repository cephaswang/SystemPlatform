import Foundation

enum PrerequisiteChecker {

    // BlackHole 2ch 驅動程式的標準安裝路徑（不論透過 Homebrew 或官方 .pkg 安裝，都會裝在這裡）
    private static let blackHoleDriverPath = "/Library/Audio/Plug-Ins/HAL/BlackHole2ch.driver"

    // 直接檢查驅動程式檔案是否存在於磁碟。
    // 之所以不用「查詢目前系統音訊裝置清單」的方式判斷，是因為 coreaudiod
    // 有時候會快取舊的裝置清單：驅動程式檔案已經被刪除，但在還沒重開機／
    // 重啟 coreaudiod 之前，裝置清單可能仍然「看得到」已移除的裝置，
    // 導致誤判成「還在安裝」。直接檢查檔案系統上的實際檔案，才能反映
    // 當下最真實的安裝狀態。
    static func isBlackHoleInstalled() -> Bool {
        FileManager.default.fileExists(atPath: blackHoleDriverPath)
    }

    // 把內嵌的安裝腳本寫到桌面；如果桌面因權限問題（TCC）寫入失敗，
    // 自動改寫到「文件」資料夾（App 本來就能正常存取逐字稿的地方），
    // 確保功能不會因為使用者還沒授權桌面存取而整個失效。
    // 回傳實際寫入後的檔案路徑；兩個位置都失敗才回傳 nil
    @discardableResult
    static func copySetupScriptToDesktop() -> URL? {
        let candidateDirectories: [URL] = [
            FileManager.default.urls(for: .desktopDirectory, in: .userDomainMask).first,
            FileManager.default.urls(for: .downloadsDirectory, in: .userDomainMask).first,
            FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first
        ].compactMap { $0 }

        for directory in candidateDirectories {
            let destinationURL = directory.appendingPathComponent(SetupScript.fileName)
            do {
                if FileManager.default.fileExists(atPath: destinationURL.path) {
                    try FileManager.default.removeItem(at: destinationURL)
                }

                try SetupScript.content.write(to: destinationURL, atomically: true, encoding: .utf8)

                // 設定為可執行檔（等同 chmod +x）
                try FileManager.default.setAttributes(
                    [.posixPermissions: 0o755],
                    ofItemAtPath: destinationURL.path
                )

                print("✅ 安裝腳本已寫入「\(directory.lastPathComponent)」：\(destinationURL.path)")
                return destinationURL
            } catch {
                print("⚠️ 寫入「\(directory.lastPathComponent)」失敗：\(error.localizedDescription)，嘗試下一個位置")
                continue
            }
        }

        print("❌ 複製安裝腳本失敗：桌面、下載、文件資料夾皆無法寫入")
        return nil
    }
}

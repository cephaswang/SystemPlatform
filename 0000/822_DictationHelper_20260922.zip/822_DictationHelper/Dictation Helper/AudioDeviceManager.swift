import Foundation
import CoreAudio
import Combine

struct AudioDeviceInfo: Identifiable, Hashable {
    let id: AudioDeviceID
    let name: String
}

final class AudioDeviceManager: ObservableObject {

    @Published var inputDevices: [AudioDeviceInfo] = []
    @Published var currentInputDeviceID: AudioDeviceID?

    init() {
        refreshDevices()
    }

    func refreshDevices() {
        inputDevices = Self.fetchInputDevices()
        currentInputDeviceID = Self.getDefaultInputDevice()
    }

    // 列舉系統中所有具備輸入聲道的音訊裝置
    static func fetchInputDevices() -> [AudioDeviceInfo] {
        var propertySize: UInt32 = 0
        var address = AudioObjectPropertyAddress(
            mSelector: kAudioHardwarePropertyDevices,
            mScope: kAudioObjectPropertyScopeGlobal,
            mElement: kAudioObjectPropertyElementMain)

        AudioObjectGetPropertyDataSize(AudioObjectID(kAudioObjectSystemObject), &address, 0, nil, &propertySize)
        let deviceCount = Int(propertySize) / MemoryLayout<AudioDeviceID>.size
        guard deviceCount > 0 else { return [] }

        var deviceIDs = [AudioDeviceID](repeating: 0, count: deviceCount)
        AudioObjectGetPropertyData(AudioObjectID(kAudioObjectSystemObject), &address, 0, nil, &propertySize, &deviceIDs)

        var result: [AudioDeviceInfo] = []

        for deviceID in deviceIDs {
            var inputAddress = AudioObjectPropertyAddress(
                mSelector: kAudioDevicePropertyStreamConfiguration,
                mScope: kAudioObjectPropertyScopeInput,
                mElement: kAudioObjectPropertyElementMain)

            var streamSize: UInt32 = 0
            AudioObjectGetPropertyDataSize(deviceID, &inputAddress, 0, nil, &streamSize)
            guard streamSize > 0 else { continue }

            let bufferListPointer = UnsafeMutablePointer<AudioBufferList>.allocate(
                capacity: Int(streamSize))
            defer { bufferListPointer.deallocate() }

            AudioObjectGetPropertyData(deviceID, &inputAddress, 0, nil, &streamSize, bufferListPointer)
            let bufferList = UnsafeMutableAudioBufferListPointer(bufferListPointer)
            let channelCount = bufferList.reduce(0) { $0 + Int($1.mNumberChannels) }
            guard channelCount > 0 else { continue } // 沒有輸入聲道，跳過（純輸出裝置）

            var nameAddress = AudioObjectPropertyAddress(
                mSelector: kAudioObjectPropertyName,
                mScope: kAudioObjectPropertyScopeGlobal,
                mElement: kAudioObjectPropertyElementMain)

            var name: Unmanaged<CFString>?
            var nameSize = UInt32(MemoryLayout<Unmanaged<CFString>?>.size)
            let status = withUnsafeMutablePointer(to: &name) { ptr -> OSStatus in
                AudioObjectGetPropertyData(deviceID, &nameAddress, 0, nil, &nameSize, ptr)
            }

            let deviceName: String
            if status == noErr, let cfName = name?.takeRetainedValue() {
                deviceName = cfName as String
            } else {
                deviceName = "裝置 #\(deviceID)"
            }

            result.append(AudioDeviceInfo(id: deviceID, name: deviceName))
        }

        return result
    }

    // 取得目前系統預設輸入裝置
    static func getDefaultInputDevice() -> AudioDeviceID? {
        var deviceID = AudioDeviceID(0)
        var size = UInt32(MemoryLayout<AudioDeviceID>.size)
        var address = AudioObjectPropertyAddress(
            mSelector: kAudioHardwarePropertyDefaultInputDevice,
            mScope: kAudioObjectPropertyScopeGlobal,
            mElement: kAudioObjectPropertyElementMain)

        let status = AudioObjectGetPropertyData(
            AudioObjectID(kAudioObjectSystemObject), &address, 0, nil, &size, &deviceID)

        return status == noErr ? deviceID : nil
    }

    // 設定系統預設輸入裝置（等同命令列版本的 SwitchAudioSource -t input）
    func setDefaultInputDevice(_ deviceID: AudioDeviceID) {
        var mutableID = deviceID
        var address = AudioObjectPropertyAddress(
            mSelector: kAudioHardwarePropertyDefaultInputDevice,
            mScope: kAudioObjectPropertyScopeGlobal,
            mElement: kAudioObjectPropertyElementMain)

        let status = AudioObjectSetPropertyData(
            AudioObjectID(kAudioObjectSystemObject),
            &address, 0, nil,
            UInt32(MemoryLayout<AudioDeviceID>.size),
            &mutableID)

        if status == noErr {
            currentInputDeviceID = deviceID
        }
    }
}

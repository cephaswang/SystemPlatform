#!/bin/bash
#
# uninstall.sh - 移除「聽抄小幫手」與相關安裝的外掛/工具
#
# 這支腳本會嘗試移除：
#   1. BlackHole 2ch 虛擬音訊裝置
#   2. App 本身（如果已安裝在 /Applications）
#   3. App 儲存的偏好設定（語系選擇、雙語模式等）
#
# 無法自動移除、需要手動處理的部分（腳本結束時會列出）：
#   - Audio MIDI 設定裡建立的 Multi-Output Device
#     （這是系統層級的音訊路由設定，沒有官方公開指令可移除，需手動點）
#
# 使用方式：
#   chmod +x uninstall.sh
#   ./uninstall.sh
#

APP_NAME="Dictation Helper"
APP_PATH="/Applications/${APP_NAME}.app"

echo "===================================================="
echo " 聽抄小幫手 - 移除腳本"
echo "===================================================="
echo ""
echo "這支腳本會嘗試移除："
echo "  1. BlackHole 2ch 虛擬音訊裝置"
echo "  2. App 本身（如果安裝在 /Applications）"
echo "  3. App 儲存的偏好設定"
echo ""
echo "無法自動處理、需要你手動操作的部分："
echo "  - Audio MIDI 設定裡建立的 Multi-Output Device"
echo ""
read -p "確定要繼續嗎？(y/N) " confirm
if [[ "$confirm" != "y" && "$confirm" != "Y" ]]; then
    echo "已取消，未做任何變更"
    exit 0
fi

# ---------- 1. 移除 BlackHole 2ch ----------
echo ""
echo "🔍 檢查 BlackHole 2ch 安裝方式..."

REMOVED_DRIVER=false

if command -v brew >/dev/null 2>&1 && brew list --cask blackhole-2ch >/dev/null 2>&1; then
    echo "⚙️  偵測到透過 Homebrew 安裝，執行 brew uninstall..."
    brew uninstall --cask blackhole-2ch
    echo "✅ 已透過 Homebrew 移除 BlackHole 2ch"
    REMOVED_DRIVER=true
elif [ -d "/Library/Audio/Plug-Ins/HAL/BlackHole2ch.driver" ]; then
    echo "⚙️  偵測到 BlackHole 驅動程式檔案（非 Homebrew 安裝），需要系統管理員權限移除"
    sudo rm -rf "/Library/Audio/Plug-Ins/HAL/BlackHole2ch.driver"
    echo "✅ 已移除 BlackHole 驅動程式檔案"
    REMOVED_DRIVER=true
else
    echo "ℹ️  未偵測到 BlackHole 2ch，略過此步驟"
fi

if [ "$REMOVED_DRIVER" = true ]; then
    echo "🔄 重新啟動 coreaudiod，讓系統重新整理音訊裝置清單..."
    sudo killall coreaudiod 2>/dev/null || true
    echo "✅ 已重新啟動（原本正在播放的聲音可能會短暫中斷一下，屬正常現象）"
fi

# ---------- 2. 移除 App 本身 ----------
echo ""
if [ -d "$APP_PATH" ]; then
    read -p "偵測到「$APP_NAME」安裝在 /Applications，是否移除？(y/N) " remove_app
    if [[ "$remove_app" == "y" || "$remove_app" == "Y" ]]; then
        rm -rf "$APP_PATH"
        echo "✅ 已移除 $APP_PATH"
    else
        echo "ℹ️  略過移除 App 本身"
    fi
else
    echo "ℹ️  未在 /Applications 找到「$APP_NAME」（可能是直接從 Xcode 執行、尚未安裝到此處），略過"
fi

# ---------- 3. 移除偏好設定 ----------
echo ""
echo "🔍 尋找 App 的 Bundle Identifier..."
BUNDLE_ID=""
if [ -d "$APP_PATH" ]; then
    BUNDLE_ID=$(mdls -name kMDItemCFBundleIdentifier -raw "$APP_PATH" 2>/dev/null)
fi

if [ -n "$BUNDLE_ID" ] && [ "$BUNDLE_ID" != "(null)" ]; then
    echo "找到 Bundle Identifier：$BUNDLE_ID"
    read -p "是否清除這個 App 儲存的偏好設定（語系選擇、雙語模式等）？(y/N) " remove_prefs
    if [[ "$remove_prefs" == "y" || "$remove_prefs" == "Y" ]]; then
        defaults delete "$BUNDLE_ID" 2>/dev/null && echo "✅ 已清除偏好設定" || echo "ℹ️  沒有找到對應的偏好設定（可能本來就是空的）"
    fi
else
    echo "⚠️  找不到 Bundle Identifier（App 可能已經被移除，或還沒安裝到 /Applications 過）"
    echo "   如果你知道確切的 Bundle ID，可以自行手動執行："
    echo "   defaults delete <你的 Bundle ID>"
fi

# ---------- 結尾：列出需要手動處理的部分 ----------
echo ""
echo "===================================================="
echo " 以下步驟需要手動操作："
echo "===================================================="
cat << 'EOF'

[1] 移除 Multi-Output Device
    - 開啟「Audio MIDI 設定」（Spotlight 搜尋 Audio MIDI Setup）
    - 左側清單找到「Multi-Output Device」
    - 選取後按左下角「-」（減號）移除
    - 或直接對它按右鍵 → Remove Device

[2] 如果移除 BlackHole 後，系統設定「聲音」的輸出/輸入清單
    還殘留舊項目沒消失，重新開機一次即可清除乾淨

EOF

echo "===================================================="
echo " 移除腳本執行完畢"
echo "===================================================="

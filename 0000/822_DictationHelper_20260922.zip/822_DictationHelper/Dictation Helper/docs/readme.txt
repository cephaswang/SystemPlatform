brew uninstall --cask blackhole-2ch --force
brew install --cask blackhole-2ch

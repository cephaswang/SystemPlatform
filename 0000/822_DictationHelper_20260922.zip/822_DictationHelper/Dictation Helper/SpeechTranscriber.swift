import Foundation
import AVFoundation
import Speech
import Combine

final class SpeechTranscriber: ObservableObject {

    // 單語模式使用的即時顯示；雙語模式請看 liveTextA / liveTextB
    @Published var liveText: String = ""
    @Published var liveTextA: String = ""
    @Published var liveTextB: String = ""

    @Published var savedSentences: [String] = []
    @Published var isRunning: Bool = false
    @Published var statusMessage: String = ""
    @Published var outputFileURL: URL?
    @Published var isBilingualMode: Bool = false

    private let audioEngine = AVAudioEngine()

    // 單語模式
    private var recognizer: SFSpeechRecognizer?
    private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?
    private var recognitionTask: SFSpeechRecognitionTask?
    private var latestText: String = ""

    // 雙語模式：A、B 兩個引擎同時處理同一份音訊
    private var recognizerA: SFSpeechRecognizer?
    private var recognizerB: SFSpeechRecognizer?
    private var requestA: SFSpeechAudioBufferRecognitionRequest?
    private var requestB: SFSpeechAudioBufferRecognitionRequest?
    private var taskA: SFSpeechRecognitionTask?
    private var taskB: SFSpeechRecognitionTask?
    private var latestTextA: String = ""
    private var latestTextB: String = ""

    // 雙語模式：等待另一邊也 final，再比較信心值擇優寫入
    private struct PendingCandidate {
        let text: String
        let confidence: Float
        let isTrackA: Bool // 記錄這個候選來自哪一路，避免同一路的兩句話被誤判成互相競爭
    }
    private var pendingCandidate: PendingCandidate?
    private var pendingTimer: Timer?
    private let pendingWindow: TimeInterval = 1.2 // 等待另一邊 final 的最長時間（秒）

    private var outputFileHandle: FileHandle?
    private var pendingOutputDirectory: URL?

    // 用來過濾「上一次」工作結束時姍姍來遲的殘留回報（例如按停止後又立刻按開始）
    private var currentSessionID = UUID()

    // MARK: - 開始聽抄（單語模式）

    func start(localeIdentifier: String, outputDirectory: URL) {
        guard !isRunning else { return }
        let sessionID = prepareNewSession(outputDirectory: outputDirectory)
        isBilingualMode = false

        guard let recognizer = SFSpeechRecognizer(locale: Locale(identifier: localeIdentifier)),
              recognizer.isAvailable else {
            statusMessage = "❌ 無法使用語系「\(localeIdentifier)」的語音辨識"
            return
        }
        self.recognizer = recognizer

        requestPermissions { [weak self] granted in
            guard let self = self else { return }
            DispatchQueue.main.async {
                guard self.currentSessionID == sessionID else { return }
                if granted {
                    self.beginSingleRecognition(sessionID: sessionID)
                } else {
                    self.statusMessage = "❌ 麥克風或語音辨識權限被拒絕，請至「系統設定 > 隱私權與安全性」開啟"
                }
            }
        }
    }

    // MARK: - 開始聽抄（雙語模式：同時辨識兩種語言，自動選信心較高者）

    func startBilingual(localeA: String, localeB: String, outputDirectory: URL) {
        guard !isRunning else { return }
        let sessionID = prepareNewSession(outputDirectory: outputDirectory)
        isBilingualMode = true

        guard let recA = SFSpeechRecognizer(locale: Locale(identifier: localeA)), recA.isAvailable,
              let recB = SFSpeechRecognizer(locale: Locale(identifier: localeB)), recB.isAvailable else {
            statusMessage = "❌ 無法使用語系「\(localeA)」或「\(localeB)」的語音辨識"
            return
        }
        self.recognizerA = recA
        self.recognizerB = recB

        requestPermissions { [weak self] granted in
            guard let self = self else { return }
            DispatchQueue.main.async {
                guard self.currentSessionID == sessionID else { return }
                if granted {
                    self.beginBilingualRecognition(sessionID: sessionID)
                } else {
                    self.statusMessage = "❌ 麥克風或語音辨識權限被拒絕，請至「系統設定 > 隱私權與安全性」開啟"
                }
            }
        }
    }

    // MARK: - 共用：準備新的一輪聽抄

    @discardableResult
    private func prepareNewSession(outputDirectory: URL) -> UUID {
        statusMessage = ""
        liveText = ""
        liveTextA = ""
        liveTextB = ""
        savedSentences = []

        pendingOutputDirectory = outputDirectory
        outputFileURL = nil
        outputFileHandle = nil

        pendingCandidate = nil
        pendingTimer?.invalidate()
        pendingTimer = nil

        latestText = ""
        latestTextA = ""
        latestTextB = ""

        let sessionID = UUID()
        currentSessionID = sessionID
        return sessionID
    }

    private func requestPermissions(completion: @escaping (Bool) -> Void) {
        SFSpeechRecognizer.requestAuthorization { status in
            guard status == .authorized else {
                completion(false)
                return
            }
            AVCaptureDevice.requestAccess(for: .audio) { granted in
                completion(granted)
            }
        }
    }

    // MARK: - 單語模式實作

    private func beginSingleRecognition(sessionID: UUID) {
        let request = SFSpeechAudioBufferRecognitionRequest()
        request.shouldReportPartialResults = true
        recognitionRequest = request

        let inputNode = audioEngine.inputNode
        let format = inputNode.outputFormat(forBus: 0)

        inputNode.installTap(onBus: 0, bufferSize: 1024, format: format) { [weak self] buffer, _ in
            self?.recognitionRequest?.append(buffer)
        }

        audioEngine.prepare()
        do {
            try audioEngine.start()
            isRunning = true
        } catch {
            statusMessage = "❌ 音訊引擎啟動失敗：\(error.localizedDescription)"
            return
        }

        recognitionTask = recognizer?.recognitionTask(with: request) { [weak self] result, error in
            guard let self = self else { return }
            guard self.currentSessionID == sessionID else { return }

            if let result = result {
                let text = result.bestTranscription.formattedString
                self.latestText = text
                DispatchQueue.main.async {
                    guard self.currentSessionID == sessionID else { return }
                    self.liveText = text
                }

                if result.isFinal {
                    self.appendToFile(text)
                    self.latestText = ""
                }
            }

            if let error = error {
                let nsError = error as NSError
                let isBenign = nsError.code == 1110 || !self.isRunning
                if !isBenign {
                    DispatchQueue.main.async {
                        guard self.currentSessionID == sessionID else { return }
                        self.statusMessage = "⚠️ 辨識問題：\(error.localizedDescription)"
                    }
                }
            }
        }
    }

    // MARK: - 雙語模式實作

    private func beginBilingualRecognition(sessionID: UUID) {
        let reqA = SFSpeechAudioBufferRecognitionRequest()
        reqA.shouldReportPartialResults = true
        let reqB = SFSpeechAudioBufferRecognitionRequest()
        reqB.shouldReportPartialResults = true
        requestA = reqA
        requestB = reqB

        let inputNode = audioEngine.inputNode
        let format = inputNode.outputFormat(forBus: 0)

        // 同一份音訊同時餵給兩個辨識引擎：兩個 request 是各自獨立、非同步處理音訊的，
        // 直接把「同一個」AVAudioPCMBuffer 參考丟給兩邊，容易在其中一路還沒讀完時
        // 就被另一路或下一次 tap 回呼覆寫／釋放，導致其中一路（甚至兩路）拿到損毀的音訊，
        // 這正是先前雙語辨識結果會出現大量語意不連貫亂碼的主因之一。
        // 修法：其中一路用原始 buffer，另一路用「複製」出來的獨立 buffer。
        inputNode.installTap(onBus: 0, bufferSize: 1024, format: format) { [weak self] buffer, _ in
            guard let self = self else { return }
            self.requestA?.append(buffer)
            if let bufferCopy = self.duplicate(buffer) {
                self.requestB?.append(bufferCopy)
            } else {
                // 極少數情況複製失敗時，寧可讓 B 這次少聽一段，也不要冒著共用 buffer 的風險
                self.requestB?.append(buffer)
            }
        }

        audioEngine.prepare()
        do {
            try audioEngine.start()
            isRunning = true
        } catch {
            statusMessage = "❌ 音訊引擎啟動失敗：\(error.localizedDescription)"
            return
        }

        taskA = recognizerA?.recognitionTask(with: reqA) { [weak self] result, error in
            self?.handleBilingualResult(result: result, error: error, isTrackA: true, sessionID: sessionID)
        }
        taskB = recognizerB?.recognitionTask(with: reqB) { [weak self] result, error in
            self?.handleBilingualResult(result: result, error: error, isTrackA: false, sessionID: sessionID)
        }
    }

    // 深層複製一份 AVAudioPCMBuffer，讓兩個獨立的辨識 request 各自擁有互不干擾的音訊資料
    private func duplicate(_ buffer: AVAudioPCMBuffer) -> AVAudioPCMBuffer? {
        guard let copy = AVAudioPCMBuffer(pcmFormat: buffer.format, frameCapacity: buffer.frameCapacity) else {
            return nil
        }
        copy.frameLength = buffer.frameLength
        let channelCount = Int(buffer.format.channelCount)
        let frameLength = Int(buffer.frameLength)
        guard frameLength > 0 else { return copy }

        if let src = buffer.floatChannelData, let dst = copy.floatChannelData {
            for ch in 0..<channelCount {
                dst[ch].update(from: src[ch], count: frameLength)
            }
        } else if let src = buffer.int16ChannelData, let dst = copy.int16ChannelData {
            for ch in 0..<channelCount {
                dst[ch].update(from: src[ch], count: frameLength)
            }
        } else if let src = buffer.int32ChannelData, let dst = copy.int32ChannelData {
            for ch in 0..<channelCount {
                dst[ch].update(from: src[ch], count: frameLength)
            }
        } else {
            return nil // 未知的取樣格式，交由呼叫端決定退回原本的做法
        }
        return copy
    }

    private func handleBilingualResult(result: SFSpeechRecognitionResult?, error: Error?, isTrackA: Bool, sessionID: UUID) {
        guard currentSessionID == sessionID else { return }

        if let result = result {
            let text = result.bestTranscription.formattedString

            if isTrackA { latestTextA = text } else { latestTextB = text }

            DispatchQueue.main.async {
                guard self.currentSessionID == sessionID else { return }
                if isTrackA {
                    self.liveTextA = text
                } else {
                    self.liveTextB = text
                }
            }

            if result.isFinal {
                let segments = result.bestTranscription.segments
                let confidence: Float = segments.isEmpty
                    ? 0
                    : segments.map { $0.confidence }.reduce(0, +) / Float(segments.count)

                if isTrackA { latestTextA = "" } else { latestTextB = "" }
                DispatchQueue.main.async {
                    guard self.currentSessionID == sessionID else { return }
                    if isTrackA { self.liveTextA = "" } else { self.liveTextB = "" }
                }

                handleFinalCandidate(text: text, confidence: confidence, isTrackA: isTrackA, sessionID: sessionID)
            }
        }

        if let error = error {
            let nsError = error as NSError
            let isBenign = nsError.code == 1110 || !self.isRunning
            if !isBenign {
                DispatchQueue.main.async {
                    guard self.currentSessionID == sessionID else { return }
                    self.statusMessage = "⚠️ 辨識問題（\(isTrackA ? "語言 A" : "語言 B")）：\(error.localizedDescription)"
                }
            }
        }
    }

    // 判斷某個語系「應該」以中日韓文字為主（用來在信心值不可靠時，當作次要判斷依據）
    private func expectsCJKScript(localeIdentifier: String) -> Bool {
        let lower = localeIdentifier.lowercased()
        return lower.hasPrefix("zh") || lower.hasPrefix("ja") || lower.hasPrefix("ko")
    }

    // 計算一段文字裡「符合預期文字系統」的比例（0~1）。用來輔助判斷：
    // 中文引擎聽到英文語音時，常會硬湊出一串看起來「有信心」但語意不通的文字，
    // 這種輔助分數可以在 confidence 打平（例如裝置端辨識常固定回傳 0）時提供額外依據。
    private func scriptConsistencyScore(_ text: String, expectCJK: Bool) -> Double {
        let scalars = text.unicodeScalars.filter { !CharacterSet.whitespacesAndNewlines.contains($0) && !CharacterSet.punctuationCharacters.contains($0) }
        guard !scalars.isEmpty else { return 0 }
        let cjkCount = scalars.filter { (0x4E00...0x9FFF).contains($0.value) || (0x3400...0x4DBF).contains($0.value) }.count
        let ratio = Double(cjkCount) / Double(scalars.count)
        return expectCJK ? ratio : (1 - ratio)
    }

    // 在兩個候選之間擇優：優先看信心值（差距明顯時直接採信）；
    // 差距不明顯或雙方都是 0（常見於裝置端辨識）時，改用文字系統一致性分數輔助判斷。
    private func pickWinner(_ a: PendingCandidate, _ b: PendingCandidate) -> String {
        let confidenceGap = abs(a.confidence - b.confidence)
        if confidenceGap > 0.05 {
            return a.confidence >= b.confidence ? a.text : b.text
        }

        let aLocale = a.isTrackA ? recognizerA?.locale.identifier : recognizerB?.locale.identifier
        let bLocale = b.isTrackA ? recognizerA?.locale.identifier : recognizerB?.locale.identifier
        let aScore = scriptConsistencyScore(a.text, expectCJK: expectsCJKScript(localeIdentifier: aLocale ?? ""))
        let bScore = scriptConsistencyScore(b.text, expectCJK: expectsCJKScript(localeIdentifier: bLocale ?? ""))

        if aScore == bScore {
            // 真的分不出高下時，維持原本「信心值較高者優先」的行為
            return a.confidence >= b.confidence ? a.text : b.text
        }
        return aScore > bScore ? a.text : b.text
    }

    // 收到任一語言的 final 結果時呼叫：限時等待「另一邊」也 final，比較後擇優寫入。
    // 注意：只會拿 A 的候選跟 B 的候選配對比較，同一路連續兩句話絕不會被拿來互相競爭。
    private func handleFinalCandidate(text: String, confidence: Float, isTrackA: Bool, sessionID: UUID) {
        guard !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return }
        let newCandidate = PendingCandidate(text: text, confidence: confidence, isTrackA: isTrackA)

        DispatchQueue.main.async { [weak self] in
            guard let self = self, self.currentSessionID == sessionID else { return }

            if let existing = self.pendingCandidate {
                if existing.isTrackA == isTrackA {
                    // 同一路又搶先送來下一句：代表上一句其實沒等到對方，先把上一句寫入，
                    // 再讓這一句重新排隊等待對方，避免同一路的兩句話被誤判成互相競爭。
                    self.pendingTimer?.invalidate()
                    self.pendingTimer = nil
                    self.appendToFile(existing.text)
                    self.pendingCandidate = nil
                    self.schedulePending(newCandidate, sessionID: sessionID)
                } else {
                    // 兩路各自的候選都到齊了，正式擇優寫入
                    self.pendingTimer?.invalidate()
                    self.pendingTimer = nil
                    self.pendingCandidate = nil
                    self.appendToFile(self.pickWinner(existing, newCandidate))
                }
            } else {
                self.schedulePending(newCandidate, sessionID: sessionID)
            }
        }
    }

    // 把候選存起來，限時等待另一路的對應候選；逾時就直接採用目前手上這個
    private func schedulePending(_ candidate: PendingCandidate, sessionID: UUID) {
        pendingCandidate = candidate
        pendingTimer = Timer.scheduledTimer(withTimeInterval: pendingWindow, repeats: false) { [weak self] _ in
            guard let self = self, self.currentSessionID == sessionID else { return }
            if let pending = self.pendingCandidate {
                self.appendToFile(pending.text)
                self.pendingCandidate = nil
            }
            self.pendingTimer = nil
        }
    }

    // MARK: - 停止聽抄

    func stop() {
        guard isRunning else { return }

        // 讓任何稍後才送達的回呼都被視為「舊工作」而被忽略
        currentSessionID = UUID()

        audioEngine.stop()
        audioEngine.inputNode.removeTap(onBus: 0)

        // 單語模式收尾
        recognitionRequest?.endAudio()
        recognitionTask?.cancel()
        recognitionRequest = nil
        recognitionTask = nil

        // 雙語模式收尾
        requestA?.endAudio()
        requestB?.endAudio()
        taskA?.cancel()
        taskB?.cancel()
        requestA = nil
        requestB = nil
        taskA = nil
        taskB = nil

        pendingTimer?.invalidate()
        pendingTimer = nil

        // 不管有沒有等到官方判定的 isFinal，只要還有內容就強制寫入，避免遺失
        if isBilingualMode {
            if let candidate = pendingCandidate {
                appendToFile(candidate.text)
                pendingCandidate = nil
            } else if !latestTextA.isEmpty || !latestTextB.isEmpty {
                // 兩邊都還沒 final，沒有信心值可比較時，權宜選字數較多的那邊
                let fallback = latestTextA.count >= latestTextB.count ? latestTextA : latestTextB
                if !fallback.isEmpty {
                    appendToFile(fallback)
                }
            }
            latestTextA = ""
            latestTextB = ""
        } else {
            if !latestText.isEmpty {
                appendToFile(latestText)
                latestText = ""
            }
        }

        outputFileHandle?.closeFile()
        isRunning = false
    }

    // MARK: - 自動斷句寫檔（單語 / 雙語共用）

    private func appendToFile(_ text: String) {
        guard !text.isEmpty else { return }

        let now = Date() // 用同一個 Date 產生檔名與時間戳記，確保兩者完全一致

        // 延遲建檔：第一句話真正要寫入時才建立檔案，檔名時間 = 這句話的時間
        if outputFileHandle == nil {
            guard let directory = pendingOutputDirectory else { return }
            let fileNameFormatter = DateFormatter()
            fileNameFormatter.dateFormat = "yyyy-MM-dd_HHmmss"
            let fileName = "transcript_\(fileNameFormatter.string(from: now)).txt"
            let fileURL = directory.appendingPathComponent(fileName)
            FileManager.default.createFile(atPath: fileURL.path, contents: nil)
            outputFileHandle = try? FileHandle(forWritingTo: fileURL)
            DispatchQueue.main.async {
                self.outputFileURL = fileURL
            }
        }

        let timeFormatter = DateFormatter()
        timeFormatter.dateFormat = "HH:mm:ss"
        let timePrefix = timeFormatter.string(from: now)

        func isSentenceEnder(_ ch: Character) -> Bool {
            return "。！？.!?".contains(ch)
        }

        var sentences: [String] = []
        var current = ""
        for ch in text {
            current.append(ch)
            if isSentenceEnder(ch) {
                let trimmed = current.trimmingCharacters(in: .whitespacesAndNewlines)
                if !trimmed.isEmpty { sentences.append(trimmed) }
                current = ""
            }
        }
        let remaining = current.trimmingCharacters(in: .whitespacesAndNewlines)
        if !remaining.isEmpty { sentences.append(remaining) }
        if sentences.isEmpty {
            sentences = [text.trimmingCharacters(in: .whitespacesAndNewlines)]
        }

        var fileOutput = ""
        for sentence in sentences where !sentence.isEmpty {
            let line = "[\(timePrefix)] \(sentence)"
            fileOutput += line + "\n"
            DispatchQueue.main.async {
                self.savedSentences.append(line)
            }
        }
        fileOutput += "\n" // 每次寫入之間加空行區隔

        if let data = fileOutput.data(using: .utf8) {
            outputFileHandle?.seekToEndOfFile()
            outputFileHandle?.write(data)
        }
    }
}

import Foundation

// 內嵌 setup.sh 的完整內容，讓 App 可以在偵測到前置軟體缺失時，
// 直接把這份腳本寫到使用者桌面，不需要額外的 Bundle Resource 設定步驟。
enum SetupScript {
    static let fileName = "setup.sh"

    static let content = """
    #!/bin/bash
    #
    # setup.sh - 「聽抄小幫手」App 前置軟體安裝腳本
    #
    # 這支腳本會自動安裝：
    #   1. Homebrew（若尚未安裝）
    #   2. BlackHole 2ch（虛擬音訊裝置，用來把喇叭聲音導入語音辨識）
    #
    # 使用方式：
    #   chmod +x setup.sh
    #   ./setup.sh
    #

    set -e

    echo "===================================================="
    echo " 聽抄小幫手 - 前置軟體安裝"
    echo "===================================================="
    echo ""

    # ---------- 1. 檢查 / 安裝 Homebrew ----------
    if command -v brew >/dev/null 2>&1; then
        echo "✅ 已安裝 Homebrew：$(brew --version | head -n 1)"
    else
        echo "⚙️  尚未安裝 Homebrew，開始安裝..."
        /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

        if [ -f "/opt/homebrew/bin/brew" ]; then
            echo 'eval "$(/opt/homebrew/bin/brew shellenv)"' >> "$HOME/.zprofile"
            eval "$(/opt/homebrew/bin/brew shellenv)"
        fi

        echo "✅ Homebrew 安裝完成"
    fi
    echo ""

    # ---------- 2. 檢查 / 安裝 BlackHole 2ch ----------
    echo "🔍 檢查 BlackHole 2ch 是否已安裝..."
    if system_profiler SPAudioDataType 2>/dev/null | grep -q "BlackHole 2ch"; then
        echo "✅ 系統已偵測到 BlackHole 2ch 裝置"
    elif brew list --cask blackhole-2ch >/dev/null 2>&1; then
        echo "✅ Homebrew 顯示 blackhole-2ch 已安裝（可能需要重新開機或重新登入才會出現在音訊裝置清單）"
    else
        echo "⚙️  尚未安裝 BlackHole 2ch，開始安裝..."
        brew install blackhole-2ch
        echo "✅ BlackHole 2ch 安裝完成"
        echo "⚠️  安裝驅動程式後，建議「登出再登入」或「重新開機」，虛擬音訊裝置才會正確出現"
    fi
    echo ""

    echo "===================================================="
    echo " 自動安裝部分已完成，以下步驟需要手動操作："
    echo "===================================================="
    cat << 'EOF'

    [1] 建立 Multi-Output Device（讓你聽得到聲音，同時能被辨識）
        - 開啟「Audio MIDI 設定」（Spotlight 搜尋 Audio MIDI Setup）
        - 左下角「+」→「建立多重輸出裝置」
        - 勾選：你的實體喇叭/耳機 ＋ BlackHole 2ch
        - 在 BlackHole 2ch 那一列勾選「Drift Correction」

    [2] 開啟系統聽抄功能（Speech Framework 依賴此開關）
        - 系統設定 → 鍵盤 → 聽抄 → 開啟
        - 確認語言清單有你要用的語言，必要時下載語音套件

    [3] 完成以上設定後，重新開啟本 App

    EOF

    echo "===================================================="
    echo " 安裝腳本執行完畢"
    echo "===================================================="
    """
}

#!/bin/bash
#
# setup.sh -「喇叭聽寫小幫手」使用者安裝腳本
#
# 適用對象：一般使用者（已經拿到編譯好的 App，只需要準備好周邊環境）
#
# 這支腳本會自動：
#   1. 安裝 BlackHole 2ch（虛擬音訊裝置，用來把喇叭聲音導入語音辨識）
#      → 直接下載官方預先編譯好的安裝檔（.pkg），不需要 Homebrew，不需要編譯
#
# 無法自動化、需要你手動做的部分（腳本結束時會再提醒一次）：
#   - 在「Audio MIDI 設定」建立 Multi-Output Device
#     （這一步涉及圖形介面操作，沒有官方公開指令可自動建立，需手動點）
#   - 設定 > 鍵盤 > 聽寫，開啟系統聽寫功能
#
# 使用方式：
#   chmod +x setup.sh
#   ./setup.sh
#

set -e

BLACKHOLE_PKG_URL_API="https://api.github.com/repos/ExistentialAudio/BlackHole/releases/latest"
TMP_PKG="/tmp/BlackHole2ch.pkg"

echo "===================================================="
echo " 喇叭聽寫小幫手 - 使用前準備"
echo "===================================================="
echo ""

# ---------- 檢查作業系統 ----------
if [[ "$(uname)" != "Darwin" ]]; then
    echo "❌ 這支腳本只能在 macOS 上執行"
    exit 1
fi

# ---------- 安裝 BlackHole 2ch ----------
echo "🔍 檢查 BlackHole 2ch 音訊裝置..."

if system_profiler SPAudioDataType 2>/dev/null | grep -q "BlackHole 2ch"; then
    echo "✅ 系統已偵測到 BlackHole 2ch，略過安裝"
else
    echo "⚙️  尚未偵測到 BlackHole 2ch，開始下載官方安裝檔..."

    # 從 GitHub 最新發行版動態取得 .pkg 下載連結，避免版本寫死過時
    PKG_URL="$(curl -fsSL "$BLACKHOLE_PKG_URL_API" | grep '"browser_download_url"' | grep '2ch.*\.pkg' | head -n 1 | sed -E 's/.*"([^"]+)".*/\1/')"

    if [ -z "$PKG_URL" ]; then
        echo "❌ 無法自動取得下載連結，請手動前往以下網址下載並安裝："
        echo "   https://github.com/ExistentialAudio/BlackHole/releases"
        exit 1
    fi

    echo "⬇️  下載中：$PKG_URL"
    curl -fsSL "$PKG_URL" -o "$TMP_PKG"

    echo "🔐 安裝需要系統管理員權限，接下來會要求輸入電腦密碼..."
    sudo installer -pkg "$TMP_PKG" -target /

    rm -f "$TMP_PKG"
    echo "✅ BlackHole 2ch 安裝完成"
fi
echo ""

# ---------- 驗證安裝結果 ----------
echo "🔍 驗證安裝結果..."

if [ -d "/Library/Audio/Plug-Ins/HAL" ] && ls "/Library/Audio/Plug-Ins/HAL" 2>/dev/null | grep -qi blackhole; then
    echo "✅ 驅動檔案確認：/Library/Audio/Plug-Ins/HAL 內已有 BlackHole 相關檔案"
else
    echo "⚠️  尚未看到驅動檔案，可能需要重新開機才會生效"
fi

if system_profiler SPAudioDataType 2>/dev/null | grep -q "BlackHole 2ch"; then
    echo "✅ 系統已偵測到 BlackHole 2ch 裝置"
else
    echo "⚠️  系統音訊清單尚未偵測到裝置，請「登出再登入」或「重新開機」後再檢查一次"
fi
echo ""

echo "===================================================="
echo " 自動安裝部分已完成，以下步驟需要手動操作："
echo "===================================================="
cat << 'EOF'

[1] 建立 Multi-Output Device（讓你聽得到聲音，同時能被辨識）
    - 開啟「Audio MIDI 設定」（Spotlight 搜尋 Audio MIDI Setup）
    - 左下角「+」→「建立多重輸出裝置」
    - 勾選：你的實體喇叭/耳機 ＋ BlackHole 2ch
    - 在 BlackHole 2ch 那一列勾選「Drift Correction」

[2] 開啟系統聽寫功能（App 依賴此開關）
    - 系統設定 → 鍵盤 → 聽寫 → 開啟
    - 確認語言清單有你要用的語言，必要時下載語音套件

[3] 開啟「喇叭聽寫小幫手」App，在介面中：
    - 「輸入裝置」選單選擇 BlackHole 2ch
    - 「語系」選單選擇要用的語言
    - 按「開始聽寫」

若步驟 [1] 完成後，App 的「輸入裝置」選單仍看不到 BlackHole 2ch，
請先重新開機一次，再重新開啟 App。

EOF

echo "===================================================="
echo " 安裝腳本執行完畢"
echo "===================================================="

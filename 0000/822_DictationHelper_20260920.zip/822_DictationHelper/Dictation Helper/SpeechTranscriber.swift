import Foundation
import AVFoundation
import Speech
import Combine

final class SpeechTranscriber: ObservableObject {

    // 單語模式使用的即時顯示；雙語模式請看 liveTextA / liveTextB
    @Published var liveText: String = ""
    @Published var liveTextA: String = ""
    @Published var liveTextB: String = ""

    @Published var savedSentences: [String] = []
    @Published var isRunning: Bool = false
    @Published var statusMessage: String = ""
    @Published var outputFileURL: URL?
    @Published var isBilingualMode: Bool = false

    private let audioEngine = AVAudioEngine()

    // 單語模式
    private var recognizer: SFSpeechRecognizer?
    private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?
    private var recognitionTask: SFSpeechRecognitionTask?
    private var latestText: String = ""

    // 雙語模式：A、B 兩個引擎同時處理同一份音訊
    private var recognizerA: SFSpeechRecognizer?
    private var recognizerB: SFSpeechRecognizer?
    private var requestA: SFSpeechAudioBufferRecognitionRequest?
    private var requestB: SFSpeechAudioBufferRecognitionRequest?
    private var taskA: SFSpeechRecognitionTask?
    private var taskB: SFSpeechRecognitionTask?
    private var latestTextA: String = ""
    private var latestTextB: String = ""

    // 雙語模式：等待另一邊也 final，再比較信心值擇優寫入
    private struct PendingCandidate {
        let text: String
        let confidence: Float
    }
    private var pendingCandidate: PendingCandidate?
    private var pendingTimer: Timer?
    private let pendingWindow: TimeInterval = 1.2 // 等待另一邊 final 的最長時間（秒）

    private var outputFileHandle: FileHandle?
    private var pendingOutputDirectory: URL?

    // 用來過濾「上一次」工作結束時姍姍來遲的殘留回報（例如按停止後又立刻按開始）
    private var currentSessionID = UUID()

    // MARK: - 開始聽寫（單語模式）

    func start(localeIdentifier: String, outputDirectory: URL) {
        guard !isRunning else { return }
        let sessionID = prepareNewSession(outputDirectory: outputDirectory)
        isBilingualMode = false

        guard let recognizer = SFSpeechRecognizer(locale: Locale(identifier: localeIdentifier)),
              recognizer.isAvailable else {
            statusMessage = "❌ 無法使用語系「\(localeIdentifier)」的語音辨識"
            return
        }
        self.recognizer = recognizer

        requestPermissions { [weak self] granted in
            guard let self = self else { return }
            DispatchQueue.main.async {
                guard self.currentSessionID == sessionID else { return }
                if granted {
                    self.beginSingleRecognition(sessionID: sessionID)
                } else {
                    self.statusMessage = "❌ 麥克風或語音辨識權限被拒絕，請至「系統設定 > 隱私權與安全性」開啟"
                }
            }
        }
    }

    // MARK: - 開始聽寫（雙語模式：同時辨識兩種語言，自動選信心較高者）

    func startBilingual(localeA: String, localeB: String, outputDirectory: URL) {
        guard !isRunning else { return }
        let sessionID = prepareNewSession(outputDirectory: outputDirectory)
        isBilingualMode = true

        guard let recA = SFSpeechRecognizer(locale: Locale(identifier: localeA)), recA.isAvailable,
              let recB = SFSpeechRecognizer(locale: Locale(identifier: localeB)), recB.isAvailable else {
            statusMessage = "❌ 無法使用語系「\(localeA)」或「\(localeB)」的語音辨識"
            return
        }
        self.recognizerA = recA
        self.recognizerB = recB

        requestPermissions { [weak self] granted in
            guard let self = self else { return }
            DispatchQueue.main.async {
                guard self.currentSessionID == sessionID else { return }
                if granted {
                    self.beginBilingualRecognition(sessionID: sessionID)
                } else {
                    self.statusMessage = "❌ 麥克風或語音辨識權限被拒絕，請至「系統設定 > 隱私權與安全性」開啟"
                }
            }
        }
    }

    // MARK: - 共用：準備新的一輪聽寫

    @discardableResult
    private func prepareNewSession(outputDirectory: URL) -> UUID {
        statusMessage = ""
        liveText = ""
        liveTextA = ""
        liveTextB = ""
        savedSentences = []

        pendingOutputDirectory = outputDirectory
        outputFileURL = nil
        outputFileHandle = nil

        pendingCandidate = nil
        pendingTimer?.invalidate()
        pendingTimer = nil

        latestText = ""
        latestTextA = ""
        latestTextB = ""

        let sessionID = UUID()
        currentSessionID = sessionID
        return sessionID
    }

    private func requestPermissions(completion: @escaping (Bool) -> Void) {
        SFSpeechRecognizer.requestAuthorization { status in
            guard status == .authorized else {
                completion(false)
                return
            }
            AVCaptureDevice.requestAccess(for: .audio) { granted in
                completion(granted)
            }
        }
    }

    // MARK: - 單語模式實作

    private func beginSingleRecognition(sessionID: UUID) {
        let request = SFSpeechAudioBufferRecognitionRequest()
        request.shouldReportPartialResults = true
        recognitionRequest = request

        let inputNode = audioEngine.inputNode
        let format = inputNode.outputFormat(forBus: 0)

        inputNode.installTap(onBus: 0, bufferSize: 1024, format: format) { [weak self] buffer, _ in
            self?.recognitionRequest?.append(buffer)
        }

        audioEngine.prepare()
        do {
            try audioEngine.start()
            isRunning = true
        } catch {
            statusMessage = "❌ 音訊引擎啟動失敗：\(error.localizedDescription)"
            return
        }

        recognitionTask = recognizer?.recognitionTask(with: request) { [weak self] result, error in
            guard let self = self else { return }
            guard self.currentSessionID == sessionID else { return }

            if let result = result {
                let text = result.bestTranscription.formattedString
                self.latestText = text
                DispatchQueue.main.async {
                    guard self.currentSessionID == sessionID else { return }
                    self.liveText = text
                }

                if result.isFinal {
                    self.appendToFile(text)
                    self.latestText = ""
                }
            }

            if let error = error {
                let nsError = error as NSError
                let isBenign = nsError.code == 1110 || !self.isRunning
                if !isBenign {
                    DispatchQueue.main.async {
                        guard self.currentSessionID == sessionID else { return }
                        self.statusMessage = "⚠️ 辨識問題：\(error.localizedDescription)"
                    }
                }
            }
        }
    }

    // MARK: - 雙語模式實作

    private func beginBilingualRecognition(sessionID: UUID) {
        let reqA = SFSpeechAudioBufferRecognitionRequest()
        reqA.shouldReportPartialResults = true
        let reqB = SFSpeechAudioBufferRecognitionRequest()
        reqB.shouldReportPartialResults = true
        requestA = reqA
        requestB = reqB

        let inputNode = audioEngine.inputNode
        let format = inputNode.outputFormat(forBus: 0)

        // 同一份音訊 buffer 同時餵給兩個辨識引擎
        inputNode.installTap(onBus: 0, bufferSize: 1024, format: format) { [weak self] buffer, _ in
            self?.requestA?.append(buffer)
            self?.requestB?.append(buffer)
        }

        audioEngine.prepare()
        do {
            try audioEngine.start()
            isRunning = true
        } catch {
            statusMessage = "❌ 音訊引擎啟動失敗：\(error.localizedDescription)"
            return
        }

        taskA = recognizerA?.recognitionTask(with: reqA) { [weak self] result, error in
            self?.handleBilingualResult(result: result, error: error, isTrackA: true, sessionID: sessionID)
        }
        taskB = recognizerB?.recognitionTask(with: reqB) { [weak self] result, error in
            self?.handleBilingualResult(result: result, error: error, isTrackA: false, sessionID: sessionID)
        }
    }

    private func handleBilingualResult(result: SFSpeechRecognitionResult?, error: Error?, isTrackA: Bool, sessionID: UUID) {
        guard currentSessionID == sessionID else { return }

        if let result = result {
            let text = result.bestTranscription.formattedString

            if isTrackA { latestTextA = text } else { latestTextB = text }

            DispatchQueue.main.async {
                guard self.currentSessionID == sessionID else { return }
                if isTrackA {
                    self.liveTextA = text
                } else {
                    self.liveTextB = text
                }
            }

            if result.isFinal {
                let segments = result.bestTranscription.segments
                let confidence: Float = segments.isEmpty
                    ? 0
                    : segments.map { $0.confidence }.reduce(0, +) / Float(segments.count)

                if isTrackA { latestTextA = "" } else { latestTextB = "" }
                DispatchQueue.main.async {
                    guard self.currentSessionID == sessionID else { return }
                    if isTrackA { self.liveTextA = "" } else { self.liveTextB = "" }
                }

                handleFinalCandidate(text: text, confidence: confidence, sessionID: sessionID)
            }
        }

        if let error = error {
            let nsError = error as NSError
            let isBenign = nsError.code == 1110 || !self.isRunning
            if !isBenign {
                DispatchQueue.main.async {
                    guard self.currentSessionID == sessionID else { return }
                    self.statusMessage = "⚠️ 辨識問題（\(isTrackA ? "語言 A" : "語言 B")）：\(error.localizedDescription)"
                }
            }
        }
    }

    // 收到任一語言的 final 結果時呼叫：限時等待另一邊也 final，比較信心值後擇優寫入
    private func handleFinalCandidate(text: String, confidence: Float, sessionID: UUID) {
        guard !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return }

        DispatchQueue.main.async { [weak self] in
            guard let self = self, self.currentSessionID == sessionID else { return }

            if let existing = self.pendingCandidate {
                // 已經有一個候選在等待，這是第二個到達的 final，直接比較信心值擇優
                self.pendingTimer?.invalidate()
                self.pendingTimer = nil
                self.pendingCandidate = nil

                let winnerText = confidence >= existing.confidence ? text : existing.text
                self.appendToFile(winnerText)
            } else {
                // 第一個到達的 final，先存起來，限時等另一邊
                self.pendingCandidate = PendingCandidate(text: text, confidence: confidence)
                self.pendingTimer = Timer.scheduledTimer(withTimeInterval: self.pendingWindow, repeats: false) { [weak self] _ in
                    guard let self = self, self.currentSessionID == sessionID else { return }
                    if let candidate = self.pendingCandidate {
                        self.appendToFile(candidate.text)
                        self.pendingCandidate = nil
                    }
                    self.pendingTimer = nil
                }
            }
        }
    }

    // MARK: - 停止聽寫

    func stop() {
        guard isRunning else { return }

        // 讓任何稍後才送達的回呼都被視為「舊工作」而被忽略
        currentSessionID = UUID()

        audioEngine.stop()
        audioEngine.inputNode.removeTap(onBus: 0)

        // 單語模式收尾
        recognitionRequest?.endAudio()
        recognitionTask?.cancel()
        recognitionRequest = nil
        recognitionTask = nil

        // 雙語模式收尾
        requestA?.endAudio()
        requestB?.endAudio()
        taskA?.cancel()
        taskB?.cancel()
        requestA = nil
        requestB = nil
        taskA = nil
        taskB = nil

        pendingTimer?.invalidate()
        pendingTimer = nil

        // 不管有沒有等到官方判定的 isFinal，只要還有內容就強制寫入，避免遺失
        if isBilingualMode {
            if let candidate = pendingCandidate {
                appendToFile(candidate.text)
                pendingCandidate = nil
            } else if !latestTextA.isEmpty || !latestTextB.isEmpty {
                // 兩邊都還沒 final，沒有信心值可比較時，權宜選字數較多的那邊
                let fallback = latestTextA.count >= latestTextB.count ? latestTextA : latestTextB
                if !fallback.isEmpty {
                    appendToFile(fallback)
                }
            }
            latestTextA = ""
            latestTextB = ""
        } else {
            if !latestText.isEmpty {
                appendToFile(latestText)
                latestText = ""
            }
        }

        outputFileHandle?.closeFile()
        isRunning = false
    }

    // MARK: - 自動斷句寫檔（單語 / 雙語共用）

    private func appendToFile(_ text: String) {
        guard !text.isEmpty else { return }

        let now = Date() // 用同一個 Date 產生檔名與時間戳記，確保兩者完全一致

        // 延遲建檔：第一句話真正要寫入時才建立檔案，檔名時間 = 這句話的時間
        if outputFileHandle == nil {
            guard let directory = pendingOutputDirectory else { return }
            let fileNameFormatter = DateFormatter()
            fileNameFormatter.dateFormat = "yyyy-MM-dd_HHmmss"
            let fileName = "transcript_\(fileNameFormatter.string(from: now)).txt"
            let fileURL = directory.appendingPathComponent(fileName)
            FileManager.default.createFile(atPath: fileURL.path, contents: nil)
            outputFileHandle = try? FileHandle(forWritingTo: fileURL)
            DispatchQueue.main.async {
                self.outputFileURL = fileURL
            }
        }

        let timeFormatter = DateFormatter()
        timeFormatter.dateFormat = "HH:mm:ss"
        let timePrefix = timeFormatter.string(from: now)

        func isSentenceEnder(_ ch: Character) -> Bool {
            return "。！？.!?".contains(ch)
        }

        var sentences: [String] = []
        var current = ""
        for ch in text {
            current.append(ch)
            if isSentenceEnder(ch) {
                let trimmed = current.trimmingCharacters(in: .whitespacesAndNewlines)
                if !trimmed.isEmpty { sentences.append(trimmed) }
                current = ""
            }
        }
        let remaining = current.trimmingCharacters(in: .whitespacesAndNewlines)
        if !remaining.isEmpty { sentences.append(remaining) }
        if sentences.isEmpty {
            sentences = [text.trimmingCharacters(in: .whitespacesAndNewlines)]
        }

        var fileOutput = ""
        for sentence in sentences where !sentence.isEmpty {
            let line = "[\(timePrefix)] \(sentence)"
            fileOutput += line + "\n"
            DispatchQueue.main.async {
                self.savedSentences.append(line)
            }
        }
        fileOutput += "\n" // 每次寫入之間加空行區隔

        if let data = fileOutput.data(using: .utf8) {
            outputFileHandle?.seekToEndOfFile()
            outputFileHandle?.write(data)
        }
    }
}

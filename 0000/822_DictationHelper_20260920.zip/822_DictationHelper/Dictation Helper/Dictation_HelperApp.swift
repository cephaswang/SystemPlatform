import SwiftUI

extension Notification.Name {
    static let showHelpWindow = Notification.Name("showHelpWindow")
}

@main
struct Dictation_HelperApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
        .windowResizability(.contentSize)
        .commands {
            CommandGroup(replacing: .help) {
                Button("聽寫小幫手 使用說明") {
                    NotificationCenter.default.post(name: .showHelpWindow, object: nil)
                }
                .keyboardShortcut("?", modifiers: [.command])

                Divider()

                Button("聯絡支援：share35app@gmail.com") {
                    let subject = "聽寫小幫手 - 使用問題".addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
                    if let url = URL(string: "mailto:share35app@gmail.com?subject=\(subject)") {
                        NSWorkspace.shared.open(url)
                    }
                }
            }
        }
    }
}

import SwiftUI

struct LauncherView: View {

    let onSelectImport: () -> Void
    let onSelectVoiceCapture: () -> Void

    @ObservedObject private var setupManager = AudioSetupManager.shared
    @State private var showSetupSheet = false

    var body: some View {
        let _ = print("🖼️ [\(Self.self)] body 重新評估 (\(#fileID))")

        VStack(spacing: 24) {
/*
            Text("VoxNote 語音工作站")
                .font(.title)
                .bold()

            Text("請選擇要開啟的模式")
                .font(.subheadline)
                .foregroundColor(.secondary)
*/
            
            HStack(spacing: 20) {

                LauncherButton(
                    title: "匯入音檔轉錄",
                    subtitle: "已有音檔，事後轉成文字稿",
                    systemImage: "waveform.badge.plus",
                    action: onSelectImport
                )

                LauncherButton(
                    title: "聽抄小幫手",
                    subtitle: "邊聽系統喇叭聲音，邊即時轉文字",
                    systemImage: "speaker.wave.2.circle",
                    action: onSelectVoiceCapture
                )
            }

            // 即時聽抄環境設置入口
            Button {
                setupManager.checkAll()
                showSetupSheet = true
            } label: {
                HStack(spacing: 6) {
                    Image(systemName: setupManager.allReady ? "checkmark.circle.fill" : "gearshape.fill")
                        .foregroundColor(setupManager.allReady ? .green : .secondary)
                    Text(setupManager.allReady ? "聽抄小幫手環境已設置完成" : "尚未設置即時聽抄所需環境，點此設置")
                        .font(.caption)
                }
                .foregroundColor(.secondary)
            }
            .buttonStyle(.plain)
        }
        .padding(32)
        //.frame(width: 480)
        .frame(maxWidth: .infinity)
        .onAppear {
            setupManager.checkAll()
        }
        .sheet(isPresented: $showSetupSheet) {
            AudioSetupView()
        }
    }
}

/// 單一入口按鈕（純 UI 元件）
private struct LauncherButton: View {
    let title: String
    let subtitle: String
    let systemImage: String
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            VStack(spacing: 10) {
                Image(systemName: systemImage)
                    .font(.system(size: 36))
                Text(title)
                    .font(.headline)
                Text(subtitle)
                    .font(.caption)
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
            }
            .padding()
           // .frame(width: 190, height: 160)
            .frame(maxWidth: .infinity, minHeight: 160)
            .background(Color(nsColor: .controlBackgroundColor))
            .cornerRadius(12)
        }
        .buttonStyle(.plain)
    }
}

#Preview {
    LauncherView(onSelectImport: {}, onSelectVoiceCapture: {})
}

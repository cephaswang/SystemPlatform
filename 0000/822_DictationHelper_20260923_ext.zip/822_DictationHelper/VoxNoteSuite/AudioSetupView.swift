import SwiftUI

struct AudioSetupView: View {

    @ObservedObject private var manager = AudioSetupManager.shared
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        VStack(alignment: .leading, spacing: 20) {

            HStack {
                Text("聽抄小幫手環境設置")
                    .font(.title2)
                    .bold()
                Spacer()
                Button("關閉") { dismiss() }
            }

            Text("聽抄小幫手需要把系統喇叭的聲音同時送到一個虛擬裝置，才能被錄音辨識。以下四項只需要設置一次。")
                .font(.callout)
                .foregroundColor(.secondary)

            VStack(spacing: 0) {
                ForEach(SetupStep.allCases) { step in
                    StepRow(step: step, status: manager.statuses[step] ?? .notInstalled)
                    if step != SetupStep.allCases.last {
                        Divider()
                    }
                }
            }
            .padding(12)
            .background(Color(nsColor: .controlBackgroundColor))
            .cornerRadius(10)

            if !manager.log.isEmpty {
                ScrollView {
                    VStack(alignment: .leading, spacing: 4) {
                        ForEach(Array(manager.log.enumerated()), id: \.offset) { _, line in
                            Text(line)
                                .font(.system(.caption, design: .monospaced))
                        }
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                }
                .frame(height: 110)
                .padding(8)
                .background(Color(nsColor: .textBackgroundColor))
                .cornerRadius(8)
            }

            HStack(spacing: 12) {
                Button {
                    Task { await manager.runOneClickSetup() }
                } label: {
                    Label("一鍵設置", systemImage: "wand.and.stars")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)
                .disabled(manager.isBusy || manager.allReady)

                Button {
                    manager.runFFmpegReinstall()
                } label: {
                    Label("重新安裝外掛", systemImage: "arrow.triangle.2.circlepath")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.bordered)
                .disabled(manager.isBusy)

                /*
                Button(role: .destructive) {
                    Task { await manager.runOneClickRemoval() }
                } label: {
                    Label("一鍵移除", systemImage: "trash")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.bordered)
                .disabled(manager.isBusy)
                */
            }

            if manager.isBusy {
                HStack(spacing: 8) {
                    ProgressView().controlSize(.small)
                    Text("處理中，過程中可能會跳出密碼輸入視窗…")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }

            Text("提醒：安裝／移除 BlackHole 需要輸入你 Mac 的管理員密碼；此功能無法在 App Store 沙盒版本下使用。")
                .font(.caption2)
                .foregroundColor(.secondary)
        }
        .padding(24)
        .frame(width: 460)
        .onAppear { manager.checkAll() }
        .sheet(isPresented: Binding(
            get: { manager.showFFmpegInstructions },
            set: { manager.showFFmpegInstructions = $0 }
        )) {
            FFmpegInstructionsView(
                locationDescription: manager.ffmpegScriptLocationDescription,
                command: manager.ffmpegScriptCommand,
                onCopy: manager.copyFFmpegCommandToClipboard,
                onDismiss: { manager.showFFmpegInstructions = false }
            )
        }
    }
}

private struct StepRow: View {
    let step: SetupStep
    let status: SetupStatus

    var body: some View {
        HStack(spacing: 12) {
            icon
            VStack(alignment: .leading, spacing: 2) {
                Text(step.rawValue)
                    .font(.subheadline)
                    .bold()
                Text(step.detail)
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            Spacer()
        }
        .padding(.vertical, 8)
    }

    @ViewBuilder
    private var icon: some View {
        switch status {
        case .installed:
            Image(systemName: "checkmark.circle.fill")
                .foregroundColor(.green)
        case .notInstalled:
            Image(systemName: "circle")
                .foregroundColor(.secondary)
        case .checking:
            ProgressView().controlSize(.small)
        case .error:
            Image(systemName: "exclamationmark.triangle.fill")
                .foregroundColor(.orange)
        }
    }
}

#Preview {
    AudioSetupView()
}

// 提醒使用者到「終端機」貼上指令執行 setup.sh（外掛重新安裝），
// 作法與 ContentView.swift 的 SetupInstructionsView 一致
private struct FFmpegInstructionsView: View {
    let locationDescription: String
    let command: String
    let onCopy: () -> Void
    let onDismiss: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("重新安裝外掛（ffmpeg）")
                .font(.title2)
                .bold()

            Text("已經把安裝腳本複製到：")
            Text(locationDescription)
                .font(.system(.body, design: .monospaced))

            VStack(alignment: .leading, spacing: 6) {
                Text("請打開「終端機」App，貼上（指令已複製到剪貼簿）並執行以下指令：")
                Text(command)
                    .font(.system(.body, design: .monospaced))
                    .textSelection(.enabled)
                    .padding(8)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.gray.opacity(0.1))
                    .cornerRadius(6)
            }

            Text("⚠️ 執行過程中可能會要求輸入你 Mac 的管理員密碼。")
                .font(.caption)
                .foregroundColor(.secondary)

            HStack {
                Spacer()
                Button("複製指令", action: onCopy)
                Button("知道了", role: .cancel, action: onDismiss)
                    .buttonStyle(.borderedProminent)
            }
        }
        .padding(24)
        .frame(width: 460)
    }
}

import Foundation

// 將 App Bundle 內附的 setup.sh 複製到使用者 Downloads 資料夾，
// 讓 App 在偵測到前置軟體缺失時可直接引導使用者執行。
// （原本是複製到桌面，但 App Sandbox 沒有 Desktop Folder 的 Capabilities 勾選項，
//   會被拒絕存取，因此改用已授權 Read/Write 的 Downloads 資料夾。）
//
// ⚠️ 注意：改為直接複製檔案後，setup.sh 必須加入 Xcode 專案的
//         Target -> Build Phases -> Copy Bundle Resources，
//         才能透過 Bundle.main 找到它。
enum SetupScript {
    static let fileName = "setup.sh"

    enum SetupScriptError: LocalizedError {
        case resourceNotFound
        case desktopNotFound
        case downloadsNotFound

        var errorDescription: String? {
            switch self {
            case .resourceNotFound:
                return "找不到內附的 \(SetupScript.fileName)，請確認已加入 Bundle Resource。"
            case .desktopNotFound:
                return "找不到使用者桌面路徑。"
            case .downloadsNotFound:
                return "找不到使用者 Downloads 路徑。"
            }
        }
    }

    /// 取得桌面上目標檔案的 URL（~/Desktop/setup.sh）
    static func desktopDestinationURL() throws -> URL {
        guard let desktopURL = FileManager.default.urls(for: .desktopDirectory, in: .userDomainMask).first else {
            throw SetupScriptError.desktopNotFound
        }
        return desktopURL.appendingPathComponent(fileName)
    }

    /// 取得 Downloads 資料夾目標檔案的 URL（~/Downloads/setup.sh）
    static func downloadsDestinationURL() throws -> URL {
        guard let downloadsURL = FileManager.default.urls(for: .downloadsDirectory, in: .userDomainMask).first else {
            throw SetupScriptError.downloadsNotFound
        }
        return downloadsURL.appendingPathComponent(fileName)
    }

    /// 若桌面已存在同名檔案，先刪除，再把 Bundle 內附的 setup.sh 複製到桌面。
    /// - Returns: 複製完成後的桌面檔案 URL
    ///
    /// ⚠️ 保留此函式僅供參考／未來若改用 NSOpenPanel 讓使用者自行選取桌面時使用。
    ///    App Sandbox 底下直接寫入 Desktop 會因為沒有對應的 Capabilities 勾選項而被拒絕存取，
    ///    目前 UI 實際呼叫的是下面的 installToDownloads()。
    @discardableResult
    static func installToDesktop() throws -> URL {
        try copy(to: try desktopDestinationURL().deletingLastPathComponent())
    }

    /// 若 Downloads 資料夾已存在同名檔案，先刪除，再把 Bundle 內附的 setup.sh 複製過去。
    /// 使用 Downloads 而非 Desktop，是因為 App Sandbox 的 File Access 只能在 Capabilities
    /// 勾選 Downloads Folder（Read/Write），沒有對應的 Desktop Folder 勾選項。
    /// - Returns: 複製完成後的 Downloads 檔案 URL
    @discardableResult
    static func installToDownloads() throws -> URL {
        try copy(to: try downloadsDestinationURL().deletingLastPathComponent())
    }

    /// 若指定資料夾已存在同名檔案，先刪除，再把 Bundle 內附的 setup.sh 複製過去。
    /// - Parameter directory: 目標資料夾（例如桌面、下載、文件）
    /// - Returns: 複製完成後的檔案 URL
    @discardableResult
    static func copy(to directory: URL) throws -> URL {
        guard let bundledURL = Bundle.main.url(forResource: "setup", withExtension: "sh") else {
            throw SetupScriptError.resourceNotFound
        }

        let destinationURL = directory.appendingPathComponent(fileName)
        let fileManager = FileManager.default

        // 若目標資料夾已存在同名檔案，先刪除
        if fileManager.fileExists(atPath: destinationURL.path) {
            try fileManager.removeItem(at: destinationURL)
        }

        // 直接複製 setup.sh 到目標資料夾
        try fileManager.copyItem(at: bundledURL, to: destinationURL)

        // 賦予可執行權限，讓使用者可直接 ./setup.sh 執行
        try fileManager.setAttributes([.posixPermissions: 0o755], ofItemAtPath: destinationURL.path)

        return destinationURL
    }
}

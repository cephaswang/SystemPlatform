import SwiftUI
import AppKit

/// App Delegate：只用來處理「最後一個視窗關閉時是否結束 App」。
///
/// Apple App Review（Guideline 4 - Design）指出：關閉主視窗後沒有任何選單
/// 項目可以重新開啟視窗。因為這是單一用途工具、本來就不支援多視窗
/// （見下方 commands 裡拿掉 .newItem 的註解），所以採用 Apple 建議的
/// 替代方案：主視窗關閉時直接結束整個 App，而不是留著叫不回來的背景進程。
final class AppDelegate: NSObject, NSApplicationDelegate {
    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool {
        true
    }
}

/// 整個 App 唯一的進入點。
/// 原本 VoxNoteImportApp.swift 與 Dictation_HelperApp.swift 各自宣告了一個
/// `@main struct ... : App`（且都被註解掉以避免「一個 executable 只能有一個
/// @main」的編譯錯誤）。現在改成只維持同一個 target、同一個視窗，
/// 因此只需要這一個進入點，其餘兩個檔案裡的 App 宣告都要移除或砍掉整個檔案。
@main
struct VoxNoteSuiteApp: App {

    // 讓 SwiftUI App 生命週期掛上傳統 AppKit delegate，
    // 用來實作 applicationShouldTerminateAfterLastWindowClosed。
    @NSApplicationDelegateAdaptor(AppDelegate.self) private var appDelegate

    // 全域共用的匯入清單狀態，透過環境物件注入各畫面
    @StateObject private var libraryStore = AudioLibraryStore()

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(libraryStore)
        }
        .windowResizability(.contentSize)
        .commands {
            // 沿用原本 Dictation_HelperApp.swift 的選單設定：
            // 這是單一用途工具，不支援多視窗同時聽寫（會搶佔同一個麥克風輸入），
            // 直接把「開新視窗」選項拿掉。
            CommandGroup(replacing: .newItem) { }

            CommandGroup(replacing: .help) {
                // 原本這裡是用 NotificationCenter.default.post(name: .showHelpWindow, ...)，
                // 但整個專案沒有任何地方監聽這個通知，導致按下選單完全沒反應。
                // 改成直接呼叫共用的開啟使用說明函式，
                // 不需要透過通知，也不需要把 HelpView 塞進畫面階層。
                Button("聽抄小幫手 使用說明") {
                    HelpDocsOpener.open()
                }
                .keyboardShortcut("?", modifiers: [.command])

                Divider()

                Button("聯絡支援：share35app@gmail.com") {
                    let subject = "聽抄小幫手 - 使用問題".addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
                    if let url = URL(string: "mailto:share35app@gmail.com?subject=\(subject)") {
                        NSWorkspace.shared.open(url)
                    }
                }
            }
        }

        Settings {
            SettingsView()
                .environmentObject(libraryStore)
        }
    }
}

# 聽抄小幫手 Windows 10 版（VoiceCapture for Windows）企劃書

**版本：v0.1 草案（依 macOS 版 v2.0 + VoxNote 架構文件 v3 改寫）** **專案定位**：單一 Windows 桌面 App，內含「匯入音檔轉文字稿」與「聽抄（即時轉錄）」兩個模式，比照 macOS 版現況（VoxNote 兩模組已整併為單一 App，不再是三個各自獨立的 App）。

---

## 一、專案背景與目標

沿用 macOS 版動機：命令列聽抄流程圖形化、環境設置自動化、麥克風即時聽抄、匯入現成錄音批次轉逐字稿。Windows 版目標對齊 macOS 版第二節 1–11 項（圖形介面、多語系、即時顯示＋即時寫檔、依標點斷句加時間戳、輸入裝置選單、於檔案總管顯示逐字稿、容錯強制寫檔、麥克風來源免虛擬裝置、環境一鍵設置、匯入批次轉錄與多格式匯出、內建教學）。

**Windows 版有一項架構性簡化，先在此點出**：macOS 需要 BlackHole 虛擬音訊裝置＋Multi-Output Device 才能一邊播放一邊擷取系統聲音；Windows 的 WASAPI 原生支援「**Loopback 錄製模式**」，可以直接擷取任一輸出裝置目前播放的聲音，**不需要虛擬裝置、不需要建立聚合裝置、也不需要切換系統輸出**。這使得 Windows 版的「環境設置」步驟大幅簡化（見第四章）。

---

## 二、功能規格

### 2.1 App 整體流程

與 macOS 版相同：啟動後進入模式選擇畫面（「匯入音檔轉文字稿」／「聽抄」），下方環境狀態列，內建說明頁。

### 2.2 模式一：匯入音檔轉文字稿

- 支援格式：mp3／m4a／wav／webm（webm 先用 ffmpeg 轉成可辨識格式）
- 匯入：拖放或「選擇檔案」（Windows 開檔對話框 `OpenFileDialog`）
- 語系選單、音檔清單（狀態＋長度，可新增刪除）、逐字稿檢視（含時間戳記）
- 匯出：TXT／SRT／DOCX／PDF，可勾選是否含時間戳記

### 2.3 模式二：聽抄（即時轉錄）

**聲音來源選單**：列出系統目前所有輸入裝置＋新增「系統聲音（Loopback）」選項，名稱後加註用途。與 macOS 不同：**系統聲音不是一個實體裝置，而是對「目前預設輸出裝置」做 Loopback 擷取**，選單邏輯需相應調整（是選一個輸出裝置的 loopback，而非選一個輸入裝置）。

| 項目 | macOS 版 | Windows 版 |
| --- | --- | --- |
| 系統聲音來源 | BlackHole 2ch（偽裝成輸入裝置） | 對預設輸出裝置做 WASAPI Loopback 擷取，不佔用「輸入裝置」清單位置 |
| 開始聽抄時的動作 | 自動切換系統輸出／輸入裝置 | **不需要切換任何系統裝置**：喇叭/耳機正常播放，同時用 Loopback 擷取，兩者互不影響 |
| 停止後裝置狀態 | 輸出仍停留在 Multi-Output Device（macOS 版已知限制 #6） | 無此問題，因為從未更動過系統裝置設定 |
| 麥克風來源 | AVAudioEngine 擷取指定輸入裝置 | WASAPI Capture 擷取指定輸入裝置，邏輯相同 |
| 排除臨時聚合裝置 | 排除 `CADefaultDeviceAggregate-*` | Windows 無對應的臨時聚合裝置問題，此項規則可移除 |

**辨識與輸出**：語系動態列出本機支援語系（見 3.1 語音辨識選型）、即時顯示可捲動可複製、依中英文句尾標點斷句寫檔＋時間戳記、停止前跳出確認、強制寫入未定案內容、聽抄中鎖定語系與裝置選單、「於檔案總管顯示」快捷鍵。雙語模式（雙引擎比較信心分數）維持與 macOS 版相同的設計，作為介面隱藏功能移植。

---

## 三、系統架構

### 3.1 技術選型對照（macOS → Windows）

| 項目 | macOS 版 | Windows 版 |
| --- | --- | --- |
| UI 框架 | SwiftUI | WPF（.NET 8） |
| 語音辨識 | Speech Framework（`SFSpeechRecognizer`） | `Windows.Media.SpeechRecognition.SpeechRecognizer`（WinRT，桌面 App 可透過 `Microsoft.Windows.SDK.Contracts` 呼叫），使用連續聽寫（dictation）topic constraint |
| 音訊擷取 | AVFoundation（`AVAudioEngine`） | **NAudio**：麥克風用 `WasapiCapture`，系統聲音用 `WasapiLoopbackCapture` |
| 音訊裝置列舉/切換 | CoreAudio | NAudio/`MMDeviceEnumerator`（列舉裝置）；**變更系統預設裝置在 Windows 無官方公開 API**（需透過未公開的 `IPolicyConfig` COM 介面，或退而不提供此功能，見風險） |
| 虛擬音訊裝置 | BlackHole 2ch | **不需要**（WASAPI Loopback 取代） |
| 音檔轉檔 | ffmpeg（webm→m4a） | ffmpeg.exe（相同） |
| 環境安裝 | setup.sh／uninstall.sh | 只需檢查/安裝 ffmpeg（若語音辨識語言包缺少，導引至「設定 → 時間與語言 → 語音」下載語言） |
| 檔案輸出 | FileManager／FileHandle | `System.IO`；DOCX 用 OpenXML SDK，PDF 用既有 PDF 產生套件（比照本 App 系列已用過的 pdf 產生方式） |

### 3.2 語音辨識選型說明（Windows 特有考量）

Windows 內建連續聽寫辨識能力落在兩條路：

1. **`Windows.Media.SpeechRecognition`（WinRT）**：延續系統「線上語音辨識」（需連網，資料傳送到 Microsoft 雲端），語系需先於「設定 → 時間與語言 → 語音」下載對應語言包；效果與涵蓋語系數量不如 macOS 的 Speech Framework 完整。
2. **`System.Speech.Recognition`（SAPI，較舊）**：完全離線，但只支援已安裝的 SAPI 語音辨識引擎（英文為主，中文支援有限，需自行訓練語音設定檔），不適合直接對齊 macOS 版「動態列出 60 幾種語系」的體驗。

**建議**：Phase 1 先以路線 1（`Windows.Media.SpeechRecognition`）對齊 macOS 版的介面與流程，並在企劃中明確告知使用者「聽抄需要網路連線」；語系清單改為「動態列出目前系統已安裝語言包的語音辨識語系」，而非 macOS 版的離線 63 種語系。是否額外整合雲端語音服務（如 Azure Speech）以擴大語系涵蓋，列入待確認事項。

### 3.3 聽抄的音訊路徑

```
系統聲音模式：
  預設輸出裝置（喇叭/耳機，持續正常播放）
       └→ WasapiLoopbackCapture → 語音辨識 → 即時畫面 + 逐字稿檔案
  （不更動任何系統裝置設定）

麥克風模式：
  指定輸入裝置 → WasapiCapture → 語音辨識 → 即時畫面 + 逐字稿檔案
```

兩種模式路徑都比 macOS 版簡單一層（少了 Multi-Output Device 與裝置切換）。

### 3.4 專案模組拆分（建議）

```
DictationHelperWin/
├── App/ (App.xaml, App.xaml.cs, AppState.cs)
├── Modules/
│   ├── Launcher/ (LauncherView：模式選擇＋環境狀態列)
│   ├── LiveDictation/
│   │   ├── DictationView.xaml       # 對應 ContentView
│   │   ├── SpeechTranscriber.cs     # 辨識核心＋斷句寫檔＋雙語模式
│   │   └── AudioDeviceManager.cs    # 裝置列舉、Loopback/Capture 建立
│   └── ImportTranscribe/
│       ├── Models/ (AudioFile, TranscriptSegment)
│       ├── Services/ (AudioImportService, AudioConverterService, SpeechRecognitionService, ExportService)
│       └── Views/ (ImportView, AudioLibraryView, TranscriptEditorView, ExportSheetView, SettingsView)
├── Shared/
│   ├── EnvironmentSetup/ (EnvironmentCheckService：只檢查 ffmpeg 與語言包)
│   ├── ExplorerActions.cs
│   └── PermissionManager.cs         # 麥克風權限（Windows 隱私設定）
├── docs/
└── Resources/ffmpeg.exe
```

---

## 四、環境設置（大幅簡化）

| 項目 | macOS 版四項檢查 | Windows 版 |
| --- | --- | --- |
| 虛擬音訊裝置 | 需要（BlackHole） | **免除** |
| Multi-Output Device | 需要 | **免除** |
| 系統輸出切換 | 需要 | **免除** |
| ffmpeg | 需要 | 需要（webm 轉檔） |
| 語音辨識語言包 | 系統內建，隨語系選單自動涵蓋 | 需要（若走 `Windows.Media.SpeechRecognition` 路線，語言包需使用者自行於系統設定下載；App 可提供「開啟語音設定」捷徑） |

「一鍵設置／重新安裝外掛／一鍵移除」三個按鈕在 Windows 版可簡化為：檢查 ffmpeg 是否存在（不存在則提供下載或內嵌安裝）＋檢查語音辨識語言包是否已安裝（提供開啟系統設定的捷徑），**不需要終端機指令、不需要管理員密碼、不需要重新開機**。

---

## 五、風險與已知限制

| 項目 | 說明 |
| --- | --- |
| **語音辨識涵蓋語系與離線能力** | 與 macOS 版最大落差；需在企劃中明確定案路線（見 3.2），並告知使用者網路需求 |
| **無法變更系統預設輸出/輸入裝置** | Windows 無官方公開 API（`IPolicyConfig` 為未公開介面，微軟不保證相容性，且可能被防毒軟體判定為可疑行為）；但因 Windows 版採 Loopback，**本來就不需要切換裝置**，此限制實際影響有限，僅麥克風模式若要「自動切換到某支麥克風」時受限，可退而僅列出選單供使用者手動選擇 |
| ffmpeg 依賴 | 與 macOS 版相同 |
| 麥克風模式混入環境音 | 與 macOS 版相同 |
| 雙語模式 CPU 用量 | 與 macOS 版相同 |
| 麥克風/語音辨識權限 | Windows 對應「設定 → 隱私權與安全性 → 麥克風」「語音辨識」，App 需引導使用者開啟 |
| App 簽章 | 未簽章安裝檔會觸發 SmartScreen 警告，需程式碼簽章憑證 |

---

## 六、開發階段規劃（建議）

| 階段 | 內容 |
| --- | --- |
| Phase 1 | 麥克風即時聽抄（WasapiCapture + `Windows.Media.SpeechRecognition`）、斷句寫檔 |
| Phase 2 | 系統聲音聽抄（`WasapiLoopbackCapture`），驗證與麥克風模式共用的辨識/寫檔邏輯 |
| Phase 3 | 匯入音檔轉文字稿模組（含 webm→ffmpeg 轉檔、多語系、逐字稿檢視） |
| Phase 4 | 匯出功能（TXT／SRT／DOCX／PDF） |
| Phase 5 | 環境設置畫面（ffmpeg 檢查、語言包捷徑）、於檔案總管顯示、教學頁 |
| Phase 6 | 雙語模式移植、打包簽章與發布（獨立安裝檔／Microsoft Store 兩路線評估） |

---

## 七、待確認事項

- [ ] 語音辨識路線定案：`Windows.Media.SpeechRecognition`（線上、語言包依賴）v.s. 整合第三方雲端語音服務（如 Azure Speech，涵蓋語系更廣但需 API 金鑰與費用）
- [ ] 品牌名稱是否延用「聽抄小幫手」，或另立 Windows 版名稱
- [ ] 麥克風裝置選擇是否需要「記住上次選擇」邏輯（沿用 macOS 版設計）
- [ ] DOCX／PDF 匯出套件選型（OpenXML SDK 之外是否有現成方案）
- [ ] 發行路線：獨立安裝檔（需程式碼簽章）或 Microsoft Store（MSIX 封裝下呼叫 WASAPI Loopback、執行外部 ffmpeg.exe 的沙盒相容性需驗證）
- [ ] 是否需要系統匣常駐模式（比照 macOS 版「未來擴充建議」的選單列模式）

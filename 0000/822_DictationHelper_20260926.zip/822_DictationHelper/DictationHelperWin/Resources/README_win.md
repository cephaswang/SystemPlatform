# Resources

請將 `ffmpeg.exe`（Windows 版）放置於此資料夾。

對應企劃書三、3.4 專案模組拆分與第四章環境設置：
- App 啟動時（`EnvironmentCheckService`）會先檢查此處是否已內嵌 `ffmpeg.exe`，
  若不存在則退而檢查系統 PATH 是否可執行 `ffmpeg -version`。
- 僅在匯入 `.webm` 音檔時才需要用到（見 `AudioConverterService`），
  轉為可辨識的 `.wav` 格式後再送入語音辨識引擎。

發行時建議連同 `ffmpeg.exe`（授權需為 LGPL/GPL 相容的建置版本）一併封裝進安裝檔。

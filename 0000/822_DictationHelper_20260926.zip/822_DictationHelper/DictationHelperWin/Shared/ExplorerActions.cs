using System.Diagnostics;

namespace DictationHelperWin.Shared;

/// <summary>
/// 對應企劃書二、第 6 項：於檔案總管顯示逐字稿；第四章：開啟系統語音設定捷徑。
/// </summary>
public static class ExplorerActions
{
    /// <summary>在檔案總管中開啟並選取指定檔案（對應 macOS 版「於 Finder 顯示」）。</summary>
    public static void ShowFileInExplorer(string filePath)
    {
        Process.Start(new ProcessStartInfo
        {
            FileName = "explorer.exe",
            Arguments = $"/select,\"{filePath}\"",
            UseShellExecute = true
        });
    }

    /// <summary>
    /// 對應企劃書第四章：語言包缺少時，導引至「設定 → 時間與語言 → 語音」。
    /// </summary>
    public static void OpenWindowsSpeechSettings()
    {
        Process.Start(new ProcessStartInfo
        {
            FileName = "ms-settings:speech",
            UseShellExecute = true
        });
    }

    /// <summary>對應企劃書第五章：導引使用者開啟「隱私權與安全性 → 麥克風」設定。</summary>
    public static void OpenMicrophonePrivacySettings()
    {
        Process.Start(new ProcessStartInfo
        {
            FileName = "ms-settings:privacy-microphone",
            UseShellExecute = true
        });
    }
}

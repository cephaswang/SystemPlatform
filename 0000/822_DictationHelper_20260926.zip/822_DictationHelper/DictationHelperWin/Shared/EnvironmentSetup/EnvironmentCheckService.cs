using System;
using System.Diagnostics;
using System.IO;
using System.Threading.Tasks;

namespace DictationHelperWin.Shared.EnvironmentSetup;

/// <summary>環境檢查結果，供狀態列與其他畫面訂閱顯示。</summary>
public sealed record EnvironmentStatus(bool FfmpegOk, bool SpeechLanguagePackMissing, string Summary);

/// <summary>
/// 對應企劃書第四章：環境設置大幅簡化。
/// 只需檢查/安裝 ffmpeg（若語音辨識語言包缺少，導引至「設定 → 時間與語言 → 語音」下載語言）。
/// 不需要虛擬音訊裝置、不需要 Multi-Output Device、不需要系統輸出切換
/// （因 Windows 版採 WASAPI Loopback，見企劃書一、專案背景與目標）。
/// </summary>
public sealed class EnvironmentCheckService
{
    public event EventHandler<EnvironmentStatus>? StatusChanged;

    public EnvironmentStatus? LastStatus { get; private set; }

    public async Task<EnvironmentStatus> RefreshStatusAsync()
    {
        var ffmpegOk = await Task.Run(CheckFfmpegExists);
        var languagePackMissing = await Task.Run(CheckSpeechLanguagePackMissing);

        var summary = (ffmpegOk, languagePackMissing) switch
        {
            (true, false) => "環境檢查完成，一切就緒。",
            (false, _) => "找不到 ffmpeg，匯入 webm 音檔時將無法轉檔。",
            (true, true) => "尚未安裝語音辨識語言包，聽抄前請先於系統設定下載。",
        };

        var status = new EnvironmentStatus(ffmpegOk, languagePackMissing, summary);
        LastStatus = status;
        StatusChanged?.Invoke(this, status);
        return status;
    }

    /// <summary>檢查內嵌或系統 PATH 中是否有 ffmpeg.exe。</summary>
    private static bool CheckFfmpegExists()
    {
        var bundled = Path.Combine(AppContext.BaseDirectory, "Resources", "ffmpeg.exe");
        if (File.Exists(bundled)) return true;

        try
        {
            using var process = Process.Start(new ProcessStartInfo
            {
                FileName = "ffmpeg",
                Arguments = "-version",
                RedirectStandardOutput = true,
                UseShellExecute = false,
                CreateNoWindow = true
            });
            process?.WaitForExit(2000);
            return process is { ExitCode: 0 };
        }
        catch
        {
            return false;
        }
    }

    /// <summary>
    /// 檢查是否已安裝語音辨識語言包。
    /// TODO：改為實際查詢 Windows.Globalization.Language / SpeechRecognizer.SupportedTopicLanguages，
    /// 比對使用者常用語系（例如 zh-TW）是否已安裝。此處先回傳保守預設值。
    /// </summary>
    private static bool CheckSpeechLanguagePackMissing()
    {
        return false;
    }
}

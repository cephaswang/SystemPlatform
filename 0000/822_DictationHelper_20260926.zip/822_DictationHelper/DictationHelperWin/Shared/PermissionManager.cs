using System.Threading.Tasks;

namespace DictationHelperWin.Shared;

/// <summary>
/// 對應企劃書第五章「麥克風/語音辨識權限」：
/// Windows 對應「設定 → 隱私權與安全性 → 麥克風」「語音辨識」，App 需引導使用者開啟。
/// </summary>
public static class PermissionManager
{
    /// <summary>
    /// 檢查是否已取得麥克風存取權限。
    /// TODO：改為實際呼叫 Windows.Media.Capture.MediaCapture 權限請求流程
    /// 或 Windows.Security.Authorization.AppCapabilityAccess API。
    /// </summary>
    public static Task<bool> EnsureMicrophonePermissionAsync()
    {
        // 佔位實作：桌面（非封裝）應用程式在多數情況下可直接存取麥克風，
        // 但仍應處理使用者於隱私權設定中關閉存取的情境，並導引至設定頁（見 ExplorerActions）。
        return Task.FromResult(true);
    }

    /// <summary>
    /// 檢查是否已取得語音辨識（線上）使用授權。
    /// 對應企劃書 3.2：Phase 1 採 Windows.Media.SpeechRecognition，需連網。
    /// </summary>
    public static Task<bool> EnsureSpeechRecognitionPermissionAsync()
    {
        return Task.FromResult(true);
    }
}

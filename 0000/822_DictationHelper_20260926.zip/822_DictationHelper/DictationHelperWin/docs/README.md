# 聽抄小幫手 Windows 版（VoiceCapture for Windows）

本專案骨架依據《聽抄小幫手 Windows 10 版企劃書》v0.1 草案產生，對應章節如下：

| 專案位置 | 對應企劃書章節 |
| --- | --- |
| `App/` | 二、2.1 App 整體流程；三、3.4 專案模組拆分 |
| `Modules/Launcher/` | 二、2.1 模式選擇畫面＋環境狀態列 |
| `Modules/LiveDictation/` | 二、2.3 模式二：聽抄（即時轉錄）；三、3.3 聽抄的音訊路徑 |
| `Modules/ImportTranscribe/` | 二、2.2 模式一：匯入音檔轉文字稿 |
| `Shared/EnvironmentSetup/` | 四、環境設置（大幅簡化） |
| `Shared/ExplorerActions.cs`、`PermissionManager.cs` | 二、第 6 項；五、風險與已知限制（麥克風/語音辨識權限） |
| `Resources/ffmpeg.exe` | 三、3.1 技術選型對照；四、環境設置 |

## 目前狀態

這是**骨架（scaffold）**，對應企劃書六、開發階段規劃的 Phase 1～2 之前的結構準備：

- 已建立：UI 畫面（XAML）、模組拆分、裝置列舉、環境檢查、匯出（TXT／SRT）框架。
- 尚未實作（標記為 `TODO`，需依第七章「待確認事項」定案後補上）：
  - `Windows.Media.SpeechRecognition` 實際辨識邏輯串接（`SpeechTranscriber.cs`、`SpeechRecognitionService.cs`）
  - DOCX／PDF 匯出（`ExportService.cs`）
  - 語言包安裝狀態實際偵測（`EnvironmentCheckService.cs`）
  - 麥克風/語音辨識權限的實際 API 呼叫（`PermissionManager.cs`）

## 建置需求

- .NET 8 SDK
- Windows 10 (build ≥ 17763) 或 Windows 11
- NuGet 套件：NAudio、DocumentFormat.OpenXml、Microsoft.Windows.SDK.Contracts（見 `DictationHelperWin.csproj`）

## 待確認事項（原文照錄，見企劃書第七章）

- [ ] 語音辨識路線定案：`Windows.Media.SpeechRecognition` v.s. 第三方雲端語音服務（如 Azure Speech）
- [ ] 品牌名稱是否延用「聽抄小幫手」
- [ ] 麥克風裝置「記住上次選擇」邏輯（本骨架已於 `AppState` 預留欄位與 `SettingsView` UI）
- [ ] DOCX／PDF 匯出套件選型
- [ ] 發行路線：獨立安裝檔 v.s. Microsoft Store（MSIX 沙盒相容性）
- [ ] 系統匣常駐模式

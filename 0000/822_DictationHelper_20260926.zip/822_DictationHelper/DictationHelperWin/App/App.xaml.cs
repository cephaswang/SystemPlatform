using System.Windows;

namespace DictationHelperWin.App;

/// <summary>
/// 對應企劃書二、2.1：App 進入點。
/// 啟動流程：初始化 AppState → 顯示模式選擇畫面（LauncherView）。
/// </summary>
public partial class App : Application
{
    /// <summary>
    /// 全域共用狀態（見 AppState.cs），供 Launcher／LiveDictation／ImportTranscribe 三個模組共用。
    /// </summary>
    public static AppState State { get; private set; } = new AppState();

    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);

        // 對應企劃書第四章：環境設置大幅簡化。
        // 啟動時僅需非同步檢查 ffmpeg 是否存在、語音辨識語言包是否已安裝，
        // 不需要終端機指令、不需要管理員密碼、不需要重新開機。
        _ = State.EnvironmentCheck.RefreshStatusAsync();
    }

    protected override void OnExit(ExitEventArgs e)
    {
        // 對應企劃書 2.3：聽抄中若尚有未寫入的暫存內容，離開前應強制寫檔（容錯機制）。
        State.Dispose();
        base.OnExit(e);
    }
}

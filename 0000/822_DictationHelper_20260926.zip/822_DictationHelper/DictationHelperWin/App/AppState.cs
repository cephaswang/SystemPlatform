using System;
using DictationHelperWin.Modules.LiveDictation;
using DictationHelperWin.Modules.ImportTranscribe.Services;
using DictationHelperWin.Shared.EnvironmentSetup;

namespace DictationHelperWin.App;

/// <summary>
/// 全域共用狀態容器。
/// 對應企劃書三、3.4 專案模組拆分：App/AppState.cs 統一持有跨模組會用到的服務實例，
/// 避免 Launcher／LiveDictation／ImportTranscribe 各自重複建立。
/// </summary>
public sealed class AppState : IDisposable
{
    /// <summary>對應企劃書第四章：環境狀態列所顯示的 ffmpeg／語言包檢查結果。</summary>
    public EnvironmentCheckService EnvironmentCheck { get; } = new EnvironmentCheckService();

    /// <summary>對應企劃書 3.1／3.3：裝置列舉、Loopback／Capture 建立。</summary>
    public AudioDeviceManager AudioDeviceManager { get; } = new AudioDeviceManager();

    /// <summary>對應企劃書 2.3：聽抄模式辨識核心＋斷句寫檔＋雙語模式。</summary>
    public SpeechTranscriber SpeechTranscriber { get; }

    /// <summary>對應企劃書 2.2：匯入音檔轉文字稿模組所需的匯出服務。</summary>
    public ExportService ExportService { get; } = new ExportService();

    /// <summary>是否記住上次麥克風裝置選擇（見第七章待確認事項，先保留設定欄位）。</summary>
    public bool RememberLastMicrophone { get; set; } = true;

    public string? LastSelectedMicrophoneId { get; set; }

    public AppState()
    {
        SpeechTranscriber = new SpeechTranscriber(AudioDeviceManager);
    }

    public void Dispose()
    {
        SpeechTranscriber.Dispose();
        AudioDeviceManager.Dispose();
    }
}

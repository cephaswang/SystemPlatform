using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using NAudio.Wave;

namespace DictationHelperWin.Modules.LiveDictation;

public sealed class TranscriptSegmentEventArgs : EventArgs
{
    public required string Text { get; init; }
    public required TimeSpan Timestamp { get; init; }
}

/// <summary>
/// 對應企劃書三、3.1／3.2：聽抄模式的辨識核心。
/// 路線採 Phase 1 建議：Windows.Media.SpeechRecognition（WinRT，需連網）。
/// 負責：依中英文句尾標點斷句寫檔＋時間戳記、即時顯示、容錯強制寫檔、雙語模式（隱藏功能）。
/// </summary>
public sealed class SpeechTranscriber : IDisposable
{
    private readonly AudioDeviceManager _deviceManager;
    private IWaveIn? _capture;
    private StreamWriter? _transcriptWriter;
    private string? _transcriptFilePath;
    private DateTime _sessionStartTime;
    private string _pendingText = string.Empty;

    /// <summary>已完成斷句、寫入檔案的逐字稿片段。</summary>
    public event EventHandler<TranscriptSegmentEventArgs>? SegmentTranscribed;

    /// <summary>尚未斷句的即時辨識文字（供 UI 顯示辨識中狀態）。</summary>
    public event EventHandler<string>? PartialTextUpdated;

    /// <summary>是否啟用雙語模式（雙引擎比較信心分數）。對應企劃書 2.3：作為介面隱藏功能移植。</summary>
    public bool DualLanguageModeEnabled { get; set; }

    public SpeechTranscriber(AudioDeviceManager deviceManager)
    {
        _deviceManager = deviceManager;
    }

    /// <summary>
    /// 對應企劃書 3.2：動態列出目前系統已安裝語言包的語音辨識語系。
    /// TODO：改為實際呼叫 Windows.Media.SpeechRecognition.SpeechRecognizer.SupportedTopicLanguages
    /// 搭配已安裝語言包比對後回傳。此處先回傳佔位清單。
    /// </summary>
    public IReadOnlyList<string> GetAvailableLanguages()
    {
        return new[] { "中文（繁體，台灣）", "English (United States)", "日本語" };
    }

    /// <summary>
    /// 開始聽抄。依 source.Kind 決定走 Loopback 或麥克風路徑（見企劃書 3.3 音訊路徑圖）。
    /// 回傳本次聽抄逐字稿的檔案路徑。
    /// </summary>
    public async Task<string> StartAsync(AudioSourceOption source, string language)
    {
        _sessionStartTime = DateTime.Now;
        _pendingText = string.Empty;

        var fileName = $"聽抄_{_sessionStartTime:yyyyMMdd_HHmmss}.txt";
        var documentsPath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
        _transcriptFilePath = Path.Combine(documentsPath, "聽抄小幫手", fileName);
        Directory.CreateDirectory(Path.GetDirectoryName(_transcriptFilePath)!);
        _transcriptWriter = new StreamWriter(_transcriptFilePath, append: false) { AutoFlush = true };

        _capture = source.Kind == AudioSourceKind.SystemLoopback
            ? _deviceManager.CreateLoopbackCapture()
            : _deviceManager.CreateMicrophoneCapture(source.DeviceId!);

        _capture.DataAvailable += OnAudioDataAvailable;
        _capture.StartRecording();

        // TODO：初始化 Windows.Media.SpeechRecognition.SpeechRecognizer，
        // 設定 language 對應的 Language、加入連續聽寫（dictation）topic constraint，
        // 並將 _capture 擷取到的音訊串流餵給辨識引擎，於 ResultGenerated / HypothesisGenerated
        // 事件中分別觸發 OnFinalSegment（斷句寫檔）與 PartialTextUpdated（即時顯示）。

        await Task.CompletedTask;
        return _transcriptFilePath;
    }

    private void OnAudioDataAvailable(object? sender, WaveInEventArgs e)
    {
        // TODO：將原始音訊資料轉送給語音辨識引擎。
    }

    /// <summary>
    /// 對應企劃書 2.3：依中英文句尾標點（。！？.!?）斷句，寫入檔案並附上時間戳記。
    /// 供辨識引擎回呼使用。
    /// </summary>
    private void OnFinalSegment(string text)
    {
        var timestamp = DateTime.Now - _sessionStartTime;
        _transcriptWriter?.WriteLine($"[{timestamp:hh\\:mm\\:ss}] {text}");
        SegmentTranscribed?.Invoke(this, new TranscriptSegmentEventArgs { Text = text, Timestamp = timestamp });
    }

    /// <summary>
    /// 停止聽抄。對應企劃書 2.3：停止前跳出確認（於 DictationView 處理）、
    /// 強制寫入未定案內容（flushPending）。
    /// </summary>
    public async Task StopAsync(bool flushPending)
    {
        if (flushPending && !string.IsNullOrWhiteSpace(_pendingText))
        {
            OnFinalSegment(_pendingText);
            _pendingText = string.Empty;
        }

        if (_capture is not null)
        {
            _capture.DataAvailable -= OnAudioDataAvailable;
            _capture.StopRecording();
            _capture.Dispose();
            _capture = null;
        }

        _transcriptWriter?.Flush();
        _transcriptWriter?.Dispose();
        _transcriptWriter = null;

        await Task.CompletedTask;
    }

    public void Dispose()
    {
        _capture?.Dispose();
        _transcriptWriter?.Dispose();
    }
}

using System;
using System.Collections.Generic;
using System.Linq;
using NAudio.CoreAudioApi;
using NAudio.Wave;

namespace DictationHelperWin.Modules.LiveDictation;

/// <summary>聲音來源種類：麥克風（輸入裝置）或系統聲音（對輸出裝置做 Loopback）。</summary>
public enum AudioSourceKind
{
    Microphone,
    SystemLoopback
}

/// <summary>
/// 對應企劃書 2.3：聲音來源選單的資料項目。
/// 「系統聲音」不是實體裝置，而是對「目前預設輸出裝置」做 Loopback 擷取，
/// 因此不佔用輸入裝置清單位置，UI 上以獨立選項＋用途註記呈現。
/// </summary>
public sealed record AudioSourceOption(string DisplayName, AudioSourceKind Kind, string? DeviceId);

/// <summary>
/// 對應企劃書三、3.1：音訊裝置列舉/切換。
/// 使用 NAudio 的 MMDeviceEnumerator 列舉裝置；
/// Windows 無官方公開 API 可變更系統預設裝置（見第五章風險），本類別僅負責列舉與建立擷取器，
/// 不提供「切換系統預設裝置」功能。
/// </summary>
public sealed class AudioDeviceManager : IDisposable
{
    private readonly MMDeviceEnumerator _enumerator = new();

    /// <summary>
    /// 列出目前所有輸入裝置＋「系統聲音（Loopback）」選項。
    /// 對應企劃書 2.3 表格：與 macOS 版不同，系統聲音來源不需要排除臨時聚合裝置
    /// （Windows 無對應的 CADefaultDeviceAggregate-* 問題）。
    /// </summary>
    public IReadOnlyList<AudioSourceOption> GetAvailableSources()
    {
        var options = new List<AudioSourceOption>();

        // 系統聲音（Loopback）選項置頂，名稱後加註用途，符合企劃書 2.3 的 UI 要求。
        options.Add(new AudioSourceOption(
            "系統聲音（擷取目前播放的聲音，例如會議、影片、音樂）",
            AudioSourceKind.SystemLoopback,
            DeviceId: null));

        foreach (var device in _enumerator.EnumerateAudioEndPoints(DataFlow.Capture, DeviceState.Active))
        {
            options.Add(new AudioSourceOption(
                $"麥克風：{device.FriendlyName}",
                AudioSourceKind.Microphone,
                device.ID));
        }

        return options;
    }

    /// <summary>
    /// 對應企劃書 3.3 系統聲音路徑：對「預設輸出裝置」建立 WasapiLoopbackCapture，
    /// 不更動任何系統裝置設定，喇叭/耳機持續正常播放。
    /// </summary>
    public IWaveIn CreateLoopbackCapture()
    {
        var defaultRenderDevice = _enumerator.GetDefaultAudioEndpoint(DataFlow.Render, Role.Multimedia);
        return new WasapiLoopbackCapture(defaultRenderDevice);
    }

    /// <summary>
    /// 對應企劃書 3.3 麥克風路徑：對指定輸入裝置建立 WasapiCapture。
    /// </summary>
    public IWaveIn CreateMicrophoneCapture(string deviceId)
    {
        var device = _enumerator.GetDevice(deviceId);
        return new WasapiCapture(device);
    }

    public void Dispose()
    {
        _enumerator.Dispose();
    }
}

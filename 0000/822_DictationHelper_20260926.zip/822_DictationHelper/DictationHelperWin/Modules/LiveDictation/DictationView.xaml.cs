using System;
using System.Windows;
using System.Windows.Input;
using DictationHelperWin.Shared;

namespace DictationHelperWin.Modules.LiveDictation;

/// <summary>
/// 對應企劃書二、2.3：模式二 聽抄（即時轉錄）的畫面邏輯。
/// 音訊擷取／辨識核心委派給 SpeechTranscriber，本檔案只處理 UI 狀態切換。
/// </summary>
public partial class DictationView : Window
{
    private readonly SpeechTranscriber _transcriber = App.App.State.SpeechTranscriber;
    private bool _isDictating;
    private string? _currentTranscriptFilePath;

    public DictationView()
    {
        InitializeComponent();

        // 對應企劃書 2.3：聽抄中鎖定語系與裝置選單（於 StartStopButton_Click 內切換 IsEnabled）。
        AudioSourceComboBox.ItemsSource = App.App.State.AudioDeviceManager.GetAvailableSources();
        LanguageComboBox.ItemsSource = _transcriber.GetAvailableLanguages();

        _transcriber.SegmentTranscribed += OnSegmentTranscribed;
        _transcriber.PartialTextUpdated += OnPartialTextUpdated;

        // 對應企劃書二、第 6 項：快捷鍵，於檔案總管顯示目前逐字稿。
        InputBindings.Add(new KeyBinding(
            new RelayCommand(_ => ShowInExplorerButton_Click(this, new RoutedEventArgs())),
            Key.E, ModifierKeys.Control));

        Closing += DictationView_Closing;
    }

    private void OnSegmentTranscribed(object? sender, TranscriptSegmentEventArgs e)
    {
        Dispatcher.Invoke(() =>
        {
            // 對應企劃書 2.3：依中英文句尾標點斷句寫檔＋時間戳記。
            TranscriptTextBox.AppendText($"[{e.Timestamp:hh\\:mm\\:ss}] {e.Text}\n");
            TranscriptTextBox.ScrollToEnd();
        });
    }

    private void OnPartialTextUpdated(object? sender, string partialText)
    {
        Dispatcher.Invoke(() => StatusText.Text = $"辨識中… {partialText}");
    }

    private async void StartStopButton_Click(object sender, RoutedEventArgs e)
    {
        if (!_isDictating)
        {
            var source = AudioSourceComboBox.SelectedItem as AudioSourceOption;
            var language = LanguageComboBox.SelectedItem as string;
            if (source is null || language is null)
            {
                MessageBox.Show("請先選擇聲音來源與語系。", "提醒", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // 對應企劃書 3.3：
            // - 系統聲音模式：對「目前預設輸出裝置」做 WasapiLoopbackCapture，不更動任何系統裝置設定。
            // - 麥克風模式：對指定輸入裝置做 WasapiCapture。
            _currentTranscriptFilePath = await _transcriber.StartAsync(source, language);

            _isDictating = true;
            StartStopButton.Content = "停止聽抄";
            AudioSourceComboBox.IsEnabled = false;
            LanguageComboBox.IsEnabled = false;
            StatusText.Text = "聽抄中…";
        }
        else
        {
            // 對應企劃書 2.3：停止前跳出確認、強制寫入未定案內容。
            var confirm = MessageBox.Show("確定要停止聽抄嗎？未定案的內容將會強制寫入檔案。",
                "確認停止", MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (confirm != MessageBoxResult.Yes) return;

            await _transcriber.StopAsync(flushPending: true);

            _isDictating = false;
            StartStopButton.Content = "開始聽抄";
            AudioSourceComboBox.IsEnabled = true;
            LanguageComboBox.IsEnabled = true;
            StatusText.Text = "已停止";
        }
    }

    private void ShowInExplorerButton_Click(object sender, RoutedEventArgs e)
    {
        if (_currentTranscriptFilePath is not null)
        {
            ExplorerActions.ShowFileInExplorer(_currentTranscriptFilePath);
        }
    }

    private async void DictationView_Closing(object? sender, System.ComponentModel.CancelEventArgs e)
    {
        if (_isDictating)
        {
            // 對應企劃書 2.3：容錯強制寫檔，關閉視窗前仍需寫入未定案內容。
            await _transcriber.StopAsync(flushPending: true);
        }
    }
}

/// <summary>簡易 ICommand 實作，供快捷鍵綁定使用。</summary>
internal sealed class RelayCommand : ICommand
{
    private readonly Action<object?> _execute;
    public RelayCommand(Action<object?> execute) => _execute = execute;
    public event EventHandler? CanExecuteChanged { add { } remove { } }
    public bool CanExecute(object? parameter) => true;
    public void Execute(object? parameter) => _execute(parameter);
}

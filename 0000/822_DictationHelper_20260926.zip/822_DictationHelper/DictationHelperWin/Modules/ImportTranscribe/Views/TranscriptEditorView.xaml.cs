using System.Collections.ObjectModel;
using System.Windows.Controls;
using DictationHelperWin.Modules.ImportTranscribe.Models;

namespace DictationHelperWin.Modules.ImportTranscribe.Views;

/// <summary>對應企劃書二、2.2：逐字稿檢視（含時間戳記）。</summary>
public partial class TranscriptEditorView : UserControl
{
    public TranscriptEditorView()
    {
        InitializeComponent();
    }

    public void LoadSegments(ObservableCollection<TranscriptSegment> segments)
    {
        SegmentsListView.ItemsSource = segments;
    }
}

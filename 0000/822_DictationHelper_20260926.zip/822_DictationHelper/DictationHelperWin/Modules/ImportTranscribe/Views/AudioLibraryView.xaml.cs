using System;
using System.Collections.ObjectModel;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using DictationHelperWin.Modules.ImportTranscribe.Models;

namespace DictationHelperWin.Modules.ImportTranscribe.Views;

/// <summary>
/// 對應企劃書二、2.2：音檔清單（狀態＋長度，可新增刪除）。
/// </summary>
public partial class AudioLibraryView : UserControl
{
    public ObservableCollection<AudioFile> Files { get; } = new();

    public AudioFile? SelectedFile => FileListView.SelectedItem as AudioFile;

    /// <summary>當使用者於清單中選取不同音檔時觸發，供 ImportView 更新逐字稿檢視。</summary>
    public event EventHandler<AudioFile>? FileSelected;

    public AudioLibraryView()
    {
        InitializeComponent();
        FileListView.ItemsSource = Files;
    }

    public void AddFiles(IEnumerable<AudioFile> files)
    {
        foreach (var f in files) Files.Add(f);
    }

    private void FileListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (SelectedFile is not null)
            FileSelected?.Invoke(this, SelectedFile);
    }

    private void RemoveMenuItem_Click(object sender, RoutedEventArgs e)
    {
        if (SelectedFile is not null)
            Files.Remove(SelectedFile);
    }
}

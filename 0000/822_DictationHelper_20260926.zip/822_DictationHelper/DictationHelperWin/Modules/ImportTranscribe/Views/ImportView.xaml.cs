using System.Linq;
using System.Windows;
using Microsoft.Win32;
using DictationHelperWin.Modules.ImportTranscribe.Models;
using DictationHelperWin.Modules.ImportTranscribe.Services;

namespace DictationHelperWin.Modules.ImportTranscribe.Views;

/// <summary>
/// 對應企劃書二、2.2：模式一 匯入音檔轉文字稿的主畫面，整合音檔清單與逐字稿檢視。
/// </summary>
public partial class ImportView : Window
{
    private readonly AudioImportService _importService = new();
    private readonly AudioConverterService _converterService = new();
    private readonly SpeechRecognitionService _recognitionService = new();

    public ImportView()
    {
        InitializeComponent();
    }

    /// <summary>對應企劃書 2.2：匯入（Windows 開檔對話框 OpenFileDialog）。</summary>
    private void SelectFilesButton_Click(object sender, RoutedEventArgs e)
    {
        var dialog = new OpenFileDialog
        {
            Multiselect = true,
            Filter = "音訊檔案 (*.mp3;*.m4a;*.wav;*.webm)|*.mp3;*.m4a;*.wav;*.webm"
        };

        if (dialog.ShowDialog() == true)
        {
            var files = _importService.ImportFiles(dialog.FileNames);
            AudioLibrary.AddFiles(files);
        }
    }

    /// <summary>對應企劃書 2.2：拖放匯入。</summary>
    private void ImportView_Drop(object sender, DragEventArgs e)
    {
        if (!e.Data.GetDataPresent(DataFormats.FileDrop)) return;

        var paths = ((string[])e.Data.GetData(DataFormats.FileDrop))
            .Where(_importService.IsSupported);
        var files = _importService.ImportFiles(paths);
        AudioLibrary.AddFiles(files);
    }

    private void AudioLibrary_FileSelected(object? sender, AudioFile file)
    {
        TranscriptEditor.LoadSegments(file.Segments);
    }

    /// <summary>對應企劃書 2.2：匯出 TXT／SRT／DOCX／PDF，可勾選是否含時間戳記。</summary>
    private void ExportButton_Click(object sender, RoutedEventArgs e)
    {
        var selected = AudioLibrary.SelectedFile;
        if (selected is null)
        {
            MessageBox.Show("請先在音檔清單中選擇一個已完成辨識的檔案。", "提醒",
                MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        var exportSheet = new ExportSheetView(selected.Segments);
        exportSheet.Owner = this;
        exportSheet.ShowDialog();
    }

    private void SettingsButton_Click(object sender, RoutedEventArgs e)
    {
        var settings = new SettingsView { Owner = this };
        settings.ShowDialog();
    }
}

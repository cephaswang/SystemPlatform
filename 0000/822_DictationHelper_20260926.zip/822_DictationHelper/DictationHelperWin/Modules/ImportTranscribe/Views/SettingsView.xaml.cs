using System.Windows;
using DictationHelperWin.Shared;

namespace DictationHelperWin.Modules.ImportTranscribe.Views;

/// <summary>
/// 對應企劃書第四章：環境設置畫面（ffmpeg 檢查、語言包捷徑）。
/// </summary>
public partial class SettingsView : Window
{
    public SettingsView()
    {
        InitializeComponent();

        RememberMicCheckBox.IsChecked = App.App.State.RememberLastMicrophone;
        RememberMicCheckBox.Checked += (_, _) => App.App.State.RememberLastMicrophone = true;
        RememberMicCheckBox.Unchecked += (_, _) => App.App.State.RememberLastMicrophone = false;

        RefreshEnvironmentStatus();
    }

    private void RefreshEnvironmentStatus()
    {
        var status = App.App.State.EnvironmentCheck.LastStatus;
        FfmpegStatusText.Text = status is null
            ? "ffmpeg：尚未檢查"
            : $"ffmpeg：{(status.FfmpegOk ? "已就緒" : "找不到，webm 轉檔功能無法使用")}";
        SpeechPackStatusText.Text = status is null
            ? "語音辨識語言包：尚未檢查"
            : $"語音辨識語言包：{(status.SpeechLanguagePackMissing ? "尚未安裝" : "已安裝")}";
    }

    private void OpenSpeechSettingsButton_Click(object sender, RoutedEventArgs e)
    {
        ExplorerActions.OpenWindowsSpeechSettings();
    }

    private void CloseButton_Click(object sender, RoutedEventArgs e)
    {
        Close();
    }
}

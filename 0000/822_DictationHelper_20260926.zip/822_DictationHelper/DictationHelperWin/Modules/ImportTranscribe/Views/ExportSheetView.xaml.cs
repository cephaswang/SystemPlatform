using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;
using DictationHelperWin.Modules.ImportTranscribe.Models;
using DictationHelperWin.Modules.ImportTranscribe.Services;

namespace DictationHelperWin.Modules.ImportTranscribe.Views;

/// <summary>
/// 對應企劃書二、2.2：匯出：TXT／SRT／DOCX／PDF，可勾選是否含時間戳記。
/// </summary>
public partial class ExportSheetView : Window
{
    private readonly IReadOnlyList<TranscriptSegment> _segments;
    private readonly ExportService _exportService = new();

    public ExportSheetView(IReadOnlyList<TranscriptSegment> segments)
    {
        InitializeComponent();
        _segments = segments;
    }

    private async void ExportConfirmButton_Click(object sender, RoutedEventArgs e)
    {
        var format = ((ComboBoxItem)FormatComboBox.SelectedItem).Content!.ToString() switch
        {
            "SRT" => ExportFormat.Srt,
            "DOCX" => ExportFormat.Docx,
            "PDF" => ExportFormat.Pdf,
            _ => ExportFormat.Txt
        };

        var dialog = new SaveFileDialog
        {
            Filter = format switch
            {
                ExportFormat.Srt => "SubRip 字幕 (*.srt)|*.srt",
                ExportFormat.Docx => "Word 文件 (*.docx)|*.docx",
                ExportFormat.Pdf => "PDF 文件 (*.pdf)|*.pdf",
                _ => "純文字檔 (*.txt)|*.txt"
            }
        };

        if (dialog.ShowDialog() != true) return;

        try
        {
            await _exportService.ExportAsync(
                _segments, dialog.FileName, format, IncludeTimestampsCheckBox.IsChecked == true);
            Close();
        }
        catch (System.Exception ex)
        {
            MessageBox.Show($"匯出失敗：{ex.Message}", "錯誤", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }
}

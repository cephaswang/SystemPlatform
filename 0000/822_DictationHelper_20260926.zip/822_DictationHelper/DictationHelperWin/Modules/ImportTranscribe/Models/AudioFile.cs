using System;
using System.Collections.ObjectModel;

namespace DictationHelperWin.Modules.ImportTranscribe.Models;

public enum AudioFileStatus
{
    Pending,
    Converting,
    Transcribing,
    Completed,
    Failed
}

/// <summary>
/// 對應企劃書 2.2：音檔清單（狀態＋長度，可新增刪除）。
/// 支援格式：mp3／m4a／wav／webm（webm 先用 ffmpeg 轉成可辨識格式）。
/// </summary>
public sealed class AudioFile
{
    public required string FilePath { get; init; }
    public string FileName => System.IO.Path.GetFileName(FilePath);
    public TimeSpan Duration { get; set; }
    public AudioFileStatus Status { get; set; } = AudioFileStatus.Pending;
    public string? ConvertedFilePath { get; set; }
    public ObservableCollection<TranscriptSegment> Segments { get; } = new();
}

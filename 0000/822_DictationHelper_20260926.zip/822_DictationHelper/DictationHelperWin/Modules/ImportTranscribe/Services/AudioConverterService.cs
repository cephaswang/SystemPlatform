using System;
using System.Diagnostics;
using System.IO;
using System.Threading.Tasks;

namespace DictationHelperWin.Modules.ImportTranscribe.Services;

/// <summary>
/// 對應企劃書 2.2／3.1：webm 先用 ffmpeg 轉成可辨識格式（如 wav），與 macOS 版相同做法。
/// ffmpeg.exe 內嵌於 Resources/（見 3.4 專案模組拆分）。
/// </summary>
public sealed class AudioConverterService
{
    private static string FfmpegPath => Path.Combine(AppContext.BaseDirectory, "Resources", "ffmpeg.exe");

    public bool NeedsConversion(string filePath) =>
        Path.GetExtension(filePath).Equals(".webm", StringComparison.OrdinalIgnoreCase);

    /// <summary>將 webm 轉為 wav，回傳轉檔後的檔案路徑。</summary>
    public async Task<string> ConvertToWavAsync(string sourceFilePath)
    {
        var outputPath = Path.ChangeExtension(sourceFilePath, ".converted.wav");

        var startInfo = new ProcessStartInfo
        {
            FileName = FfmpegPath,
            Arguments = $"-y -i \"{sourceFilePath}\" -ar 16000 -ac 1 \"{outputPath}\"",
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            UseShellExecute = false,
            CreateNoWindow = true
        };

        using var process = Process.Start(startInfo)
            ?? throw new InvalidOperationException("無法啟動 ffmpeg，請確認 Resources/ffmpeg.exe 是否存在。");

        await process.WaitForExitAsync();
        if (process.ExitCode != 0)
        {
            var error = await process.StandardError.ReadToEndAsync();
            throw new InvalidOperationException($"ffmpeg 轉檔失敗：{error}");
        }

        return outputPath;
    }
}

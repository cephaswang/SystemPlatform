using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using DictationHelperWin.Modules.ImportTranscribe.Models;

namespace DictationHelperWin.Modules.ImportTranscribe.Services;

/// <summary>
/// 對應企劃書 2.2／3.2：匯入音檔的批次辨識服務。
/// 與聽抄模式（SpeechTranscriber）共用同一套 Windows.Media.SpeechRecognition 辨識邏輯，
/// 差異在於輸入來源是檔案而非即時音訊串流（見企劃書 3.4 模組拆分：ImportTranscribe 獨立於 LiveDictation）。
/// </summary>
public sealed class SpeechRecognitionService
{
    /// <summary>對應企劃書 3.2：動態列出目前系統已安裝語言包的語音辨識語系。</summary>
    public IReadOnlyList<string> GetAvailableLanguages()
    {
        return new[] { "中文（繁體，台灣）", "English (United States)", "日本語" };
    }

    /// <summary>
    /// 針對單一（已轉檔為可辨識格式的）音檔進行批次辨識，回傳含時間戳記的逐字稿片段清單。
    /// TODO：實作 Windows.Media.SpeechRecognition.SpeechRecognizer 讀檔辨識流程，
    /// 並依中英文句尾標點斷句組成 TranscriptSegment。
    /// </summary>
    public Task<IReadOnlyList<TranscriptSegment>> TranscribeFileAsync(string filePath, string language)
    {
        IReadOnlyList<TranscriptSegment> placeholder = Array.Empty<TranscriptSegment>();
        return Task.FromResult(placeholder);
    }
}

using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using DictationHelperWin.Modules.ImportTranscribe.Models;

namespace DictationHelperWin.Modules.ImportTranscribe.Services;

public enum ExportFormat { Txt, Srt, Docx, Pdf }

/// <summary>
/// 對應企劃書 2.2：匯出：TXT／SRT／DOCX／PDF，可勾選是否含時間戳記。
/// DOCX 用 OpenXML SDK；PDF 套件選型見第七章待確認事項。
/// </summary>
public sealed class ExportService
{
    public async Task ExportAsync(
        IReadOnlyList<TranscriptSegment> segments,
        string outputPath,
        ExportFormat format,
        bool includeTimestamps)
    {
        switch (format)
        {
            case ExportFormat.Txt:
                await ExportTxtAsync(segments, outputPath, includeTimestamps);
                break;
            case ExportFormat.Srt:
                await ExportSrtAsync(segments, outputPath);
                break;
            case ExportFormat.Docx:
                // TODO：使用 DocumentFormat.OpenXml 產生 .docx（見 csproj 已加入套件參考）。
                throw new System.NotImplementedException("DOCX 匯出待實作（見第七章待確認事項）。");
            case ExportFormat.Pdf:
                // TODO：PDF 產生套件選型待第七章確認後實作。
                throw new System.NotImplementedException("PDF 匯出待實作（見第七章待確認事項）。");
        }
    }

    private static async Task ExportTxtAsync(
        IReadOnlyList<TranscriptSegment> segments, string outputPath, bool includeTimestamps)
    {
        var sb = new StringBuilder();
        foreach (var seg in segments)
        {
            if (includeTimestamps)
                sb.AppendLine($"[{seg.StartTime:hh\\:mm\\:ss}] {seg.Text}");
            else
                sb.AppendLine(seg.Text);
        }
        await File.WriteAllTextAsync(outputPath, sb.ToString(), Encoding.UTF8);
    }

    private static async Task ExportSrtAsync(IReadOnlyList<TranscriptSegment> segments, string outputPath)
    {
        var sb = new StringBuilder();
        var index = 1;
        foreach (var seg in segments)
        {
            sb.AppendLine(index.ToString());
            sb.AppendLine($"{FormatSrtTime(seg.StartTime)} --> {FormatSrtTime(seg.EndTime)}");
            sb.AppendLine(seg.Text);
            sb.AppendLine();
            index++;
        }
        await File.WriteAllTextAsync(outputPath, sb.ToString(), Encoding.UTF8);
    }

    private static string FormatSrtTime(System.TimeSpan t) =>
        $"{t.Hours:00}:{t.Minutes:00}:{t.Seconds:00},{t.Milliseconds:000}";
}

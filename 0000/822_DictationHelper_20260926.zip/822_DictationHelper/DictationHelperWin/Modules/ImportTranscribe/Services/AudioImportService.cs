using System;
using System.Collections.Generic;
using System.IO;
using DictationHelperWin.Modules.ImportTranscribe.Models;

namespace DictationHelperWin.Modules.ImportTranscribe.Services;

/// <summary>
/// 對應企劃書 2.2：匯入：拖放或「選擇檔案」（Windows 開檔對話框 OpenFileDialog）。
/// 支援格式：mp3／m4a／wav／webm。
/// </summary>
public sealed class AudioImportService
{
    private static readonly HashSet<string> SupportedExtensions = new(StringComparer.OrdinalIgnoreCase)
    {
        ".mp3", ".m4a", ".wav", ".webm"
    };

    public bool IsSupported(string filePath) =>
        SupportedExtensions.Contains(Path.GetExtension(filePath));

    /// <summary>將使用者拖放或選擇的檔案路徑轉換為 AudioFile 清單項目。</summary>
    public IReadOnlyList<AudioFile> ImportFiles(IEnumerable<string> filePaths)
    {
        var result = new List<AudioFile>();
        foreach (var path in filePaths)
        {
            if (!IsSupported(path)) continue;

            result.Add(new AudioFile
            {
                FilePath = path,
                // TODO：讀取音檔實際長度（可用 NAudio 的 AudioFileReader / MediaFoundationReader）。
                Duration = TimeSpan.Zero,
                Status = AudioFileStatus.Pending
            });
        }
        return result;
    }
}

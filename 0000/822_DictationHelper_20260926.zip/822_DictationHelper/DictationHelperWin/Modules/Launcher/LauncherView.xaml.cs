using System.Windows;
using DictationHelperWin.Modules.LiveDictation;
using DictationHelperWin.Modules.ImportTranscribe.Views;

namespace DictationHelperWin.Modules.Launcher;

/// <summary>
/// 對應企劃書二、2.1：模式選擇畫面＋環境狀態列。
/// 這是整個 App 的啟動視窗（見 App.xaml 的 StartupUri）。
/// </summary>
public partial class LauncherView : Window
{
    private App.AppState State => Application.Current is App.App app ? App.App.State : App.App.State;

    public LauncherView()
    {
        InitializeComponent();

        // 對應企劃書第四章：訂閱環境檢查結果，更新狀態列文字與「開啟語音設定」按鈕顯示與否。
        App.App.State.EnvironmentCheck.StatusChanged += OnEnvironmentStatusChanged;
    }

    private void OnEnvironmentStatusChanged(object? sender, Shared.EnvironmentSetup.EnvironmentStatus status)
    {
        Dispatcher.Invoke(() =>
        {
            EnvironmentStatusText.Text = status.Summary;
            OpenSpeechSettingsButton.Visibility = status.SpeechLanguagePackMissing
                ? Visibility.Visible
                : Visibility.Collapsed;
        });
    }

    /// <summary>對應企劃書 2.2：切換到「匯入音檔轉文字稿」模式。</summary>
    private void ImportModeButton_Click(object sender, RoutedEventArgs e)
    {
        var importView = new ImportView();
        importView.Show();
        Close();
    }

    /// <summary>對應企劃書 2.3：切換到「聽抄（即時轉錄）」模式。</summary>
    private void LiveDictationModeButton_Click(object sender, RoutedEventArgs e)
    {
        var dictationView = new DictationView();
        dictationView.Show();
        Close();
    }

    /// <summary>
    /// 對應企劃書第四章：語言包缺少時，導引至「設定 → 時間與語言 → 語音」。
    /// </summary>
    private void OpenSpeechSettingsButton_Click(object sender, RoutedEventArgs e)
    {
        Shared.ExplorerActions.OpenWindowsSpeechSettings();
    }

    /// <summary>對應企劃書二、2.1：內建說明頁。</summary>
    private void HelpButton_Click(object sender, RoutedEventArgs e)
    {
        MessageBox.Show(
            "聽抄小幫手使用教學（草稿）：\n" +
            "1. 匯入音檔轉文字稿：拖放或選擇音檔，選擇語系後開始辨識。\n" +
            "2. 聽抄：選擇麥克風或系統聲音（Loopback），即時顯示逐字稿並自動存檔。",
            "說明 / 教學", MessageBoxButton.OK, MessageBoxImage.Information);
    }
}

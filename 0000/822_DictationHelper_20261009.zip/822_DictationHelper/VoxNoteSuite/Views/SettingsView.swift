import SwiftUI

struct SettingsView: View {

    enum RecognitionEngine: String, CaseIterable, Identifiable {
        case appleSpeech = "Apple Speech Framework"
        case whisperLocal = "Whisper（本地端）"
        case whisperCloud = "Whisper（雲端 API）"

        var id: String { rawValue }

        /// 畫面顯示名稱。注意：rawValue 會存進 UserDefaults（@AppStorage），
        /// 不可改成翻譯後的文字，否則使用者既有的設定會失效；顯示一律用 displayName。
        var displayName: String {
            switch self {
            case .appleSpeech: return "Apple Speech Framework"
            case .whisperLocal: return L10n.t("settings.engine.whisperLocal")
            case .whisperCloud: return L10n.t("settings.engine.whisperCloud")
            }
        }
    }

    @EnvironmentObject private var library: AudioLibraryStore

    @AppStorage("selectedLocale") private var selectedLocale: String = L10n.defaultRecognitionLocaleID
    @AppStorage("recognitionEngine") private var recognitionEngine: RecognitionEngine = .appleSpeech
    @AppStorage("shortcutStartImport") private var shortcutStartImport: String = "⌘I"
    @AppStorage("shortcutExport") private var shortcutExport: String = "⌘E"

    private let availableLocales = ["zh-TW", "zh-CN", "en-US", "en-GB", "ja-JP"]

    var body: some View {
        let _ = print("🖼️ [\(Self.self)] body (\(#fileID))")
        
        TabView {
            generalTab
                .tabItem { Label("settings.tab.general", systemImage: "gearshape") }

            shortcutsTab
                .tabItem { Label("settings.tab.shortcuts", systemImage: "keyboard") }
        }
        .padding(20)
        .frame(width: 420, height: 260)
    }

    private var generalTab: some View {
        Form {
            Picker("settings.locale", selection: $selectedLocale) {
                ForEach(availableLocales, id: \.self) { locale in
                    Text(verbatim: L10n.recognitionLocaleName(locale)).tag(locale)
                }
            }

            // Whisper（本地端／雲端 API）尚未實作，暫時不顯示辨識引擎選項；
            // 目前一律使用 Apple Speech Framework。列舉的 case 保留，日後實作時再放回選單。
        }
        .padding(.top, 12)
        .onAppear {
            // 若先前殘留了 Whisper 的設定值，重設回可用的引擎
            if recognitionEngine != .appleSpeech { recognitionEngine = .appleSpeech }
        }
    }

    private var shortcutsTab: some View {
        Form {
            TextField("settings.shortcut.import", text: $shortcutStartImport)
            TextField("settings.shortcut.export", text: $shortcutExport)

            Text("settings.shortcut.note")
                .font(.caption)
                .foregroundColor(.secondary)
        }
        .padding(.top, 12)
    }
}

#Preview {
    SettingsView()
        .environmentObject(AudioLibraryStore())
}

#!/usr/bin/env bash
#
# YTGrab — 路線 A：Developer ID 簽章 + 公證 + 製作 DMG
#
# 用法：
#   SIGN_IDENTITY="Developer ID Application: Your Name (TEAMID)" \
#   NOTARY_PROFILE="ytgrab-notary" \
#   ./scripts/sign-and-notarize.sh
#
# 事前準備：
#   1. 鑰匙圈內已有「Developer ID Application」憑證
#   2. 儲存過公證憑證（只需做一次）：
#        xcrun notarytool store-credentials "ytgrab-notary" \
#          --apple-id "you@example.com" --team-id "TEAMID" --password "<app-specific password>"
#   3. Vendor/ 內已放好 yt-dlp_macos、ffmpeg、deno（見下方）
#   4. Xcode 專案已設定 Copy Files：Destination = Wrapper，Subpath = Contents/Helpers，
#      並且 Run Script（簽章）在 CODE_SIGNING_ALLOWED=NO 時必須直接略過
#
# 可用環境變數（皆有預設值）：
#   PROJECT, SCHEME, APP_NAME, BUILD_DIR, VENDOR_DIR
#   APP_ENTITLEMENTS   主程式 entitlements（沒有此檔就不帶 --entitlements）
#   HELPER_ENT_DIR     helper entitlements 目錄，預設 Vendor/entitlements/direct/
#                      依序尋找 <檔名>.entitlements、_default.entitlements，都沒有就不帶
#                      （yt-dlp_macos 為 PyInstaller 包裝，Hardened Runtime 下通常需要
#                       com.apple.security.cs.disable-library-validation；deno 可能需要
#                       com.apple.security.cs.allow-jit。以「試跑」步驟的結果為準）
#
# 本腳本不會修改專案檔；產物在 build/release/。

set -euo pipefail

# 從腳本所在位置往上找專案根目錄（含 YTGrab.xcodeproj 的資料夾）。
# 放在 scripts/ 或 YTGrab/docs/ 都可以，從哪個目錄執行也都可以。
find_project_root() {
  local dir
  dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
  while [ "$dir" != "/" ]; do
    if [ -d "$dir/YTGrab.xcodeproj" ]; then
      echo "$dir"
      return 0
    fi
    dir="$(dirname "$dir")"
  done
  return 1
}

ROOT="$(find_project_root)" || { echo "找不到 YTGrab.xcodeproj（請確認腳本放在專案資料夾內）" >&2; exit 1; }
PROJECT="${PROJECT:-$ROOT/YTGrab.xcodeproj}"
SCHEME="${SCHEME:-YTGrab}"
APP_NAME="${APP_NAME:-YTGrab}"
BUILD_DIR="${BUILD_DIR:-$ROOT/build/release}"
VENDOR_DIR="${VENDOR_DIR:-$ROOT/Vendor}"
APP_ENTITLEMENTS="${APP_ENTITLEMENTS:-$ROOT/YTGrab/YTGrab.entitlements}"
HELPER_ENT_DIR="${HELPER_ENT_DIR:-$VENDOR_DIR/entitlements/direct}"

: "${SIGN_IDENTITY:?請設定 SIGN_IDENTITY（例如 Developer ID Application: Your Name (TEAMID)）}"
: "${NOTARY_PROFILE:?請設定 NOTARY_PROFILE（xcrun notarytool store-credentials 建立的名稱）}"

ARCHIVE="$BUILD_DIR/$APP_NAME.xcarchive"
APP="$BUILD_DIR/$APP_NAME.app"
HELPERS_DIR="$APP/Contents/Helpers"

log()  { printf '\n\033[1;34m▶ %s\033[0m\n' "$*"; }
warn() { printf '\033[1;33m⚠ %s\033[0m\n' "$*" >&2; }
die()  { printf '\033[1;31m✖ %s\033[0m\n' "$*" >&2; exit 1; }
need() { command -v "$1" >/dev/null 2>&1 || die "找不到指令：$1"; }

for cmd in xcodebuild codesign xcrun ditto hdiutil file spctl; do need "$cmd"; done

helper_entitlements() {
  local name="$1"
  if [[ -f "$HELPER_ENT_DIR/$name.entitlements" ]]; then
    echo "$HELPER_ENT_DIR/$name.entitlements"
  elif [[ -f "$HELPER_ENT_DIR/_default.entitlements" ]]; then
    echo "$HELPER_ENT_DIR/_default.entitlements"
  fi
}

# 送公證並等待結果；只有 status: Accepted 才算成功
notarize() {
  local file="$1" out
  out="$(xcrun notarytool submit "$file" --keychain-profile "$NOTARY_PROFILE" --wait 2>&1)" || true
  printf '%s\n' "$out"
  if ! grep -q "status: Accepted" <<<"$out"; then
    local id
    id="$(grep -m1 -Eo 'id: [0-9a-f-]{36}' <<<"$out" | awk '{print $2}' || true)"
    [[ -n "$id" ]] && warn "查看詳細記錄：xcrun notarytool log $id --keychain-profile $NOTARY_PROFILE"
    die "公證未通過：$file"
  fi
}

# ---------------------------------------------------------------- 1. 檢查
log "檢查內建執行檔"
[[ -d "$VENDOR_DIR" ]] || die "找不到 $VENDOR_DIR"
ls "$VENDOR_DIR"/yt-dlp* >/dev/null 2>&1 || die "Vendor/ 內缺少 yt-dlp（yt-dlp_macos）"
[[ -f "$VENDOR_DIR/ffmpeg" ]] || die "Vendor/ 內缺少 ffmpeg"
[[ -f "$VENDOR_DIR/deno"   ]] || warn "Vendor/ 內沒有 deno，YouTube 可能無法取得完整格式"
[[ -f "$APP_ENTITLEMENTS"  ]] || warn "找不到 $APP_ENTITLEMENTS，主程式將不帶 entitlements 簽章"

# ---------------------------------------------------------------- 2. Archive（不簽章）
log "建置 Release（不簽章，稍後手動簽）"
rm -rf "$BUILD_DIR"
mkdir -p "$BUILD_DIR"
xcodebuild archive \
  -project "$PROJECT" \
  -scheme "$SCHEME" \
  -configuration Release \
  -destination 'generic/platform=macOS' \
  -archivePath "$ARCHIVE" \
  CODE_SIGNING_ALLOWED=NO \
  CODE_SIGN_IDENTITY="" \
  ENABLE_HARDENED_RUNTIME=YES

SRC_APP="$ARCHIVE/Products/Applications/$APP_NAME.app"
[[ -d "$SRC_APP" ]] || die "Archive 內找不到 $APP_NAME.app"
ditto "$SRC_APP" "$APP"

# ---------------------------------------------------------------- 3. 簽 helper（由內而外）
[[ -d "$HELPERS_DIR" ]] || die "App 內沒有 Contents/Helpers，請確認 Xcode 的 Copy Files 設定"

log "簽署 Helpers"
signed=0
while IFS= read -r -d '' f; do
  if [[ "$(file -b "$f")" == *Mach-O* ]]; then
    ent="$(helper_entitlements "$(basename "$f")")"
    args=(--force --options runtime --timestamp --sign "$SIGN_IDENTITY")
    if [[ -n "$ent" ]]; then
      args+=(--entitlements "$ent")
    fi
    echo "  • $(basename "$f")${ent:+  (entitlements: $(basename "$ent"))}"
    codesign "${args[@]}" "$f"
    signed=$((signed + 1))
  fi
done < <(find "$HELPERS_DIR" -type f -print0)
[[ "$signed" -gt 0 ]] || die "Contents/Helpers 內沒有找到任何 Mach-O 執行檔"
# 註：目前的 helper 都是單一檔案。若日後改用含多個 dylib 的資料夾版本，需改成由深到淺簽署。

# ---------------------------------------------------------------- 4. 簽主程式
log "簽署主程式"
app_args=(--force --options runtime --timestamp --sign "$SIGN_IDENTITY")
if [[ -f "$APP_ENTITLEMENTS" ]]; then
  app_args+=(--entitlements "$APP_ENTITLEMENTS")
fi
codesign "${app_args[@]}" "$APP"

log "驗證簽章"
codesign --verify --deep --strict --verbose=2 "$APP"

# ---------------------------------------------------------------- 5. 試跑（簽章後 helper 是否還能執行）
log "試跑 helpers"
smoke() {
  local f="$1" name
  name="$(basename "$f")"
  case "$name" in
    yt-dlp*)       "$f" --version >/dev/null 2>&1 ;;
    ffmpeg|ffprobe) "$f" -version >/dev/null 2>&1 ;;
    deno)          "$f" --version >/dev/null 2>&1 ;;
    *)             return 0 ;;
  esac
}
for f in "$HELPERS_DIR"/*; do
  [[ -f "$f" ]] || continue
  if smoke "$f"; then
    echo "  ✓ $(basename "$f")"
  else
    die "簽章後無法執行：$(basename "$f")（檢查 helper 的 entitlements，例如 disable-library-validation / allow-jit）"
  fi
done

# ---------------------------------------------------------------- 6. 公證 App
log "公證 App"
ZIP="$BUILD_DIR/$APP_NAME-notarize.zip"
ditto -c -k --keepParent "$APP" "$ZIP"
notarize "$ZIP"
xcrun stapler staple "$APP"
xcrun stapler validate "$APP"
spctl -a -vv "$APP"
rm -f "$ZIP"

# ---------------------------------------------------------------- 7. DMG
VERSION="$(/usr/libexec/PlistBuddy -c 'Print CFBundleShortVersionString' "$APP/Contents/Info.plist" 2>/dev/null || echo "0.0.0")"
DMG="$BUILD_DIR/$APP_NAME-$VERSION.dmg"

log "製作 DMG：$(basename "$DMG")"
STAGING="$BUILD_DIR/dmg-staging"
rm -rf "$STAGING"
mkdir -p "$STAGING"
ditto "$APP" "$STAGING/$APP_NAME.app"
ln -s /Applications "$STAGING/Applications"
hdiutil create -volname "$APP_NAME" -srcfolder "$STAGING" -ov -format UDZO "$DMG"
rm -rf "$STAGING"

codesign --force --timestamp --sign "$SIGN_IDENTITY" "$DMG"

log "公證 DMG"
notarize "$DMG"
xcrun stapler staple "$DMG"
spctl -a -t open --context context:primary-signature -vv "$DMG"

log "完成"
echo "  App：$APP"
echo "  DMG：$DMG"

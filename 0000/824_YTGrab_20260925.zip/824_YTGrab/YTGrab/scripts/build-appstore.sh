#!/usr/bin/env bash
#
# YTGrab — 路線 B：Mac App Store 封存與匯出（.pkg）
#
# 用法：
#   TEAM_ID="XXXXXXXXXX" ./scripts/build-appstore.sh
#
# 事前準備：
#   1. Xcode 已登入開發者帳號，且該 Team 可建立 Mac App Store 的發行憑證與描述檔
#      （本腳本使用自動簽署與 -allowProvisioningUpdates）
#   2. 專案設定：
#        - Copy Files：Destination = Wrapper，Subpath = Contents/Helpers
#        - App Sandbox 已啟用，YTGrab.entitlements 內至少有
#            com.apple.security.app-sandbox
#            com.apple.security.network.client
#            com.apple.security.files.user-selected.read-write
#        - Copy Files 之後加一個 Run Script 階段，用 sandbox + inherit 的 entitlements 簽 helper：
#
#            [ -n "$EXPANDED_CODE_SIGN_IDENTITY" ] || exit 0
#            HELPERS="$CODESIGNING_FOLDER_PATH/Contents/Helpers"
#            [ -d "$HELPERS" ] || exit 0
#            for f in "$HELPERS"/*; do
#              codesign --force --options runtime --timestamp \
#                --sign "$EXPANDED_CODE_SIGN_IDENTITY" \
#                --entitlements "$SRCROOT/Vendor/entitlements/appstore/_default.entitlements" "$f"
#            done
#
#          Vendor/entitlements/appstore/_default.entitlements 內容：
#            com.apple.security.app-sandbox = true
#            com.apple.security.inherit     = true
#          （yt-dlp_macos、deno 是否還需要 disable-library-validation / allow-jit，
#            須在 Sandbox 下實測；若上架版無法執行，就是路線 B 的阻礙之一。）
#   3. 本腳本會以編譯條件 APPSTORE 建置，關閉 YTDLPUpdater 的更新程式碼（Guideline 2.5.2）
#
# 可用環境變數：
#   PROJECT, SCHEME, APP_NAME, BUILD_DIR, EXPORT_OPTIONS
#
# 產物：build/appstore/export/*.pkg。上傳請用 Transporter；或把 ExportOptions-appstore.plist
# 的 destination 改成 upload，匯出時就會直接上傳到 App Store Connect。

set -euo pipefail

# 從腳本所在位置往上找專案根目錄（含 YTGrab.xcodeproj 的資料夾）。
# 放在 scripts/ 或 YTGrab/docs/ 都可以，從哪個目錄執行也都可以。
find_project_root() {
  local dir
  dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
  while [ "$dir" != "/" ]; do
    if [ -d "$dir/YTGrab.xcodeproj" ]; then
      echo "$dir"
      return 0
    fi
    dir="$(dirname "$dir")"
  done
  return 1
}

ROOT="$(find_project_root)" || { echo "找不到 YTGrab.xcodeproj（請確認腳本放在專案資料夾內）" >&2; exit 1; }
PROJECT="${PROJECT:-$ROOT/YTGrab.xcodeproj}"
SCHEME="${SCHEME:-YTGrab}"
APP_NAME="${APP_NAME:-YTGrab}"
BUILD_DIR="${BUILD_DIR:-$ROOT/build/appstore}"
EXPORT_OPTIONS="${EXPORT_OPTIONS:-$ROOT/scripts/ExportOptions-appstore.plist}"

: "${TEAM_ID:?請設定 TEAM_ID（10 碼 Team ID）}"

ARCHIVE="$BUILD_DIR/$APP_NAME.xcarchive"
APP="$ARCHIVE/Products/Applications/$APP_NAME.app"
HELPERS_DIR="$APP/Contents/Helpers"
EXPORT_DIR="$BUILD_DIR/export"
RESOLVED_PLIST="$BUILD_DIR/ExportOptions.resolved.plist"

log()  { printf '\n\033[1;34m▶ %s\033[0m\n' "$*"; }
warn() { printf '\033[1;33m⚠ %s\033[0m\n' "$*" >&2; }
die()  { printf '\033[1;31m✖ %s\033[0m\n' "$*" >&2; exit 1; }
need() { command -v "$1" >/dev/null 2>&1 || die "找不到指令：$1"; }

for cmd in xcodebuild codesign file strings pkgutil; do need "$cmd"; done
[[ -f "$EXPORT_OPTIONS" ]] || die "找不到 $EXPORT_OPTIONS"

entitlements_of() { codesign -d --entitlements :- "$1" 2>/dev/null || true; }

# ---------------------------------------------------------------- 1. Archive
log "封存（編譯條件 APPSTORE）"
rm -rf "$BUILD_DIR"
mkdir -p "$BUILD_DIR"
xcodebuild archive \
  -project "$PROJECT" \
  -scheme "$SCHEME" \
  -configuration Release \
  -destination 'generic/platform=macOS' \
  -archivePath "$ARCHIVE" \
  -allowProvisioningUpdates \
  DEVELOPMENT_TEAM="$TEAM_ID" \
  CODE_SIGN_STYLE=Automatic \
  ENABLE_APP_SANDBOX=YES \
  ENABLE_HARDENED_RUNTIME=YES \
  SWIFT_ACTIVE_COMPILATION_CONDITIONS='$(inherited) APPSTORE'

[[ -d "$APP" ]] || die "Archive 內找不到 $APP_NAME.app"

# ---------------------------------------------------------------- 2. 送審前檢查
log "檢查：Sandbox 與 helper entitlements"
app_ents="$(entitlements_of "$APP")"
grep -q 'com.apple.security.app-sandbox' <<<"$app_ents" \
  || die "主程式沒有啟用 App Sandbox"

[[ -d "$HELPERS_DIR" ]] || die "App 內沒有 Contents/Helpers，請確認 Xcode 的 Copy Files 設定"

checked=0
while IFS= read -r -d '' f; do
  if [[ "$(file -b "$f")" == *Mach-O* ]]; then
    ents="$(entitlements_of "$f")"
    grep -q 'com.apple.security.app-sandbox' <<<"$ents" \
      || die "helper 沒有 app-sandbox：$(basename "$f")（檢查 Run Script 簽章階段）"
    grep -q 'com.apple.security.inherit' <<<"$ents" \
      || die "helper 沒有 com.apple.security.inherit：$(basename "$f")"
    echo "  ✓ $(basename "$f")"
    checked=$((checked + 1))
  fi
done < <(find "$HELPERS_DIR" -type f -print0)
[[ "$checked" -gt 0 ]] || die "Contents/Helpers 內沒有找到任何 Mach-O 執行檔"

log "檢查：必要 helper 是否存在"
ls "$HELPERS_DIR"/yt-dlp* >/dev/null 2>&1 || die "缺少 yt-dlp"
[[ -f "$HELPERS_DIR/ffmpeg" ]] || die "缺少 ffmpeg"
[[ -f "$HELPERS_DIR/deno"   ]] || warn "沒有 deno，YouTube 可能無法取得完整格式"

log "檢查：上架版不得含 yt-dlp 自我更新程式碼（Guideline 2.5.2）"
EXEC_NAME="$(/usr/libexec/PlistBuddy -c 'Print CFBundleExecutable' "$APP/Contents/Info.plist")"
# 不用 grep -q：pipefail 下 grep 提前結束會讓 strings 收到 SIGPIPE，造成誤判
update_hits="$(strings -a "$APP/Contents/MacOS/$EXEC_NAME" | grep -c 'api.github.com/repos/yt-dlp' || true)"
if [[ "${update_hits:-0}" -gt 0 ]]; then
  die "執行檔內仍有 yt-dlp 更新網址；確認 Build Settings 的 Active Compilation Conditions 有 APPSTORE"
fi
echo "  ✓ 未發現更新用網址"

# ---------------------------------------------------------------- 3. 匯出
log "匯出 .pkg"
sed "s/__TEAM_ID__/$TEAM_ID/g" "$EXPORT_OPTIONS" > "$RESOLVED_PLIST"
xcodebuild -exportArchive \
  -archivePath "$ARCHIVE" \
  -exportPath "$EXPORT_DIR" \
  -exportOptionsPlist "$RESOLVED_PLIST" \
  -allowProvisioningUpdates

PKG="$(find "$EXPORT_DIR" -maxdepth 1 -name '*.pkg' -print -quit)"
if [[ -n "$PKG" ]]; then
  log "驗證 .pkg 簽章"
  pkgutil --check-signature "$PKG"
  echo
  echo "產物：$PKG"
  echo "上傳：使用 Transporter，或將 ExportOptions-appstore.plist 的 destination 改為 upload"
else
  warn "匯出目錄內沒有 .pkg（若 destination 設為 upload，這是正常的）"
fi

log "完成"
echo "提醒：送審前請確認 App Review Information → Notes 已貼上企劃案第八章的回覆稿，"
echo "      且 5.2.3（下載第三方平台媒體）的處理方式已決定。"

確認 Xcode.app 已安裝到 Finder /Applications 確認有 Xcode.app（不是只有命令列工具）。如果沒有，先從 App Store 或 developer.apple.com 下載安裝 Xcode。

切換 xcode-select 指向完整 Xcode在終端機執行：sudo xcode-select --switch /Applications/Xcode.app/Contents/Developer 會要求輸入你的 Mac 密碼（是你自己電腦的登入密碼，不是 Apple ID）。之後可用 xcode-select -p 確認路徑已經改成 /Applications/Xcode.app/Contents/Developer。

回到專案根目錄再執行腳本你剛剛是在 .../824_YTGrab/YTGrab/docs 這一層執行的，但 YTGrab.xcodeproj 在上兩層（.../824_YTGrab/），xcodebuild 找不到專案檔。先 cd 到有 YTGrab.xcodeproj 的那一層，例如：cd /Users/admin/Documents/workspace/824_YTGrab，再執行 bash YTGrab/docs/build-unsigned.sh，或把腳本移到專案根目錄後執行。

照這三步做完後,再跑一次 bash build-unsigned.sh(注意要在有 YTGrab.xcodeproj 的那一層執行,不是 docs 資料夾裡)應該就能正常 Archive 了。如果切換完 Xcode 後還有錯誤,把新的錯誤訊息貼給我。


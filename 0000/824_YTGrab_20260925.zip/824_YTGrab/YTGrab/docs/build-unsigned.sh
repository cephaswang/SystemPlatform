#!/bin/bash
# YTGrab 打包腳本（未簽章版）：Archive -> 匯出 .app -> 打包 dmg
# 不做 code signing / notarization，使用者開啟時會看到 Gatekeeper 警告，
# 需自行右鍵開啟或執行 xattr -cr 才能執行（見腳本最下方說明，可附給使用者）。

set -euo pipefail

# 從腳本所在位置往上找專案根目錄（含 YTGrab.xcodeproj 的資料夾）。
# 放在 scripts/ 或 YTGrab/docs/ 都可以，從哪個目錄執行也都可以。
find_project_root() {
  local dir
  dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
  while [ "$dir" != "/" ]; do
    if [ -d "$dir/YTGrab.xcodeproj" ]; then
      echo "$dir"
      return 0
    fi
    dir="$(dirname "$dir")"
  done
  return 1
}

ROOT="$(find_project_root)" || { echo "找不到 YTGrab.xcodeproj（請確認腳本放在專案資料夾內）" >&2; exit 1; }
cd "${ROOT}"

# 可選：ADHOC_SIGN_HELPERS=1 ./scripts/build-unsigned.sh
#   對 Contents/Helpers 內的執行檔做 ad-hoc 簽章（Apple Silicon 不允許執行完全未簽章的 arm64 程式）。
#   官方 yt-dlp_macos 通常已有 ad-hoc 簽章；若下方「試跑」失敗再開啟此選項。

# ========== 設定區 ==========
APP_NAME="YTGrab"
SCHEME="YTGrab"
PROJECT="YTGrab.xcodeproj"

BUILD_DIR="./build"
ARCHIVE_PATH="${BUILD_DIR}/${APP_NAME}.xcarchive"
EXPORT_PATH="${BUILD_DIR}/export"
APP_PATH="${EXPORT_PATH}/${APP_NAME}.app"
DMG_PATH="${BUILD_DIR}/${APP_NAME}.dmg"
EXPORT_OPTIONS_PLIST="${BUILD_DIR}/ExportOptions.plist"
# =============================

mkdir -p "${BUILD_DIR}"

echo "==> 1. 產生 ExportOptions.plist（若尚未存在，設定為不簽章）"
if [ ! -f "${EXPORT_OPTIONS_PLIST}" ]; then
  cat > "${EXPORT_OPTIONS_PLIST}" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>method</key>
    <string>developer-id</string>
    <key>signingStyle</key>
    <string>manual</string>
    <key>signingCertificate</key>
    <string>-</string>
</dict>
</plist>
EOF
fi

echo "==> 2. Archive（Debug/Release 皆可，這裡用 Release）"
xcodebuild -project "${PROJECT}" -scheme "${SCHEME}" \
  -configuration Release \
  CODE_SIGN_IDENTITY="" CODE_SIGNING_REQUIRED=NO CODE_SIGNING_ALLOWED=NO \
  -archivePath "${ARCHIVE_PATH}" archive

echo "==> 3. 直接從 archive 取出 .app（不走 exportArchive，避免要求簽章）"
rm -rf "${EXPORT_PATH}"
mkdir -p "${EXPORT_PATH}"
cp -R "${ARCHIVE_PATH}/Products/Applications/${APP_NAME}.app" "${EXPORT_PATH}/"

echo "==> 3.5 檢查內建 helper（Contents/Helpers）"
HELPERS_DIR="${APP_PATH}/Contents/Helpers"
if [ ! -d "${HELPERS_DIR}" ]; then
  echo "  ⚠ App 內沒有 Contents/Helpers：yt-dlp / ffmpeg / deno 未內建。"
  echo "    使用者需自行安裝（例如 Homebrew），並在設定頁指定路徑。"
  echo "    要內建：把執行檔放進 Vendor/，並在 Xcode 加 Copy Files（Destination = Wrapper，Subpath = Contents/Helpers）"
else
  for f in "${HELPERS_DIR}"/*; do
    [ -f "$f" ] || continue
    name="$(basename "$f")"
    if [ "${ADHOC_SIGN_HELPERS:-0}" = "1" ] && [[ "$(file -b "$f")" == *Mach-O* ]]; then
      codesign --force --sign - "$f"
    fi
    case "$name" in
      yt-dlp*|deno)   probe_args="--version" ;;
      ffmpeg|ffprobe) probe_args="-version" ;;
      *)              continue ;;
    esac
    if "$f" $probe_args >/dev/null 2>&1; then
      echo "  ✓ $name"
    else
      echo "  ⚠ $name 無法執行（可試 ADHOC_SIGN_HELPERS=1）"
    fi
  done
fi

# 企劃案、腳本等內部文件不應該進到 App 內（若 docs/ 還在 YTGrab/ 資料夾內，會被 Xcode 一起打包）
leaked="$(find "${APP_PATH}/Contents/Resources" -maxdepth 2 \
  \( -name '*企劃案*' -o -name 'build-unsigned.sh' -o -name 'ExportOptions.plist' -o -name 'readme.txt' \) \
  | wc -l | tr -d ' ')"
if [ "${leaked}" -gt 0 ]; then
  echo "  ⚠ App 的 Resources 內含 ${leaked} 個內部文件（企劃案 / 腳本）。"
  echo "    請把 docs/ 移出 YTGrab/ 資料夾，只留下 YTGrabHelp.html。"
fi

echo "==> 4. 打包成 dmg"
rm -f "${DMG_PATH}"
hdiutil create -volname "${APP_NAME}" -srcfolder "${EXPORT_PATH}" \
  -ov -format UDZO "${DMG_PATH}"

echo ""
echo "完成！可發佈的檔案：${DMG_PATH}"
echo "（未簽章、未公證，使用者開啟時會看到安全性警告，請把下方說明一併附給使用者）"
echo ""
echo "======================================================"
echo "給使用者的開啟方式（因為 App 未經過 Apple 公證）："
echo ""
echo "方法一（推薦，圖形介面）："
echo "  1. 把 App 拖進「應用程式」資料夾"
echo "  2. 在 Finder 中「按住 Control 點一下」App 圖示（或滑鼠右鍵）"
echo "  3. 選單選「打開」，跳出的警告視窗中再按一次「打開」"
echo "  （之後就能正常雙擊開啟，不會再跳這個警告）"
echo ""
echo "方法二（終端機指令，一次解決）："
echo "  xattr -cr /Applications/${APP_NAME}.app"
echo "======================================================"

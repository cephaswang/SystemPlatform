import SwiftUI
internal import UniformTypeIdentifiers

struct URLInputView: View {
    @EnvironmentObject private var appState: AppState
    @State private var urlText: String = ""

    var body: some View {
        HStack {
            TextField("貼上或拖曳影片網址…", text: $urlText)
                .textFieldStyle(.roundedBorder)
                .onSubmit { fetch() }

            Button("解析") { fetch() }
                .disabled(urlText.trimmingCharacters(in: .whitespaces).isEmpty || appState.isFetchingInfo)
        }
        .onDrop(of: [.url, .text], isTargeted: nil) { providers in
            guard let provider = providers.first else { return false }
            _ = provider.loadObject(ofClass: URL.self) { url, _ in
                if let url {
                    DispatchQueue.main.async {
                        urlText = url.absoluteString
                        fetch()
                    }
                }
            }
            return true
        }
    }

    private func fetch() {
        let trimmed = urlText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }
        Task { await appState.fetchInfo(for: trimmed) }
    }
}

import SwiftUI
import AppKit
internal import UniformTypeIdentifiers

/// 播放列表畫面：列出所有項目，讓使用者勾選後，用同一組畫質設定批次加入下載佇列。
struct PlaylistView: View {
    let playlist: PlaylistInfo

    @EnvironmentObject private var appState: AppState

    /// 用 playlistIndex（清單中的順序）當識別，而不是影片 id：
    /// 同一支影片可能在清單裡出現兩次，用 id 會讓勾選狀態互相干擾。
    @State private var selectedIndexes: Set<Int>
    @State private var preset: DownloadPreset = .best
    @State private var useSubfolder = true
    @State private var lastEnqueuedCount: Int?
    @State private var lastExportedURL: URL?
    @State private var exportErrorMessage: String?

    /// 純文字列表的內容格式
    enum TextExportStyle: String, CaseIterable, Identifiable {
        case titlesAndURLs = "標題與網址"
        case urlsOnly = "僅網址"
        case titlesOnly = "僅標題"

        var id: String { rawValue }

        func render(_ entries: [PlaylistEntry]) -> String {
            switch self {
            case .urlsOnly:
                // 一行一個網址，可直接給 `yt-dlp -a 檔案.txt` 使用
                return entries.compactMap(\.videoURL).joined(separator: "\n") + "\n"
            case .titlesOnly:
                return entries.map(\.title).joined(separator: "\n") + "\n"
            case .titlesAndURLs:
                return entries
                    .map { "\($0.playlistIndex). \($0.title)\n\($0.videoURL ?? "")" }
                    .joined(separator: "\n\n") + "\n"
            }
        }
    }

    /// 批次下載沒辦法逐支挑 format_id，改用 yt-dlp 的格式選擇語法做「上限」。
    enum DownloadPreset: String, CaseIterable, Identifiable {
        case best = "最佳畫質"
        case p1080 = "1080p 以下"
        case p720 = "720p 以下"
        case p480 = "480p 以下"
        case audioOnly = "僅音訊"

        var id: String { rawValue }

        /// nil 代表交給 YTDLPClient 預設的 bestvideo+bestaudio/best
        var formatSelector: String? {
            switch self {
            case .best: return nil
            case .p1080: return "bestvideo[height<=1080]+bestaudio/best[height<=1080]"
            case .p720: return "bestvideo[height<=720]+bestaudio/best[height<=720]"
            case .p480: return "bestvideo[height<=480]+bestaudio/best[height<=480]"
            case .audioOnly: return "bestaudio"
            }
        }
    }

    init(playlist: PlaylistInfo) {
        self.playlist = playlist
        // 預設勾選所有可下載的項目
        _selectedIndexes = State(
            initialValue: Set(playlist.entries.filter(\.isAvailable).map(\.playlistIndex))
        )
    }

    private var availableEntries: [PlaylistEntry] {
        playlist.entries.filter(\.isAvailable)
    }

    private var unavailableCount: Int {
        playlist.entries.count - availableEntries.count
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            header
            controls

            List(playlist.entries, id: \.playlistIndex) { entry in
                row(for: entry)
            }
            .frame(minHeight: 200)

            footer
        }
    }

    // MARK: - Header / Controls

    private var header: some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(playlist.title ?? "播放列表")
                .font(.headline)
                .lineLimit(2)

            Text(headerSubtitle)
                .font(.subheadline)
                .foregroundStyle(.secondary)
        }
    }

    private var headerSubtitle: String {
        var parts: [String] = []
        if let uploader = playlist.uploader { parts.append(uploader) }
        parts.append("共 \(playlist.entries.count) 支")
        if unavailableCount > 0 { parts.append("\(unavailableCount) 支無法下載") }
        return parts.joined(separator: " · ")
    }

    private var controls: some View {
        HStack(spacing: 12) {
            Button("全選") {
                selectedIndexes = Set(availableEntries.map(\.playlistIndex))
            }
            Button("全不選") {
                selectedIndexes.removeAll()
            }
            Text("已選 \(selectedIndexes.count) / \(availableEntries.count)")
                .font(.caption)
                .foregroundStyle(.secondary)

            Spacer()

            Picker("畫質", selection: $preset) {
                ForEach(DownloadPreset.allCases) { preset in
                    Text(preset.rawValue).tag(preset)
                }
            }
            .pickerStyle(.menu)
            .fixedSize()
        }
    }

    private var footer: some View {
        VStack(alignment: .leading, spacing: 8) {
            // 只要列表、不下載影片：匯出成純文字檔
            HStack(spacing: 10) {
                Menu("匯出文字檔…") {
                    ForEach(TextExportStyle.allCases) { style in
                        Button(style.rawValue) { exportText(style) }
                    }
                }
                .fixedSize()
                .disabled(selectedIndexes.isEmpty)

                if let exportError = exportErrorMessage {
                    Text("匯出失敗：\(exportError)")
                        .font(.caption)
                        .foregroundStyle(.red)
                } else if let url = lastExportedURL {
                    Text("已匯出 \(url.lastPathComponent)")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    Button("在 Finder 顯示") {
                        FinderActions.reveal(file: url, fallbackDirectory: url.deletingLastPathComponent())
                    }
                    .buttonStyle(.link)
                    .font(.caption)
                }

                Spacer()
            }

            HStack {
                Toggle("存進以播放列表命名的資料夾", isOn: $useSubfolder)
                    .toggleStyle(.checkbox)

                Spacer()

                if let count = lastEnqueuedCount {
                    Text("已加入 \(count) 個任務")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    Button("開啟下載資料夾") {
                        FinderActions.openDirectory(currentOutputDirectory)
                    }
                    .buttonStyle(.link)
                    .font(.caption)
                }

                Button("加入下載佇列（\(selectedIndexes.count)）") { enqueueSelected() }
                    .buttonStyle(.borderedProminent)
                    .disabled(selectedIndexes.isEmpty)
            }
        }
    }

    // MARK: - Row

    private func row(for entry: PlaylistEntry) -> some View {
        HStack(spacing: 10) {
            Toggle("", isOn: binding(for: entry))
                .toggleStyle(.checkbox)
                .labelsHidden()
                .disabled(!entry.isAvailable)

            Text("\(entry.playlistIndex)")
                .font(.caption.monospacedDigit())
                .foregroundStyle(.secondary)
                .frame(width: 30, alignment: .trailing)

            AsyncImage(url: entry.thumbnailURL.flatMap(URL.init(string:))) { image in
                image.resizable().aspectRatio(contentMode: .fill)
            } placeholder: {
                Color.gray.opacity(0.2)
            }
            .frame(width: 64, height: 36)
            .clipShape(RoundedRectangle(cornerRadius: 4))

            VStack(alignment: .leading, spacing: 2) {
                Text(entry.title).lineLimit(1)

                Text(detailText(for: entry))
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
            }

            Spacer()
        }
        .opacity(entry.isAvailable ? 1 : 0.4)
    }

    private func binding(for entry: PlaylistEntry) -> Binding<Bool> {
        Binding(
            get: { selectedIndexes.contains(entry.playlistIndex) },
            set: { isOn in
                if isOn {
                    selectedIndexes.insert(entry.playlistIndex)
                } else {
                    selectedIndexes.remove(entry.playlistIndex)
                }
            }
        )
    }

    private func detailText(for entry: PlaylistEntry) -> String {
        [entry.uploader, durationText(entry.duration)]
            .compactMap { $0 }
            .joined(separator: " · ")
    }

    private func durationText(_ seconds: Double?) -> String? {
        guard let seconds else { return nil }
        let total = Int(seconds)
        let h = total / 3600
        let m = (total % 3600) / 60
        let s = total % 60
        return h > 0
            ? String(format: "%d:%02d:%02d", h, m, s)
            : String(format: "%d:%02d", m, s)
    }

    // MARK: - Actions

    /// 下載的目的資料夾（依「存進播放列表資料夾」開關決定）。
    private var currentOutputDirectory: URL {
        useSubfolder
            ? appState.downloadDirectory
                .appendingPathComponent(Self.sanitizedFolderName(playlist.title), isDirectory: true)
            : appState.downloadDirectory
    }

    private func enqueueSelected() {
        let outputDirectory = currentOutputDirectory

        var count = 0
        for entry in playlist.entries
        where entry.isAvailable && selectedIndexes.contains(entry.playlistIndex) {
            guard let url = entry.videoURL else { continue }
            let task = DownloadTask(
                sourceURL: url,
                title: entry.title,
                selectedFormatID: preset.formatSelector,
                outputDirectory: outputDirectory
            )
            appState.queueManager.enqueue(task)
            count += 1
        }
        lastEnqueuedCount = count
    }

    /// 把「已勾選」的項目寫成純文字檔，不下載任何影片。
    private func exportText(_ style: TextExportStyle) {
        let entries = playlist.entries.filter { selectedIndexes.contains($0.playlistIndex) }
        guard !entries.isEmpty else { return }

        let panel = NSSavePanel()
        panel.allowedContentTypes = [.plainText]
        panel.nameFieldStringValue = Self.sanitizedFolderName(playlist.title) + ".txt"
        panel.directoryURL = appState.downloadDirectory
        panel.canCreateDirectories = true

        guard panel.runModal() == .OK, let url = panel.url else { return }

        do {
            try style.render(entries).write(to: url, atomically: true, encoding: .utf8)
            lastExportedURL = url
            exportErrorMessage = nil
        } catch {
            exportErrorMessage = error.localizedDescription
        }
    }

    /// 播放列表標題可能含有不能當資料夾名稱的字元（例如 / 或 :）。
    private static func sanitizedFolderName(_ title: String?) -> String {
        let illegal = CharacterSet(charactersIn: "/\\:?%*|\"<>")
        let cleaned = (title ?? "")
            .components(separatedBy: illegal)
            .joined(separator: "_")
            .trimmingCharacters(in: CharacterSet.whitespacesAndNewlines.union(CharacterSet(charactersIn: ".")))
        return cleaned.isEmpty ? "Playlist" : cleaned
    }
}

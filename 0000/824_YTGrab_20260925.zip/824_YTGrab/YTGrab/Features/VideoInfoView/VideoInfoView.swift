import SwiftUI

struct VideoInfoView: View {
    let info: VideoInfo

    @EnvironmentObject private var appState: AppState

    @State private var selectedTab: Tab = .quality
    @State private var selectedFormatID: String?
    /// 以 SubtitleChoice.id 記錄勾選（同語言的「作者上傳」與「自動生成」是兩個不同選項）
    @State private var selectedSubtitleIDs: Set<String> = []
    @State private var subtitleQuery = ""
    @State private var lastQueuedSubtitleName: String?
    @State private var subtitleMode: SubtitleDownloadMode = .withVideo
    @State private var subtitleFormat: SubtitleFormat = .srt

    /// 語言名稱查詢一百多次有點成本，只在建立畫面時算一次，不要每次重繪都重算。
    @State private var subtitleChoices: [SubtitleChoice]

    init(info: VideoInfo) {
        self.info = info
        _subtitleChoices = State(initialValue: SubtitleChoice.choices(from: info))
    }

    enum Tab: String, CaseIterable, Identifiable {
        case quality = "畫質"
        case subtitles = "字幕"
        case audio = "音訊"
        var id: String { rawValue }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            header

            Picker("", selection: $selectedTab) {
                ForEach(Tab.allCases) { tab in
                    Text(tab.rawValue).tag(tab)
                }
            }
            .pickerStyle(.segmented)

            switch selectedTab {
            case .quality:
                qualityList
            case .subtitles:
                subtitleList
            case .audio:
                audioList
            }

            HStack {
                Spacer()
                Button("加入下載佇列") { enqueue() }
                    .buttonStyle(.borderedProminent)
                    .disabled(selectedFormatID == nil)
            }
        }
    }

    private var header: some View {
        HStack(alignment: .top, spacing: 12) {
            AsyncImage(url: info.thumbnail.flatMap(URL.init)) { image in
                image.resizable().aspectRatio(contentMode: .fill)
            } placeholder: {
                Color.gray.opacity(0.2)
            }
            .frame(width: 120, height: 68)
            .clipShape(RoundedRectangle(cornerRadius: 6))

            VStack(alignment: .leading, spacing: 4) {
                Text(info.title).font(.headline).lineLimit(2)
                if let uploader = info.uploader {
                    Text(uploader).font(.subheadline).foregroundStyle(.secondary)
                }
                Text(info.durationFormatted).font(.caption).foregroundStyle(.secondary)
            }
            Spacer()
        }
    }

    // MARK: - 畫質 Tab（video-only + progressive）

    private var qualityFormats: [FormatInfo] {
        (info.formats ?? []).filter(\.isVideoFormat)
    }

    private var qualityList: some View {
        List(qualityFormats, selection: Binding(
            get: { selectedFormatID },
            set: { selectedFormatID = $0 }
        )) { format in
            HStack {
                Text(format.displayLabel)
                Spacer()
                if selectedFormatID == format.id {
                    Image(systemName: "checkmark.circle.fill").foregroundStyle(.blue)
                }
            }
            .contentShape(Rectangle())
            .onTapGesture { selectedFormatID = format.id }
        }
        .frame(minHeight: 140)
        .overlay(alignment: .topTrailing) {
            Button("最佳畫質自動選") {
                selectedFormatID = nil // nil 代表交給 YTDLPClient 用 bestvideo+bestaudio
            }
            .font(.caption)
            .padding(6)
        }
    }

    // MARK: - 字幕 Tab

    private var filteredSubtitleChoices: [SubtitleChoice] {
        let query = subtitleQuery.trimmingCharacters(in: .whitespaces)
        guard !query.isEmpty else { return subtitleChoices }
        return subtitleChoices.filter { $0.matches(query) }
    }

    /// 沒有 `-orig` 的原始語言字幕時（舊版 yt-dlp），剩下的自動字幕直接叫「自動生成」。
    private var hasOriginalAutomatic: Bool {
        subtitleChoices.contains(where: \.isOriginalAuto)
    }

    private func sectionTitle(for group: SubtitleChoice.Group) -> String {
        switch group {
        case .uploaded: return "作者上傳的字幕"
        case .automaticOriginal: return "自動生成（原始語言）"
        case .automaticTranslated: return hasOriginalAutomatic ? "自動翻譯" : "自動生成"
        }
    }

    private var subtitleList: some View {
        VStack(alignment: .leading, spacing: 8) {
            if subtitleChoices.isEmpty {
                Text("此影片沒有可用字幕").foregroundStyle(.secondary)
            } else {
                TextField("搜尋語言（例如：日文、Japanese、ja）", text: $subtitleQuery)
                    .textFieldStyle(.roundedBorder)

                List {
                    ForEach(SubtitleChoice.Group.allCases, id: \.self) { group in
                        subtitleSection(group)
                    }
                }
                .frame(minHeight: 160)

                HStack {
                    Picker("下載方式", selection: $subtitleMode) {
                        ForEach(SubtitleDownloadMode.allCases) { mode in
                            Text(mode.rawValue).tag(mode)
                        }
                    }
                    Picker("格式", selection: $subtitleFormat) {
                        ForEach(SubtitleFormat.allCases) { format in
                            Text(format.rawValue.uppercased()).tag(format)
                        }
                    }
                }
                .pickerStyle(.menu)

                Group {
                    if let name = lastQueuedSubtitleName {
                        Text("已加入下載佇列：\(name)")
                    } else {
                        Text("按各列右側的下載鈕只下載該語言的字幕；勾選多個後按下方「加入下載佇列」則依「下載方式」處理。")
                    }
                }
                .font(.caption)
                .foregroundStyle(.secondary)
            }
        }
    }

    @ViewBuilder
    private func subtitleSection(_ group: SubtitleChoice.Group) -> some View {
        let items = filteredSubtitleChoices.filter { $0.group == group }
        if !items.isEmpty {
            Section(sectionTitle(for: group)) {
                ForEach(items) { choice in
                    subtitleRow(choice)
                }
            }
        }
    }

    private func subtitleRow(_ choice: SubtitleChoice) -> some View {
        HStack {
            Toggle(isOn: Binding(
                get: { selectedSubtitleIDs.contains(choice.id) },
                set: { isOn in
                    if isOn { selectedSubtitleIDs.insert(choice.id) }
                    else { selectedSubtitleIDs.remove(choice.id) }
                }
            )) {
                VStack(alignment: .leading, spacing: 1) {
                    Text(choice.displayName)
                    Text(choice.detailText)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }

            Spacer()

            Button {
                downloadSubtitleOnly(choice)
            } label: {
                Label("下載", systemImage: "arrow.down.circle")
            }
            .buttonStyle(.borderless)
            .help("只下載「\(choice.displayName)」字幕，不下載影片")
        }
    }

    // MARK: - 音訊 Tab

    private var audioFormats: [FormatInfo] {
        (info.formats ?? []).filter(\.isAudioOnly)
    }

    private var audioList: some View {
        List(audioFormats, selection: Binding(
            get: { selectedFormatID },
            set: { selectedFormatID = $0 }
        )) { format in
            HStack {
                Text(format.displayLabel)
                Spacer()
                if selectedFormatID == format.id {
                    Image(systemName: "checkmark.circle.fill").foregroundStyle(.blue)
                }
            }
            .contentShape(Rectangle())
            .onTapGesture { selectedFormatID = format.id }
        }
        .frame(minHeight: 140)
    }

    // MARK: - Actions

    /// 「加入下載佇列」：影片 +（若有勾選）字幕，字幕依「下載方式」處理。
    private func enqueue() {
        let chosen = subtitleChoices.filter { selectedSubtitleIDs.contains($0.id) }
        // 同一個語言代碼可能同時勾了「作者上傳」與「自動生成」，--sub-langs 只需要列一次
        var languages: [String] = []
        for code in chosen.map(\.languageCode) where !languages.contains(code) {
            languages.append(code)
        }

        let task = DownloadTask(
            sourceURL: info.webpageURL ?? "",
            title: info.title,
            selectedFormatID: selectedFormatID,
            subtitleLanguages: languages,
            subtitleMode: chosen.isEmpty ? nil : subtitleMode,
            subtitleFormat: subtitleFormat,
            subtitleWriteManual: chosen.contains { !$0.isAutomatic },
            subtitleWriteAuto: chosen.contains { $0.isAutomatic },
            outputDirectory: appState.downloadDirectory
        )
        appState.queueManager.enqueue(task)
    }

    /// 每一列的下載鈕：只下載這一種語言的字幕（不下載影片），使用目前選的字幕格式。
    private func downloadSubtitleOnly(_ choice: SubtitleChoice) {
        let task = DownloadTask(
            sourceURL: info.webpageURL ?? "",
            title: "\(info.title)（字幕：\(choice.displayName)）",
            selectedFormatID: nil,
            subtitleLanguages: [choice.languageCode],
            subtitleMode: .subtitleOnly,
            subtitleFormat: subtitleFormat,
            subtitleWriteManual: !choice.isAutomatic,
            subtitleWriteAuto: choice.isAutomatic,
            outputDirectory: appState.downloadDirectory
        )
        appState.queueManager.enqueue(task)
        lastQueuedSubtitleName = choice.displayName
    }
}

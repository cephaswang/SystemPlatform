import SwiftUI

struct DownloadQueueView: View {
    @EnvironmentObject private var queueManager: DownloadQueueManager
    @EnvironmentObject private var conversionQueueManager: ConversionQueueManager

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            Text("下載佇列").font(.headline).padding([.horizontal, .top])

            if queueManager.tasks.isEmpty {
                Text("目前沒有下載任務").foregroundStyle(.secondary).padding()
            } else {
                List(queueManager.tasks) { task in
                    DownloadTaskRow(task: task, queueManager: queueManager)
                }
                // 下載清單通常會撐滿可用空間，固定高度避免把下面的轉檔清單擠出畫面
                .frame(minHeight: 160)
            }

            // 新增：轉檔佇列（.mov → .mp4），只在有任務時才顯示，避免空畫面時佔位置
            if !conversionQueueManager.tasks.isEmpty {
                Text("轉檔佇列").font(.headline).padding([.horizontal, .top])
                List(conversionQueueManager.tasks) { task in
                    ConversionTaskRow(task: task, queueManager: conversionQueueManager)
                }
                .frame(minHeight: 100)
            }
        }
    }
}

private struct DownloadTaskRow: View {
    @ObservedObject var task: DownloadTask
    let queueManager: DownloadQueueManager

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack {
                Text(task.title).lineLimit(1)
                Spacer()
                statusLabel
            }

            ProgressView(value: task.progress)

            HStack {
                if !task.speedText.isEmpty {
                    Text(task.speedText).font(.caption).foregroundStyle(.secondary)
                }
                if !task.etaText.isEmpty {
                    Text("剩餘 \(task.etaText)").font(.caption).foregroundStyle(.secondary)
                }
                Spacer()
                actionButtons
            }
        }
        .padding(.vertical, 4)
    }

    @ViewBuilder
    private var statusLabel: some View {
        switch task.status {
        case .queued: Text("等待中").font(.caption).foregroundStyle(.secondary)
        case .running: Text("下載中").font(.caption).foregroundStyle(.blue)
        case .paused: Text("已暫停").font(.caption).foregroundStyle(.orange)
        case .completed: Text("已完成").font(.caption).foregroundStyle(.green)
        case .failed: Text("失敗").font(.caption).foregroundStyle(.red)
        case .cancelled: Text("已取消").font(.caption).foregroundStyle(.secondary)
        }
    }

    @ViewBuilder
    private var actionButtons: some View {
        switch task.status {
        case .running:
            Button("暫停") { queueManager.pause(task) }
            Button("取消") { queueManager.cancel(task) }
        case .paused:
            Button("繼續") { queueManager.resume(task) }
            Button("取消") { queueManager.cancel(task) }
        case .queued:
            Button("取消") { queueManager.cancel(task) }
        case .failed:
            Button("重試") { queueManager.retry(task) }
        case .completed, .cancelled:
            EmptyView()
        }
    }
}

/// 新增：轉檔任務列，UI 邏輯比照 DownloadTaskRow，但狀態機比較單純（沒有暫停/繼續）。
private struct ConversionTaskRow: View {
    @ObservedObject var task: ConversionTask
    let queueManager: ConversionQueueManager

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack {
                Text(task.title).lineLimit(1)
                Spacer()
                statusLabel
            }

            ProgressView(value: task.progress)

            HStack {
                Spacer()
                actionButtons
            }
        }
        .padding(.vertical, 4)
    }

    @ViewBuilder
    private var statusLabel: some View {
        switch task.status {
        case .queued: Text("等待中").font(.caption).foregroundStyle(.secondary)
        case .running: Text("轉檔中").font(.caption).foregroundStyle(.blue)
        case .completed: Text("已完成").font(.caption).foregroundStyle(.green)
        case .failed: Text("失敗").font(.caption).foregroundStyle(.red)
        case .cancelled: Text("已取消").font(.caption).foregroundStyle(.secondary)
        }
    }

    @ViewBuilder
    private var actionButtons: some View {
        switch task.status {
        case .running, .queued:
            Button("取消") { queueManager.cancel(task) }
        case .failed:
            Button("重試") { queueManager.retry(task) }
        case .completed, .cancelled:
            EmptyView()
        }
    }
}

import AppKit

/// 「查看下載的檔案」相關的 Finder 動作。UI 只呼叫這裡，不直接碰 NSWorkspace。
enum FinderActions {

    /// 在 Finder 裡選取該檔案。
    /// 檔案不存在（例如只下載字幕，或檔案已被移走）時，退而開啟 fallbackDirectory。
    static func reveal(file: URL?, fallbackDirectory: URL) {
        if let file, FileManager.default.fileExists(atPath: file.path) {
            NSWorkspace.shared.activateFileViewerSelecting([file])
        } else {
            openDirectory(fallbackDirectory)
        }
    }

    /// 用預設 App 開啟檔案（例如影片用預設播放器）。
    static func open(file: URL?) {
        guard let file, FileManager.default.fileExists(atPath: file.path) else { return }
        NSWorkspace.shared.open(file)
    }

    /// 開啟資料夾。資料夾還不存在時（yt-dlp 要開始下載才會建立子資料夾），
    /// 往上找到第一個存在的上層資料夾開啟。
    static func openDirectory(_ url: URL) {
        let fileManager = FileManager.default
        var directory = url
        while !fileManager.fileExists(atPath: directory.path), directory.path != "/" {
            directory = directory.deletingLastPathComponent()
        }
        NSWorkspace.shared.open(directory)
    }
}

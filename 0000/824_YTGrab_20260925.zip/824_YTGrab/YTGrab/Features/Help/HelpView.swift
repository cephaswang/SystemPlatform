import SwiftUI
import WebKit

struct HelpView: NSViewRepresentable {
    func makeNSView(context: Context) -> WKWebView {
        let webView = WKWebView()
        webView.allowsBackForwardNavigationGestures = true
        webView.navigationDelegate = context.coordinator

        guard let url = Bundle.main.url(forResource: "YTGrabHelp", withExtension: "html") else {
            webView.loadHTMLString("<p style='font:15px -apple-system;padding:24px'>找不到說明文件，請確認 YTGrabHelp.html 已加入 Copy Bundle Resources。</p>", baseURL: nil)
            return webView
        }
        webView.loadFileURL(url, allowingReadAccessTo: url.deletingLastPathComponent())
        return webView
    }

    func updateNSView(_ nsView: WKWebView, context: Context) {}

    func makeCoordinator() -> Coordinator { Coordinator() }

    final class Coordinator: NSObject, WKNavigationDelegate {
        // 文件內的外部連結（ffmpeg.org 等）改用預設瀏覽器開啟，不在說明視窗裡跳走
        func webView(_ webView: WKWebView,
                     decidePolicyFor navigationAction: WKNavigationAction,
                     decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
            if navigationAction.navigationType == .linkActivated,
               let url = navigationAction.request.url,
               url.scheme == "http" || url.scheme == "https" {
                NSWorkspace.shared.open(url)
                decisionHandler(.cancel)
                return
            }
            decisionHandler(.allow)
        }
    }
}

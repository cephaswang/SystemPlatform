import SwiftUI
import AppKit

struct SettingsView: View {
    @EnvironmentObject private var appState: AppState
    @EnvironmentObject private var queueManager: DownloadQueueManager
    @State private var ytdlpVersion: String = "讀取中…"
    @State private var ffmpegVersion: String = "讀取中…"

    var body: some View {
        Form {
            Section("下載") {
                HStack {
                    Text("下載路徑")
                    Spacer()
                    Text(appState.downloadDirectory.path)
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                    Button("選擇…") { chooseDownloadDirectory() }
                }

                Stepper(
                    "同時下載數量：\(queueManager.maxConcurrentDownloads)",
                    value: $queueManager.maxConcurrentDownloads,
                    in: 1...5
                )
            }

            Section("yt-dlp") {
                #if !APPSTORE
                HStack {
                    Text("執行檔路徑")
                    Spacer()
                    TextField("", text: $appState.ytdlpBinaryPath)
                        .textFieldStyle(.roundedBorder)
                        .multilineTextAlignment(.trailing)
                        .frame(maxWidth: 260)
                    Button("選擇…") { chooseYTDLPBinary() }
                }
                #endif

                HStack {
                    Text("版本")
                    Spacer()
                    Text(ytdlpVersion).foregroundStyle(.secondary)
                }

                #if APPSTORE
                Text("yt-dlp 隨 App 內建，版本會隨 App 更新。")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                #else
                YTDLPUpdateRow(updater: appState.ytdlpUpdater) {
                    // 安裝完成：改用新版路徑並重新讀版本
                    appState.refreshYTDLPPath()
                    await checkYTDLPVersion()
                }

                Text("找不到執行檔時，可在終端機執行「which yt-dlp」確認安裝路徑，再貼到上方欄位或用「選擇…」指定。")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                #endif
            }

            // 新增：影片轉檔設定（HowTo.mov → mp4）
            Section("影片轉檔") {
                #if !APPSTORE
                HStack {
                    Text("ffmpeg 路徑")
                    Spacer()
                    TextField("", text: $appState.ffmpegBinaryPath)
                        .textFieldStyle(.roundedBorder)
                        .multilineTextAlignment(.trailing)
                        .frame(maxWidth: 260)
                    Button("選擇…") { chooseFFmpegBinary() }
                }
                #endif

                HStack {
                    Text("版本")
                    Spacer()
                    Text(ffmpegVersion).foregroundStyle(.secondary)
                }

                Toggle("轉檔成功後刪除原始 .mov", isOn: $appState.deleteSourceMovAfterConversion)

                #if !APPSTORE
                Text("找不到執行檔時，可在終端機執行「which ffmpeg」確認安裝路徑，再貼到上方欄位或用「選擇…」指定。")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                #endif
            }

            Section("Cookies") {
                Text("支援從瀏覽器匯入 Cookies（--cookies-from-browser），用於需要登入才能存取的內容。")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                // TODO: 瀏覽器選擇下拉選單（Safari / Chrome / Firefox）
            }
        }
        .padding()
        .frame(width: 480)
        .task {
            await checkYTDLPVersion()
            await checkFFmpegVersion()
        }
        .onChange(of: appState.ytdlpBinaryPath) { _ in
            Task { await checkYTDLPVersion() }
        }
        .onChange(of: appState.ffmpegBinaryPath) { _ in
            Task { await checkFFmpegVersion() }
        }
    }

    private func checkYTDLPVersion() async {
        do {
            ytdlpVersion = try await appState.client.fetchVersion()
        } catch {
            ytdlpVersion = "無法取得（\(error.localizedDescription)）"
        }
    }

    private func checkFFmpegVersion() async {
        ffmpegVersion = await appState.fetchFFmpegVersion()
    }

    private func chooseDownloadDirectory() {
        let panel = NSOpenPanel()
        panel.canChooseDirectories = true
        panel.canChooseFiles = false
        panel.allowsMultipleSelection = false
        if panel.runModal() == .OK, let url = panel.url {
            appState.downloadDirectory = url
        }
    }

    private func chooseYTDLPBinary() {
        let panel = NSOpenPanel()
        panel.canChooseDirectories = false
        panel.canChooseFiles = true
        panel.allowsMultipleSelection = false
        panel.directoryURL = URL(fileURLWithPath: "/usr/local/bin")
        panel.prompt = "選擇 yt-dlp"
        if panel.runModal() == .OK, let url = panel.url {
            appState.ytdlpBinaryPath = url.path
        }
    }

    private func chooseFFmpegBinary() {
        let panel = NSOpenPanel()
        panel.canChooseDirectories = false
        panel.canChooseFiles = true
        panel.allowsMultipleSelection = false
        panel.directoryURL = URL(fileURLWithPath: "/usr/local/bin")
        panel.prompt = "選擇 ffmpeg"
        if panel.runModal() == .OK, let url = panel.url {
            appState.ffmpegBinaryPath = url.path
        }
    }
}

#if !APPSTORE
/// yt-dlp 更新列：檢查 → 顯示狀態 → 下載並安裝。
/// 單獨拆成 View，因為 `YTDLPUpdater` 是獨立的 ObservableObject，
/// 放在 AppState 底下時它的 @Published 變化不會讓 SettingsView 重繪。
private struct YTDLPUpdateRow: View {
    @ObservedObject var updater: YTDLPUpdater
    /// 安裝成功後呼叫（切換到新版路徑、重讀版本）
    let onInstalled: () async -> Void

    var body: some View {
        HStack {
            Text(statusText)
                .font(.caption)
                .foregroundStyle(.secondary)
            Spacer()
            switch updater.state {
            case .checking, .downloading:
                ProgressView().controlSize(.small)
            case .updateAvailable:
                Button("下載並安裝") {
                    Task {
                        await updater.installUpdate()
                        if case .installed = updater.state {
                            await onInstalled()
                        }
                    }
                }
            default:
                Button("檢查更新") { Task { await updater.checkForUpdate() } }
            }
        }
    }

    private var statusText: String {
        switch updater.state {
        case .unavailable, .idle:
            return ""
        case .checking:
            return "檢查中…"
        case .upToDate(let current):
            return "已是最新版（\(current)）"
        case .updateAvailable(_, let latest):
            return "有新版本：\(latest)"
        case .downloading(let latest):
            return "正在下載並驗證 \(latest)…"
        case .installed(let version):
            return "已更新至 \(version)"
        case .failed(let message):
            return "更新失敗：\(message)"
        }
    }
}
#endif

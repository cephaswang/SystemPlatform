import SwiftUI

struct RootView: View {
    @EnvironmentObject private var appState: AppState

    var body: some View {
        VStack(spacing: 0) {
            URLInputView()
                .padding()

            Divider()

            content

            Divider()

            downloadFolderBar

            DownloadQueueView()
                .environmentObject(appState.queueManager)
                .frame(maxHeight: 220)
        }
    }

    /// 隨時可以開啟下載資料夾，不用等任務完成。
    private var downloadFolderBar: some View {
        HStack {
            Label(appState.downloadDirectory.lastPathComponent, systemImage: "folder")
                .font(.caption)
                .foregroundStyle(.secondary)
            Spacer()
            Button("開啟下載資料夾") {
                FinderActions.openDirectory(appState.downloadDirectory)
            }
            .buttonStyle(.link)
            .font(.caption)
        }
        .padding(.horizontal)
        .padding(.vertical, 6)
    }

    @ViewBuilder
    private var content: some View {
        if appState.isFetchingInfo {
            ProgressView("解析中…")
                .padding()
                .frame(maxWidth: .infinity, maxHeight: 200)
        } else if let playlist = appState.currentPlaylist {
            PlaylistView(playlist: playlist)
                .padding()
        } else if let info = appState.currentVideoInfo {
            VideoInfoView(info: info)
                .padding()
        } else if let url = appState.pendingChoiceURL {
            playlistChoice(for: url)
        } else if let error = appState.fetchErrorMessage {
            Text("解析失敗：\(error)")
                .foregroundStyle(.red)
                .padding()
        } else {
            Text("貼上網址後點「解析」開始")
                .foregroundStyle(.secondary)
                .padding()
                .frame(maxWidth: .infinity, maxHeight: 200)
        }
    }

    /// 網址同時帶有影片與播放列表（例如 watch?v=...&list=...）時，讓使用者決定要抓哪一個。
    private func playlistChoice(for url: String) -> some View {
        VStack(spacing: 12) {
            Text("這個網址同時指向一支影片和一個播放列表")
                .font(.headline)

            HStack(spacing: 12) {
                Button("只解析這支影片") {
                    Task { await appState.fetchVideo(url: url) }
                }
                Button("解析整個播放列表") {
                    Task { await appState.fetchPlaylist(url: url) }
                }
                .buttonStyle(.borderedProminent)
            }
        }
        .padding()
        .frame(maxWidth: .infinity, maxHeight: 200)
    }
}

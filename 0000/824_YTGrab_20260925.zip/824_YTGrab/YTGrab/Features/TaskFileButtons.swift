import SwiftUI

/// 下載完成的任務列上顯示的按鍵：開啟檔案、在 Finder 顯示，
/// 若輸出檔是 .mov 則額外顯示「轉成 MP4」。
/// 任務尚未完成時不顯示任何東西，可以直接放進每一列而不用自己判斷狀態。
struct TaskFileButtons: View {
    @ObservedObject var task: DownloadTask
    @EnvironmentObject private var appState: AppState

    private var isMovFile: Bool {
        task.outputFileURL?.pathExtension.lowercased() == "mov"
    }

    var body: some View {
        if task.status == .completed {
            HStack(spacing: 8) {
                Button {
                    FinderActions.open(file: task.outputFileURL)
                } label: {
                    Image(systemName: "play.circle")
                }
                .help("用預設程式開啟")
                .disabled(task.outputFileURL == nil)

                Button {
                    FinderActions.reveal(
                        file: task.outputFileURL,
                        fallbackDirectory: task.outputDirectory
                    )
                } label: {
                    Image(systemName: "folder")
                }
                .help("在 Finder 顯示")

                if isMovFile, let sourceURL = task.outputFileURL {
                    Button {
                        appState.convertToMP4(sourceURL: sourceURL)
                    } label: {
                        Label("轉成 MP4", systemImage: "arrow.triangle.2.circlepath")
                    }
                    .help("用 ffmpeg 轉成 .mp4（大多數情況幾秒內完成，不會影響畫質）")
                }
            }
            .buttonStyle(.borderless)
        }
    }
}

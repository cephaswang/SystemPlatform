import Foundation
import Combine

/// 管理整個下載佇列：新增任務、控制同時下載數量上限、
/// 暫停/取消/重試。實際跟 yt-dlp 溝通委派給 YTDLPClient。
@MainActor
final class DownloadQueueManager: ObservableObject {
    @Published var tasks: [DownloadTask] = []
    @Published var maxConcurrentDownloads: Int = 2

    private let client: YTDLPClient
    private var runningCount = 0

    init(client: YTDLPClient) {
        self.client = client
    }

    func enqueue(_ task: DownloadTask) {
        tasks.append(task)
        processQueueIfNeeded()
    }

    func cancel(_ task: DownloadTask) {
        task.process?.terminate()
        task.status = .cancelled
        if case .running = task.status {
            runningCount = max(0, runningCount - 1)
        }
        processQueueIfNeeded()
    }

    func pause(_ task: DownloadTask) {
        // yt-dlp 本身沒有「暫停」訊號，這裡用 terminate + 之後 retry 時靠 --continue 續傳實現類似效果。
        task.process?.terminate()
        task.status = .paused
        runningCount = max(0, runningCount - 1)
        processQueueIfNeeded()
    }

    func resume(_ task: DownloadTask) {
        task.status = .queued
        processQueueIfNeeded()
    }

    func retry(_ task: DownloadTask) {
        task.status = .queued
        task.progress = 0
        processQueueIfNeeded()
    }

    private func processQueueIfNeeded() {
        guard runningCount < maxConcurrentDownloads else { return }
        guard let next = tasks.first(where: { $0.status == .queued }) else { return }
        start(next)
    }

    private func start(_ task: DownloadTask) {
        runningCount += 1
        task.status = .running

        let process = client.startDownload(
            task: task,
            onProgress: { [weak task] percent, speed, eta in
                guard let task else { return }
                task.progress = percent
                task.speedText = speed
                task.etaText = eta
            },
            onCompletion: { [weak self, weak task] result in
                guard let self, let task else { return }
                self.runningCount = max(0, self.runningCount - 1)
                switch result {
                case .success:
                    task.status = .completed
                    task.progress = 1
                    task.consumeReportedOutputPath()
                case .failure(let error):
                    task.discardReportFile()
                    if case ProcessRunnerError.nonZeroExit = error {
                        task.status = .failed(error.localizedDescription)
                    } else if task.status == .paused || task.status == .cancelled {
                        // 使用者主動中止，不算失敗
                    } else {
                        task.status = .failed(error.localizedDescription)
                    }
                }
                self.processQueueIfNeeded()
            }
        )
        task.process = process
    }
}

import Foundation

/// 對應 yt-dlp JSON 的 `formats` 陣列中每一項。
/// 涵蓋畫面格式（video-only / progressive）與純音訊格式。
struct FormatInfo: Codable, Identifiable, Hashable {
    let formatID: String
    let ext: String
    let resolution: String?
    let fps: Double?
    let vcodec: String?
    let acodec: String?
    let abr: Double?        // 音訊位元率 kbps
    let vbr: Double?        // 視訊位元率 kbps
    let filesize: Int64?
    let filesizeApprox: Int64?
    let formatNote: String?

    var id: String { formatID }

    enum CodingKeys: String, CodingKey {
        case formatID = "format_id"
        case ext, resolution, fps, vcodec, acodec, abr, vbr
        case filesize
        case filesizeApprox = "filesize_approx"
        case formatNote = "format_note"
    }

    /// 縮圖預覽用的 storyboard（YouTube 的 sb0/sb1/sb2，ext 為 mhtml），
    /// 不是可下載的影片，兩個 Tab 都不應該顯示。
    var isStoryboard: Bool {
        ext == "mhtml" || formatNote == "storyboard"
    }

    /// video-only：有視訊軌但沒有音訊軌（acodec == "none"）
    var isVideoOnly: Bool {
        !isStoryboard
            && (vcodec != nil && vcodec != "none")
            && (acodec == nil || acodec == "none")
    }

    /// audio-only：只有音訊軌
    var isAudioOnly: Bool {
        guard !isStoryboard else { return false }
        // 明確標示沒有視訊軌（HLS 音訊等格式常缺 acodec 欄位，缺欄位仍視為音訊）
        if vcodec == "none" || resolution == "audio only" {
            return acodec != "none"
        }
        // 沒有任何視訊資訊時，必須確定有音訊 codec 才當成純音訊
        return vcodec == nil && acodec != nil && acodec != "none"
    }

    /// 兩軌都有（progressive format，常見於畫質較低的選項）
    var isProgressive: Bool {
        !isStoryboard
            && (vcodec != nil && vcodec != "none")
            && (acodec != nil && acodec != "none")
    }

    /// 給「畫質」Tab 用：排除 storyboard、純音訊，以及兩軌都沒有的無效格式。
    var isVideoFormat: Bool {
        !isStoryboard && !isAudioOnly && vcodec != "none" && resolution != "audio only"
    }

    var estimatedSize: Int64? { filesize ?? filesizeApprox }

    var displaySizeString: String {
        guard let bytes = estimatedSize else { return "未知大小" }
        return ByteCountFormatter.string(fromByteCount: bytes, countStyle: .file)
    }

    var displayLabel: String {
        var parts: [String] = []
        if let resolution, resolution != "audio only" {
            parts.append(resolution)
        }
        if isAudioOnly {
            parts.append("音訊")
            if let abr { parts.append("\(Int(abr))kbps") }
        }
        if let fps, fps > 0, !isAudioOnly {
            parts.append("\(Int(fps))fps")
        }
        parts.append(ext.uppercased())
        parts.append(displaySizeString)
        return parts.joined(separator: " · ")
    }
}

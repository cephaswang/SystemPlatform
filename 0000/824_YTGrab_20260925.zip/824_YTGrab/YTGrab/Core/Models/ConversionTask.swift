import Foundation
import Combine

/// 單一轉檔任務（目前用於 .mov → .mp4）的狀態與資訊。
/// 結構比照 DownloadTask 的模式：class + ObservableObject，
/// 讓 SwiftUI 畫面用 @ObservedObject 即時反映進度變化。
final class ConversionTask: ObservableObject, Identifiable {
    enum Status: Equatable {
        case queued
        case running
        case completed
        case failed(String)
        case cancelled
    }

    let id = UUID()
    let sourceURL: URL
    let targetURL: URL
    /// 轉檔成功後是否刪除原始 .mov（對應設定頁的開關）
    let deleteSourceOnSuccess: Bool

    @Published var status: Status = .queued
    @Published var progress: Double = 0

    /// 供 TaskFileButtons / FinderActions 沿用既有介面：
    /// 未完成時回傳 nil，讓「開啟」「在 Finder 顯示」等按鍵能重用同一套邏輯。
    var outputFileURL: URL? {
        status == .completed ? targetURL : nil
    }
    var outputDirectory: URL {
        targetURL.deletingLastPathComponent()
    }

    /// 轉檔用的 ffmpeg 程序，供取消時 terminate()
    var process: Process?

    init(sourceURL: URL, targetURL: URL, deleteSourceOnSuccess: Bool = false) {
        self.sourceURL = sourceURL
        self.targetURL = targetURL
        self.deleteSourceOnSuccess = deleteSourceOnSuccess
    }

    var title: String {
        "轉檔：\(sourceURL.lastPathComponent) → \(targetURL.lastPathComponent)"
    }
}

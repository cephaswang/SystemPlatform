import Foundation

// MARK: - 語言名稱

/// 把 yt-dlp 的語言代碼轉成人看得懂的名稱。
/// 直接用系統的 Locale 資料，不用自己維護一份一百多種語言的對照表。
enum LanguageDisplay {

    private static let chinese = Locale(identifier: "zh_Hant_TW")

    /// yt-dlp 對 YouTube「原始語言的自動字幕」會在代碼後面加 `-orig`（例如 `en-orig`）。
    static func split(_ code: String) -> (base: String, isOriginal: Bool) {
        code.hasSuffix("-orig")
            ? (String(code.dropLast("-orig".count)), true)
            : (code, false)
    }

    /// 繁體中文名稱，例如 "af" → "南非荷蘭文"、"zh-Hant" → "繁體中文"。
    /// 系統查不到的代碼原樣顯示。
    static func chineseName(for code: String) -> String {
        let (base, isOriginal) = split(code)
        let name = localized(base, in: chinese) ?? base
        return isOriginal ? "\(name)（原始語言）" : name
    }

    /// 該語言自己的寫法，例如 "ar" → "العربية"、"ja" → "日本語"。
    static func nativeName(for code: String) -> String? {
        let base = split(code).base
        return localized(base, in: Locale(identifier: base))
    }

    /// 常用語言排在前面，其餘依名稱排序。
    static func sortPriority(for code: String) -> Int {
        let pinned = ["zh-Hant", "zh-TW", "zh-Hans", "zh-CN", "zh", "en", "ja", "ko"]
        return pinned.firstIndex(of: split(code).base) ?? pinned.count
    }

    private static func localized(_ identifier: String, in locale: Locale) -> String? {
        guard let name = locale.localizedString(forIdentifier: identifier),
              !name.isEmpty, name != identifier else { return nil }
        return name
    }
}

// MARK: - SubtitleChoice

/// 字幕清單中的一個選項（一種語言 × 作者上傳或自動生成）。
/// 同一個語言代碼可能同時有「作者上傳」和「自動生成」兩種，
/// 所以識別碼把兩者區分開，勾選狀態才不會互相干擾。
struct SubtitleChoice: Identifiable, Hashable {
    let languageCode: String
    let isAutomatic: Bool
    let displayName: String
    let nativeName: String?
    let availableExts: [String]

    var id: String { (isAutomatic ? "auto:" : "manual:") + languageCode }

    var isOriginalAuto: Bool {
        isAutomatic && LanguageDisplay.split(languageCode).isOriginal
    }

    /// 第二行小字：該語言自己的寫法 · 語言代碼
    var detailText: String {
        [nativeName, languageCode].compactMap { $0 }.joined(separator: " · ")
    }

    enum Group: CaseIterable {
        case uploaded
        case automaticOriginal
        case automaticTranslated
    }

    var group: Group {
        if !isAutomatic { return .uploaded }
        return isOriginalAuto ? .automaticOriginal : .automaticTranslated
    }

    init(languageCode: String, isAutomatic: Bool, availableExts: [String]) {
        self.languageCode = languageCode
        self.isAutomatic = isAutomatic
        self.availableExts = availableExts
        self.displayName = LanguageDisplay.chineseName(for: languageCode)

        // 母語名稱跟中文名稱一樣時（例如中文）不重複顯示
        let base = LanguageDisplay.split(languageCode).base
        let native = LanguageDisplay.nativeName(for: languageCode)
        self.nativeName = native == LanguageDisplay.chineseName(for: base) ? nil : native
    }

    /// 搜尋用：中文名稱、母語名稱、語言代碼任一符合即可。
    func matches(_ query: String) -> Bool {
        displayName.localizedCaseInsensitiveContains(query)
            || languageCode.localizedCaseInsensitiveContains(query)
            || (nativeName?.localizedCaseInsensitiveContains(query) ?? false)
    }

    /// 把 VideoInfo 的 subtitles / automatic_captions 轉成 UI 好用的扁平清單。
    static func choices(from info: VideoInfo) -> [SubtitleChoice] {
        func build(_ tracks: [String: [SubtitleTrack]]?, automatic: Bool) -> [SubtitleChoice] {
            (tracks ?? [:])
                // live_chat 是直播的聊天室重播，不是字幕
                .filter { $0.key != "live_chat" }
                .map {
                    SubtitleChoice(
                        languageCode: $0.key,
                        isAutomatic: automatic,
                        availableExts: $0.value.map(\.ext)
                    )
                }
        }

        return (build(info.subtitles, automatic: false) + build(info.automaticCaptions, automatic: true))
            .sorted { lhs, rhs in
                let lp = LanguageDisplay.sortPriority(for: lhs.languageCode)
                let rp = LanguageDisplay.sortPriority(for: rhs.languageCode)
                if lp != rp { return lp < rp }
                return lhs.displayName.localizedStandardCompare(rhs.displayName) == .orderedAscending
            }
    }
}

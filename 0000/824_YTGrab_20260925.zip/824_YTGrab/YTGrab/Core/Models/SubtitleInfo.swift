import Foundation

/// 對應 `subtitles` / `automatic_captions` 底下，某語言的其中一種檔案格式。
struct SubtitleTrack: Codable, Hashable {
    let ext: String
    let url: String?
    let name: String?
}

/// 給 UI 使用的扁平化字幕選項（結合語言代碼 + 是否為自動生成）
struct SubtitleOption: Identifiable, Hashable {
    let id = UUID()
    let languageCode: String
    let displayName: String
    let isAutomatic: Bool
    let availableExts: [String]
}

enum SubtitleDownloadMode: String, CaseIterable, Identifiable {
    case subtitleOnly = "僅下載字幕"
    case withVideo = "隨影片一起下載"
    var id: String { rawValue }
}

enum SubtitleFormat: String, CaseIterable, Identifiable {
    case srt, vtt, ass
    var id: String { rawValue }
}

/// 語言代碼轉可讀名稱的簡易對照表，找不到就直接顯示代碼本身。
enum LanguageNameResolver {
    static let table: [String: String] = [
        "zh-Hant": "繁體中文", "zh-Hans": "簡體中文", "zh": "中文",
        "en": "英文", "ja": "日文", "ko": "韓文",
        "fr": "法文", "de": "德文", "es": "西班牙文", "vi": "越南文"
    ]

    static func name(for code: String) -> String {
        table[code] ?? code
    }
}

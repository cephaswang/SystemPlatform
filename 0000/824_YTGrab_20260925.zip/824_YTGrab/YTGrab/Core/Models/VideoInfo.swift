import Foundation

/// 對應 `yt-dlp -J <url>` 回傳 JSON 的主要欄位。
/// 只解析我們用得到的欄位，其餘 yt-dlp 額外欄位一律忽略（forward-compatible）。
struct VideoInfo: Codable, Identifiable, Hashable {
    let id: String
    let title: String
    let uploader: String?
    let duration: Double?
    let thumbnail: String?
    let webpageURL: String?

    /// 單一影片才有；播放清單項目用 PlaylistEntry 代表（定義在 PlaylistModels.swift）
    let formats: [FormatInfo]?

    /// key: 語言代碼 (e.g. "zh-Hant", "en")；value: 該語言可用的字幕檔案清單
    let subtitles: [String: [SubtitleTrack]]?
    let automaticCaptions: [String: [SubtitleTrack]]?

    /// 若是播放清單網址，yt-dlp 會回傳 `_type: "playlist"` 且帶有 entries
    let type: String?
    let entries: [PlaylistEntry]?

    enum CodingKeys: String, CodingKey {
        case id, title, uploader, duration, thumbnail
        case webpageURL = "webpage_url"
        case formats
        case subtitles
        case automaticCaptions = "automatic_captions"
        case type = "_type"
        case entries
    }

    var isPlaylist: Bool { type == "playlist" }

    var durationFormatted: String {
        guard let duration else { return "--:--" }
        let totalSeconds = Int(duration)
        let h = totalSeconds / 3600
        let m = (totalSeconds % 3600) / 60
        let s = totalSeconds % 60
        return h > 0
            ? String(format: "%d:%02d:%02d", h, m, s)
            : String(format: "%d:%02d", m, s)
    }
}

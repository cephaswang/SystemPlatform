import Foundation
import Combine

enum DownloadStatus: Equatable {
    case queued
    case running
    case paused
    case completed
    case failed(String)
    case cancelled
}

/// UI 與 DownloadQueueManager 共用的下載任務資料。
/// class + ObservableObject：每筆任務的進度更新只需要重繪該任務列，不用整個佇列重繪。
final class DownloadTask: Identifiable, ObservableObject, Equatable {
    let id = UUID()
    let sourceURL: String
    let title: String
    let selectedFormatID: String?
    /// 選到的格式是否為「純影像、無聲」（對應 FormatInfo.isVideoOnly）。
    /// true 時 YTDLPClient 組指令會自動補上 +bestaudio，讓 yt-dlp/ffmpeg 合併音視訊。
    /// 播放清單批次下載用的是已經組好的完整格式選擇字串（見 PlaylistView.DownloadPreset），
    /// 不會、也不應該把這個設為 true，否則會被再補一次 +bestaudio 變成無效語法。
    let needsAudioMerge: Bool
    let subtitleLanguages: [String]
    let subtitleMode: SubtitleDownloadMode?
    let subtitleFormat: SubtitleFormat
    /// 要下載「作者上傳」的字幕（--write-subs）
    let subtitleWriteManual: Bool
    /// 要下載「自動生成 / 自動翻譯」的字幕（--write-auto-subs）。
    /// yt-dlp 的 --write-subs 不會包含自動字幕，兩者要分開指定。
    let subtitleWriteAuto: Bool
    let outputDirectory: URL

    @Published var status: DownloadStatus = .queued
    @Published var progress: Double = 0          // 0...1
    @Published var speedText: String = ""
    @Published var etaText: String = ""

    /// 下載完成後 yt-dlp 回報的最終檔案（合併、轉檔、搬移之後的路徑）。
    /// 只下載字幕（--skip-download）時不會有值，UI 應退而顯示資料夾。
    @Published var outputFileURL: URL?

    var process: Process?

    /// yt-dlp 用 `--print-to-file after_move:%(filepath)s` 把最終路徑寫進這個暫存檔，
    /// 這樣不用去解析 yt-dlp 的文字輸出。
    var reportFileURL: URL {
        FileManager.default.temporaryDirectory
            .appendingPathComponent("ytgrab-\(id.uuidString)-path.txt")
    }

    /// 下載成功後呼叫：讀出最終檔案路徑並刪除暫存檔。
    /// 重試 / 續傳會在檔案裡追加多行，取最後一行。
    func consumeReportedOutputPath() {
        defer { discardReportFile() }
        guard let text = try? String(contentsOf: reportFileURL, encoding: .utf8),
              let lastLine = text.split(whereSeparator: \.isNewline).last
        else { return }

        let path = lastLine.trimmingCharacters(in: .whitespaces)
        guard !path.isEmpty else { return }
        outputFileURL = URL(fileURLWithPath: path)
    }

    func discardReportFile() {
        try? FileManager.default.removeItem(at: reportFileURL)
    }

    init(sourceURL: String,
         title: String,
         selectedFormatID: String?,
         needsAudioMerge: Bool = false,
         subtitleLanguages: [String] = [],
         subtitleMode: SubtitleDownloadMode? = nil,
         subtitleFormat: SubtitleFormat = .srt,
         subtitleWriteManual: Bool = true,
         subtitleWriteAuto: Bool = false,
         outputDirectory: URL) {
        self.sourceURL = sourceURL
        self.title = title
        self.selectedFormatID = selectedFormatID
        self.needsAudioMerge = needsAudioMerge
        self.subtitleLanguages = subtitleLanguages
        self.subtitleMode = subtitleMode
        self.subtitleFormat = subtitleFormat
        self.subtitleWriteManual = subtitleWriteManual
        self.subtitleWriteAuto = subtitleWriteAuto
        self.outputDirectory = outputDirectory
    }

    static func == (lhs: DownloadTask, rhs: DownloadTask) -> Bool {
        lhs.id == rhs.id
    }
}

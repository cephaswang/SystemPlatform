import Foundation
import Combine

/// 管理轉檔佇列，架構跟 DownloadQueueManager 一致：控制同時執行數量、取消/重試。
/// 獨立成一個佇列（而非塞進 DownloadQueueManager），
/// 是因為轉檔沒有「暫停/續傳」的概念，狀態機比下載單純，分開比較不會互相干擾。
@MainActor
final class ConversionQueueManager: ObservableObject {
    @Published var tasks: [ConversionTask] = []
    @Published var maxConcurrentConversions: Int = 1

    /// 由 AppState 在 ffmpegBinaryPath 變動時同步更新，見 AppState.swift 的 didSet。
    var ffmpegPath: String

    private var runningCount = 0

    init(ffmpegPath: String) {
        self.ffmpegPath = ffmpegPath
    }

    func enqueue(_ task: ConversionTask) {
        tasks.append(task)
        processQueueIfNeeded()
    }

    func cancel(_ task: ConversionTask) {
        task.process?.terminate()
        task.status = .cancelled
        runningCount = max(0, runningCount - 1)
        processQueueIfNeeded()
    }

    func retry(_ task: ConversionTask) {
        task.status = .queued
        task.progress = 0
        processQueueIfNeeded()
    }

    private func processQueueIfNeeded() {
        guard runningCount < maxConcurrentConversions else { return }
        guard let next = tasks.first(where: { $0.status == .queued }) else { return }
        start(next)
    }

    private func start(_ task: ConversionTask) {
        runningCount += 1
        task.status = .running

        let process = VideoConverter.convert(
            task: task,
            ffmpegPath: ffmpegPath,
            onProgress: { [weak task] percent in
                task?.progress = percent
            },
            onCompletion: { [weak self, weak task] result in
                guard let self, let task else { return }
                self.runningCount = max(0, self.runningCount - 1)
                switch result {
                case .success:
                    task.status = .completed
                    task.progress = 1
                case .failure(let error):
                    if task.status != .cancelled {
                        task.status = .failed(error.localizedDescription)
                    }
                }
                self.processQueueIfNeeded()
            }
        )
        task.process = process
    }
}

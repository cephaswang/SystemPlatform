import Foundation
import AVFoundation

/// 封裝 ffmpeg 轉檔（目前用於 .mov → .mp4）。
/// 呼叫方式仿照 YTDLPClient 呼叫 yt-dlp 的模式：組參數 → 交給
/// ProcessRunner.runStreaming → 用 ffmpeg 的進度輸出換算百分比。
enum VideoConverter {

    /// 大多數 QuickTime 錄的 .mov 內部本來就是 H.264 + AAC，跟 .mp4 是同一種編碼，
    /// 差別只在外層容器格式，所以預設用 `-c copy`：不重新編碼，幾秒內完成、畫質完全不變。
    /// 如果來源是 ProRes、HEVC 等 QuickTime 專屬編碼，`-c copy` 到 mp4 容器可能失敗，
    /// 這種情況才需要 `reencode: true`，改用 libx264 + aac 重新編碼（速度慢很多）。
    @discardableResult
    static func convert(
        task: ConversionTask,
        ffmpegPath: String,
        reencode: Bool = false,
        onProgress: @escaping (Double) -> Void,
        onCompletion: @escaping (Result<Void, ProcessRunnerError>) -> Void
    ) -> Process? {
        let durationSeconds = probeDuration(url: task.sourceURL)

        var arguments = ["-y", "-i", task.sourceURL.path]
        arguments += reencode ? ["-c:v", "libx264", "-c:a", "aac"] : ["-c", "copy"]
        // -progress pipe:1 讓 ffmpeg 輸出穩定的 key=value 格式（而非人類可讀的那一行動態更新的文字），
        // 每個進度區塊的最後一行是 progress=continue 或 progress=end，逐行解析不會受版本影響。
        arguments += ["-progress", "pipe:1", "-nostats", task.targetURL.path]

        return ProcessRunner.runStreaming(
            executablePath: ffmpegPath,
            arguments: arguments,
            onLine: { line in
                guard let durationSeconds, durationSeconds > 0 else { return }
                guard line.hasPrefix("out_time_ms=") else { return }
                let valueString = line.dropFirst("out_time_ms=".count)
                // 欄位名稱雖然叫 out_time_ms，實際單位是微秒
                guard let microseconds = Double(valueString) else { return }
                let elapsedSeconds = microseconds / 1_000_000
                onProgress(min(elapsedSeconds / durationSeconds, 1.0))
            },
            onCompletion: { result in
                if case .success = result {
                    onProgress(1.0)
                    if task.deleteSourceOnSuccess {
                        try? FileManager.default.removeItem(at: task.sourceURL)
                    }
                }
                onCompletion(result)
            }
        )
    }

    /// 用 AVFoundation 讀取來源檔時長，換算 ffmpeg 的 out_time_ms 為百分比。
    /// 選用 AVFoundation 而非解析 `ffmpeg -i` 的 stderr 文字，理由跟企劃案
    /// 2.2「不解析文字輸出」對 yt-dlp JSON 的原則一致：stderr 格式沒有版本保證。
    /// 讀不到時回傳 nil，呼叫端會停止回報百分比，但轉檔本身仍會正常進行、完成。
    private static func probeDuration(url: URL) -> Double? {
        let asset = AVURLAsset(url: url)
        let duration = asset.duration
        guard duration.isValid, !duration.isIndefinite else { return nil }
        let seconds = CMTimeGetSeconds(duration)
        return (seconds.isFinite && seconds > 0) ? seconds : nil
    }
}

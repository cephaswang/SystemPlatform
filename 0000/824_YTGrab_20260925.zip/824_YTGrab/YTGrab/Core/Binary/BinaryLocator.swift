//
//  BinaryLocator.swift
//  YTGrab / Core/Binary
//
//  找出隨 App 內建（或使用者更新後）的 yt-dlp / ffmpeg / deno，
//  並組出呼叫 yt-dlp 時需要附加的參數與環境變數。
//
//  內建位置：<App>.app/Contents/Helpers/
//    → Xcode「Copy Files」階段：Destination = Wrapper，Subpath = Contents/Helpers
//    → 每個檔案都必須在簽章階段簽過（見 scripts/）
//
//  發行通道：
//    - 獨立分發（Developer ID）：允許把新版 yt-dlp 放到 Application Support 覆蓋內建版本
//    - Mac App Store：在 Build Settings → Active Compilation Conditions 加上 `APPSTORE`，
//      關閉自我更新（Guideline 2.5.2），只使用內建版本
//

import Foundation

// MARK: - 發行通道

enum BuildChannel {
    #if APPSTORE
    static let allowsSelfUpdate = false
    #else
    static let allowsSelfUpdate = true
    #endif
}

// MARK: - 工具定義

enum HelperTool: String, CaseIterable, Sendable {
    case ytdlp
    case ffmpeg
    case ffprobe
    case deno

    var displayName: String {
        switch self {
        case .ytdlp: return "yt-dlp"
        case .ffmpeg: return "ffmpeg"
        case .ffprobe: return "ffprobe"
        case .deno: return "deno"
        }
    }

    /// 可接受的檔名（官方 macOS 版 yt-dlp 檔名為 yt-dlp_macos，內建時可保留或改名）
    var candidateFileNames: [String] {
        switch self {
        case .ytdlp: return ["yt-dlp", "yt-dlp_macos"]
        case .ffmpeg: return ["ffmpeg"]
        case .ffprobe: return ["ffprobe"]
        case .deno: return ["deno"]
        }
    }

    var versionArguments: [String] {
        switch self {
        case .ytdlp, .deno: return ["--version"]
        case .ffmpeg, .ffprobe: return ["-version"]
        }
    }

    /// 缺少時 App 無法運作的工具。deno 為 YouTube 所需，但缺少時只是部分格式取不到，故不列為必要。
    var isRequired: Bool {
        switch self {
        case .ytdlp, .ffmpeg: return true
        case .ffprobe, .deno: return false
        }
    }
}

struct ResolvedTool: Sendable {
    enum Source: Sendable {
        case updated   // Application Support 內的更新版（僅獨立分發）
        case bundled   // App 內建
        case system    // 系統路徑（僅 DEBUG，方便尚未內建 binary 時開發）
    }

    let tool: HelperTool
    let url: URL
    let source: Source
}

// MARK: - 位置與參數

enum BinaryLocator {

    // MARK: 目錄

    /// 更新版 yt-dlp 的存放位置。Sandbox 下會落在容器內，但上架版不會使用。
    static var overrideDirectory: URL {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        return base.appendingPathComponent("YTGrab/bin", isDirectory: true)
    }

    /// 內建執行檔的搜尋順序。標準位置是 Contents/Helpers，其餘為容錯。
    static var bundledDirectories: [URL] {
        var dirs: [URL] = [
            Bundle.main.bundleURL
                .appendingPathComponent("Contents", isDirectory: true)
                .appendingPathComponent("Helpers", isDirectory: true)
        ]
        if let macOSDir = Bundle.main.executableURL?.deletingLastPathComponent() {
            dirs.append(macOSDir.appendingPathComponent("Helpers", isDirectory: true))
            dirs.append(macOSDir)
        }
        return dirs
    }

    #if DEBUG
    private static let systemDirectories: [URL] = [
        URL(fileURLWithPath: "/opt/homebrew/bin", isDirectory: true),
        URL(fileURLWithPath: "/usr/local/bin", isDirectory: true)
    ]
    #endif

    /// yt-dlp 的快取目錄（`--cache-dir`）。放在系統的 Caches 底下，Sandbox 下即容器內。
    static var cacheDirectory: URL {
        let base = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask)[0]
        let dir = base
            .appendingPathComponent(Bundle.main.bundleIdentifier ?? "YTGrab", isDirectory: true)
            .appendingPathComponent("yt-dlp", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir
    }

    // MARK: 解析

    /// 依「更新版 → 內建 → （DEBUG）系統」的順序找出工具。
    static func resolve(_ tool: HelperTool) -> ResolvedTool? {
        if BuildChannel.allowsSelfUpdate, tool == .ytdlp,
           let url = firstExecutable(named: tool.candidateFileNames, in: [overrideDirectory]) {
            return ResolvedTool(tool: tool, url: url, source: .updated)
        }
        if let url = firstExecutable(named: tool.candidateFileNames, in: bundledDirectories) {
            return ResolvedTool(tool: tool, url: url, source: .bundled)
        }
        #if DEBUG
        if let url = firstExecutable(named: tool.candidateFileNames, in: systemDirectories) {
            return ResolvedTool(tool: tool, url: url, source: .system)
        }
        #endif
        return nil
    }

    static func url(for tool: HelperTool) -> URL? {
        resolve(tool)?.url
    }

    /// 只看內建版本（更新流程與比較版本時使用）。
    static func bundledURL(for tool: HelperTool) -> URL? {
        firstExecutable(named: tool.candidateFileNames, in: bundledDirectories)
    }

    /// 只看更新版。上架版一律回傳 nil。
    static func overrideURL(for tool: HelperTool) -> URL? {
        guard BuildChannel.allowsSelfUpdate, tool == .ytdlp else { return nil }
        return firstExecutable(named: tool.candidateFileNames, in: [overrideDirectory])
    }

    static func missingRequiredTools() -> [HelperTool] {
        HelperTool.allCases.filter { $0.isRequired && resolve($0) == nil }
    }

    /// 找不到工具時，仍回傳「內建位置應有的路徑」，讓畫面上的錯誤訊息指得出該放哪裡。
    static func expectedBundledPath(for tool: HelperTool) -> String {
        let dir = bundledDirectories.first
            ?? Bundle.main.bundleURL.appendingPathComponent("Contents/Helpers", isDirectory: true)
        return dir.appendingPathComponent(tool.candidateFileNames[0], isDirectory: false).path
    }

    /// 目前解析到的各工具所在目錄（去除重複，保持順序）。
    static func helperDirectoryPaths() -> [String] {
        var dirs: [String] = []
        for tool in HelperTool.allCases {
            if let dir = url(for: tool)?.deletingLastPathComponent().path, !dirs.contains(dir) {
                dirs.append(dir)
            }
        }
        return dirs
    }

    private static func firstExecutable(named names: [String], in directories: [URL]) -> URL? {
        let fm = FileManager.default
        for dir in directories {
            for name in names {
                let url = dir.appendingPathComponent(name, isDirectory: false)
                var isDirectory: ObjCBool = false
                if fm.fileExists(atPath: url.path, isDirectory: &isDirectory),
                   !isDirectory.boolValue,
                   fm.isExecutableFile(atPath: url.path) {
                    return url
                }
            }
        }
        return nil
    }

    // MARK: 呼叫 yt-dlp 時附加的參數與環境

    /// 附加在每一次 yt-dlp 呼叫的參數：ffmpeg 位置、JS runtime、快取目錄。
    /// 找不到對應工具時，該項參數會省略（不會帶入無效路徑）。
    /// - Parameter ffmpegPath: 使用者在設定頁指定的 ffmpeg（獨立分發版才可能有）。
    ///   該路徑不存在或不可執行時，改用 `resolve(.ffmpeg)` 的結果。
    static func ytdlpHelperArguments(ffmpegPath: String? = nil) -> [String] {
        var args: [String] = []

        var ffmpegURL: URL? = url(for: .ffmpeg)
        if let ffmpegPath, FileManager.default.isExecutableFile(atPath: ffmpegPath) {
            ffmpegURL = URL(fileURLWithPath: ffmpegPath)
        }
        if let ffmpeg = ffmpegURL {
            // 檔名是 ffmpeg 時傳所在目錄，yt-dlp 會在同目錄一併找 ffprobe；其他檔名只能傳檔案本身
            let location = ffmpeg.lastPathComponent == "ffmpeg"
                ? ffmpeg.deletingLastPathComponent().path
                : ffmpeg.path
            args += ["--ffmpeg-location", location]
        }
        if let deno = url(for: .deno) {
            args += ["--js-runtimes", "deno:\(deno.path)"]
        }
        args += ["--cache-dir", cacheDirectory.path]
        return args
    }

    /// 啟動 yt-dlp 時使用的環境變數：沿用目前環境，並把工具所在目錄加到 PATH 前面。
    static func helperEnvironment() -> [String: String] {
        var env = ProcessInfo.processInfo.environment
        let existing = env["PATH"] ?? "/usr/bin:/bin:/usr/sbin:/sbin"
        env["PATH"] = (helperDirectoryPaths() + [existing]).joined(separator: ":")
        return env
    }

    // MARK: 版本

    /// 以 `--version` 讀取工具版本（回傳第一行）。找不到或執行失敗回傳 nil。
    static func version(of tool: HelperTool) async -> String? {
        guard let url = url(for: tool) else { return nil }
        return await runVersion(executable: url, arguments: tool.versionArguments)
    }

    /// 執行指定檔案並取得輸出的第一行。設有逾時，逾時後終止程序。
    static func runVersion(executable: URL,
                           arguments: [String],
                           timeout: TimeInterval = 30) async -> String? {
        await withCheckedContinuation { (continuation: CheckedContinuation<String?, Never>) in
            let process = Process()
            process.executableURL = executable
            process.arguments = arguments
            let stdout = Pipe()
            process.standardOutput = stdout
            process.standardError = Pipe()

            process.terminationHandler = { proc in
                let data = stdout.fileHandleForReading.readDataToEndOfFile()
                guard proc.terminationStatus == 0,
                      let text = String(data: data, encoding: .utf8) else {
                    continuation.resume(returning: nil)
                    return
                }
                let firstLine = text
                    .split(whereSeparator: \.isNewline)
                    .first
                    .map { String($0).trimmingCharacters(in: .whitespaces) }
                continuation.resume(returning: (firstLine?.isEmpty == false) ? firstLine : nil)
            }

            do {
                try process.run()
                DispatchQueue.global().asyncAfter(deadline: .now() + timeout) {
                    if process.isRunning { process.terminate() }
                }
            } catch {
                continuation.resume(returning: nil)
            }
        }
    }

    // MARK: 清理過期的更新版

    /// App 升級後，內建的 yt-dlp 可能比先前下載的更新版還新；此時刪除更新版，改用內建版。
    /// 建議在 App 啟動時呼叫一次。上架版不做任何事。
    static func pruneStaleYTDLPOverride() async {
        if !BuildChannel.allowsSelfUpdate { return }
        guard let override = overrideURL(for: .ytdlp),
              let bundled = bundledURL(for: .ytdlp) else { return }

        async let overrideVersion = runVersion(executable: override, arguments: HelperTool.ytdlp.versionArguments)
        async let bundledVersion = runVersion(executable: bundled, arguments: HelperTool.ytdlp.versionArguments)
        let (ov, bv) = await (overrideVersion, bundledVersion)

        // 更新版無法執行，或不比內建新 → 移除更新版
        if let ov, let bv {
            if !VersionCompare.isNewer(ov, than: bv) {
                try? FileManager.default.removeItem(at: override)
            }
        } else if ov == nil {
            try? FileManager.default.removeItem(at: override)
        }
    }
}

// MARK: - 版本比較

/// yt-dlp 版本為日期格式（例如 2025.11.12，或夜間版 2025.11.12.232900）。
/// 依「.」分段，逐段以數字比較。
enum VersionCompare {
    static func isNewer(_ lhs: String, than rhs: String) -> Bool {
        let a = components(lhs)
        let b = components(rhs)
        for i in 0..<max(a.count, b.count) {
            let x = i < a.count ? a[i] : 0
            let y = i < b.count ? b[i] : 0
            if x != y { return x > y }
        }
        return false
    }

    static func isEqual(_ lhs: String, _ rhs: String) -> Bool {
        !isNewer(lhs, than: rhs) && !isNewer(rhs, than: lhs)
    }

    private static func components(_ version: String) -> [Int] {
        version
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .split(separator: ".")
            .map { Int($0.filter(\.isNumber)) ?? 0 }
    }
}

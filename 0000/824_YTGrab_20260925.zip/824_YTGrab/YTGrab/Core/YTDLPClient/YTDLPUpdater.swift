//
//  YTDLPUpdater.swift
//  YTGrab / Core/Binary
//
//  yt-dlp 版本檢查與更新（對應企劃案 2.2「Binary 管理」）。
//
//  - 只用於獨立分發（Developer ID）。
//  - 上架版（編譯條件 APPSTORE）不含任何下載或更新程式碼，避免違反 Guideline 2.5.2
//    （不得下載並執行會改變 App 功能的程式碼）。scripts/build-appstore.sh 會檢查
//    上架版的執行檔內沒有更新用的網址。
//
//  流程：GitHub Releases API → 下載 yt-dlp_macos 與 SHA2-256SUMS → 驗證雜湊 →
//        設定可執行權限 → 試跑 `--version` → 原子性替換
//        ~/Library/Application Support/YTGrab/bin/yt-dlp
//  只處理 yt-dlp 的 stable 版；ffmpeg、deno 隨 App 更新發版。
//

import Foundation
import Combine   // ObservableObject / @Published

// MARK: - 狀態（兩種通道共用，讓 Settings 畫面不必分支編譯）

enum YTDLPUpdateState: Equatable {
    case unavailable                                   // 上架版：不提供更新
    case idle
    case checking
    case upToDate(current: String)
    case updateAvailable(current: String?, latest: String)
    case downloading(latest: String)
    case installed(version: String)
    case failed(String)
}

#if APPSTORE

// MARK: - 上架版：只保留空殼

@MainActor
final class YTDLPUpdater: ObservableObject {
    @Published private(set) var state: YTDLPUpdateState = .unavailable
    var isSupported: Bool { false }

    func checkForUpdate() async {}
    func installUpdate() async {}
    func checkIfDue(minimumInterval: TimeInterval = 86_400) async {}
}

#else

import CryptoKit
import Darwin

// MARK: - 獨立分發版

private enum UpdateError: LocalizedError {
    case http(Int)
    case rateLimited
    case assetMissing(String)
    case checksumMissing
    case checksumMismatch
    case selfTestFailed

    var errorDescription: String? {
        switch self {
        case .http(let code): return "伺服器回應錯誤（HTTP \(code)）"
        case .rateLimited: return "GitHub API 請求次數已達上限，請稍後再試"
        case .assetMissing(let name): return "找不到發行檔案：\(name)"
        case .checksumMissing: return "SHA2-256SUMS 中沒有對應的雜湊值"
        case .checksumMismatch: return "檔案雜湊值不符，已取消更新"
        case .selfTestFailed: return "新版 yt-dlp 無法正常執行，已取消更新"
        }
    }
}

private struct GitHubRelease: Decodable, Sendable {
    struct Asset: Decodable, Sendable {
        let name: String
        let browserDownloadUrl: URL
    }
    let tagName: String
    let assets: [Asset]
}

@MainActor
final class YTDLPUpdater: ObservableObject {

    @Published private(set) var state: YTDLPUpdateState = .idle
    var isSupported: Bool { true }

    private static let releaseAPI = URL(string: "https://api.github.com/repos/yt-dlp/yt-dlp/releases/latest")!
    private static let binaryAssetName = "yt-dlp_macos"
    private static let checksumAssetName = "SHA2-256SUMS"
    private static let lastCheckKey = "YTGrab.lastYTDLPUpdateCheck"

    private var latestRelease: GitHubRelease?

    // MARK: 檢查

    /// 距離上次檢查超過 minimumInterval 才檢查（預設 24 小時）。適合在 App 啟動時呼叫。
    func checkIfDue(minimumInterval: TimeInterval = 86_400) async {
        if let last = UserDefaults.standard.object(forKey: Self.lastCheckKey) as? Date,
           Date().timeIntervalSince(last) < minimumInterval {
            return
        }
        await checkForUpdate()
    }

    func checkForUpdate() async {
        switch state {
        case .checking, .downloading: return
        default: break
        }
        state = .checking
        do {
            let release = try await Self.fetchLatestRelease()
            latestRelease = release
            UserDefaults.standard.set(Date(), forKey: Self.lastCheckKey)

            let current = await BinaryLocator.version(of: .ytdlp)
            if let current, !VersionCompare.isNewer(release.tagName, than: current) {
                state = .upToDate(current: current)
            } else {
                state = .updateAvailable(current: current, latest: release.tagName)
            }
        } catch {
            state = .failed(error.localizedDescription)
        }
    }

    // MARK: 安裝

    func installUpdate() async {
        if case .downloading = state { return }
        do {
            let release: GitHubRelease
            if let cached = latestRelease {
                release = cached
            } else {
                release = try await Self.fetchLatestRelease()
            }
            state = .downloading(latest: release.tagName)
            let version = try await Self.downloadVerifyAndInstall(release)
            latestRelease = nil
            state = .installed(version: version)
        } catch {
            state = .failed(error.localizedDescription)
        }
    }

    // MARK: - 網路與檔案（不在主執行緒上執行）

    nonisolated private static func fetchLatestRelease() async throws -> GitHubRelease {
        var request = URLRequest(url: releaseAPI)
        request.setValue("application/vnd.github+json", forHTTPHeaderField: "Accept")
        request.setValue("YTGrab", forHTTPHeaderField: "User-Agent")
        request.timeoutInterval = 20

        let (data, response) = try await URLSession.shared.data(for: request)
        if let http = response as? HTTPURLResponse, http.statusCode != 200 {
            if http.statusCode == 403 || http.statusCode == 429 { throw UpdateError.rateLimited }
            throw UpdateError.http(http.statusCode)
        }
        let decoder = JSONDecoder()
        decoder.keyDecodingStrategy = .convertFromSnakeCase
        return try decoder.decode(GitHubRelease.self, from: data)
    }

    nonisolated private static func downloadVerifyAndInstall(_ release: GitHubRelease) async throws -> String {
        guard let binaryAsset = release.assets.first(where: { $0.name == binaryAssetName }) else {
            throw UpdateError.assetMissing(binaryAssetName)
        }
        guard let sumsAsset = release.assets.first(where: { $0.name == checksumAssetName }) else {
            throw UpdateError.assetMissing(checksumAssetName)
        }

        // 1. 取得預期的 SHA-256
        let (sumsFile, sumsResponse) = try await URLSession.shared.download(from: sumsAsset.browserDownloadUrl)
        try checkStatus(sumsResponse)
        let sumsText = try String(contentsOf: sumsFile, encoding: .utf8)
        try? FileManager.default.removeItem(at: sumsFile)
        guard let expected = expectedHash(for: binaryAssetName, in: sumsText) else {
            throw UpdateError.checksumMissing
        }

        // 2. 下載執行檔並驗證
        let (downloaded, response) = try await URLSession.shared.download(from: binaryAsset.browserDownloadUrl)
        try checkStatus(response)

        let fm = FileManager.default
        let stagingDir = fm.temporaryDirectory
            .appendingPathComponent("YTGrab-update-\(UUID().uuidString)", isDirectory: true)
        try fm.createDirectory(at: stagingDir, withIntermediateDirectories: true)
        defer { try? fm.removeItem(at: stagingDir) }

        let staged = stagingDir.appendingPathComponent("yt-dlp")
        try fm.moveItem(at: downloaded, to: staged)

        let data = try Data(contentsOf: staged, options: .mappedIfSafe)
        let actual = SHA256.hash(data: data).map { String(format: "%02x", $0) }.joined()
        guard actual == expected.lowercased() else { throw UpdateError.checksumMismatch }

        // 3. 權限、隔離屬性、試跑
        try fm.setAttributes([.posixPermissions: 0o755], ofItemAtPath: staged.path)
        _ = removexattr(staged.path, "com.apple.quarantine", 0)

        guard let reported = await BinaryLocator.runVersion(executable: staged, arguments: ["--version"]),
              VersionCompare.isEqual(reported, release.tagName) else {
            throw UpdateError.selfTestFailed
        }

        // 4. 替換
        let destinationDir = BinaryLocator.overrideDirectory
        try fm.createDirectory(at: destinationDir, withIntermediateDirectories: true)
        let destination = destinationDir.appendingPathComponent("yt-dlp")
        if fm.fileExists(atPath: destination.path) {
            _ = try fm.replaceItemAt(destination, withItemAt: staged)
        } else {
            try fm.moveItem(at: staged, to: destination)
        }
        return reported
    }

    nonisolated private static func checkStatus(_ response: URLResponse) throws {
        if let http = response as? HTTPURLResponse, !(200..<300).contains(http.statusCode) {
            throw UpdateError.http(http.statusCode)
        }
    }

    /// SHA2-256SUMS 每行格式：`<hash>  <檔名>`（檔名前可能有 `*`）
    nonisolated private static func expectedHash(for fileName: String, in text: String) -> String? {
        for line in text.split(whereSeparator: \.isNewline) {
            let parts = line.split(whereSeparator: { $0 == " " || $0 == "\t" })
            guard parts.count >= 2 else { continue }
            let name = parts[parts.count - 1].trimmingCharacters(in: CharacterSet(charactersIn: "*"))
            if name == fileName { return String(parts[0]) }
        }
        return nil
    }
}

#endif

import Foundation

// MARK: - PlaylistInfo

/// `yt-dlp -J --flat-playlist` 回傳的播放清單本體。
/// 刻意不重用 VideoInfo：VideoInfo 預期有 formats / subtitles 等欄位，
/// 而 flat-playlist 的項目只有 id / title / url / duration 等輕量資訊。
struct PlaylistInfo: Decodable {
    let type: String?
    let id: String?
    let title: String?
    let uploader: String?
    let webpageURL: String?
    let playlistCount: Int?
    let entries: [PlaylistEntry]

    enum CodingKeys: String, CodingKey {
        case type = "_type"
        case id, title, uploader, entries
        case webpageURL = "webpage_url"
        case playlistCount = "playlist_count"
    }

    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        type = try c.decodeIfPresent(String.self, forKey: .type)
        id = try c.decodeIfPresent(String.self, forKey: .id)
        title = try c.decodeIfPresent(String.self, forKey: .title)
        uploader = try c.decodeIfPresent(String.self, forKey: .uploader)
        webpageURL = try c.decodeIfPresent(String.self, forKey: .webpageURL)
        playlistCount = try c.decodeIfPresent(Int.self, forKey: .playlistCount)

        // entries 裡可能混有 null 或格式異常的項目（私人 / 已刪除影片），
        // 用 LossyBox 逐筆容錯，避免一筆壞資料讓整份清單解析失敗。
        let boxes = try c.decodeIfPresent([LossyBox<PlaylistEntry>].self, forKey: .entries) ?? []
        var decoded = boxes.compactMap(\.value)
        for i in decoded.indices {
            decoded[i].playlistIndex = i + 1
        }
        entries = decoded
    }
}

// MARK: - PlaylistEntry

struct PlaylistEntry: Identifiable, Hashable, Codable {
    let id: String
    let title: String
    let url: String?
    let webpageURL: String?
    let ieKey: String?
    let duration: Double?
    let uploader: String?
    let thumbnails: [Thumbnail]?

    /// 在清單中的順序（從 1 開始），由 PlaylistInfo 解析完後填入。
    var playlistIndex: Int = 0

    struct Thumbnail: Hashable, Codable {
        let url: String
        let width: Int?
        let height: Int?
    }

    enum CodingKeys: String, CodingKey {
        case id, title, url, duration, uploader, thumbnails
        case webpageURL = "webpage_url"
        case ieKey = "ie_key"
    }

    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        id = try c.decode(String.self, forKey: .id)
        title = try c.decodeIfPresent(String.self, forKey: .title) ?? id
        url = try c.decodeIfPresent(String.self, forKey: .url)
        webpageURL = try c.decodeIfPresent(String.self, forKey: .webpageURL)
        ieKey = try c.decodeIfPresent(String.self, forKey: .ieKey)
        duration = try c.decodeIfPresent(Double.self, forKey: .duration)
        uploader = try c.decodeIfPresent(String.self, forKey: .uploader)
        thumbnails = try c.decodeIfPresent([Thumbnail].self, forKey: .thumbnails)
    }

    /// 私人 / 已刪除的影片仍會出現在清單中，但無法下載，UI 應該灰掉且不可勾選。
    var isAvailable: Bool {
        title != "[Private video]" && title != "[Deleted video]"
    }

    /// 可直接餵給 `fetchVideoInfo(url:)` 或 DownloadTask.sourceURL 的單支影片網址。
    /// 這個網址不帶 `list=`，所以不會又被當成播放清單。
    var videoURL: String? {
        if let url, url.hasPrefix("http") { return url }
        if let webpageURL, webpageURL.hasPrefix("http") { return webpageURL }
        if ieKey == "Youtube" { return "https://www.youtube.com/watch?v=\(id)" }
        return nil
    }

    /// flat-playlist 的縮圖在 `thumbnails` 陣列，取最後一張（通常最大）；
    /// 沒有時 YouTube 可用固定網址規則補上。
    var thumbnailURL: String? {
        if let last = thumbnails?.last?.url { return last }
        if ieKey == "Youtube" { return "https://i.ytimg.com/vi/\(id)/mqdefault.jpg" }
        return nil
    }
}

// MARK: - Helper

/// 單筆解碼失敗時回傳 nil，而不是讓整個陣列 throw。
private struct LossyBox<T: Decodable>: Decodable {
    let value: T?
    init(from decoder: Decoder) throws {
        value = try? T(from: decoder)
    }
}

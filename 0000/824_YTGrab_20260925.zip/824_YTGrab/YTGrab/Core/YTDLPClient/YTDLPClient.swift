import Foundation

enum YTDLPClientError: LocalizedError {
    case notAPlaylist

    var errorDescription: String? {
        switch self {
        case .notAPlaylist:
            return "這個網址不是播放清單，或清單無法存取（可能是私人清單，需要 Cookies）。"
        }
    }
}

/// 所有跟 yt-dlp 溝通的邏輯集中在這裡：組參數、呼叫 ProcessRunner、
/// 解析回傳的 JSON。UI 層完全不需要知道 yt-dlp 的參數細節。
final class YTDLPClient {

    private(set) var binaryPath: String

    /// 使用者指定（或 AppState 解析到）的 ffmpeg 路徑，會轉成 `--ffmpeg-location` 帶給 yt-dlp。
    /// 為 nil 或不可執行時，改由 BinaryLocator 找內建版本。
    private(set) var ffmpegPath: String?

    /// progress-template 用自訂分隔符號輸出固定格式，避免解析人類可讀的進度列文字。
    /// 格式：PROGRESS|<percent>|<speed>|<eta>
    private static let progressTemplate =
        "PROGRESS|%(progress._percent_str)s|%(progress._speed_str)s|%(progress._eta_str)s"

    init(binaryPath: String, ffmpegPath: String? = nil) {
        self.binaryPath = binaryPath
        self.ffmpegPath = ffmpegPath
    }

    /// 每次呼叫 yt-dlp 都要附上的 helper 參數：ffmpeg 位置、JS runtime（deno）、快取目錄。
    /// 在呼叫當下才計算，所以更新 yt-dlp 或改 ffmpeg 路徑後不需要重建 client。
    private var helperArguments: [String] {
        BinaryLocator.ytdlpHelperArguments(ffmpegPath: ffmpegPath)
    }

    /// 使用者在設定頁改路徑，或啟動時重新掃描到新路徑時呼叫。
    func updateBinaryPath(_ newPath: String) {
        binaryPath = newPath
    }

    func updateFFmpegPath(_ newPath: String?) {
        ffmpegPath = newPath
    }

    // MARK: - 讀取資訊（列表 / 字幕清單）

    /// 判斷網址是否同時帶有播放清單參數（例如 YouTube 的 `list=`），
    /// 供 UI 決定要不要跳出「這支影片 / 整個清單」的選擇。
    func urlContainsPlaylistReference(_ urlString: String) -> Bool {
        guard let components = URLComponents(string: urlString) else { return false }
        return components.queryItems?.contains { $0.name == "list" } ?? false
    }

    /// 解析單一網址，取得完整資訊（畫質、字幕等）。
    /// 強制加上 `--no-playlist`：即使網址同時帶有播放清單參數
    /// （例如 YouTube 的 `...&list=...`），也只抓該支影片本身，
    /// 不會被 yt-dlp 預設行為誤判成要解析整個播放清單。
    /// 播放清單模式請改用 `fetchPlaylist(url:)`。
    func fetchVideoInfo(url: String) async throws -> VideoInfo {
        let output = try await ProcessRunner.run(
            executablePath: binaryPath,
            arguments: ["-J", "--no-warnings", "--no-playlist"] + helperArguments + [url]
        )
        let data = Data(output.utf8)
        return try JSONDecoder().decode(VideoInfo.self, from: data)
    }

    /// 播放清單模式：用 flat-playlist 快速取得清單標題與所有項目，
    /// 不展開每個項目的完整格式資訊（那要等使用者勾選後再逐支 `fetchVideoInfo`）。
    /// 這裡刻意不加 --no-playlist，因為目的就是要抓整個清單；
    /// 對 `watch?v=...&list=...` 這種網址，`--yes-playlist` 會讓 yt-dlp 改抓清單。
    func fetchPlaylist(url: String) async throws -> PlaylistInfo {
        let output = try await ProcessRunner.run(
            executablePath: binaryPath,
            arguments: ["-J", "--flat-playlist", "--no-warnings", "--yes-playlist"] + helperArguments + [url]
        )
        let info = try JSONDecoder().decode(PlaylistInfo.self, from: Data(output.utf8))

        // 單支影片網址（沒有 list=）回來的 _type 是 "video"，不是清單。
        guard info.type == "playlist" || !info.entries.isEmpty else {
            throw YTDLPClientError.notAPlaylist
        }
        return info
    }

    /// 只要項目列表時的簡便版本（保留原本的呼叫介面）。
    func fetchPlaylistEntries(url: String) async throws -> [PlaylistEntry] {
        try await fetchPlaylist(url: url).entries
    }

    // MARK: - 下載

    /// 組裝下載任務所需的 yt-dlp 參數。
    /// 播放清單的每個項目都以單支影片網址（不帶 list=）建立 DownloadTask，
    /// 所以這裡維持 --no-playlist 即可。
    func downloadArguments(for task: DownloadTask) -> [String] {
        var args: [String] = [
            "--newline",
            "--no-warnings",
            "--no-playlist",
            "--progress-template", Self.progressTemplate,
            // 下載、合併、搬移全部完成後，把最終檔案路徑寫進暫存檔（供「在 Finder 顯示」使用）。
            // 用 --print-to-file 而不是 --print：後者會讓 yt-dlp 進入 quiet 模式而關掉進度輸出。
            "--print-to-file", "after_move:%(filepath)s", task.reportFileURL.path,
            "-o", "\(task.outputDirectory.path)/%(title)s.%(ext)s"
        ]

        if let formatID = task.selectedFormatID {
            if task.needsAudioMerge {
                // 選到的是 video-only 格式（沒有聲音），補上 +bestaudio 讓 yt-dlp/ffmpeg
                // 自動下載對應的最佳音軌並合併。萬一找不到可搭配的音軌（極少數情況），
                // `/` 後面的原始 formatID 是備援，至少不會直接失敗（但仍會沒有聲音）。
                args += ["-f", "\(formatID)+bestaudio/\(formatID)"]
            } else {
                // 已經是完整的格式選擇字串（例如播放清單批次下載用的
                // "bestvideo[height<=1080]+bestaudio/..."）或本身就有聲音（progressive / 純音訊），
                // 不需要、也不能再補一次 +bestaudio。
                args += ["-f", formatID]
            }
        } else {
            args += ["-f", "bestvideo+bestaudio/best"]
        }

        // 影音分軌時，下載完自動用 ffmpeg 合併
        args += ["--merge-output-format", "mp4"]

        if let mode = task.subtitleMode, !task.subtitleLanguages.isEmpty {
            let langs = task.subtitleLanguages.joined(separator: ",")
            args += ["--sub-langs", langs, "--convert-subs", task.subtitleFormat.rawValue]

            // --write-subs 只會存「作者上傳」的字幕；自動生成 / 自動翻譯的字幕要另外加 --write-auto-subs。
            // 只選了自動字幕時不帶 --write-subs，避免同語言有作者上傳版本時被優先取走。
            if task.subtitleWriteManual { args.append("--write-subs") }
            if task.subtitleWriteAuto { args.append("--write-auto-subs") }

            switch mode {
            case .subtitleOnly:
                args.append("--skip-download")
            case .withVideo:
                args.append("--embed-subs")
            }
        }

        // ffmpeg 位置、deno（YouTube 需要 JS runtime）、快取目錄
        args += helperArguments

        args.append(task.sourceURL)
        return args
    }

    /// 啟動下載，透過 onProgress / onCompletion 回呼通知呼叫端（DownloadQueueManager）。
    @discardableResult
    func startDownload(
        task: DownloadTask,
        onProgress: @escaping (_ percent: Double, _ speed: String, _ eta: String) -> Void,
        onCompletion: @escaping (Result<Void, Error>) -> Void
    ) -> Process? {
        let args = downloadArguments(for: task)

        return ProcessRunner.runStreaming(
            executablePath: binaryPath,
            arguments: args,
            onLine: { line in
                guard line.hasPrefix("PROGRESS|") else { return }
                let parts = line.split(separator: "|", maxSplits: 3, omittingEmptySubsequences: false)
                guard parts.count == 4 else { return }
                let percentStr = parts[1].trimmingCharacters(in: .whitespaces).replacingOccurrences(of: "%", with: "")
                let percent = (Double(percentStr) ?? 0) / 100.0
                onProgress(percent, String(parts[2]), String(parts[3]))
            },
            onCompletion: { result in
                switch result {
                case .success:
                    onCompletion(.success(()))
                case .failure(let error):
                    onCompletion(.failure(error))
                }
            }
        )
    }

    // MARK: - 版本管理

    func fetchVersion() async throws -> String {
        try await ProcessRunner.run(executablePath: binaryPath, arguments: ["--version"])
            .trimmingCharacters(in: .whitespacesAndNewlines)
    }
}

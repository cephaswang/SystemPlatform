import SwiftUI
import AppKit
internal import UniformTypeIdentifiers

@main
struct YTGrabApp: App {
    @StateObject private var appState = AppState()

    var body: some Scene {
        let _ = print("🖼️ [\(Self.self)] body (\(#fileID))")
        
        WindowGroup {
            RootView()
                .environmentObject(appState)
                .environmentObject(appState.conversionQueueManager)   // 新增：HowTo.mov → mp4 轉檔佇列
        }
        .commands {
            HelpCommands()
            // 新增：不限於下載結果，讓使用者能挑選電腦上任何一支影片檔案來轉檔。
            CommandGroup(after: .newItem) {
                Button("轉換影片為 MP4…") {
                    pickAndConvertLocalMovies()
                }
                .keyboardShortcut("m", modifiers: [.command, .shift])
            }
        }

        Window("YTGrab 使用說明", id: "help") {
            HelpView()
                .frame(minWidth: 680, minHeight: 520)
        }
        .defaultSize(width: 960, height: 760)
    }

    /// 開啟系統的檔案選擇視窗，選好的每個檔案都丟進轉檔佇列（appState.conversionQueueManager）。
    /// 用 NSOpenPanel 而非 SwiftUI 的 .fileImporter，是因為這裡是選單指令、不依附特定畫面的 View。
    private func pickAndConvertLocalMovies() {
        let panel = NSOpenPanel()
        panel.canChooseFiles = true
        panel.canChooseDirectories = false
        panel.allowsMultipleSelection = true
        panel.allowedContentTypes = [.movie, .video, .quickTimeMovie, .mpeg4Movie]
        panel.prompt = "選擇要轉檔的影片"
        guard panel.runModal() == .OK else { return }

        for url in panel.urls {
            appState.convertToMP4(sourceURL: url)
        }
    }
}

struct HelpCommands: Commands {
    @Environment(\.openWindow) private var openWindow

    var body: some Commands {
        CommandGroup(replacing: .help) {
            Button("YTGrab 使用說明") {
                openWindow(id: "help")
            }
            .keyboardShortcut("?", modifiers: .command)
        }
    }
}

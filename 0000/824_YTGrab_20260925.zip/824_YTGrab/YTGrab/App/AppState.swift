import Foundation
import Combine

@MainActor
final class AppState: ObservableObject {
    @Published var ytdlpBinaryPath: String {
        didSet {
            UserDefaults.standard.set(ytdlpBinaryPath, forKey: Self.customPathKey)
            client.updateBinaryPath(ytdlpBinaryPath)
        }
    }
    // MARK: - 新增：ffmpeg 路徑（供 HowTo.mov → mp4 轉檔功能使用）
    @Published var ffmpegBinaryPath: String {
        didSet {
            UserDefaults.standard.set(ffmpegBinaryPath, forKey: Self.ffmpegPathKey)
            conversionQueueManager.ffmpegPath = ffmpegBinaryPath
            client.updateFFmpegPath(ffmpegBinaryPath)   // yt-dlp 合併影音、轉字幕時也用同一個 ffmpeg
        }
    }
    /// 轉檔成功後是否刪除原始 .mov，設定頁的開關會綁定這個值
    @Published var deleteSourceMovAfterConversion = false

    @Published var downloadDirectory: URL {
        didSet {
            #if APPSTORE
            Self.saveDownloadDirectoryBookmark(downloadDirectory)
            #endif
        }
    }
    @Published var currentVideoInfo: VideoInfo?
    @Published var currentPlaylist: PlaylistInfo?
    /// 網址同時帶有影片與 list= 時，暫存起來等使用者選「單支影片 / 整個播放列表」。
    @Published var pendingChoiceURL: String?
    @Published var isFetchingInfo = false
    @Published var fetchErrorMessage: String?

    let client: YTDLPClient
    let queueManager: DownloadQueueManager
    let conversionQueueManager: ConversionQueueManager
    /// yt-dlp 更新（僅獨立分發版有作用；上架版是空殼）。SettingsView 使用。
    let ytdlpUpdater = YTDLPUpdater()

    private static let customPathKey = "ytdlpBinaryPath"
    private static let ffmpegPathKey = "ffmpegBinaryPath"

    /// 依序嘗試：
    /// 1. BinaryLocator：Application Support 內的更新版（僅獨立分發）→ App 內建（Contents/Helpers）
    /// 2. 使用者在設定頁手動指定過的路徑（僅獨立分發）
    /// 3. Homebrew / 系統常見路徑（僅獨立分發）
    ///
    /// 上架版（APPSTORE）只使用內建版本：Sandbox 下無法執行任意路徑的外部程式。
    private static func resolveYTDLPPath() -> String {
        if let resolved = BinaryLocator.resolve(.ytdlp), resolved.source != .system {
            return resolved.url.path
        }

        #if APPSTORE
        return BinaryLocator.expectedBundledPath(for: .ytdlp)
        #else
        let fileManager = FileManager.default

        if let savedPath = UserDefaults.standard.string(forKey: customPathKey),
           fileManager.isExecutableFile(atPath: savedPath) {
            return savedPath
        }

        let candidates = [
            "/opt/homebrew/bin/yt-dlp",   // Apple Silicon Homebrew
            "/usr/local/bin/yt-dlp",      // Intel Homebrew / 常見手動安裝路徑
            "/usr/bin/yt-dlp",
            "/opt/local/bin/yt-dlp"       // MacPorts
        ]
        for path in candidates where fileManager.isExecutableFile(atPath: path) {
            return path
        }

        // 都找不到時，仍回傳最常見的路徑當預設值，讓使用者在設定頁看到並可以修正
        return candidates.first!
        #endif
    }

    /// 跟 resolveYTDLPPath 邏輯完全比照，只是找的是 ffmpeg。
    private static func resolveFFmpegPath() -> String {
        if let resolved = BinaryLocator.resolve(.ffmpeg), resolved.source != .system {
            return resolved.url.path
        }

        #if APPSTORE
        return BinaryLocator.expectedBundledPath(for: .ffmpeg)
        #else
        let fileManager = FileManager.default

        if let savedPath = UserDefaults.standard.string(forKey: ffmpegPathKey),
           fileManager.isExecutableFile(atPath: savedPath) {
            return savedPath
        }

        let candidates = [
            "/opt/homebrew/bin/ffmpeg",
            "/usr/local/bin/ffmpeg",
            "/usr/bin/ffmpeg",
            "/opt/local/bin/ffmpeg"
        ]
        for path in candidates where fileManager.isExecutableFile(atPath: path) {
            return path
        }

        return candidates.first!
        #endif
    }

    /// 更新 yt-dlp 之後（或清掉過期的更新版之後）重新解析 yt-dlp 路徑。
    /// 不動 ffmpeg，以免蓋掉使用者在設定頁指定的路徑。
    func refreshYTDLPPath() {
        let resolved = Self.resolveYTDLPPath()
        if resolved != ytdlpBinaryPath {
            ytdlpBinaryPath = resolved
        }
    }

    #if APPSTORE
    // MARK: - 上架版：記住使用者選的下載資料夾（security-scoped bookmark）
    // 需要 entitlement：com.apple.security.files.bookmarks.app-scope

    private static let downloadBookmarkKey = "downloadDirectoryBookmark"

    private static func saveDownloadDirectoryBookmark(_ url: URL) {
        guard let data = try? url.bookmarkData(
            options: .withSecurityScope,
            includingResourceValuesForKeys: nil,
            relativeTo: nil
        ) else { return }
        UserDefaults.standard.set(data, forKey: downloadBookmarkKey)
    }

    private static func restoreDownloadDirectory() -> URL? {
        guard let data = UserDefaults.standard.data(forKey: downloadBookmarkKey) else { return nil }
        var isStale = false
        guard let url = try? URL(
            resolvingBookmarkData: data,
            options: .withSecurityScope,
            relativeTo: nil,
            bookmarkDataIsStale: &isStale
        ), url.startAccessingSecurityScopedResource() else { return nil }
        if isStale { saveDownloadDirectoryBookmark(url) }
        return url   // 存取權限維持到 App 結束，不需要 stopAccessing
    }
    #endif

    init() {
        let resolvedPath = Self.resolveYTDLPPath()
        let resolvedFFmpegPath = Self.resolveFFmpegPath()

        self.ytdlpBinaryPath = resolvedPath
        self.ffmpegBinaryPath = resolvedFFmpegPath
        let defaultDownloadDirectory = FileManager.default.urls(for: .downloadsDirectory, in: .userDomainMask).first
            ?? FileManager.default.homeDirectoryForCurrentUser
        #if APPSTORE
        self.downloadDirectory = Self.restoreDownloadDirectory() ?? defaultDownloadDirectory
        #else
        self.downloadDirectory = defaultDownloadDirectory
        #endif

        let client = YTDLPClient(binaryPath: resolvedPath, ffmpegPath: resolvedFFmpegPath)
        self.client = client
        self.queueManager = DownloadQueueManager(client: client)
        self.conversionQueueManager = ConversionQueueManager(ffmpegPath: resolvedFFmpegPath)

        // App 升級後，內建的 yt-dlp 可能比先前下載的更新版新；清掉過期的更新版後重新解析路徑。
        // 只讀取本機檔案，不連網。
        Task { [weak self] in
            await BinaryLocator.pruneStaleYTDLPOverride()
            self?.refreshYTDLPPath()
        }
    }

    private enum URLKind {
        case video              // 一般單支影片
        case videoInPlaylist    // watch?v=...&list=...：要問使用者想抓哪一個
        case playlist           // /playlist?list=...：一定是整個列表
    }

    private func classify(_ urlString: String) -> URLKind {
        guard client.urlContainsPlaylistReference(urlString) else { return .video }
        let path = URLComponents(string: urlString)?.path ?? ""
        return path.hasPrefix("/playlist") ? .playlist : .videoInPlaylist
    }

    private func resetResults() {
        currentVideoInfo = nil
        currentPlaylist = nil
        pendingChoiceURL = nil
        fetchErrorMessage = nil
    }

    /// URLInputView 的入口：依網址類型分流。
    func fetchInfo(for urlString: String) async {
        switch classify(urlString) {
        case .video:
            await fetchVideo(url: urlString)
        case .playlist:
            await fetchPlaylist(url: urlString)
        case .videoInPlaylist:
            resetResults()
            pendingChoiceURL = urlString
        }
    }

    /// 只解析單支影片（YTDLPClient 會加 --no-playlist）。
    func fetchVideo(url: String) async {
        resetResults()
        isFetchingInfo = true
        defer { isFetchingInfo = false }

        do {
            currentVideoInfo = try await client.fetchVideoInfo(url: url)
        } catch {
            fetchErrorMessage = error.localizedDescription
        }
    }

    /// 解析整個播放列表（flat-playlist，只取項目清單）。
    func fetchPlaylist(url: String) async {
        resetResults()
        isFetchingInfo = true
        defer { isFetchingInfo = false }

        do {
            currentPlaylist = try await client.fetchPlaylist(url: url)
        } catch {
            fetchErrorMessage = error.localizedDescription
        }
    }

    // MARK: - 新增：HowTo.mov → mp4 轉檔

    /// 供 TaskFileButtons 的「轉成 MP4」按鍵、以及選單「轉換影片為 MP4…」呼叫，
    /// 兩種入口共用同一份邏輯：目標檔案放在同一個資料夾，副檔名換成 .mp4。
    /// 來源不限於 .mov，任何 ffmpeg 讀得懂的影片格式都適用。
    func convertToMP4(sourceURL: URL) {
        var targetURL = sourceURL.deletingPathExtension().appendingPathExtension("mp4")
        // 來源本身就是 .mp4 時，上面那行算出來的路徑會跟原檔一樣，
        // 用 -y 覆寫的話等於把原檔洗掉，這裡改成另存一份帶後綴的檔名。
        if targetURL.path == sourceURL.path {
            targetURL = sourceURL.deletingPathExtension().appendingPathExtension("converted.mp4")
        }
        let task = ConversionTask(
            sourceURL: sourceURL,
            targetURL: targetURL,
            deleteSourceOnSuccess: deleteSourceMovAfterConversion
        )
        conversionQueueManager.enqueue(task)
    }

    /// 供 SettingsView 顯示 ffmpeg 版本，用法比照 client.fetchVersion()。
    func fetchFFmpegVersion() async -> String {
        do {
            let output = try await ProcessRunner.run(executablePath: ffmpegBinaryPath, arguments: ["-version"])
            // 第一行類似 "ffmpeg version 6.1.1 Copyright (c) ..."，只取到第一個換行前的內容即可
            return output.split(separator: "\n").first.map(String.init) ?? output
        } catch {
            return "無法取得（\(error.localizedDescription)）"
        }
    }
}

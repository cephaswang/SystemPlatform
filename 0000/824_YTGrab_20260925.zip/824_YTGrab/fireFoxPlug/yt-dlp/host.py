#!/usr/bin/env python3
"""
host.py
Native Messaging Host：透過 stdin/stdout 與 Firefox 擴充功能通訊，
接收下載請求後呼叫本機安裝的 yt-dlp 執行，並將進度／結果回傳給擴充功能。

通訊協定（Firefox Native Messaging）：
- 每則訊息前面有 4 bytes（原生位元組序）表示訊息長度，後面接 UTF-8 編碼的 JSON。
- 詳見：https://extensionworkshop.com/documentation/develop/native-messaging/

安全性原則：
- 本程式只接受擴充功能明確傳入的網址與參數，不接受任意 shell 字串。
- 呼叫 yt-dlp 一律使用參數陣列（不經過 shell），避免注入風險。
- 只允許擴充功能在 com.example.ytdlp.json 中宣告的 extension ID 呼叫。
"""

import json
import struct
import subprocess
import sys
import shutil
import os

# ---- 基本設定 -----------------------------------------------------------

YTDLP_BIN = shutil.which("yt-dlp") or "/opt/homebrew/bin/yt-dlp"
FFMPEG_BIN = shutil.which("ffmpeg") or "/opt/homebrew/bin/ffmpeg"
DEFAULT_DOWNLOAD_DIR = os.path.expanduser("~/Downloads")


# ---- Native Messaging I/O -------------------------------------------------

def read_message():
    """從 stdin 讀取一則訊息（4-byte 長度前綴 + JSON）。"""
    raw_length = sys.stdin.buffer.read(4)
    if len(raw_length) == 0:
        sys.exit(0)  # Firefox 關閉了連線
    message_length = struct.unpack("=I", raw_length)[0]
    message = sys.stdin.buffer.read(message_length).decode("utf-8")
    return json.loads(message)


def send_message(message_dict):
    """依 Native Messaging 協定，把訊息寫回 stdout 給擴充功能。"""
    encoded = json.dumps(message_dict).encode("utf-8")
    length_prefix = struct.pack("=I", len(encoded))
    sys.stdout.buffer.write(length_prefix)
    sys.stdout.buffer.write(encoded)
    sys.stdout.buffer.flush()


# ---- 指令處理 ---------------------------------------------------------

def handle_check_available():
    """回報 yt-dlp / ffmpeg 是否已安裝，供擴充功能顯示狀態。"""
    return {
        "type": "CHECK_AVAILABLE_RESULT",
        "ytdlpAvailable": shutil.which("yt-dlp") is not None or os.path.exists(YTDLP_BIN),
        "ffmpegAvailable": shutil.which("ffmpeg") is not None or os.path.exists(FFMPEG_BIN),
    }


def handle_download(payload):
    """
    呼叫 yt-dlp 下載指定網址。

    payload 預期欄位：
      - url (str)：目標網址（使用者自行提供，需自行確認擁有下載權利）
      - outputDir (str, 可省略)：下載儲存目錄，預設為 ~/Downloads
      - format (str, 可省略)：yt-dlp 的 -f 參數，預設為 "best"
    """
    url = payload.get("url")
    if not url:
        return {"type": "DOWNLOAD_RESULT", "ok": False, "error": "缺少 url 參數"}

    output_dir = payload.get("outputDir") or DEFAULT_DOWNLOAD_DIR
    # 不指定 format 時，不傳 -f，讓 yt-dlp 自動選擇最佳影音流並用 ffmpeg 合併
    # （比強制 -f best 選單一預先合併格式的畫質更好）
    video_format = payload.get("format")

    os.makedirs(output_dir, exist_ok=True)

    output_template = os.path.join(output_dir, "%(title)s.%(ext)s")

    command = [YTDLP_BIN]
    if video_format:
        command += ["-f", video_format]
    command += [
        "-o", output_template,
        "--no-playlist",
        url,
    ]

    try:
        result = subprocess.run(
            command,
            capture_output=True,
            text=True,
            timeout=1800,  # 30 分鐘逾時保護
        )
    except FileNotFoundError:
        return {
            "type": "DOWNLOAD_RESULT",
            "ok": False,
            "error": "找不到 yt-dlp，請先執行：brew install yt-dlp",
        }
    except subprocess.TimeoutExpired:
        return {"type": "DOWNLOAD_RESULT", "ok": False, "error": "下載逾時"}

    if result.returncode != 0:
        return {
            "type": "DOWNLOAD_RESULT",
            "ok": False,
            "error": result.stderr.strip()[-2000:],  # 避免訊息過長
        }

    return {
        "type": "DOWNLOAD_RESULT",
        "ok": True,
        "stdout": result.stdout.strip()[-2000:],
        "outputDir": output_dir,
    }


def handle_get_info(payload):
    """呼叫 `yt-dlp --dump-json` 取得影片中繼資料（不下載），供擴充功能顯示標題／畫質選項。"""
    url = payload.get("url")
    if not url:
        return {"type": "INFO_RESULT", "ok": False, "error": "缺少 url 參數"}

    command = [YTDLP_BIN, "--dump-json", "--no-playlist", url]

    try:
        result = subprocess.run(command, capture_output=True, text=True, timeout=60)
    except FileNotFoundError:
        return {
            "type": "INFO_RESULT",
            "ok": False,
            "error": "找不到 yt-dlp，請先執行：brew install yt-dlp",
        }
    except subprocess.TimeoutExpired:
        return {"type": "INFO_RESULT", "ok": False, "error": "取得資訊逾時"}

    if result.returncode != 0:
        return {"type": "INFO_RESULT", "ok": False, "error": result.stderr.strip()[-2000:]}

    try:
        info = json.loads(result.stdout)
    except json.JSONDecodeError:
        return {"type": "INFO_RESULT", "ok": False, "error": "無法解析 yt-dlp 回傳資料"}

    return {
        "type": "INFO_RESULT",
        "ok": True,
        "title": info.get("title"),
        "duration": info.get("duration"),
        "formats": [
            {
                "formatId": f.get("format_id"),
                "ext": f.get("ext"),
                "resolution": f.get("resolution"),
                "filesize": f.get("filesize"),
            }
            for f in info.get("formats", [])
        ],
    }


# ---- 主迴圈 -----------------------------------------------------------

def main():
    while True:
        message = read_message()
        message_type = message.get("type")

        if message_type == "CHECK_AVAILABLE":
            response = handle_check_available()
        elif message_type == "DOWNLOAD":
            response = handle_download(message)
        elif message_type == "GET_INFO":
            response = handle_get_info(message)
        else:
            response = {"type": "ERROR", "error": f"未知的指令類型: {message_type}"}

        send_message(response)


if __name__ == "__main__":
    main()

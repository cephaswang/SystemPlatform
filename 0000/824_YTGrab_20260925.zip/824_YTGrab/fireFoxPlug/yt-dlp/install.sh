#!/usr/bin/env bash
#
# install.sh
# 在 macOS 上安裝 Native Messaging Host：
# 1. 確認 yt-dlp / ffmpeg / python3 是否存在
# 2. 賦予 host.py 執行權限
# 3. 產生正確絕對路徑的 host manifest（com.example.ytdlp.json）
# 4. 複製到 Firefox 的 NativeMessagingHosts 目錄
#
# 使用方式：
#   cd native-host
#   chmod +x install.sh
#   ./install.sh

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
HOST_PY="$SCRIPT_DIR/host.py"
TEMPLATE_JSON="$SCRIPT_DIR/com.example.ytdlp.json"

TARGET_DIR="$HOME/Library/Application Support/Mozilla/NativeMessagingHosts"
TARGET_JSON="$TARGET_DIR/com.example.ytdlp.json"

echo "==> 檢查相依工具"

if ! command -v python3 >/dev/null 2>&1; then
  echo "找不到 python3，請先安裝（macOS 內建或 brew install python）。"
  exit 1
fi

if ! command -v yt-dlp >/dev/null 2>&1; then
  echo "找不到 yt-dlp，正在嘗試以 Homebrew 安裝..."
  if command -v brew >/dev/null 2>&1; then
    brew install yt-dlp
  else
    echo "找不到 Homebrew，請先安裝 Homebrew 或手動安裝 yt-dlp 後再重新執行此腳本。"
    exit 1
  fi
fi

if ! command -v ffmpeg >/dev/null 2>&1; then
  echo "找不到 ffmpeg，正在嘗試以 Homebrew 安裝..."
  if command -v brew >/dev/null 2>&1; then
    brew install ffmpeg
  else
    echo "警告：未安裝 ffmpeg，部分格式合併功能可能無法使用。"
  fi
fi

echo "==> 設定 host.py 執行權限"
chmod +x "$HOST_PY"

echo "==> 產生 Native Messaging Host 設定檔"
mkdir -p "$TARGET_DIR"

# 將範本中的 path 換成目前這台機器上 host.py 的絕對路徑
python3 - "$TEMPLATE_JSON" "$HOST_PY" "$TARGET_JSON" <<'PY'
import json
import sys

template_path, host_py_path, target_path = sys.argv[1:4]

with open(template_path, "r", encoding="utf-8") as f:
    data = json.load(f)

data["path"] = host_py_path

with open(target_path, "w", encoding="utf-8") as f:
    json.dump(data, f, indent=2, ensure_ascii=False)
PY

echo "==> 完成"
echo "Native Messaging Host 設定檔已寫入："
echo "  $TARGET_JSON"
echo ""
echo "host.py 執行路徑："
echo "  $HOST_PY"
echo ""
echo "提醒：allowed_extensions 中的擴充功能 ID 需與 manifest.json 的"
echo "browser_specific_settings.gecko.id 一致，目前設定為 video-analyzer@example.com。"
echo "若有修改過擴充功能 ID，請同步更新 com.example.ytdlp.json 後重新執行此腳本。"

打包成安裝檔
bash
cd video-analyzer-extension
npm run build

(base) admin@admins-Mac-mini video-analyzer-extension % npm start
(base) admin@admins-Mac-mini video-analyzer-extension % pwd
/Users/admin/Documents/workspace/824_YTGrab/fireFoxPlug/video-analyzer-extension

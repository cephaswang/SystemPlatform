打包成安裝檔
bash
cd video-analyzer-extension

rm -rf node_modules

npm install
npm audit fix --force
npm run build

npm start

/Users/admin/Documents/workspace/824_YTGrab/fireFoxPlug/video-analyzer-extension

https://www.facebook.com/reel/2192311934663219

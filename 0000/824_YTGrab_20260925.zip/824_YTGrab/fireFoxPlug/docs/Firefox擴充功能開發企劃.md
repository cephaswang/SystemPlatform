# Firefox 擴充功能開發企劃：影片分析與下載工具

## 一、專案概述

這是一個 Firefox 瀏覽器擴充功能（Extension／Add-on）的開發規劃，功能鎖定在：
- 分析網頁中的影片來源（偵測 `<video>` 標籤、串流連結等）
- 提供下載選項給使用者，並可選擇透過本機 yt-dlp 進行進階下載

**重要提醒**：多數影片平台（YouTube、Netflix、Facebook 等）的服務條款明確禁止未授權下載其內容，部分平台更有 DRM（數位版權保護）機制，規避 DRM 在許多地區（含美國 DMCA）屬違法行為。建議將此工具的應用範圍限定在：
- 使用者自己上傳／擁有版權的影片
- 明確標示公開授權（Creative Commons）的內容
- 開放式媒體檔案（如教育機構公開課程、自架網站的直接影片檔）

實務執行時建議先確認目標網站的使用條款。

---

## 二、macOS M4 開發環境需求

Firefox 擴充功能本質上是網頁技術（HTML／CSS／JavaScript），**不需要 Xcode 或編譯原生 App**，M4 晶片本身不影響開發（Apple Silicon 對這類工具都原生支援）。

### 必要軟體

| 軟體 | 用途 | 備註 |
|---|---|---|
| **Firefox（一般版或 Developer Edition）** | 測試、除錯用瀏覽器 | `web-ext-config.cjs` 預設指向一般版 `firefox`；若改用 Developer Edition，需改成其執行檔絕對路徑，或先安裝該版本 |
| **Node.js + npm** | 執行建置工具鏈 | 用 Homebrew 安裝最方便 |
| **web-ext**（Mozilla 官方 CLI 工具） | 本機執行、打包、簽署、上架擴充功能 | 透過 npm 安裝，是 Firefox 官方推薦的開發工具 |
| **程式碼編輯器**（VS Code 為主流選擇） | 撰寫擴充功能檔案 | 非必要但強烈建議，有擴充套件生態可裝 ESLint、Manifest 語法檢查等 |
| **Homebrew** | macOS 套件管理工具 | 用來安裝上述 Node.js 等工具 |

### 選用／進階工具

| 軟體 | 用途 |
|---|---|
| **Git** | 版本控制（M4 macOS 內建或透過 Xcode Command Line Tools 取得） |
| **Xcode Command Line Tools** | 僅提供 Git、編譯基礎工具，本身不用於擴充功能開發，但很多 npm 套件安裝時需要它 |
| **Firefox Add-ons 開發者帳號** | 上架至 addons.mozilla.org（AMO）需要，簽署擴充功能也需要此帳號 |
| **yt-dlp** | 進階下載功能的核心工具，透過 Native Messaging 呼叫（見第六章） |
| **ffmpeg** | 搭配 yt-dlp 合併音視訊流、格式轉換 |
| **Deno** | yt-dlp 解析 YouTube 格式所需的 JavaScript runtime（見第七章） |

### 不需要的東西
- 不需要 Xcode（那是給 iOS/macOS 原生 App 用的）
- 不需要任何 C/C++ 編譯器（除非要用 Native Messaging 搭配本機程式，那是進階功能）
- 不需要特殊的「編譯軟體」——Firefox 擴充功能不需要傳統意義上的編譯，`web-ext build` 只是打包成 `.xpi` 檔

---

## 三、開發流程規劃

1. **環境建置**：Homebrew → Node.js → web-ext → VS Code
2. **專案架構**：建立 manifest.json（擴充功能設定檔）、背景腳本、內容腳本（content script，負責偵測頁面影片元素）、彈出視窗介面（popup UI）
3. **本機測試**：用 `npm start`（即 `web-ext run`）直接在 Firefox 中載入擴充功能做即時測試，不需每次重新打包
4. **打包**：`npm run build`（即 `web-ext build`）產生 `.xpi` 安裝檔
5. **簽署與上架**：透過 Mozilla 開發者帳號簽署（未簽署的擴充功能無法在正式版 Firefox 安裝），可選擇上架 AMO 公開發布，或僅供自己/團隊私下安裝

---

## 四、權限與審核注意事項

Firefox 擴充功能上架 AMO 需經過 Mozilla 審核，若功能涉及「批量下載影片」，容易被要求：
- 詳細說明使用情境與合法性
- 避免預設繞過平台保護機制的功能
- manifest 中宣告的權限要合理對應功能描述

目前專案 `manifest.json` 實際宣告的權限：

| 權限 | 用途 |
|---|---|
| `activeTab` | 取得目前使用中分頁資訊 |
| `downloads` | 呼叫瀏覽器原生下載 API |
| `storage` | 儲存使用者設定（設定頁） |
| `nativeMessaging` | 與本機 yt-dlp host 通訊（進階下載） |
| `webNavigation` | 偵測分頁導航，清除舊的影片偵測快取 |
| `<all_urls>` | 讓 content script 能在任意網頁執行偵測 |

---

## 五、專案完整檔案結構表

```
video-analyzer-extension/
├── manifest.json
├── background/
│   └── background.js
├── content-scripts/
│   └── content.js
├── popup/
│   ├── popup.html
│   ├── popup.css
│   └── popup.js
├── options/
│   ├── options.html
│   ├── options.css
│   └── options.js
├── icons/
│   ├── icon-16.png
│   ├── icon-32.png
│   ├── icon-48.png
│   └── icon-128.png
├── _locales/
│   ├── zh_TW/
│   │   └── messages.json
│   └── en/
│       └── messages.json
├── package.json
├── web-ext-config.cjs
├── .gitignore
└── README.md
```

> **與最初規劃的差異**：`web-ext-config.js` 已改名為 `web-ext-config.cjs`（`web-ext` 8.x 起要求明確的 CommonJS/ESM 副檔名，`.js` 會被判定為格式不明確而報錯）。`package.json` 中所有 `web-ext` 指令都已同步改為指向 `.cjs`。

### 檔案用途說明

| 檔案／資料夾 | 類型 | 用途說明 |
|---|---|---|
| `manifest.json` | 必要 | 擴充功能核心設定檔，宣告名稱、版本、`default_locale`、權限、進入點 |
| `background/background.js` | 必要 | 背景腳本，處理影片清單暫存、`downloads` API 下載、Native Messaging 連線與請求佇列 |
| `content-scripts/content.js` | 必要 | 注入到網頁中的腳本，掃描 DOM（`<video>`、`<source>` 標籤）並回傳偵測結果 |
| `popup/popup.html` | 必要 | 彈出視窗，顯示偵測到的影片清單、下載按鈕，以及「進階下載（yt-dlp）」區塊 |
| `popup/popup.css` | 建議 | popup 介面樣式，含進階下載區塊的狀態顏色（可用／不可用／結果） |
| `popup/popup.js` | 必要 | 處理 popup 互動邏輯：一般下載走 `downloads` API；進階下載檢查 yt-dlp 可用性後透過訊息呼叫 background |
| `options/options.html` | 選用 | 使用者設定頁面（檔名樣板、自動重新掃描） |
| `options/options.css` | 選用 | 設定頁面樣式 |
| `options/options.js` | 選用 | 設定頁面邏輯與儲存（搭配 `storage` API） |
| `icons/` | 必要 | 各尺寸擴充功能圖示，AMO 上架與工具列顯示都需要 |
| `_locales/` | 選用（但一旦存在即為必要） | 多語系文字檔；**只要此資料夾存在，`manifest.json` 就必須宣告 `default_locale`，否則 Firefox 會判定整個擴充功能無效** |
| `package.json` | 建議 | Node.js 專案設定，管理 `web-ext` 等開發依賴套件與四個指令（`start`／`lint`／`build`／`sign`） |
| `web-ext-config.cjs` | 選用 | `web-ext` 工具的自訂設定（測試用 Firefox 執行檔、打包忽略清單等） |
| `.gitignore` | 建議 | 版本控制忽略清單（`node_modules/`、打包產出、`.DS_Store` 等） |
| `README.md` | 建議 | 專案說明文件，記錄安裝、開發、打包、簽署流程 |

### 打包後產出

| 檔案 | 說明 |
|---|---|
| `web-ext-artifacts/*.xpi` | 執行 `npm run build`（`web-ext build`）後產生的安裝檔 |

---

## 六、引用 yt-dlp 處理影片（Native Messaging 架構）

### 為什麼不能直接引用

Firefox 擴充功能執行在瀏覽器的沙盒（sandbox）JavaScript 環境中，基於安全性限制：
- 無法執行本機二進位檔案（yt-dlp 是 Python 寫的獨立執行檔）
- 無法直接呼叫系統 shell 指令
- content script／background script 都被隔離，不能存取檔案系統或啟動子行程

### 可行方案：Native Messaging

架構是三層：

```
Firefox 擴充功能 (JS)
      ↕ (透過 stdin/stdout 通訊)
本機原生應用程式 (Native App／Host)
      ↕ (subprocess 呼叫)
yt-dlp 執行檔
```

### 實際實作的通訊協定

`background.js` 與 `native-host/host.py` 之間以三種訊息類型溝通：

| 訊息類型 | 方向 | 用途 |
|---|---|---|
| `CHECK_AVAILABLE` → `CHECK_AVAILABLE_RESULT` | popup 開啟時自動送出 | 回報本機是否已安裝 yt-dlp／ffmpeg，決定進階下載按鈕是否啟用 |
| `GET_INFO` → `INFO_RESULT` | 預留 | 呼叫 `yt-dlp --dump-json` 取得標題、時長、可用格式（不下載），目前 popup 尚未使用此功能 |
| `DOWNLOAD` → `DOWNLOAD_RESULT` | 使用者點擊「分析並下載目前頁面」 | 以目前分頁網址呼叫 yt-dlp 執行下載 |

`background.js` 內以 FIFO 佇列比對請求與回應，因為 `host.py` 採一收一送、依序處理，且 Native Messaging 的 port 本身不帶請求 ID。

### 實際檔案結構（可彈性擺放）

規劃時建議放在擴充功能內：

```
video-analyzer-extension/
├── ...（第五章原有結構）
└── native-host/
    ├── host.py
    ├── com.example.ytdlp.json
    └── install.sh
```

**實測發現**：`install.sh` 是用腳本自身所在的相對路徑組合絕對路徑，因此這個資料夾**也可以放在擴充功能外面**（例如與 `video-analyzer-extension/` 同層的獨立資料夾），一樣能正常運作，只要記得進入該資料夾再執行 `./install.sh`。

| 檔案 | 用途說明 |
|---|---|
| `host.py` | 常駐 stdin/stdout 迴圈，處理 `CHECK_AVAILABLE`／`GET_INFO`／`DOWNLOAD` 三種指令，以參數陣列（非 shell 字串）呼叫 yt-dlp，避免指令注入風險，並有 30 分鐘下載逾時保護 |
| `com.example.ytdlp.json` | Host 設定檔範本，`allowed_extensions` 對應 `manifest.json` 的 `browser_specific_settings.gecko.id`（`video-analyzer@example.com`） |
| `install.sh` | 檢查／安裝 yt-dlp、ffmpeg，賦予 `host.py` 執行權限，自動把絕對路徑寫入設定檔並複製到 `~/Library/Application Support/Mozilla/NativeMessagingHosts/` |

### macOS 上安裝 yt-dlp 與相依套件

```bash
brew install yt-dlp
brew install ffmpeg
```

### 重要限制與提醒

1. **AMO 審核**：涉及 Native Messaging 呼叫外部下載工具的擴充功能，Mozilla 審核會更嚴格，需要清楚說明用途
2. **無法直接上架自動安裝**：Native Host 必須讓使用者另外執行 `install.sh` 手動安裝，這不是單純裝完擴充功能就能用的體驗
3. **簽署考量**：如果只是自己或小範圍使用，可以用 Firefox 的「未列出（unlisted）」簽署方式，不用公開上架
4. **法律風險不變**：yt-dlp 本身是合法的開源工具（用途中立），但實際下載哪些平台的影片，仍受限於該平台的服務條款，這點不會因為換了下載工具而改變

---

## 七、實際開發過程中遇到的問題與修正

以下是實作、測試階段實際遇到並已修正的問題，供之後排查類似狀況參考。

### 7.1 `web-ext-config.js` 副檔名棄用警告

**現象**：`npm start` 出現 `WARNING: config file ... should be renamed to ".cjs" or ".mjs"`，新版 `web-ext` 甚至會直接報錯 `Cannot find module ...web-ext-config.js`。

**修正**：檔案改名為 `web-ext-config.cjs`，並同步更新 `package.json` 四個指令（`start`／`lint`／`build`／`sign`）與 `web-ext-config.cjs` 內 `ignoreFiles` 清單裡的檔名參照。

### 7.2 找不到 Firefox Developer Edition

**現象**：`Error: spawn /Applications/Firefox Developer Edition.app/... ENOENT`。

**原因**：`web-ext-config.cjs` 預設指定啟動 Developer Edition，但本機只裝了一般版 Firefox。

**修正**：把 `run.firefox` 改成 `"firefox"`（一般版），或改成 Developer Edition 執行檔的絕對路徑（需先安裝該版本）。

### 7.3 `_locales` 存在但缺少 `default_locale`

**現象**：`WebExtError: ... Reading manifest: The "default_locale" property is required when a "_locales/" directory is present.`

**原因**：只要專案裡有 `_locales/` 資料夾，Firefox 就強制要求 `manifest.json` 宣告 `default_locale`。

**修正**：在 `manifest.json` 加入 `"default_locale": "zh_TW"`。

### 7.4 背景腳本因缺少權限而整支掛掉

**現象**：`background.js` 用到 `browser.webNavigation.onCommitted`，但 `manifest.json` 未宣告 `webNavigation` 權限，導致 `browser.webNavigation` 為 `undefined`，執行到該行直接拋出 `TypeError`，整支背景腳本停擺（連帶下載、影片偵測功能都失效）。

**修正**：在 `manifest.json` 的 `permissions` 加入 `"webNavigation"`。

### 7.5 專案資料夾內誤植巢狀路徑

**現象**：下載檔案時不小心把完整路徑（`mnt/user-data/outputs/...`）一起存進了專案資料夾，形成多餘的巢狀資料夾。

**修正**：確認下載時只保留檔案本身，並用 `rm -rf` 清除誤植的巢狀資料夾。

### 7.6 yt-dlp 下載 YouTube 影片失敗

**現象**：
```
WARNING: "-f best" selects the best pre-merged format which is often not the best option...
WARNING: [youtube] No supported JavaScript runtime could be found...
ERROR: [youtube] xxxxx: Requested format is not available.
```

**原因與修正**：
1. `host.py` 原本預設用 `-f best`，只挑單一預先合併格式，畫質較差 → 改成不指定 `-f` 時完全不傳該參數，讓 yt-dlp 自動選最佳影音流並用 ffmpeg 合併；`popup.js` 也移除預設傳送 `format: "best"`。
2. yt-dlp 新版解析 YouTube 格式需要 JavaScript runtime（用於解密簽章機制），未安裝時格式清單會不完整，導致指定格式抓不到 → 安裝 Deno：
   ```bash
   brew install deno
   ```
   `host.py` 屬於 Native Messaging Host，非擴充功能打包內容，修改或環境變動後**不需要重新載入擴充功能**，Firefox 每次呼叫都會重啟該行程。

### 7.7 Firefox 瀏覽器主控台雜訊（Nimbus 實驗警告）

**現象**：主控台出現大量 `Experiment ... has unknown featureId ...` 訊息。

**原因**：這是 Firefox 內部 Nimbus 實驗系統（A/B 測試機制）的警告，與擴充功能開發完全無關，因為 `web-ext-config.cjs` 開了 `browserConsole: true` 才會一併顯示。

**修正**：非必要，可忽略；若想減少雜訊，可將 `browserConsole` 設為 `false`。

---

## 八、目前功能完成度

| 功能 | 狀態 |
|---|---|
| 頁面影片偵測（`<video>`/`<source>` 直連網址） | 完成 |
| 一般下載（`downloads` API） | 完成 |
| 多語系文字檔（中／英） | 完成，但目前介面文字仍為寫死中文，尚未接上 `chrome.i18n` |
| 設定頁（檔名樣板、自動重新掃描） | UI 與儲存邏輯完成，尚未接回下載流程實際套用 |
| Native Messaging Host（yt-dlp／ffmpeg） | 完成，含安裝腳本 |
| 進階下載 UI 與 background 串接 | 完成：可用性檢查、下載請求、結果顯示 |
| `GET_INFO`（下載前預覽標題／可用格式） | host.py 已支援，popup 尚未串接 UI |
| AMO 簽署與上架 | 尚未執行 |

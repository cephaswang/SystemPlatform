/**
 * background.js
 * 常駐背景腳本：
 * 1. 接收來自 content script 的「偵測到影片」訊息，暫存於各分頁對應的清單。
 * 2. 接收來自 popup 的「下載」請求，透過 downloads API 觸發下載
 *    （僅處理頁面 DOM 中直接暴露的影片網址）。
 * 3. 接收來自 popup 的「進階下載」請求，透過 Native Messaging 呼叫本機
 *    native-host/host.py，再由它呼叫已安裝的 yt-dlp（需先執行
 *    native-host/install.sh 完成本機部署，否則連線會失敗）。
 *
 * 注意：本腳本本身不會嘗試繞過任何平台的 DRM 或授權保護機制；
 * 進階下載是否合法，取決於使用者對該網址內容的實際權利與該平台服務條款。
 */

const NATIVE_HOST_NAME = "com.example.ytdlp";

// 分頁 ID -> 偵測到的影片清單
const tabVideoMap = new Map();

// ---- Native Messaging（與本機 yt-dlp host 通訊）--------------------------

let nativePort = null;
// FIFO 佇列：host.py 採一收一送、依序處理，因此用佇列依序比對回應與請求
let pendingNativeRequests = [];

function getNativePort() {
  if (nativePort) return nativePort;

  nativePort = browser.runtime.connectNative(NATIVE_HOST_NAME);

  nativePort.onMessage.addListener((response) => {
    const pending = pendingNativeRequests.shift();
    if (pending) pending.resolve(response);
  });

  nativePort.onDisconnect.addListener(() => {
    const error = browser.runtime.lastError
      ? browser.runtime.lastError.message
      : "Native host 已中斷連線（可能尚未安裝，請先執行 native-host/install.sh）";

    // 連線中斷時，讓所有還在等待的請求都收到錯誤，避免卡死
    pendingNativeRequests.forEach((pending) => pending.reject(new Error(error)));
    pendingNativeRequests = [];
    nativePort = null;
  });

  return nativePort;
}

function sendNativeRequest(message) {
  return new Promise((resolve, reject) => {
    let port;
    try {
      port = getNativePort();
    } catch (error) {
      reject(error);
      return;
    }
    pendingNativeRequests.push({ resolve, reject });
    port.postMessage(message);
  });
}

browser.runtime.onMessage.addListener((message, sender) => {
  const tabId = sender.tab ? sender.tab.id : null;

  switch (message.type) {
    case "VIDEOS_DETECTED": {
      if (tabId !== null) {
        tabVideoMap.set(tabId, message.videos || []);
        updateBadge(tabId, message.videos ? message.videos.length : 0);
      }
      return Promise.resolve({ ok: true });
    }

    case "GET_VIDEOS_FOR_ACTIVE_TAB": {
      return getActiveTabId().then((activeTabId) => {
        return {
          tabId: activeTabId,
          videos: tabVideoMap.get(activeTabId) || []
        };
      });
    }

    case "DOWNLOAD_VIDEO": {
      return downloadVideo(message.url, message.filename);
    }

    case "YTDLP_CHECK_AVAILABLE": {
      return sendNativeRequest({ type: "CHECK_AVAILABLE" }).catch((error) => ({
        type: "CHECK_AVAILABLE_RESULT",
        ytdlpAvailable: false,
        ffmpegAvailable: false,
        error: error.message
      }));
    }

    case "YTDLP_GET_INFO": {
      return sendNativeRequest({
        type: "GET_INFO",
        url: message.url
      }).catch((error) => ({
        type: "INFO_RESULT",
        ok: false,
        error: error.message
      }));
    }

    case "YTDLP_DOWNLOAD": {
      return sendNativeRequest({
        type: "DOWNLOAD",
        url: message.url,
        outputDir: message.outputDir,
        format: message.format
      }).catch((error) => ({
        type: "DOWNLOAD_RESULT",
        ok: false,
        error: error.message
      }));
    }

    default:
      return undefined;
  }
});

// 分頁關閉時清除暫存資料，避免記憶體累積
browser.tabs.onRemoved.addListener((tabId) => {
  tabVideoMap.delete(tabId);
});

// 分頁重新導向 / 重新整理時清除舊資料
browser.webNavigation.onCommitted.addListener((details) => {
  if (details.frameId === 0) {
    tabVideoMap.delete(details.tabId);
    updateBadge(details.tabId, 0);
  }
});

function getActiveTabId() {
  return browser.tabs
    .query({ active: true, currentWindow: true })
    .then((tabs) => (tabs.length > 0 ? tabs[0].id : null));
}

function updateBadge(tabId, count) {
  browser.browserAction.setBadgeText({
    tabId,
    text: count > 0 ? String(count) : ""
  });
  browser.browserAction.setBadgeBackgroundColor({ color: "#2b7de9" });
}

function downloadVideo(url, filename) {
  return browser.downloads
    .download({
      url,
      filename,
      saveAs: false
    })
    .then((downloadId) => ({ ok: true, downloadId }))
    .catch((error) => ({ ok: false, error: error.message }));
}

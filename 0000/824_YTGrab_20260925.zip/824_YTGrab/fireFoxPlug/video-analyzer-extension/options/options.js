/**
 * options.js
 * 讀取／儲存使用者偏好設定，存放於 browser.storage.local。
 */

const DEFAULTS = {
  filenameTemplate: "{title}-{index}.{ext}",
  autoRescan: true
};

const form = document.getElementById("options-form");
const filenameInput = document.getElementById("filename-template");
const autoRescanInput = document.getElementById("auto-rescan");
const saveStatus = document.getElementById("save-status");

function loadOptions() {
  browser.storage.local.get(DEFAULTS).then((stored) => {
    filenameInput.value = stored.filenameTemplate;
    autoRescanInput.checked = stored.autoRescan;
  });
}

function saveOptions(event) {
  event.preventDefault();

  const options = {
    filenameTemplate: filenameInput.value.trim() || DEFAULTS.filenameTemplate,
    autoRescan: autoRescanInput.checked
  };

  browser.storage.local.set(options).then(() => {
    saveStatus.textContent = "已儲存";
    setTimeout(() => {
      saveStatus.textContent = "";
    }, 2000);
  });
}

form.addEventListener("submit", saveOptions);
document.addEventListener("DOMContentLoaded", loadOptions);

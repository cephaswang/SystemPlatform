/**
 * content.js
 * 注入到每個頁面的內容腳本：
 * 掃描 DOM 中的 <video> / <source> 元素，收集可直接存取的影片網址，
 * 並將結果送回 background script。
 *
 * 僅收集頁面中「明確暴露的直連網址」，不嘗試攔截或解密任何加密串流
 * （例如 DRM 保護的內容不會出現在這份清單中）。
 */

(function () {
  function collectVideos() {
    const found = new Map(); // url -> info，避免重複

    // 1. <video> 標籤本身的 src
    document.querySelectorAll("video").forEach((video) => {
      addIfValid(found, video.currentSrc || video.src, video);
      // 2. <video> 底下的 <source> 子標籤
      video.querySelectorAll("source").forEach((source) => {
        addIfValid(found, source.src, video);
      });
    });

    return Array.from(found.values());
  }

  function addIfValid(map, url, videoEl) {
    if (!url || map.has(url)) return;
    if (!/^https?:|^blob:/.test(url)) return;

    map.set(url, {
      url,
      pageTitle: document.title,
      width: videoEl.videoWidth || null,
      height: videoEl.videoHeight || null,
      duration: isFinite(videoEl.duration) ? videoEl.duration : null,
      guessedExt: guessExtension(url)
    });
  }

  function guessExtension(url) {
    const match = url.match(/\.(mp4|webm|ogg|m3u8|mov)(\?|$)/i);
    return match ? match[1].toLowerCase() : "unknown";
  }

  function reportToBackground() {
    const videos = collectVideos();
    if (videos.length > 0) {
      browser.runtime.sendMessage({
        type: "VIDEOS_DETECTED",
        videos
      });
    }
  }

  // 初次載入時掃描一次
  reportToBackground();

  // 頁面動態載入影片（如 SPA、延遲載入）時，用 MutationObserver 持續偵測
  const observer = new MutationObserver(() => {
    reportToBackground();
  });

  observer.observe(document.documentElement, {
    childList: true,
    subtree: true,
    attributes: true,
    attributeFilter: ["src"]
  });
})();

/**
 * popup.js
 * 向 background 要求目前分頁偵測到的影片清單，並渲染成列表；
 * 使用者點擊下載按鈕時，請求 background 觸發下載。
 */

const listEl = document.getElementById("video-list");
const emptyStateEl = document.getElementById("empty-state");
const refreshBtn = document.getElementById("refresh-btn");
const optionsLink = document.getElementById("options-link");

const ytdlpStatusEl = document.getElementById("ytdlp-status");
const ytdlpDownloadBtn = document.getElementById("ytdlp-download-btn");
const ytdlpResultEl = document.getElementById("ytdlp-result");

function loadVideos() {
  browser.runtime
    .sendMessage({ type: "GET_VIDEOS_FOR_ACTIVE_TAB" })
    .then((response) => {
      renderVideos((response && response.videos) || []);
    });
}

function renderVideos(videos) {
  listEl.innerHTML = "";

  if (videos.length === 0) {
    emptyStateEl.style.display = "block";
    return;
  }

  emptyStateEl.style.display = "none";

  videos.forEach((video, index) => {
    const li = document.createElement("li");
    li.className = "video-item";

    const meta = document.createElement("div");
    meta.className = "video-meta";
    meta.textContent = buildMetaText(video);

    const actions = document.createElement("div");
    actions.className = "video-actions";

    const downloadBtn = document.createElement("button");
    downloadBtn.type = "button";
    downloadBtn.className = "download-btn";
    downloadBtn.textContent = "下載";
    downloadBtn.addEventListener("click", () => {
      handleDownload(video, index, downloadBtn);
    });

    actions.appendChild(downloadBtn);
    li.appendChild(meta);
    li.appendChild(actions);
    listEl.appendChild(li);
  });
}

function buildMetaText(video) {
  const parts = [];
  if (video.guessedExt && video.guessedExt !== "unknown") {
    parts.push(video.guessedExt.toUpperCase());
  }
  if (video.width && video.height) {
    parts.push(`${video.width}×${video.height}`);
  }
  if (video.duration) {
    parts.push(formatDuration(video.duration));
  }
  return parts.length > 0 ? parts.join(" · ") : video.url;
}

function formatDuration(seconds) {
  const total = Math.round(seconds);
  const m = Math.floor(total / 60);
  const s = total % 60;
  return `${m}:${String(s).padStart(2, "0")}`;
}

function handleDownload(video, index, buttonEl) {
  buttonEl.disabled = true;
  buttonEl.textContent = "下載中...";

  const filename = suggestFilename(video, index);

  browser.runtime
    .sendMessage({
      type: "DOWNLOAD_VIDEO",
      url: video.url,
      filename
    })
    .then((result) => {
      if (result && result.ok) {
        buttonEl.textContent = "已加入下載";
      } else {
        buttonEl.textContent = "失敗";
        buttonEl.disabled = false;
      }
    });
}

function suggestFilename(video, index) {
  const safeTitle = (video.pageTitle || "video")
    .replace(/[\\/:*?"<>|]/g, "_")
    .slice(0, 60);
  const ext = video.guessedExt !== "unknown" ? video.guessedExt : "mp4";
  return `${safeTitle}-${index + 1}.${ext}`;
}

refreshBtn.addEventListener("click", loadVideos);

optionsLink.addEventListener("click", (event) => {
  event.preventDefault();
  browser.runtime.openOptionsPage();
});

// ---- 進階下載（透過 Native Messaging 呼叫本機 yt-dlp）--------------------

function checkYtdlpAvailability() {
  ytdlpStatusEl.textContent = "檢查本機 yt-dlp 狀態中...";
  ytdlpStatusEl.className = "ytdlp-status";

  browser.runtime
    .sendMessage({ type: "YTDLP_CHECK_AVAILABLE" })
    .then((response) => {
      if (response && response.ytdlpAvailable) {
        ytdlpStatusEl.textContent = response.ffmpegAvailable
          ? "已偵測到本機 yt-dlp 與 ffmpeg。"
          : "已偵測到本機 yt-dlp（未偵測到 ffmpeg，部分格式可能無法合併）。";
        ytdlpStatusEl.classList.add("available");
        ytdlpDownloadBtn.disabled = false;
      } else {
        const reason = response && response.error ? `（${response.error}）` : "";
        ytdlpStatusEl.textContent = `找不到本機 yt-dlp host${reason}，請先執行 native-host/install.sh。`;
        ytdlpStatusEl.classList.add("unavailable");
        ytdlpDownloadBtn.disabled = true;
      }
    })
    .catch((error) => {
      ytdlpStatusEl.textContent = `檢查失敗：${error.message}`;
      ytdlpStatusEl.classList.add("unavailable");
      ytdlpDownloadBtn.disabled = true;
    });
}

function getActiveTabUrl() {
  return browser.tabs
    .query({ active: true, currentWindow: true })
    .then((tabs) => (tabs.length > 0 ? tabs[0].url : null));
}

function handleYtdlpDownload() {
  ytdlpResultEl.textContent = "";
  ytdlpResultEl.className = "ytdlp-result";
  ytdlpDownloadBtn.disabled = true;
  ytdlpDownloadBtn.textContent = "下載中...（可能需要一段時間）";

  getActiveTabUrl()
    .then((url) => {
      if (!url) {
        throw new Error("無法取得目前分頁網址");
      }
      return browser.runtime.sendMessage({
        type: "YTDLP_DOWNLOAD",
        url
      });
    })
    .then((result) => {
      if (result && result.ok) {
        ytdlpResultEl.textContent = `下載完成，已儲存至：${result.outputDir}`;
        ytdlpResultEl.classList.add("ok");
      } else {
        const message = (result && result.error) || "下載失敗（未知錯誤）";
        ytdlpResultEl.textContent = message;
        ytdlpResultEl.classList.add("error");
      }
    })
    .catch((error) => {
      ytdlpResultEl.textContent = error.message;
      ytdlpResultEl.classList.add("error");
    })
    .finally(() => {
      ytdlpDownloadBtn.disabled = false;
      ytdlpDownloadBtn.textContent = "分析並下載目前頁面";
    });
}

ytdlpDownloadBtn.addEventListener("click", handleYtdlpDownload);

document.addEventListener("DOMContentLoaded", () => {
  loadVideos();
  checkYtdlpAvailability();
});

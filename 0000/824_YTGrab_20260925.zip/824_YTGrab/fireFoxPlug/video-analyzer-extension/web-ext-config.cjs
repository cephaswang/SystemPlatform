// web-ext 設定檔
// 文件：https://extensionworkshop.com/documentation/develop/getting-started-with-web-ext/

module.exports = {
  // 執行 `npm start` (web-ext run) 時套用
  run: {
    // "firefox" = 一般版；若有安裝 Developer Edition 想改用它，
    // 改成 Developer Edition 執行檔的絕對路徑，例如：
    // "/Applications/Firefox Developer Edition.app/Contents/MacOS/firefox"
    firefox: "firefox",
    startUrl: ["about:debugging#/runtime/this-firefox"],
    browserConsole: false, // 改為 true 可看到瀏覽器主控台（含大量無關的內部訊息）
    reload: true
  },

  // 執行 `npm run build` (web-ext build) 時套用
  build: {
    overwriteDest: true
  },

  // 執行 `npm run lint` (web-ext lint) 時套用
  lint: {
    warningsAsErrors: false
  },

  // 執行 `npm run sign` (web-ext sign) 時套用
  // apiKey / apiSecret 建議透過環境變數帶入，不要寫死在此檔案：
  //   WEB_EXT_API_KEY=xxx WEB_EXT_API_SECRET=xxx npm run sign
  sign: {
    channel: "unlisted"
  },

  // 打包／執行時要忽略的檔案
  ignoreFiles: [
    "package.json",
    "package-lock.json",
    "web-ext-config.cjs",
    "README.md",
    "native-host/**",
    "node_modules/**",
    ".git/**"
  ],

  sourceDir: "."
};

# Video Analyzer — Firefox 擴充功能

分析目前頁面中的影片元素，並提供下載連結。

> **使用範圍提醒**：本工具只偵測頁面 DOM 中明確暴露的直連影片網址（`<video>`／`<source>` 的
> `src`，副檔名如 `.mp4`／`.webm`／`.m3u8` 等），不會嘗試繞過任何平台的 DRM 或授權保護機制。
> 請僅用於下載你擁有權利、或明確標示公開授權（如 Creative Commons）的影片內容，並遵守各
> 網站的服務條款。

---

## 專案結構

```
video-analyzer-extension/
├── manifest.json           擴充功能核心設定檔
├── background/
│   └── background.js       背景腳本，處理下載與分頁間的影片清單
├── content-scripts/
│   └── content.js          注入頁面，掃描 <video>/<source> 元素
├── popup/
│   ├── popup.html
│   ├── popup.css
│   └── popup.js            工具列彈出視窗，顯示清單與下載按鈕
├── options/
│   ├── options.html
│   ├── options.css
│   └── options.js          設定頁（檔名樣板、自動重新掃描）
├── icons/                  16/32/48/128 px 工具列與 AMO 圖示
├── _locales/
│   ├── zh_TW/messages.json
│   └── en/messages.json    多語系文字
├── package.json
├── web-ext-config.js       web-ext 開發／打包設定
└── .gitignore
```

---

## 開發環境需求

- macOS（Apple Silicon / M4 皆可）
- [Homebrew](https://brew.sh/)
- Node.js 18 以上
- Firefox（建議另裝 [Developer Edition](https://www.mozilla.org/firefox/developer/) 做測試）

```bash
brew install node
```

---

## 安裝相依套件

```bash
npm install
```

---

## 本機開發（即時載入測試）

```bash
npm start
```

這會執行 `web-ext run`，自動開啟 Firefox 並載入未打包的擴充功能，
修改程式碼後會自動重新載入（依 `web-ext-config.js` 的 `run.reload` 設定）。

也可以手動載入：在 Firefox 網址列輸入 `about:debugging#/runtime/this-firefox`，
點擊「載入臨時附加元件」，選擇本專案的 `manifest.json`。

---

## 程式碼檢查

```bash
npm run lint
```

執行 `web-ext lint`，檢查 manifest 格式與常見的擴充功能問題。

---

## 打包成 .xpi

```bash
npm run build
```

產出檔案會放在 `web-ext-artifacts/` 資料夾。

---

## 簽署（供正式版 Firefox 安裝）

未簽署的擴充功能無法在正式版 Firefox 安裝。若只自用或小範圍分發，
可用「未列出（unlisted）」簽署，不需公開上架 AMO：

```bash
WEB_EXT_API_KEY=你的_API_Key WEB_EXT_API_SECRET=你的_API_Secret npm run sign
```

API Key／Secret 需先在 [addons.mozilla.org 開發者帳號](https://addons.mozilla.org/developers/)
的「API 金鑰管理」頁面取得。**請勿將金鑰寫入程式碼或提交到版本控制。**

---

## 資料收集聲明（data_collection_permissions）

自 2025 年 11 月起，AMO 要求所有新送審的擴充功能都必須在 `manifest.json` 的
`browser_specific_settings.gecko` 底下宣告 `data_collection_permissions`，
否則簽署／送審會失敗（`General Tests` 會回報缺少此欄位）。

本擴充功能的資料流向：

- `storage`：使用者設定只存在本機瀏覽器，未對外傳輸
- `downloads`：呼叫瀏覽器原生下載 API，檔案存到使用者本機硬碟
- `nativeMessaging`：影片網址只傳給**同一台電腦上**的本機 `yt-dlp` host，不會送到開發者
  或任何第三方伺服器

因此目前宣告為不收集／不對外傳輸任何資料：

```json
"data_collection_permissions": {
  "required": ["none"]
}
```

> 若之後新增任何會把資料送到遠端伺服器的功能（例如使用統計回傳、雲端同步），
> 記得回來更新這個欄位，否則會被 AMO 審核退回。

---

## 待補項目

- Native Messaging Host（`native-host/`）：若需串接本機 `yt-dlp` 處理更複雜的來源，
  屬於進階功能，需另外建立本機常駐程式與安裝腳本，且使用者需手動安裝，無法透過
  AMO 自動部署。
- 實際上架前，建議重新檢視 `manifest.json` 中宣告的權限（`downloads`、`<all_urls>` 等）
  是否都對應到實際功能，AMO 審核會針對權限與功能描述的一致性做檢查。

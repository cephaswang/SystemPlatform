package org.share35app.DictationHelper.speech

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.launch

/**
 * 雙語模式協調器。
 *
 * 同時管理兩個 [SpeechRecognitionEngine]（例如中文＋英文），
 * 將兩者的辨識結果依信心分數比較，只把較準確的結果往下游
 * （TranscriptFileWriter / UI）發送，比照 macOS 版的設計精神。
 *
 * 使用方式：
 *   val coordinator = BilingualRecognitionCoordinator(engineA, engineB)
 *   coordinator.results.collect { best -> ... }
 *   coordinator.start()
 *   ...
 *   coordinator.stop()
 */
class BilingualRecognitionCoordinator(
    private val primaryEngine: SpeechRecognitionEngine,
    private val secondaryEngine: SpeechRecognitionEngine
) {
    private val coordinatorScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var primaryJob: Job? = null
    private var secondaryJob: Job? = null

    // 兩個引擎各自最新一次的暫存結果，用來做同一時間點的信心分數比較
    private var latestPrimaryResult: RecognitionResult? = null
    private var latestSecondaryResult: RecognitionResult? = null

    private val _results = MutableSharedFlow<RecognitionResult>(extraBufferCapacity = 16)

    /** 對外曝露的「擇優後」辨識結果串流 */
    val results: SharedFlow<RecognitionResult> = _results

    /** 同時啟動兩個引擎，開始雙語辨識 */
    fun start() {
        primaryJob = coordinatorScope.launch {
            primaryEngine.start().collect { result ->
                latestPrimaryResult = result
                emitBestResult(result)
            }
        }
        secondaryJob = coordinatorScope.launch {
            secondaryEngine.start().collect { result ->
                latestSecondaryResult = result
                emitBestResult(result)
            }
        }
    }

    /** 將 PCM 音訊同時餵給兩個引擎 */
    fun feedAudio(pcmData: ByteArray, sampleRateHz: Int) {
        primaryEngine.feedAudio(pcmData, sampleRateHz)
        secondaryEngine.feedAudio(pcmData, sampleRateHz)
    }

    /** 停止雙語辨識，釋放兩個引擎的資源 */
    fun stop() {
        primaryJob?.cancel()
        secondaryJob?.cancel()
        primaryEngine.stop()
        secondaryEngine.stop()
        latestPrimaryResult = null
        latestSecondaryResult = null
    }

    /**
     * 比較目前兩個引擎最新的結果，只有在新結果的信心分數不低於另一個引擎的
     * 最新結果，且該結果為 final 時，才往下游發送，避免同一句話被送出兩次。
     */
    private suspend fun emitBestResult(candidate: RecognitionResult) {
        if (!candidate.isFinal) return

        val other = if (candidate.languageCode == primaryEngine.languageCode) {
            latestSecondaryResult
        } else {
            latestPrimaryResult
        }

        val isBest = other == null || candidate.confidence >= other.confidence
        if (isBest) {
            _results.emit(candidate)
        }
    }
}

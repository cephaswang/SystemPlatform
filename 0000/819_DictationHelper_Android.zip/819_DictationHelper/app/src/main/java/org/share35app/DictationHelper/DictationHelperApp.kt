package org.share35app.DictationHelper

import android.app.Application

/**
 * Custom Application class for the DictationHelper app.
 */
class DictationHelperApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // Initialize any app-wide libraries or configurations here
    }
}

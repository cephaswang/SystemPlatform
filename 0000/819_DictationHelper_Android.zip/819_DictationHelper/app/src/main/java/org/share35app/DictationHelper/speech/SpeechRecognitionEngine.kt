package org.share35app.DictationHelper.speech

import kotlinx.coroutines.flow.Flow

/** 單次辨識結果，包含文字內容與信心分數，供雙語模式比較擇優使用 */
data class RecognitionResult(
    val text: String,
    val confidence: Float,
    val isFinal: Boolean,
    val languageCode: String
)

/**
 * 語音辨識引擎介面，純 Kotlin 定義，不綁定任何特定 Android API，
 * 讓雲端方案（CloudSpeechEngine）與裝置端方案（WhisperEngine）
 * 可以互換實作。
 */
interface SpeechRecognitionEngine {

    /** 這個引擎目前使用的語系代碼，例如 "zh-TW", "en-US" */
    val languageCode: String

    /**
     * 啟動辨識工作階段。
     * 呼叫後應回傳一個持續發送辨識結果的 Flow，直到 [stop] 被呼叫或發生錯誤。
     */
    fun start(): Flow<RecognitionResult>

    /**
     * 餵入一段 PCM 原始音訊資料（由 AudioCaptureService 擷取而來）。
     * @param pcmData 16-bit PCM 音訊資料
     * @param sampleRateHz 取樣率，例如 16000
     */
    fun feedAudio(pcmData: ByteArray, sampleRateHz: Int)

    /** 停止辨識工作階段，釋放底層資源（網路連線、模型 session 等） */
    fun stop()

    /** 切換辨識語系；實作可視情況決定是否需要重啟工作階段 */
    fun setLanguage(languageCode: String)
}

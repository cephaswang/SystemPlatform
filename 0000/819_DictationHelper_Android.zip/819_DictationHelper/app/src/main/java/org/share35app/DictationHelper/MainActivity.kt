package org.share35app.DictationHelper

import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import org.share35app.DictationHelper.audio.AudioCaptureService
import org.share35app.DictationHelper.ui.MainScreen
import org.share35app.DictationHelper.ui.theme.DictationHelperTheme

/**
 * App 進入點。
 *
 * 負責：
 *  1. 請求 POST_NOTIFICATIONS / RECORD_AUDIO 等執行期權限
 *  2. 透過 MediaProjectionManager 啟動螢幕/音訊擷取授權流程
 *  3. 取得授權結果後，啟動 AudioCaptureService（前景服務）
 *  4. 掛載 Compose 的 MainScreen
 */
class MainActivity : ComponentActivity() {

    private val TAG = "MainActivity"

    /** 目前是否正在錄音／擷取中，交給 Compose UI 顯示狀態用 */
    private var isCapturing by mutableStateOf(false)

    private lateinit var mediaProjectionManager: MediaProjectionManager

    // 請求錄音/通知等一般執行期權限
    private val requestPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
            val allGranted = grants.values.all { it }
            if (!allGranted) {
                Log.w(TAG, "使用者未授予必要權限，無法啟動音訊擷取")
            }
        }

    // 請求 MediaProjection（螢幕/音訊擷取）授權
    private val mediaProjectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK && result.data != null) {
                startAudioCaptureService(result.resultCode, result.data!!)
                isCapturing = true
            } else {
                Log.w(TAG, "使用者拒絕了音訊擷取授權")
                isCapturing = false
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        mediaProjectionManager =
            getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

        requestRuntimePermissionsIfNeeded()

        setContent {
            DictationHelperTheme {
                MainScreen(
                    isCapturing = isCapturing,
                    onStartCapture = { requestMediaProjection() },
                    onStopCapture = { stopAudioCaptureService() }
                )
            }
        }
    }

    /** 請求 RECORD_AUDIO 及（Android 13+）POST_NOTIFICATIONS 權限 */
    private fun requestRuntimePermissionsIfNeeded() {
        val permissions = mutableListOf(android.Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions.add(android.Manifest.permission.POST_NOTIFICATIONS)
        }
        val notGranted = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) !=
                android.content.pm.PackageManager.PERMISSION_GRANTED
        }
        if (notGranted.isNotEmpty()) {
            requestPermissionLauncher.launch(notGranted.toTypedArray())
        }
    }

    /** 發起 MediaProjection 授權請求（會跳出系統的「開始錄製/投放」對話框） */
    private fun requestMediaProjection() {
        val intent = mediaProjectionManager.createScreenCaptureIntent()
        mediaProjectionLauncher.launch(intent)
    }

    /** 帶著授權結果啟動前景服務，開始擷取播放中的音訊 */
    private fun startAudioCaptureService(resultCode: Int, data: Intent) {
        val serviceIntent = Intent(this, AudioCaptureService::class.java).apply {
            action = AudioCaptureService.ACTION_START
            putExtra(AudioCaptureService.EXTRA_RESULT_CODE, resultCode)
            putExtra(AudioCaptureService.EXTRA_RESULT_DATA, data)
        }
        ContextCompat.startForegroundService(this, serviceIntent)
    }

    /** 停止音訊擷取前景服務 */
    private fun stopAudioCaptureService() {
        val serviceIntent = Intent(this, AudioCaptureService::class.java).apply {
            action = AudioCaptureService.ACTION_STOP
        }
        startService(serviceIntent)
        isCapturing = false
    }
}

package org.share35app.DictationHelper.speech

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.launch

/**
 * 方案 B（後續擴充）：裝置端語音辨識模型，例如透過 whisper.cpp（JNI）、
 * TensorFlow Lite 或 ONNX Runtime Mobile 執行 Whisper 的行動裝置版本。
 *
 * 優點：不需網路、語音資料不出裝置、無雲端費用。
 * 缺點：需整合原生函式庫、模型檔案較大、效能受裝置影響。
 *
 * 此檔案目前僅為介面骨架，尚未整合實際的推論函式庫。
 * 後續整合時的建議步驟：
 *   1. 將 whisper.cpp 編譯為 .so，透過 JNI 提供 Kotlin 呼叫介面
 *      （或改用 TensorFlow Lite / ONNX Runtime Mobile 的官方 Kotlin API）
 *   2. 於 App 啟動或首次使用時，下載/解壓模型檔至
 *      Context.getExternalFilesDir() 底下（模型檔通常不隨 APK 一起發佈）
 *   3. 將 [feedAudio] 收到的 PCM 音訊，依模型要求的取樣率/格式做重採樣後
 *      餵給推論引擎，並將輸出的文字片段包成 [RecognitionResult] 發送
 */
class WhisperEngine(
    override var languageCode: String = "zh-TW",
    private val modelFilePath: String
) : SpeechRecognitionEngine {

    private val engineScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var isRunning = false

    override fun start(): Flow<RecognitionResult> = callbackFlow {
        isRunning = true

        engineScope.launch {
            try {
                // TODO: 載入模型（modelFilePath），初始化推論 session
                // 例如：val context = WhisperNative.loadModel(modelFilePath)
                //
                // 推論完成一段結果時：
                //   trySend(
                //       RecognitionResult(
                //           text = decodedText,
                //           confidence = decodedConfidence,
                //           isFinal = isFinalSegment,
                //           languageCode = languageCode
                //       )
                //   )
            } catch (e: Exception) {
                close(e)
            }
        }

        awaitClose {
            isRunning = false
            // TODO: 釋放模型 session / native 資源
        }
    }

    override fun feedAudio(pcmData: ByteArray, sampleRateHz: Int) {
        if (!isRunning) return
        // TODO: 視模型需求進行重採樣，並送入本地推論引擎的音訊緩衝區
    }

    override fun stop() {
        isRunning = false
        // TODO: 停止推論、釋放 native 資源
    }

    override fun setLanguage(languageCode: String) {
        this.languageCode = languageCode
        // 多語模型通常可在推論時指定語言提示（language hint），
        // 視所選的模型/函式庫 API 決定是否需要重新初始化 session
    }
}

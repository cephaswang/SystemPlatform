package org.share35app.DictationHelper.audio

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import androidx.annotation.RequiresPermission
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * 前景服務：實際執行音訊擷取。
 *
 * 使用 MediaProjection 取得的授權權杖，搭配
 * AudioPlaybackCaptureConfiguration 指定要擷取「裝置上正在播放的音訊」，
 * 透過 AudioRecord 讀取原始 PCM 資料，再交給語音辨識模組
 * （SpeechRecognitionEngine / BilingualRecognitionCoordinator）處理。
 *
 * 依 Android 系統規定，此服務必須以 foregroundServiceType="mediaProjection"
 * 執行，並在啟動後立即顯示常駐通知。
 */
class AudioCaptureService : Service() {

    companion object {
        const val ACTION_START = "org.share35app.DictationHelper.action.START"
        const val ACTION_STOP = "org.share35app.DictationHelper.action.STOP"
        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_RESULT_DATA = "extra_result_data"

        private const val NOTIFICATION_CHANNEL_ID = "audio_capture_channel"
        private const val NOTIFICATION_ID = 1001

        private const val SAMPLE_RATE_HZ = 16000
        private const val CHANNEL_CONFIG = AudioFormat.CHANNEL_IN_MONO
        private const val AUDIO_FORMAT_ENCODING = AudioFormat.ENCODING_PCM_16BIT
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var captureJob: Job? = null

    private var mediaProjection: MediaProjection? = null
    private var audioRecord: AudioRecord? = null

    /**
     * 供外部（例如 Repository/Coordinator 層）註冊，接收擷取到的 PCM 音訊資料。
     * 這裡先用最簡單的 callback 設計；正式串接語音辨識模組時，
     * 可改用注入 BilingualRecognitionCoordinator 或以事件匯流排傳遞。
     */
    var onAudioDataCaptured: ((ByteArray, Int) -> Unit)? = null

    override fun onBind(intent: Intent?): IBinder? = null

    @RequiresPermission(Manifest.permission.RECORD_AUDIO)
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> handleStart(intent)
            ACTION_STOP -> handleStop()
        }
        return START_NOT_STICKY
    }

    @RequiresPermission(Manifest.permission.RECORD_AUDIO)
    private fun handleStart(intent: Intent) {
        val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, -1)
        val resultData = intent.getParcelableExtra<Intent>(EXTRA_RESULT_DATA) ?: return

        startForeground(NOTIFICATION_ID, buildNotification())

        val projectionManager =
            getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val projection = projectionManager.getMediaProjection(resultCode, resultData) ?: run {
            // 授權權杖無效或已過期，無法取得 MediaProjection，直接停止服務
            handleStop()
            return
        }
        mediaProjection = projection

        startAudioCapture(projection)
    }

    private fun handleStop() {
        captureJob?.cancel()
        audioRecord?.stop()
        audioRecord?.release()
        audioRecord = null
        mediaProjection?.stop()
        mediaProjection = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    @RequiresPermission(Manifest.permission.RECORD_AUDIO)
    private fun startAudioCapture(projection: MediaProjection) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            // AudioPlaybackCaptureConfiguration 需要 Android 10（API 29）以上
            return
        }

        val playbackCaptureConfig = AudioPlaybackCaptureConfiguration.Builder(projection)
            .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
            .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
            .build()

        val bufferSizeBytes = AudioRecord.getMinBufferSize(
            SAMPLE_RATE_HZ,
            CHANNEL_CONFIG,
            AUDIO_FORMAT_ENCODING
        ).coerceAtLeast(4096)

        val audioFormat = AudioFormat.Builder()
            .setEncoding(AUDIO_FORMAT_ENCODING)
            .setSampleRate(SAMPLE_RATE_HZ)
            .setChannelMask(CHANNEL_CONFIG)
            .build()

        val record = AudioRecord.Builder()
            .setAudioFormat(audioFormat)
            .setBufferSizeInBytes(bufferSizeBytes)
            .setAudioPlaybackCaptureConfig(playbackCaptureConfig)
            .build()

        audioRecord = record
        record.startRecording()

        captureJob = serviceScope.launch {
            val buffer = ByteArray(bufferSizeBytes)
            while (isActive()) {
                val readBytes = record.read(buffer, 0, buffer.size)
                if (readBytes > 0) {
                    onAudioDataCaptured?.invoke(buffer.copyOf(readBytes), SAMPLE_RATE_HZ)
                }
            }
        }
    }

    private fun isActive(): Boolean = captureJob?.isCancelled == false

    /** 建立前景服務的常駐通知（Android 系統的強制規定） */
    private fun buildNotification(): Notification {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                NOTIFICATION_CHANNEL_ID,
                "音訊擷取進行中",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }

        return NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID)
            .setContentTitle("聽抄小幫手")
            .setContentText("正在擷取播放中的聲音並轉成文字…")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        handleStop()
    }
}

package org.share35app.DictationHelper.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

/** DataStore 實例，對應 macOS 版的 @AppStorage 持久化行為 */
private val Context.dataStore by preferencesDataStore(name = "dictation_helper_prefs")

/** 使用者偏好設定的資料模型 */
data class UserPreferences(
    val languageCode: String,
    val bilingualModeEnabled: Boolean,
    val secondaryLanguageCode: String
)

/**
 * 讀寫使用者偏好設定，包含：
 *   - 上次選擇的辨識語系
 *   - 雙語模式開關
 *   - 雙語模式下的第二語系
 *
 * 底層以 Jetpack DataStore Preferences 實作，取代 SharedPreferences。
 */
class UserPreferencesRepository(private val context: Context) {

    private object Keys {
        val LANGUAGE_CODE = stringPreferencesKey("language_code")
        val BILINGUAL_MODE_ENABLED = booleanPreferencesKey("bilingual_mode_enabled")
        val SECONDARY_LANGUAGE_CODE = stringPreferencesKey("secondary_language_code")
    }

    companion object {
        const val DEFAULT_LANGUAGE_CODE = "zh-TW"
        const val DEFAULT_SECONDARY_LANGUAGE_CODE = "en-US"
    }

    /** 以 Flow 形式持續觀察使用者偏好設定的變化 */
    val preferencesFlow: Flow<UserPreferences> = context.dataStore.data.map { prefs ->
        UserPreferences(
            languageCode = prefs[Keys.LANGUAGE_CODE] ?: DEFAULT_LANGUAGE_CODE,
            bilingualModeEnabled = prefs[Keys.BILINGUAL_MODE_ENABLED] ?: false,
            secondaryLanguageCode = prefs[Keys.SECONDARY_LANGUAGE_CODE]
                ?: DEFAULT_SECONDARY_LANGUAGE_CODE
        )
    }

    /** 儲存使用者選擇的主要辨識語系 */
    suspend fun setLanguageCode(languageCode: String) {
        context.dataStore.edit { prefs ->
            prefs[Keys.LANGUAGE_CODE] = languageCode
        }
    }

    /** 儲存雙語模式開關狀態 */
    suspend fun setBilingualModeEnabled(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[Keys.BILINGUAL_MODE_ENABLED] = enabled
        }
    }

    /** 儲存雙語模式下的第二語系 */
    suspend fun setSecondaryLanguageCode(languageCode: String) {
        context.dataStore.edit { prefs ->
            prefs[Keys.SECONDARY_LANGUAGE_CODE] = languageCode
        }
    }
}

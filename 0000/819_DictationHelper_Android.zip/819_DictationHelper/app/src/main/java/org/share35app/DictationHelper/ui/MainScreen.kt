package org.share35app.DictationHelper.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/** 單一已存檔逐字稿片段，供列表顯示用 */
data class TranscriptEntry(
    val timestamp: String,
    val text: String
)

/** 支援的辨識語系選項 */
val SUPPORTED_LANGUAGES = listOf("繁體中文", "English", "日本語")

/**
 * 主畫面：
 *  - 上方 AppBar，右側提供進入說明頁的按鈕
 *  - 語系下拉選單、雙語模式開關
 *  - 開始/停止擷取按鈕
 *  - 即時辨識文字
 *  - 已存檔逐字稿列表
 *
 * 目前僅為 UI 骨架：語系/雙語模式的持久化交由
 * UserPreferencesRepository 處理，實際辨識結果串流交由
 * SpeechRecognitionEngine / BilingualRecognitionCoordinator 提供，
 * 這裡先以參數方式傳入畫面所需的狀態與回呼。
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    isCapturing: Boolean,
    onStartCapture: () -> Unit,
    onStopCapture: () -> Unit,
    onNavigateToHelp: () -> Unit = {},
    liveText: String = "",
    transcriptEntries: List<TranscriptEntry> = emptyList()
) {
    var selectedLanguage by remember { mutableStateOf(SUPPORTED_LANGUAGES.first()) }
    var languageMenuExpanded by remember { mutableStateOf(false) }
    var bilingualMode by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("聽抄小幫手") },
                actions = {
                    IconButton(onClick = onNavigateToHelp) {
                        Icon(Icons.Filled.HelpOutline, contentDescription = "使用說明")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            // 語系選擇 + 雙語模式開關
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Box {
                    Button(onClick = { languageMenuExpanded = true }) {
                        Text(selectedLanguage)
                    }
                    DropdownMenu(
                        expanded = languageMenuExpanded,
                        onDismissRequest = { languageMenuExpanded = false }
                    ) {
                        SUPPORTED_LANGUAGES.forEach { lang ->
                            DropdownMenuItem(
                                text = { Text(lang) },
                                onClick = {
                                    selectedLanguage = lang
                                    languageMenuExpanded = false
                                }
                            )
                        }
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("雙語模式")
                    Switch(
                        checked = bilingualMode,
                        onCheckedChange = { bilingualMode = it }
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 開始/停止按鈕
            Button(
                onClick = { if (isCapturing) onStopCapture() else onStartCapture() },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(if (isCapturing) "停止擷取" else "開始擷取")
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 即時辨識文字
            Text(
                text = "即時辨識：",
                style = MaterialTheme.typography.labelMedium
            )
            Text(
                text = liveText.ifBlank { "（尚未開始）" },
                style = MaterialTheme.typography.bodyLarge,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))

            // 已存檔逐字稿列表
            Text(
                text = "已存檔內容：",
                style = MaterialTheme.typography.labelMedium
            )
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                contentPadding = PaddingValues(vertical = 8.dp)
            ) {
                items(transcriptEntries) { entry ->
                    Column(modifier = Modifier.padding(vertical = 4.dp)) {
                        Text(
                            text = entry.timestamp,
                            style = MaterialTheme.typography.labelSmall
                        )
                        Text(
                            text = entry.text,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            }
        }
    }
}

package org.share35app.DictationHelper.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/** 單一使用說明條目：標題 + 說明內容 */
private data class HelpItem(
    val title: String,
    val body: String
)

/** 使用說明頁的內容，比照 macOS 版 HelpView 的架構撰寫 */
private val helpItems = listOf(
    HelpItem(
        title = "這個 App 在做什麼？",
        body = "聽抄小幫手會擷取手機正在播放的聲音（例如 YouTube、Podcast App " +
            "正在播放的內容），即時轉成文字，並自動依句子拆分、加上時間戳記存檔。" +
            "不需要對著麥克風講話。"
    ),
    HelpItem(
        title = "如何開始使用？",
        body = "1. 在主畫面選擇辨識語系（或開啟雙語模式）\n" +
            "2. 按下「開始擷取」\n" +
            "3. 系統會跳出擷取授權的對話框，請選擇「立即開始」\n" +
            "4. 播放你想轉文字的影片、Podcast 或線上課程即可"
    ),
    HelpItem(
        title = "為什麼需要常駐通知？",
        body = "Android 系統規定，任何在背景擷取音訊的功能都必須以「前景服務」執行，" +
            "並在狀態列顯示常駐通知，讓使用者隨時知道 App 正在運作中。這是系統層級的" +
            "強制規範，無法關閉。"
    ),
    HelpItem(
        title = "為什麼有些 App 的聲音擷取不到？",
        body = "部分串流影音服務會將自己的音訊標記為「不可被擷取」，這是 Android 系統" +
            "提供給內容提供者的保護機制，聽抄小幫手無法繞過這個限制。"
    ),
    HelpItem(
        title = "雙語模式是什麼？",
        body = "開啟後會同時使用兩個語言的辨識引擎，並比較信心分數，自動選擇較準確的" +
            "結果存檔，適合中英文混雜的內容。請注意雙語模式會產生雙倍的辨識用量。"
    ),
    HelpItem(
        title = "沒有網路可以用嗎？",
        body = "目前版本採用雲端語音辨識服務，需要網路連線才能運作。未來版本規劃加入" +
            "裝置端離線辨識模型作為選項。"
    )
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HelpScreen(
    onNavigateBack: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("使用說明") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "返回")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            helpItems.forEach { item ->
                Text(
                    text = item.title,
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(top = 12.dp, bottom = 4.dp)
                )
                Text(
                    text = item.body,
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
    }
}

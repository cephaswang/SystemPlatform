package org.share35app.DictationHelper.util

/**
 * 斷句工具（共用邏輯）。
 *
 * 語音辨識引擎會不斷吐出「目前累積的文字片段」，本工具負責偵測句尾標點，
 * 把已經完整的句子切出來，並保留還沒結束的「殘餘文字」等待下一次輸入。
 *
 * 使用方式：
 *   val splitter = SentenceSplitter()
 *   val completed = splitter.feed(partialText) // 回傳這次新完成的句子（可能為空list）
 *   ...
 *   val remaining = splitter.flushRemaining() // 擷取結束時，把殘餘文字當作最後一句
 */
class SentenceSplitter(
    /** 視為句尾的標點符號（中、英文皆涵蓋） */
    private val terminators: Set<Char> = setOf('。', '！', '？', '.', '!', '?', '\n')
) {

    private val buffer = StringBuilder()

    /**
     * 餵入辨識引擎目前累積/新增的文字，回傳這次新切出的完整句子清單。
     * 未達句尾標點的文字會留在內部緩衝區，等待下一次呼叫。
     */
    fun feed(newText: String): List<String> {
        buffer.append(newText)
        return extractCompletedSentences()
    }

    /** 擷取結束時呼叫，把緩衝區中殘餘、尚未有句尾標點的文字視為最後一句吐出 */
    fun flushRemaining(): String? {
        val remaining = buffer.toString().trim()
        buffer.clear()
        return remaining.ifEmpty { null }
    }

    /** 重置內部狀態（例如切換語言或重新開始擷取時使用） */
    fun reset() {
        buffer.clear()
    }

    private fun extractCompletedSentences(): List<String> {
        val sentences = mutableListOf<String>()
        var start = 0

        for (i in buffer.indices) {
            if (buffer[i] in terminators) {
                val sentence = buffer.substring(start, i + 1).trim()
                if (sentence.isNotEmpty()) {
                    sentences.add(sentence)
                }
                start = i + 1
            }
        }

        // 保留還沒斷句的殘餘文字在 buffer 中
        val remainder = buffer.substring(start)
        buffer.setLength(0)
        buffer.append(remainder)

        return sentences
    }
}

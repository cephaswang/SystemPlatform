package org.share35app.DictationHelper.data

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import org.share35app.DictationHelper.util.SentenceSplitter
import java.io.File
import java.io.FileWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** 單筆已寫入檔案的逐字稿記錄，供 UI 列表顯示 */
data class TranscriptRecord(
    val timestamp: String,
    val text: String
)

/**
 * 自動斷句、加時間戳記、寫入本機文字檔。
 *
 * 每次呼叫 [appendRecognizedText] 餵入辨識引擎（或雙語協調器）吐出的文字，
 * 內部會用 [SentenceSplitter] 切出完整句子，並依「[時間戳記] 句子內容」
 * 的格式附加寫入到 App 專屬儲存空間下的逐字稿檔案。
 *
 * 檔案輸出於 Context.getExternalFilesDir()，並透過 FileProvider 提供
 * 分享/匯出功能。
 */
class TranscriptFileWriter(private val context: Context) {

    private val sentenceSplitter = SentenceSplitter()
    private val timestampFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
    private val fileNameFormat = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault())

    private var currentFile: File? = null

    /** 開始新的一場逐字稿記錄，建立新的輸出檔案 */
    fun startNewSession(): File {
        sentenceSplitter.reset()
        val dir = context.getExternalFilesDir("transcripts") ?: context.filesDir
        if (!dir.exists()) dir.mkdirs()

        val fileName = "dictation_${fileNameFormat.format(Date())}.txt"
        val file = File(dir, fileName)
        file.createNewFile()
        currentFile = file
        return file
    }

    /**
     * 餵入辨識引擎新增的文字片段，回傳這次新完成、已寫入檔案的句子清單
     * （每一句已附上時間戳記，可直接用於更新 UI 列表）。
     */
    fun appendRecognizedText(newText: String): List<TranscriptRecord> {
        val completedSentences = sentenceSplitter.feed(newText)
        return completedSentences.map { sentence -> writeSentence(sentence) }
    }

    /**
     * 結束目前的擷取工作階段：把緩衝區中尚未有句尾標點的殘餘文字，
     * 視為最後一句寫入檔案，並回傳（若無殘餘文字則回傳 null）。
     */
    fun finishSession(): TranscriptRecord? {
        val remaining = sentenceSplitter.flushRemaining() ?: return null
        return writeSentence(remaining)
    }

    /** 取得目前逐字稿檔案，供分享功能使用 */
    fun getCurrentFile(): File? = currentFile

    /**
     * 建立分享逐字稿檔案用的 Intent（透過 FileProvider 取得可分享的 content Uri）。
     * authority 需與 AndroidManifest.xml 中 <provider> 宣告的 authorities 一致。
     */
    fun createShareIntent(): Intent? {
        val file = currentFile ?: return null
        val uri = FileProvider.getUriForFile(
            context,
            "org.share35app.DictationHelper.fileprovider",
            file
        )
        return Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }

    private fun writeSentence(sentence: String): TranscriptRecord {
        val timestamp = timestampFormat.format(Date())
        val line = "[$timestamp] $sentence\n"

        currentFile?.let { file ->
            FileWriter(file, /* append = */ true).use { writer ->
                writer.write(line)
            }
        }

        return TranscriptRecord(timestamp = timestamp, text = sentence)
    }
}

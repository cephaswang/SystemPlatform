import Foundation
import AppKit
import AVFoundation
import Speech
import Combine

/// 統一管理 App 所需的系統權限請求與現況查詢（無狀態，可在任何地方建立使用）
struct PermissionManager {

    enum PermissionStatus {
        case authorized
        case denied
        case notDetermined
    }

    /// 語音辨識權限現況
    var speechRecognitionStatus: PermissionStatus {
        switch SFSpeechRecognizer.authorizationStatus() {
        case .authorized:
            return .authorized
        case .denied, .restricted:
            return .denied
        case .notDetermined:
            return .notDetermined
        @unknown default:
            return .notDetermined
        }
    }

    /// 請求語音辨識權限，回傳是否取得授權
    func requestSpeechRecognitionPermission() async -> Bool {
        dbg("permission: requesting speech authorization (current rawStatus=\(SFSpeechRecognizer.authorizationStatus().rawValue))")
        return await withCheckedContinuation { continuation in
            SFSpeechRecognizer.requestAuthorization { status in
                dbg("permission: speech authorization callback rawStatus=\(status.rawValue)")
                continuation.resume(returning: status == .authorized)
            }
        }
    }

    /// 麥克風權限現況
    var microphoneStatus: PermissionStatus {
        switch AVCaptureDevice.authorizationStatus(for: .audio) {
        case .authorized:
            return .authorized
        case .denied, .restricted:
            return .denied
        case .notDetermined:
            return .notDetermined
        @unknown default:
            return .notDetermined
        }
    }

    /// 請求麥克風權限，回傳是否取得授權
    func requestMicrophonePermission() async -> Bool {
        dbg("permission: requesting microphone access")
        let granted = await AVCaptureDevice.requestAccess(for: .audio)
        dbg("permission: microphone granted=\(granted)")
        return granted
    }

    /// 系統音訊錄製權限現況（Core Audio Process Tap，kTCCServiceAudioCapture）
    var systemAudioStatus: PermissionStatus {
        SystemAudioPermission.status
    }

    /// 請求系統音訊錄製權限，回傳是否取得授權
    func requestSystemAudioPermission() async -> Bool {
        dbg("permission: requesting system audio capture access")
        let granted = await SystemAudioPermission.request()
        dbg("permission: system audio granted=\(granted)")
        return granted
    }

    /// 提示使用者前往系統設定開啟權限（適用於使用者曾拒絕、需手動開啟的情況）
    func openSystemPrivacySettings() {
        guard let url = URL(string: "x-apple.systempreferences:com.apple.preference.security?Privacy") else { return }
        NSWorkspace.shared.open(url)
    }
}

// MARK: - 系統音訊錄製權限（只取聲音，不錄製畫面）

/// macOS 沒有公開 API 可查詢／請求「系統音訊錄製」權限，
/// 這裡透過 TCC 的 SPI 讀取 kTCCServiceAudioCapture（與 AudioCap 範例作法相同）。
/// 對話框文字來自 Info.plist 的 NSAudioCaptureUsageDescription。
/// 需要 macOS 14.4 以上；較舊的系統一律視為未決定。
enum SystemAudioPermission {

    private static let service = "kTCCServiceAudioCapture" as CFString
    private static let tccPath = "/System/Library/PrivateFrameworks/TCC.framework/Versions/A/TCC"

    private static func symbol(_ name: String) -> UnsafeMutableRawPointer? {
        guard let handle = dlopen(tccPath, RTLD_NOW) else { return nil }
        return dlsym(handle, name)
    }

    /// 目前授權狀態
    static var status: PermissionManager.PermissionStatus {
        guard let sym = symbol("TCCAccessPreflight") else { return .notDetermined }
        typealias Fn = @convention(c) (CFString, CFDictionary?) -> Int
        let fn = unsafeBitCast(sym, to: Fn.self)
        switch fn(service, nil) {
        case 0:  return .authorized
        case 1:  return .denied
        default: return .notDetermined
        }
    }

    /// 請求授權（只有「未決定」時才會跳出系統對話框）
    static func request() async -> Bool {
        guard let sym = symbol("TCCAccessRequest") else { return false }
        typealias Fn = @convention(c) (CFString, CFDictionary?, @escaping @convention(block) (Bool) -> Void) -> Void
        let fn = unsafeBitCast(sym, to: Fn.self)
        return await withCheckedContinuation { continuation in
            fn(service, nil) { granted in
                continuation.resume(returning: granted)
            }
        }
    }
}

// MARK: - 第一頁統一權限流程

/// App 第一頁載入時，依序請求所有需要的權限，並把授權狀態發布給畫面使用。
/// 順序：語音辨識 → 麥克風 → 系統音訊錄製。
/// 任何一項被拒絕都不會阻擋其他功能（匯入音檔只需語音辨識；
/// 麥克風聽抄需語音辨識＋麥克風；系統聲音需語音辨識＋系統音訊錄製）。
@MainActor
final class PermissionCoordinator: ObservableObject {

    @Published private(set) var speech: PermissionManager.PermissionStatus = .notDetermined
    @Published private(set) var microphone: PermissionManager.PermissionStatus = .notDetermined
    @Published private(set) var systemAudio: PermissionManager.PermissionStatus = .notDetermined

    private let manager = PermissionManager()
    private var didStartFlow = false

    init() {
        // 清除舊版「螢幕錄製」流程留下的旗標
        UserDefaults.standard.removeObject(forKey: "didRequestScreenRecording")
        refresh()
    }

    /// 重新讀取三項權限的目前狀態（App 回到前景時也會呼叫）
    func refresh() {
        speech = manager.speechRecognitionStatus
        microphone = manager.microphoneStatus
        systemAudio = manager.systemAudioStatus
        dbg("permission: refresh speech=\(speech) mic=\(microphone) systemAudio=\(systemAudio)")
    }

    /// 依序請求全部權限。整個 App 生命週期只會執行一次，
    /// 已決定（授權或拒絕）的項目不會重複跳出對話框。
    func requestAllIfNeeded() async {
        guard !didStartFlow else { return }
        didStartFlow = true
        dbg("PermissionCoordinator: requestAllIfNeeded start")

        // 1. 語音辨識
        if manager.speechRecognitionStatus == .notDetermined {
            _ = await manager.requestSpeechRecognitionPermission()
            refresh()
        }

        // 2. 麥克風
        if manager.microphoneStatus == .notDetermined {
            _ = await manager.requestMicrophonePermission()
            refresh()
        }

        // 3. 系統音訊錄製：系統聲音來源需要。可 await，
        //    且只有「未決定」時才會跳出對話框，授權後不需重新啟動 App。
        if manager.systemAudioStatus == .notDetermined {
            _ = await manager.requestSystemAudioPermission()
        }

        refresh()
        dbg("PermissionCoordinator: requestAllIfNeeded done")
    }

    /// 狀態列摘要文字；三項都就緒時回傳 nil
    /// （"perm.summary.screen" 的文案建議改成「系統音訊錄製」）
    var summary: String? {
        var issues: [String] = []
        if speech != .authorized { issues.append(L10n.t("perm.summary.speech")) }
        if microphone != .authorized { issues.append(L10n.t("perm.summary.mic")) }
        if systemAudio != .authorized { issues.append(L10n.t("perm.summary.screen")) }
        return issues.isEmpty ? nil : issues.joined(separator: L10n.t("env.separator"))
    }

    /// 開啟系統設定的指定隱私權分頁。
    /// pane：「SpeechRecognition」「Microphone」「ScreenCapture」
    /// （系統音訊錄製與螢幕錄製同在「螢幕與系統音訊錄製」頁面，pane 名稱為 ScreenCapture）
    func openSettings(_ pane: String) {
        guard let url = URL(string: "x-apple.systempreferences:com.apple.preference.security?Privacy_\(pane)") else { return }
        NSWorkspace.shared.open(url)
    }

    /// 使用者主動按下「前往設定」時呼叫：
    /// 尚未決定就直接請求（讓 App 註冊進清單並跳出對話框），
    /// 已拒絕或請求後仍未授權，再開啟系統設定對應分頁。
    func openSystemAudioSettings() {
        Task { @MainActor in
            if manager.systemAudioStatus == .notDetermined {
                _ = await manager.requestSystemAudioPermission()
            }
            refresh()
            if systemAudio != .authorized {
                openSettings("ScreenCapture")
            }
        }
    }
}

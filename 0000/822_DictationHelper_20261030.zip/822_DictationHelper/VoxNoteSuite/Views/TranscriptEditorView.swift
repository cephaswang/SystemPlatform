import SwiftUI

struct TranscriptEditorView: View {

    let audioFile: AudioFile

    /// 編輯後的逐字稿要寫回 Store 才會被保存
    @EnvironmentObject private var library: AudioLibraryStore

    @State private var segments: [TranscriptSegment] = []
    @State private var selectedSegmentID: TranscriptSegment.ID?
    @State private var isLoading = false

    /// 防抖用：使用者停止輸入一小段時間後才寫回 Store
    @State private var saveTask: Task<Void, Never>?

    var body: some View {
        VStack(spacing: 0) {
            header

            Divider()

            switch audioFile.status {
            case .pending, .processing:
                processingPlaceholder
            case .failed:
                // ContentUnavailableView 需要 macOS 14；為了支援 macOS 13，
                // 改用下方自製的相容版空狀態畫面。
                TranscriptEmptyStateView(
                    title: "transcript.failed.title",
                    systemImage: "exclamationmark.triangle",
                    description: "transcript.failed.description"
                )
            case .completed:
                transcriptList
            }
        }
        // 原本只用 audioFile.id 當作 task id，導致「同一個檔案從 processing 變成
        // completed」時（id 沒變）不會重新觸發，逐字稿因此一直顯示空白。
        // 改成把 status 一併納入 task id，只要 status 改變（例如轉錄完成）
        // 就會重新執行 loadSegmentsIfNeeded()，確保畫面能即時反映最新結果。
        .task(id: taskKey) {
            loadSegmentsIfNeeded()
        }
        // 使用者編輯逐字稿 → 防抖後寫回 Store 並存檔
        .onChange(of: segments) {
            scheduleSave()
        }
        // 離開畫面（切換檔案等）時立刻寫回，不讓最後幾秒的修改遺失
        .onDisappear {
            flushSave()
        }
    }

    /// 結合 id 與 status 的複合 key，用於驅動 .task(id:) 在狀態改變時重新執行
    private var taskKey: String {
        "\(audioFile.id)-\(audioFile.status)"
    }

    private var header: some View {
        HStack {
            VStack(alignment: .leading) {
                Text(audioFile.displayName)
                    .font(.headline)
                Text(audioFile.durationDescription)
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            Spacer()
        }
        .padding()
    }

    private var processingPlaceholder: some View {
        VStack(spacing: 12) {
            ProgressView()
            Text(LocalizedStringKey(audioFile.status == .pending ? "transcript.pending" : "transcript.processing"))
                .foregroundColor(.secondary)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }

    private var transcriptList: some View {
        List(selection: $selectedSegmentID) {
            ForEach($segments) { $segment in
                HStack(alignment: .top, spacing: 12) {
                    Text(segment.timestampDescription)
                        .font(.caption.monospacedDigit())
                        .foregroundColor(.secondary)
                        .frame(width: 70, alignment: .leading)

                    // 可直接編輯逐字稿內容，修正辨識誤差
                    TextField("transcript.field", text: $segment.text, axis: .vertical)
                        .textFieldStyle(.plain)
                }
                .padding(.vertical, 4)
                .tag(segment.id)
            }
        }
        .listStyle(.inset)
    }

    private func loadSegmentsIfNeeded() {
        // 原本這裡多了 `segments.isEmpty` 的條件，導致第一次（processing 階段）
        // 載入過一次空陣列後，即使之後 status 變成 completed 也不會再重新賦值。
        // 拿掉該條件，只要目前是 completed 就同步一次 audioFile.transcriptSegments，
        // 這樣「轉錄完成」與「重新轉錄同一檔案覆蓋舊結果」都能正確反映到畫面上。
        guard audioFile.status == .completed else { return }
        print("📝 loadSegmentsIfNeeded 執行，taskKey=\(taskKey)，來源 segments 數=\(audioFile.transcriptSegments.count)")
        segments = audioFile.transcriptSegments
    }

    // MARK: - 保存編輯結果

    /// 停止輸入 0.8 秒後才寫回，避免每敲一個字就編碼一次整份 JSON。
    private func scheduleSave() {
        // segments 為空代表尚未載入完成，不可寫回（否則會把既有逐字稿覆蓋成空陣列）
        guard audioFile.status == .completed, !segments.isEmpty else { return }
        saveTask?.cancel()
        let id = audioFile.id
        let snapshot = segments
        saveTask = Task { @MainActor in
            try? await Task.sleep(nanoseconds: 800_000_000)
            guard !Task.isCancelled else { return }
            library.updateTranscript(for: id, segments: snapshot)
        }
    }

    /// 立即寫回（離開畫面、切換檔案、匯出前使用）。
    private func flushSave() {
        saveTask?.cancel()
        guard audioFile.status == .completed, !segments.isEmpty else { return }
        library.updateTranscript(for: audioFile.id, segments: segments)
    }
}

/// 相容 macOS 13 的空狀態畫面，取代 macOS 14 才有的 ContentUnavailableView
private struct TranscriptEmptyStateView: View {
    let title: LocalizedStringKey
    let systemImage: String
    var description: LocalizedStringKey? = nil

    var body: some View {
        VStack(spacing: 8) {
            Image(systemName: systemImage)
                .font(.system(size: 40))
                .foregroundColor(.secondary)
            Text(title)
                .font(.title3)
                .bold()
            if let description {
                Text(description)
                    .font(.callout)
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
        .padding()
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}

#Preview {
    TranscriptEditorView(
        audioFile: AudioFile(
            id: UUID(),
            sourceURL: URL(fileURLWithPath: "/tmp/demo.m4a"),
            displayName: "會議錄音 0922",
            durationSeconds: 125,
            status: .completed
        )
    )
    .environmentObject(AudioLibraryStore())
}

import AppKit
import Combine

/// 管理「逐字稿儲存資料夾」：由使用者用 NSOpenPanel 選擇，
/// 以 security-scoped bookmark 記住，App 重啟後仍有讀寫權限。
///
/// 為什麼需要：App Sandbox 下，~/Documents 其實是容器內的隱藏目錄，
/// 使用者找不到自己的檔案（App Review Guideline 2.4.5(i)）。
/// 需要 Entitlement：User Selected File = Read/Write。
///
/// 資料夾一旦選定，就在 App 存活期間保持 security scope 開啟（更換資料夾時才關閉前一個），
/// 因此 SpeechTranscriber 寫檔、「在 Finder 中顯示」都不必各自處理 scope。
final class TranscriptFolderManager: ObservableObject {

    static let shared = TranscriptFolderManager()

    @Published private(set) var folderURL: URL?

    private let bookmarkKey = "transcriptFolderBookmark"
    private var scopedURL: URL?

    private init() {
        restore()
    }

    // MARK: - 對外介面

    /// 回傳可寫入的逐字稿資料夾；尚未選擇或已失效時，彈出選取視窗請使用者選。
    /// 使用者取消就回傳 nil（呼叫端應中止「開始聽抄」）。
    /// 必須在主執行緒呼叫。
    func ensureFolder() -> URL? {
        if let url = folderURL, FileManager.default.isWritableFile(atPath: url.path) {
            return url
        }
        return chooseFolder()
    }

    /// 彈出選取視窗讓使用者（重新）選擇資料夾。選定後會記住。
    @discardableResult
    func chooseFolder() -> URL? {
        let panel = NSOpenPanel()
        panel.canChooseDirectories = true
        panel.canChooseFiles = false
        panel.canCreateDirectories = true
        panel.allowsMultipleSelection = false
        panel.message = L10n.t("capture.folder.panel.message")
        panel.prompt = L10n.t("capture.folder.panel.prompt")

        guard panel.runModal() == .OK, let url = panel.url else { return nil }
        setFolder(url)
        return folderURL
    }

    // MARK: - bookmark

    private func setFolder(_ url: URL) {
        releaseScope()
        guard url.startAccessingSecurityScopedResource() else {
            // NSOpenPanel 剛回傳的 URL 通常已可用；萬一失敗，仍嘗試建立 bookmark
            saveBookmark(for: url)
            folderURL = url
            return
        }
        scopedURL = url
        saveBookmark(for: url)
        folderURL = url
    }

    private func saveBookmark(for url: URL) {
        do {
            let data = try url.bookmarkData(options: .withSecurityScope,
                                            includingResourceValuesForKeys: nil,
                                            relativeTo: nil)
            UserDefaults.standard.set(data, forKey: bookmarkKey)
        } catch {
            print("⚠️ TranscriptFolderManager：建立 bookmark 失敗：\(error.localizedDescription)")
        }
    }

    private func restore() {
        guard let data = UserDefaults.standard.data(forKey: bookmarkKey) else { return }
        var stale = false
        guard let url = try? URL(resolvingBookmarkData: data,
                                 options: .withSecurityScope,
                                 relativeTo: nil,
                                 bookmarkDataIsStale: &stale) else {
            UserDefaults.standard.removeObject(forKey: bookmarkKey)
            return
        }
        guard url.startAccessingSecurityScopedResource() else { return }
        scopedURL = url
        if stale { saveBookmark(for: url) }   // 資料夾被搬動／改名後，更新 bookmark
        folderURL = url
    }

    private func releaseScope() {
        scopedURL?.stopAccessingSecurityScopedResource()
        scopedURL = nil
    }

    deinit { releaseScope() }
}

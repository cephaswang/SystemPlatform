import Foundation
import AVFAudio
import CoreAudio
import Combine
import AppKit

// v3.1 改版：取代 v3.0 以 ScreenCaptureKit「建立極小影像串流、畫面直接丟棄」
// 來取得系統聲音的做法。
//
// 背景：App Review（Guideline 2.1）指出 macOS 14.4 起新增了 Core Audio Taps
// （AudioHardwareCreateProcessTap），可以單純擷取音訊、完全不會建立任何影像
// 串流，對應的授權也從「Screen & System Audio Recording」改成更小範圍的
// 「System Audio Recording Only」，使用者不會再被問「允許這個 App 錄製螢幕」。
//
// 技術依據（Apple 官方文件「Capturing system audio with Core Audio taps」，
// 以及目前已知的第三方實作案例）：
//   1. CATapDescription(stereoGlobalTapButExcludeProcesses:) 建立一個「整個
//      系統、但排除指定行程」的 tap 描述 → AudioHardwareCreateProcessTap(_:_:)
//      取得 tap 的 AudioObjectID
//   2. 用這個 tap 的 UUID 組一個「私有」聚合裝置（kAudioAggregateDeviceIsPrivateKey
//      = true，不會出現在「系統設定 > 聲音」或 Audio MIDI 設定清單裡）
//      → AudioHardwareCreateAggregateDevice(_:_:)
//   3. 向這個聚合裝置掛一個 IOProc（AudioDeviceCreateIOProcIDWithBlock），
//      在 callback 裡把送來的 AudioBufferList 複製成 AVAudioPCMBuffer，
//      透過跟 v3.0 相同的 Combine publisher 送給 SpeechTranscriber
//   4. 結束時依序：AudioDeviceStop → AudioDeviceDestroyIOProcID →
//      AudioHardwareDestroyAggregateDevice → AudioHardwareDestroyProcessTap
//
// 重要限制（務必知悉）：
//   - 這一整套 API 沒有公開的「預先查詢授權狀態」函式。v3.1 初版曾改用
//     「上一次嘗試擷取是否成功」的 UserDefaults 紀錄來推測，結果第一次使用時
//     永遠是 false，SpeechTranscriber 因此在真正開始擷取前就擋下，系統授權
//     對話框永遠不會跳出（雞生蛋、蛋生雞）。現在改成直接查 TCC 的
//     kTCCServiceAudioCapture（見 PermissionManager.swift 的
//     SystemAudioPermission），這才是權威的授權狀態。
//   - 最低系統需求是 macOS 14.4。專案的 Deployment Target 沒有同步調整的話，
//     這支檔案會直接編譯失敗（SpeechTranscriber.swift 目前是無條件
//     `private let systemAudioCapture = SystemAudioCapture()`，沒有
//     `if #available` 包住，所以沒辦法只靠 @available 標註撐過舊系統）。
//
// 使用方式（跟 v3.0 完全相同，呼叫端不用改）：
//   1. 呼叫 refreshAvailableApps() 取得目前可擷取的 App 清單
//   2. 呼叫 startCapture(source:) 開始擷取；PCM 樣本經由 audioBufferPublisher 送出
//   3. 呼叫 stopCapture() 結束擷取

/// 使用者可選擇的系統聲音來源
enum SystemAudioCaptureSource: Equatable {
    /// 整個系統：擷取所有 App 播放的聲音（排除本 App 自己）
    case entireSystem
    /// 指定單一執行中的 App
    case app(bundleIdentifier: String, displayName: String)
}

/// 可被擷取的執行中 App（清單資料改用 NSWorkspace 列舉，不再依賴
/// ScreenCaptureKit 的 SCShareableContent）
struct CapturableApp: Identifiable, Hashable {
    let id: pid_t
    let bundleIdentifier: String
    let displayName: String
}

enum SystemAudioCaptureError: LocalizedError {
    case screenRecordingPermissionDenied
    case noDisplayAvailable
    case appNotFound
    case alreadyCapturing
    case tapCreationFailed(OSStatus)
    case aggregateDeviceCreationFailed(OSStatus)
    case ioProcFailed(OSStatus)

    var errorDescription: String? {
        switch self {
        case .screenRecordingPermissionDenied:
            return L10n.t("error.screenPermission")
        case .noDisplayAvailable:
            return L10n.t("error.noDisplay")
        case .appNotFound:
            return L10n.t("error.appNotFound")
        case .alreadyCapturing:
            return L10n.t("error.alreadyCapturing")
        case .tapCreationFailed(let status):
            return "建立系統音訊 tap 失敗（status=\(status)）"
        case .aggregateDeviceCreationFailed(let status):
            return "建立音訊聚合裝置失敗（status=\(status)）"
        case .ioProcFailed(let status):
            return "啟動音訊擷取回呼失敗（status=\(status)）"
        }
    }
}

@available(macOS 14.4, *)
final class SystemAudioCapture: NSObject, ObservableObject {

    @Published private(set) var isCapturing = false
    @Published private(set) var availableApps: [CapturableApp] = []

    /// PCM 音訊樣本輸出。SpeechTranscriber 訂閱這個 publisher，
    /// 將收到的 AVAudioPCMBuffer 送進辨識引擎。跟 v3.0 的介面完全相同，
    /// 呼叫端（SpeechTranscriber.swift）不需要任何修改。
    var audioBufferPublisher: AnyPublisher<AVAudioPCMBuffer, Never> {
        audioBufferSubject.eraseToAnyPublisher()
    }

    private let audioBufferSubject = PassthroughSubject<AVAudioPCMBuffer, Never>()

    // Core Audio Taps 擷取生命週期用到的幾個控制代碼，stopCapture() 時依序釋放
    private var tapID: AudioObjectID?
    private var aggregateDeviceID: AudioObjectID?
    private var ioProcID: AudioDeviceIOProcID?
    private var tapFormat: AVAudioFormat?

    private let captureQueue = DispatchQueue(label: "com.dictationhelper.systemaudio.capture")

    // MARK: - 授權狀態（直接查 TCC 的 kTCCServiceAudioCapture）

    /// 目前系統音訊錄製授權狀態（authorized / denied / notDetermined）。
    static var permissionStatus: PermissionManager.PermissionStatus {
        SystemAudioPermission.status
    }

    /// 是否已取得系統音訊錄製授權。名稱沿用舊版，呼叫端不用改。
    static func hasScreenRecordingPermission() -> Bool {
        SystemAudioPermission.status == .authorized
    }

    /// 主動請求授權（只有「尚未決定」時才會跳出系統對話框）。
    @discardableResult
    static func requestScreenRecordingPermission() async -> Bool {
        if SystemAudioPermission.status == .notDetermined {
            _ = await SystemAudioPermission.request()
        }
        return SystemAudioPermission.status == .authorized
    }

    // MARK: - 列舉可擷取來源

    /// 重新列舉目前執行中、可被擷取的 App 清單。
    /// 改用 NSWorkspace 列舉一般可見的 App，不再依賴 ScreenCaptureKit 的
    /// SCShareableContent（那支 API 需要完整的螢幕錄製授權才能呼叫）。
    @MainActor
    func refreshAvailableApps() async throws {
        let apps = NSWorkspace.shared.runningApplications
            .filter { $0.activationPolicy == .regular }
            .compactMap { app -> CapturableApp? in
                guard let bundleID = app.bundleIdentifier,
                      let name = app.localizedName,
                      !name.isEmpty else { return nil }
                return CapturableApp(id: app.processIdentifier, bundleIdentifier: bundleID, displayName: name)
            }
            .sorted { $0.displayName.localizedStandardCompare($1.displayName) == .orderedAscending }

        availableApps = apps
    }

    // MARK: - 開始／停止擷取

    /// 開始擷取指定來源的系統聲音。
    /// 不會更動系統預設輸出／輸入裝置，使用者聽到的聲音完全不受影響
    /// （聚合裝置是私有的，不會出現在「系統設定 > 聲音」清單裡）。
    func startCapture(source: SystemAudioCaptureSource) async throws {
        guard tapID == nil else {
            throw SystemAudioCaptureError.alreadyCapturing
        }

        // 1. 建立 tap 描述
        let description: CATapDescription
        switch source {
        case .entireSystem:
            guard let ownProcess = Self.ownProcessObjectID() else {
                throw SystemAudioCaptureError.tapCreationFailed(kAudioHardwareUnspecifiedError)
            }
            // 整個系統、排除本 App 自己的聲音（例如介面音效），
            // 對應 v3.0 原本的 config.excludesCurrentProcessAudio = true
            description = CATapDescription(stereoGlobalTapButExcludeProcesses: [ownProcess])

        case .app(_, _):
            guard case .app(let bundleIdentifier, _) = source,
                  let targetApp = NSWorkspace.shared.runningApplications.first(where: { $0.bundleIdentifier == bundleIdentifier }),
                  let targetProcess = Self.processObjectID(forPID: targetApp.processIdentifier) else {
                throw SystemAudioCaptureError.appNotFound
            }
            description = CATapDescription(stereoMixdownOfProcesses: [targetProcess])
        }
        description.isPrivate = true
        description.muteBehavior = .unmuted

        var newTapID = AudioObjectID(kAudioObjectUnknown)
        let tapStatus = AudioHardwareCreateProcessTap(description, &newTapID)
        guard tapStatus == noErr else {
            throw SystemAudioCaptureError.tapCreationFailed(tapStatus)
        }

        // 2. 讀取 tap 實際的音訊格式，組成 AVAudioFormat 供後續轉換 PCM buffer 用
        guard let format = Self.readTapFormat(tapID: newTapID) else {
            AudioHardwareDestroyProcessTap(newTapID)
            throw SystemAudioCaptureError.tapCreationFailed(kAudioHardwareUnspecifiedError)
        }

        // 3. 用這個 tap 組一個「私有」聚合裝置，不會出現在聲音選單裡
        let aggregateUID = UUID().uuidString
        let aggregateDescription: [String: Any] = [
            kAudioAggregateDeviceNameKey as String: "DictationHelperSystemAudioTap",
            kAudioAggregateDeviceUIDKey as String: aggregateUID,
            kAudioAggregateDeviceIsPrivateKey as String: true,
            kAudioAggregateDeviceTapAutoStartKey as String: true,
            kAudioAggregateDeviceTapListKey as String: [
                [kAudioSubTapUIDKey as String: description.uuid.uuidString]
            ]
        ]

        var newAggregateID = AudioObjectID(kAudioObjectUnknown)
        let aggregateStatus = AudioHardwareCreateAggregateDevice(aggregateDescription as CFDictionary, &newAggregateID)
        guard aggregateStatus == noErr else {
            AudioHardwareDestroyProcessTap(newTapID)
            throw SystemAudioCaptureError.aggregateDeviceCreationFailed(aggregateStatus)
        }

        // 4. 掛上 IOProc，開始真正收音訊資料
        var newIOProcID: AudioDeviceIOProcID?
        let ioProcStatus = AudioDeviceCreateIOProcIDWithBlock(
            &newIOProcID, newAggregateID, nil
        ) { [weak self] _, inInputData, _, _, _ in
            guard let self, let pcmBuffer = Self.makePCMBuffer(from: inInputData, format: format) else { return }
            self.audioBufferSubject.send(pcmBuffer)
        }
        guard ioProcStatus == noErr, let ioProcID = newIOProcID else {
            AudioHardwareDestroyAggregateDevice(newAggregateID)
            AudioHardwareDestroyProcessTap(newTapID)
            throw SystemAudioCaptureError.ioProcFailed(ioProcStatus)
        }

        let startStatus = AudioDeviceStart(newAggregateID, ioProcID)
        guard startStatus == noErr else {
            AudioDeviceDestroyIOProcID(newAggregateID, ioProcID)
            AudioHardwareDestroyAggregateDevice(newAggregateID)
            AudioHardwareDestroyProcessTap(newTapID)
            throw SystemAudioCaptureError.ioProcFailed(startStatus)
        }

        tapID = newTapID
        aggregateDeviceID = newAggregateID
        self.ioProcID = ioProcID
        tapFormat = format

        await MainActor.run {
            self.isCapturing = true
        }
    }

    /// 結束擷取。使用者的系統輸出／輸入裝置從未被更動過，因此不需要任何還原步驟。
    func stopCapture() async {
        guard let tapID else { return }

        if let aggregateDeviceID, let ioProcID {
            AudioDeviceStop(aggregateDeviceID, ioProcID)
            AudioDeviceDestroyIOProcID(aggregateDeviceID, ioProcID)
            AudioHardwareDestroyAggregateDevice(aggregateDeviceID)
        }
        AudioHardwareDestroyProcessTap(tapID)

        self.tapID = nil
        self.aggregateDeviceID = nil
        self.ioProcID = nil
        self.tapFormat = nil

        await MainActor.run {
            self.isCapturing = false
        }
    }

    // MARK: - CoreAudio 輔助函式

    /// 把目前這個行程（自己）轉成 Core Audio 的 AudioObjectID，
    /// 用來在 .entireSystem 模式下排除自己的聲音。
    private static func ownProcessObjectID() -> AudioObjectID? {
        processObjectID(forPID: ProcessInfo.processInfo.processIdentifier)
    }

    private static func processObjectID(forPID pid: pid_t) -> AudioObjectID? {
        var mutablePID = pid
        var processObjectID = AudioObjectID(kAudioObjectUnknown)
        var address = AudioObjectPropertyAddress(
            mSelector: kAudioHardwarePropertyTranslatePIDToProcessObject,
            mScope: kAudioObjectPropertyScopeGlobal,
            mElement: kAudioObjectPropertyElementMain)
        var dataSize = UInt32(MemoryLayout<AudioObjectID>.size)
        let status = withUnsafeMutablePointer(to: &mutablePID) { pidPtr -> OSStatus in
            AudioObjectGetPropertyData(
                AudioObjectID(kAudioObjectSystemObject),
                &address,
                UInt32(MemoryLayout<pid_t>.size),
                pidPtr,
                &dataSize,
                &processObjectID)
        }
        return status == noErr ? processObjectID : nil
    }

    /// 讀取 tap 物件實際的音訊格式（kAudioTapPropertyFormat），
    /// 轉成 AVAudioFormat 供 IOProc callback 組 AVAudioPCMBuffer 用。
    private static func readTapFormat(tapID: AudioObjectID) -> AVAudioFormat? {
        var asbd = AudioStreamBasicDescription()
        var size = UInt32(MemoryLayout<AudioStreamBasicDescription>.size)
        var address = AudioObjectPropertyAddress(
            mSelector: kAudioTapPropertyFormat,
            mScope: kAudioObjectPropertyScopeGlobal,
            mElement: kAudioObjectPropertyElementMain)
        let status = AudioObjectGetPropertyData(tapID, &address, 0, nil, &size, &asbd)
        guard status == noErr else {
            print("[SystemAudioCapture] 讀取 tap 格式失敗（status=\(status)）")
            return nil
        }
        return AVAudioFormat(streamDescription: &asbd)
    }

    /// 把 IOProc 收到的 AudioBufferList（CoreAudio 擁有、只在 callback 期間有效的
    /// 記憶體）深層複製成一份獨立的 AVAudioPCMBuffer，交給 SpeechTranscriber。
    ///
    /// 不能直接包著原始指標傳出去：這塊記憶體下一輪 callback 就會被 CoreAudio
    /// 回收重用，SFSpeechAudioBufferRecognitionRequest.append(_:) 不保證是同步
    /// 處理完才回傳，用原始指標會有資料被覆寫、甚至雙語模式下兩路互相干擾的風險
    /// （這正是 v3.0 處理 ScreenCaptureKit／麥克風雙語緩衝區時踩過的坑，
    /// 見 SpeechTranscriber.swift 的 `duplicate(_:)` 註解）。
    private static func makePCMBuffer(
        from inputData: UnsafePointer<AudioBufferList>,
        format: AVAudioFormat
    ) -> AVAudioPCMBuffer? {
        let sourceList = UnsafeMutableAudioBufferListPointer(UnsafeMutablePointer(mutating: inputData))
        guard let firstBuffer = sourceList.first, firstBuffer.mDataByteSize > 0 else { return nil }

        let bytesPerFrame = format.streamDescription.pointee.mBytesPerFrame
        guard bytesPerFrame > 0 else { return nil }
        let frameCount = AVAudioFrameCount(firstBuffer.mDataByteSize / bytesPerFrame)
        guard frameCount > 0,
              let pcmBuffer = AVAudioPCMBuffer(pcmFormat: format, frameCapacity: frameCount)
        else { return nil }
        pcmBuffer.frameLength = frameCount

        let destList = UnsafeMutableAudioBufferListPointer(pcmBuffer.mutableAudioBufferList)
        for (index, sourceBuffer) in sourceList.enumerated() where index < destList.count {
            guard let sourceData = sourceBuffer.mData, let destData = destList[index].mData else { continue }
            let byteCount = min(sourceBuffer.mDataByteSize, destList[index].mDataByteSize)
            memcpy(destData, sourceData, Int(byteCount))
            destList[index].mDataByteSize = byteCount
        }

        return pcmBuffer
    }
}

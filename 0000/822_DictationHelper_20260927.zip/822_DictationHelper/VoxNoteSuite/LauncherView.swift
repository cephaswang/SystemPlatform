import SwiftUI
import AppKit

struct LauncherView: View {

    let onSelectImport: () -> Void
    let onSelectVoiceCapture: () -> Void

    // v3.0 起，環境狀態不再是「BlackHole 是否已安裝」，改為「螢幕錄製」授權狀態；
    // 不再有「一鍵設置／重新安裝外掛／一鍵移除」，
    // 點一下只會開啟簡化後的說明視窗（見下方 EnvironmentInfoView）。
    @State private var environmentStatusSummary: String?
    @State private var showEnvironmentInfoSheet = false

    var body: some View {
        let _ = print("🖼️ [\(Self.self)] body 重新評估 (\(#fileID))")

        VStack(spacing: 24) {

            Text("聽抄小幫手")
                .font(.title)
                .bold()

            Text("請選擇要開啟的模式")
                .font(.subheadline)
                .foregroundColor(.secondary)


            HStack(spacing: 20) {

                LauncherButton(
                    title: "匯入音檔轉文字稿",
                    subtitle: "已有音檔，事後轉成文字稿",
                    systemImage: "waveform.badge.plus",
                    action: onSelectImport
                )

                LauncherButton(
                    title: "聽抄",
                    subtitle: "邊聽系統聲音或麥克風，邊即時轉文字",
                    systemImage: "speaker.wave.2.circle",
                    action: onSelectVoiceCapture
                )
            }

            // 環境狀態列：只顯示螢幕錄製授權狀態，點一下開啟簡化後的
            // 說明視窗；就緒時顯示綠色打勾，不需要使用者做任何事。
            Button {
                refreshEnvironmentStatus()
                showEnvironmentInfoSheet = true
            } label: {
                HStack(spacing: 6) {
                    Image(systemName: environmentStatusSummary == nil ? "checkmark.circle.fill" : "exclamationmark.circle.fill")
                        .foregroundColor(environmentStatusSummary == nil ? .green : .orange)
                    Text(environmentStatusSummary ?? "環境已就緒")
                        .font(.caption)
                }
                .foregroundColor(.secondary)
            }
            .buttonStyle(.plain)
        }
        .padding(32)
        //.frame(width: 480)
        .frame(maxWidth: .infinity)
        .onAppear {
            refreshEnvironmentStatus()
        }
        .sheet(isPresented: $showEnvironmentInfoSheet, onDismiss: refreshEnvironmentStatus) {
            EnvironmentInfoView()
        }
    }

    private func refreshEnvironmentStatus() {
        environmentStatusSummary = PrerequisiteChecker.environmentStatusSummary()
    }
}

/// v3.0 新增，取代原本的「環境設置視窗」（AudioSetupView）。
/// 不再有任何一鍵設置／重新安裝外掛／一鍵移除的按鈕，只單純說明目前
/// 「螢幕錄製」授權的狀態，需要時引導使用者到對應的系統設定。
private struct EnvironmentInfoView: View {
    @Environment(\.dismiss) private var dismiss

    private var isScreenRecordingAuthorized: Bool { PrerequisiteChecker.isScreenRecordingAuthorized() }

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("環境狀態")
                .font(.title2)
                .bold()

            statusRow(
                ready: isScreenRecordingAuthorized,
                title: "螢幕錄製授權",
                readyText: "已授權，可以使用「聽抄」的系統聲音來源",
                notReadyText: "尚未授權，僅「聽抄」選擇系統聲音來源時才需要；第一次按下「開始聽抄」會跳出授權對話框，授權後需重新啟動 App 才會生效"
            )

            if !isScreenRecordingAuthorized {
                Button("前往「系統設定 › 隱私權與安全性 › 螢幕錄製」") {
                    if let url = URL(string: "x-apple.systempreferences:com.apple.preference.security?Privacy_ScreenCapture") {
                        NSWorkspace.shared.open(url)
                    }
                }
            }

            Text("只用「麥克風」聽抄時，完全不需要任何環境設置，也不需要安裝任何協力廠商元件。")
                .font(.caption)
                .foregroundColor(.secondary)

            HStack {
                Spacer()
                Button("關閉", role: .cancel) { dismiss() }
                    .buttonStyle(.borderedProminent)
            }
        }
        .padding(24)
        .frame(width: 440)
    }

    private func statusRow(ready: Bool, title: String, readyText: String, notReadyText: String) -> some View {
        HStack(alignment: .top, spacing: 8) {
            Image(systemName: ready ? "checkmark.circle.fill" : "exclamationmark.triangle.fill")
                .foregroundColor(ready ? .green : .orange)
            VStack(alignment: .leading, spacing: 2) {
                Text(title).bold()
                Text(ready ? readyText : notReadyText)
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
        }
    }
}

/// 單一入口按鈕（純 UI 元件）
private struct LauncherButton: View {
    let title: String
    let subtitle: String
    let systemImage: String
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            VStack(spacing: 10) {
                Image(systemName: systemImage)
                    .font(.system(size: 36))
                Text(title)
                    .font(.headline)
                Text(subtitle)
                    .font(.caption)
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
            }
            .padding()
           // .frame(width: 190, height: 160)
            .frame(maxWidth: .infinity, minHeight: 160)
            .background(Color(nsColor: .controlBackgroundColor))
            .cornerRadius(12)
        }
        .buttonStyle(.plain)
    }
}

#Preview {
    LauncherView(onSelectImport: {}, onSelectVoiceCapture: {})
}

import Foundation

/// 代表一個使用者匯入的音檔，及其轉錄進度狀態
struct AudioFile: Identifiable, Equatable, Codable {

    enum TranscriptionStatus: Equatable, Codable {
        case pending
        case processing
        case completed
        case failed
    }

    let id: UUID
    var sourceURL: URL
    /// 使用者實際上傳的原始檔案位置。匯入階段已不再做格式轉檔（僅接受
    /// AVFoundation 可原生讀取的 mp3／m4a／wav），因此目前恆等於 sourceURL；
    /// 保留此欄位是為了讓呼叫端（例如 ImportView 比對已匯入檔案）不需要跟著改動。
    var originalSourceURL: URL
    var displayName: String
    var durationSeconds: TimeInterval
    var status: TranscriptionStatus

    /// 這個檔案要用哪個語系辨識，例如 "zh-TW"、"en-US"。
    /// 由使用者於 ImportView 匯入當下選定，之後不會被全域設定覆蓋，
    /// 每個檔案各自獨立，互不影響。
    var locale: String

    /// 轉錄完成後的逐句結果；未完成前為空陣列
    var transcriptSegments: [TranscriptSegment] = []

    /// 副檔名（不含句點），例如 "mp3"、"m4a"、"wav"
    var fileExtension: String {
        sourceURL.pathExtension.lowercased()
    }

    /// UI 顯示用的時長字串，例如 "3:05"
    var durationDescription: String {
        let totalSeconds = Int(durationSeconds.rounded())
        let minutes = totalSeconds / 60
        let seconds = totalSeconds % 60
        return String(format: "%d:%02d", minutes, seconds)
    }

    init(
        id: UUID,
        sourceURL: URL,
        originalSourceURL: URL? = nil,
        displayName: String,
        durationSeconds: TimeInterval,
        status: TranscriptionStatus,
        locale: String = "zh-TW",
        transcriptSegments: [TranscriptSegment] = []
    ) {
        self.id = id
        self.sourceURL = sourceURL
        self.originalSourceURL = originalSourceURL ?? sourceURL
        self.displayName = displayName
        self.durationSeconds = durationSeconds
        self.status = status
        self.locale = locale
        self.transcriptSegments = transcriptSegments
    }

    static func == (lhs: AudioFile, rhs: AudioFile) -> Bool {
        lhs.id == rhs.id
    }
}

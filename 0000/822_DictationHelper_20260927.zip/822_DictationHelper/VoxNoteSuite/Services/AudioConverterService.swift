import Foundation
import AVFoundation

enum AudioConversionError: LocalizedError {
    case exportSessionUnavailable
    case conversionFailed(String)

    var errorDescription: String? {
        switch self {
        case .exportSessionUnavailable:
            return "無法建立音訊轉檔工作階段"
        case .conversionFailed(let reason):
            return "音檔轉換失敗：\(reason)"
        }
    }
}

/// 音檔轉換服務：將已支援讀取的音檔統一轉成辨識引擎偏好的格式（.caf）。
/// ffmpeg 轉檔功能已移除，不再處理 webm 等格式的預先轉檔；
/// 匯入階段僅接受 AVFoundation 可原生讀取的格式（見 AudioImportService.supportedExtensions）。
struct AudioConverterService {

    // MARK: - 辨識前處理：統一轉為辨識引擎偏好格式

    /// 將來源音檔轉換為 .caf（Core Audio Format），輸出至暫存目錄，回傳暫存檔 URL
    func convertToRecognitionFormat(sourceURL: URL) async throws -> URL {
        let asset = AVURLAsset(url: sourceURL)

        guard let exportSession = AVAssetExportSession(
            asset: asset,
            presetName: AVAssetExportPresetAppleM4A
        ) else {
            throw AudioConversionError.exportSessionUnavailable
        }

        let outputURL = FileManager.default.temporaryDirectory
            .appendingPathComponent(UUID().uuidString)
            .appendingPathExtension("caf")

        exportSession.outputURL = outputURL
        exportSession.outputFileType = .caf

        await exportSession.export()

        switch exportSession.status {
        case .completed:
            return outputURL
        case .failed, .cancelled:
            throw AudioConversionError.conversionFailed(
                exportSession.error?.localizedDescription ?? "未知錯誤"
            )
        default:
            throw AudioConversionError.conversionFailed("匯出工作階段狀態異常")
        }
    }

    /// 轉檔完成後清除暫存檔案
    func cleanupTemporaryFile(at url: URL) {
        try? FileManager.default.removeItem(at: url)
    }
}

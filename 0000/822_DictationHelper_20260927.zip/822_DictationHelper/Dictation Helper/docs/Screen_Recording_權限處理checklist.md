# macOS Screen Recording（螢幕與系統音訊錄製）權限處理清單

適用對象：`Dictation Helper`（Bundle ID: `org.share35app.Dictation-Helper`），
「聽抄」功能選擇「系統聲音」來源時，需要向 macOS 申請螢幕/系統音訊錄製權限。

---

## 一、Info.plist 設定

| 項目 | 內容 |
|---|---|
| Key（Xcode 顯示名稱） | `Privacy - Screen Capture Usage Description` |
| 實際 Key（原始字串） | `NSScreenCaptureUsageDescription` |
| Type | String |
| Value（範例） | 聽抄小幫手需要「螢幕與系統音訊錄製」權限，才能擷取系統喇叭聲音來即時轉成文字稿。 |

**⚠️ 這把 key 目前尚未加入專案的 Info 設定**（目前只有 Microphone、Speech Recognition 兩把）。

> 依 Apple 官方文件：使用 ScreenCaptureKit 擷取螢幕或系統音訊，必須在 Target 的 Info
> 頁籤加上 `NSScreenCaptureUsageDescription`，向使用者說明用途。
>
> **沒有這把 key 的後果**：系統會直接安靜地擋掉請求——不跳出授權對話框、
> 不報錯、App 也不會出現在「系統設定 › 隱私權與安全性 › Screen & System Audio
> Recording」清單裡，行為表現得像「什麼事都沒發生」，很容易誤以為是程式碼呼叫錯誤。

加入步驟：
1. Xcode → 選 Target → **Info** 頁籤
2. 在既有的 Key/Value 列表最下方按「+」
3. Key 打 `Privacy - Screen Capture Usage Description`（Xcode 會自動對應到 `NSScreenCaptureUsageDescription`）
4. Type 選 `String`
5. Value 填寫給使用者看的說明文字

---

## 二、程式碼：必須「真的送出請求」，不能只做檢查

| 函式 | 作用 | 是否會跳出授權視窗 |
|---|---|---|
| `CGPreflightScreenCaptureAccess()` | **只檢查**目前是否已授權 | ❌ 不會 |
| `CGRequestScreenCaptureAccess()` | **實際送出請求**（未授權時跳出系統對話框） | ✅ 會（僅第一次） |
| 啟動 `ScreenCaptureKit` / Core Audio Process Tap 擷取工作階段 | 實際開始擷取畫面或系統音訊 | ✅ 會（若尚未授權） |

**檢查重點**：目前 `PrerequisiteChecker.isScreenRecordingAuthorized()` 這類函式，
如果內部只呼叫 `CGPreflightScreenCaptureAccess()`，代表 App 從頭到尾都只是在
「查詢狀態」，從來沒有真正「申請」過，這也是 App 完全沒出現在系統設定清單裡的
另一個可能原因（與 Info.plist 遺漏是兩個獨立、可能同時存在的問題）。

- 「環境設置」說明視窗（`EnvironmentInfoView`）**只顯示狀態，不會觸發任何請求**。
- 只有使用者實際打開「聽抄」畫面、選擇「系統聲音」來源、按下「開始聽抄」，
  程式碼才應該呼叫 `CGRequestScreenCaptureAccess()` 或啟動實際的擷取工作階段，
  這才是真正觸發系統對話框與清單註冊的動作。

---

## 三、Entitlements（若專案有開啟 App Sandbox）

| 情境 | 需要的 Entitlement |
|---|---|
| 有開啟 `com.apple.security.app-sandbox` | 需視實際使用的 API 額外檢查是否需要對應的 entitlement（例如透過 ScreenCaptureKit 存取螢幕內容），沙盒會在系統跳窗之前就先擋下 API 呼叫 |
| 沒有開啟 App Sandbox（一般直接發佈、非 App Store 的桌面 App 常見） | 通常不需要額外 entitlement，靠 TCC／Info.plist 即可 |

👉 待確認：本專案的 `.entitlements` 檔案目前是否有開啟 App Sandbox，尚未看過內容，
若有開啟，需要另外確認對應 entitlement 是否齊全。

---

## 四、建置與簽章一致性

- **避免每次都用 Xcode 直接按 Run 除錯**：每次重新編譯，簽章或執行路徑可能改變，
  macOS 的 TCC 資料庫有時會把它認成不同的 App，導致授權卡住、不會再跳窗。
- 建議：完整 Build 出正式版本後，直接在 Finder 裡雙擊執行（不透過 Xcode），
  再測試權限流程是否正常。

---

## 五、測試與除錯步驟

1. **重設既有的授權紀錄**（測試前先清乾淨，避免舊紀錄干擾判斷）：
   ```bash
   sudo tccutil reset ScreenCapture org.share35app.Dictation-Helper
   sudo tccutil reset Microphone org.share35app.Dictation-Helper
   sudo tccutil reset SpeechRecognition org.share35app.Dictation-Helper
   ```
2. 完整 Build App，直接在 Finder 執行（不透過 Xcode Run）。
3. 打開「聽抄」畫面 → 選擇「系統聲音」來源 → 按下「開始聽抄」。
4. 預期：系統跳出「Dictation Helper 想要錄製這台電腦的畫面與系統音訊」的授權對話框。
5. 若沒有跳出：
   - 打開「主控台 (Console.app)」→ 選左側你的 Mac → 搜尋關鍵字 `tccd` 或
     `Dictation Helper` → 同時執行步驟 3 的操作，觀察有沒有拒絕或錯誤紀錄。
   - 到「系統設定 › 隱私權與安全性 › Screen & System Audio Recording」確認
     App 是否有出現在清單中（有出現但沒勾選 vs. 完全沒出現，代表的問題不同）。
6. 若清單裡完全沒有這個 App：先確認第一、二節（Info.plist key、實際呼叫
   request API）是否都已補上，這是最常見的成因。
7. 也可以手動用清單左下角的「+」把 App 加進去勾選測試，但這只能解決
   「整體螢幕/音訊錄製」這類授權；若走的是較新的「System Audio Recording Only」
   （畫面上 Movavi 那個獨立分類），通常還是需要 App 在程式碼裡真的建立一次
   擷取工作階段（例如 Core Audio Process Tap）才會生效，手動加清單不一定足夠。

---

## 六、總結檢查表

- [ ] Info.plist 加上 `NSScreenCaptureUsageDescription`（Privacy - Screen Capture Usage Description）
- [ ] 確認實際啟動系統聲音擷取的程式碼有呼叫 `CGRequestScreenCaptureAccess()` 或
      啟動真正的擷取工作階段，而不是只做 `CGPreflightScreenCaptureAccess()` 檢查
- [ ] 確認 `.entitlements` 是否有開啟 App Sandbox；若有，補齊對應 entitlement
- [ ] 用完整 Build 出來、Finder 直接執行的版本測試，避免 Xcode Run 造成的簽章/路徑問題
- [ ] 測試前用 `tccutil reset` 清除舊授權紀錄
- [ ] 用「主控台 (Console.app)」搭配關鍵字 `tccd` 排查是否有 TCC 拒絕紀錄
- [ ] 確認 App 最終有出現在「系統設定 › 隱私權與安全性 › Screen & System Audio Recording」清單中，且可正常勾選

#!/bin/bash
#
# reset_permissions.sh (v2)
#
# Purpose: reset the privacy permissions already granted to
# "Dictation Helper" so the OS shows the authorization prompts again
# next time it launches. Useful for tutorials / screen recordings /
# testing the first-run permission flow.
#
# Uses the built-in macOS "tccutil" command. It only clears TCC
# (privacy database) records for this one app; it does not remove
# the app itself and does not touch other apps' permissions.
#
# Usage:
#   chmod +x reset_permissions.sh
#   ./reset_permissions.sh
#
# May prompt for your sudo password (some services need admin rights
# to reset).

set -euo pipefail

BUNDLE_ID="org.share35app.Dictation-Helper"

# Permissions this app actually uses:
#   Microphone        mic input for live transcription
#   ScreenCapture      macOS groups "system audio capture" under this
#   SpeechRecognition  Apple Speech framework
SERVICES=(
  "Microphone"
  "ScreenCapture"
  "SpeechRecognition"
)

echo "About to reset permissions for:"
echo "  Bundle ID: ${BUNDLE_ID}"
echo ""
echo "Services:"
for service in "${SERVICES[@]}"; do
  echo "  - ${service}"
done
echo ""

read -r -p "Continue? [y/N] " confirm
case "$confirm" in
  y|Y) ;;
  *)
    echo "Cancelled."
    exit 0
    ;;
esac

for service in "${SERVICES[@]}"; do
  echo ">>> tccutil reset ${service} ${BUNDLE_ID}"
  if sudo tccutil reset "${service}" "${BUNDLE_ID}"; then
    echo "    OK: ${service} reset"
  else
    echo "    WARN: failed to reset ${service} (service name may not exist on this macOS version, or there was no existing record)"
  fi
done

echo ""
echo "Done."
echo "Bundle ID ${BUNDLE_ID} will show authorization prompts again next time it uses these features."
echo "Note: after resetting ScreenCapture, you may need to fully quit and relaunch the app for it to take effect."

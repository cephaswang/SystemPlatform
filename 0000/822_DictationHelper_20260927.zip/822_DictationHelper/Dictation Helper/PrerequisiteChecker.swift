import Foundation

// v3.0 起，系統聲音來源改用 ScreenCaptureKit（見 SystemAudioCapture.swift），不再需要
// 安裝 BlackHole 虛擬音訊裝置，也不再需要把 setup.sh 複製到桌面讓使用者手動執行。
//
// 本檔案改為檢查「第一次使用」時真正還需要的兩件事（見企劃書 3.4 節）：
//   1. ffmpeg 是否就緒（僅「匯入音檔轉文字稿」模式匯入 webm 檔時需要）
//   2. 「螢幕錄製」授權狀態（僅聲音來源選「系統聲音」時需要）
enum PrerequisiteChecker {

    // MARK: - ffmpeg

    // 依序檢查：內嵌版本（Scripts/EmbedFFmpeg.sh 建置時放進 App Bundle）→
    // Homebrew 常見安裝路徑 → PATH 上找得到的版本。涵蓋「內嵌」「Homebrew 安裝」
    // 「使用者自行安裝在其他位置」三種情境（見企劃書第十節待確認事項 #3）。
    private static var candidateFFmpegPaths: [String] {
        var paths: [String] = []
        if let bundled = Bundle.main.path(forResource: "ffmpeg", ofType: nil) {
            paths.append(bundled)
        }
        paths.append(contentsOf: [
            "/opt/homebrew/bin/ffmpeg", // Apple Silicon 上的 Homebrew 安裝路徑
            "/usr/local/bin/ffmpeg"     // Intel 上的 Homebrew 安裝路徑
        ])
        return paths
    }

    /// 找出目前可用的 ffmpeg 執行檔路徑；找不到就回傳 nil
    static func resolvedFFmpegPath() -> String? {
        for path in candidateFFmpegPaths where FileManager.default.isExecutableFile(atPath: path) {
            return path
        }
        return whichFFmpegInPath()
    }

    /// ffmpeg 是否已就緒，供模式選擇畫面下方的環境狀態列顯示用
    static func isFFmpegReady() -> Bool {
        resolvedFFmpegPath() != nil
    }

    // 在使用者的 PATH 環境變數中尋找 ffmpeg，涵蓋使用者自行安裝、
    // 且未使用上面兩個 Homebrew 標準路徑的情況。
    private static func whichFFmpegInPath() -> String? {
        let process = Process()
        process.executableURL = URL(fileURLWithPath: "/usr/bin/which")
        process.arguments = ["ffmpeg"]

        let outputPipe = Pipe()
        process.standardOutput = outputPipe
        process.standardError = Pipe() // 丟棄錯誤訊息，避免污染主控台

        do {
            try process.run()
            process.waitUntilExit()
            let data = outputPipe.fileHandleForReading.readDataToEndOfFile()
            guard process.terminationStatus == 0,
                  let output = String(data: data, encoding: .utf8)?
                      .trimmingCharacters(in: .whitespacesAndNewlines),
                  !output.isEmpty
            else { return nil }
            return output
        } catch {
            print("⚠️ 呼叫 /usr/bin/which 尋找 ffmpeg 失敗：\(error.localizedDescription)")
            return nil
        }
    }

    // MARK: - 螢幕錄製授權（僅系統聲音來源需要）

    /// 「螢幕錄製」授權目前是否已取得。
    /// 只有選擇「系統聲音」來源時才需要這項授權，麥克風來源完全不受影響。
    static func isScreenRecordingAuthorized() -> Bool {
        if #available(macOS 13.0, *) {
            return SystemAudioCapture.hasScreenRecordingPermission()
        }
        return false
    }

    // MARK: - 環境狀態列摘要文字

    /// 給模式選擇畫面下方「環境狀態列」使用的簡短摘要文字，
    /// 例如「ffmpeg 尚未安裝・螢幕錄製尚未授權」；兩項都就緒時回傳 nil。
    static func environmentStatusSummary() -> String? {
        var issues: [String] = []
        if !isFFmpegReady() {
           // issues.append("ffmpeg 尚未安裝")
        }
        if !isScreenRecordingAuthorized() {
            issues.append("螢幕錄製尚未授權")
        }
        return issues.isEmpty ? nil : issues.joined(separator: "・")
    }
}

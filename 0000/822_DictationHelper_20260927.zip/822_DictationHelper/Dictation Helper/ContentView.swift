import SwiftUI
import AppKit
import Speech
import CoreAudio

// MARK: - 輸入裝置過濾

/// CoreAudio 會在行程使用「預設裝置」時，臨時建立私有聚合裝置
/// 「CADefaultDeviceAggregate-<PID>-<編號>」。它不是真實的麥克風，
/// 名稱含行程 PID、每次啟動都不同，選它會收不到聲音、無法聽抄，
/// 所以不讓它出現在麥克風清單裡，也不會被當成預設選擇。
private extension Collection {
    func excludingInternalAggregates(by name: KeyPath<Element, String>) -> [Element] {
        filter { !$0[keyPath: name].hasPrefix("CADefaultDeviceAggregate") }
    }
}

struct ContentView: View {
    @StateObject private var transcriber = SpeechTranscriber()
    @StateObject private var deviceManager = AudioDeviceManager()

    @AppStorage("selectedLocale") private var selectedLocale: String = Locale.current.identifier
    @State private var availableLocales: [String] = []

    // 雙語模式（記住使用者上次的選擇）
    @AppStorage("bilingualMode") private var bilingualMode: Bool = false
    @AppStorage("localeA") private var localeA: String = "zh-TW"
    @AppStorage("localeB") private var localeB: String = "en-US"

    // 停止聽抄確認對話框
    @State private var showStopConfirmation = false

    // 尚無逐字稿內容時的提示
    @State private var showNoTranscriptAlert = false

    // MARK: 聲音來源：系統聲音／麥克風
    //
    // v3.0 起，這是使用者最先要做的選擇：選「系統聲音」時，下方清單改列
    // 「可擷取的來源」（整個系統，或指定某個執行中的 App），資料來自
    // SCShareableContent；選「麥克風」時，下方清單才是實體輸入裝置
    // （沿用 CoreAudio 列舉方式）。選單只是使用者的「選擇意圖」，真正
    // 套用（啟動擷取，或切換系統預設輸入）是在按下「開始聽抄」的當下。
    @AppStorage("audioSourceIsSystemAudio") private var audioSourceIsSystemAudio: Bool = false

    // 麥克風來源：使用者在選單上選擇的輸入裝置。
    // 這只是畫面上的「意圖」，不會一選就立刻切換系統的預設輸入裝置；
    // 真正套用到系統是在按下「開始聽抄」的當下（見 startTranscription 區塊）。
    @State private var selectedInputDeviceID: AudioDeviceID?

    // 記住使用者上次選的麥克風裝置名稱，下次開啟 App／重新整理裝置清單時優先沿用
    @AppStorage("selectedInputDeviceName") private var selectedInputDeviceName: String = ""

    var body: some View {
        let _ = print("🖼️ [\(Self.self)] body (\(#fileID))")

        VStack(alignment: .leading, spacing: 16) {

            Text("聽抄")
                .font(.title2)
                .bold()

            // 雙語模式開關
            /*
            Toggle(isOn: $bilingualMode) {
                Text("雙語模式（同時辨識兩種語言，自動選信心較高者）")
            }
            .disabled(transcriber.isRunning)
            */

            if bilingualMode {
                // 雙語模式：兩個語言各自選單
                HStack {
                    Text("語言 A：")
                    Picker("", selection: $localeA) {
                        ForEach(availableLocales, id: \.self) { code in
                            Text("\(displayName(for: code))（\(code)）").tag(code)
                        }
                    }
                    .frame(width: 280)
                    .disabled(transcriber.isRunning)
                }
                HStack {
                    Text("語言 B：")
                    Picker("", selection: $localeB) {
                        ForEach(availableLocales, id: \.self) { code in
                            Text("\(displayName(for: code))（\(code)）").tag(code)
                        }
                    }
                    .frame(width: 280)
                    .disabled(transcriber.isRunning)
                }
                Text("💡 雙語模式會同時跑兩個辨識引擎，CPU 用量較高；每句話說完後系統會自動比較兩邊的信心分數，選較高者存檔。無法辨識「同一句話裡中英夾雜」的情況，適合「整段話都用同一種語言、但不同段落切換語言」的場景。")
                    .font(.caption)
                    .foregroundColor(.secondary)
            } else {
                // 單語模式：動態列出「這台 Mac 目前」支援語音辨識的所有語系
                HStack {
                    Text("語系：")
                    Picker("", selection: $selectedLocale) {
                        ForEach(availableLocales, id: \.self) { code in
                            Text("\(displayName(for: code))（\(code)）").tag(code)
                        }
                    }
                    .frame(width: 300)
                    .disabled(transcriber.isRunning)

                    Text("（共 \(availableLocales.count) 種）")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }

            // 聲音來源：系統聲音／麥克風
            HStack {
                Text("聲音來源：")
                Picker("", selection: $audioSourceIsSystemAudio) {
                    Text("系統聲音").tag(true)
                    Text("麥克風").tag(false)
                }
                .pickerStyle(.segmented)
                .frame(width: 220)
                .disabled(transcriber.isRunning)
            }

            if audioSourceIsSystemAudio {
                // v3.0 目前只支援「整個系統」，不提供指定單一 App 的選項。
                HStack {
                    Text("擷取來源：")
                    Text("整個系統")
                        .foregroundColor(.secondary)
                }
            } else {
                // 麥克風來源：清單是實體輸入裝置，沿用 CoreAudio 列舉方式。
                HStack {
                    Text("輸入裝置：")
                    Picker("", selection: Binding(
                        get: { selectedInputDeviceID ?? deviceManager.currentInputDeviceID ?? 0 },
                        set: { newID in
                            selectedInputDeviceID = newID
                            if let name = deviceManager.inputDevices.excludingInternalAggregates(by: \.name).first(where: { $0.id == newID })?.name {
                                selectedInputDeviceName = name
                            }
                        }
                    )) {
                        ForEach(deviceManager.inputDevices.excludingInternalAggregates(by: \.name)) { device in
                            Text(device.name).tag(device.id)
                        }
                    }
                    .frame(width: 260)
                    .disabled(transcriber.isRunning)

                    Button("重新整理") {
                        deviceManager.refreshDevices()
                        reconcileSelectedInputDevice()
                    }
                    .disabled(transcriber.isRunning)
                }
            }

            if audioSourceIsSystemAudio {
                if isScreenRecordingAuthorized {
                    Text("✅ 按下「開始聽抄」時，會直接擷取所選來源的聲音，不會更動您目前的系統輸出／輸入裝置設定，聽到的聲音完全不受影響，也不需要進「系統設定 > 聲音」")
                        .foregroundColor(.black)
                        .padding(10)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(Color.green)
                        .cornerRadius(8)
                } else {
                    Text("⚠️ 尚未取得「螢幕錄製」授權。第一次按下「開始聽抄」時系統會跳出授權對話框，授權後需要重新啟動 App 才會生效；也可以先到「系統設定 › 隱私權與安全性 › 螢幕錄製」開啟「Dictation Helper」")
                        .foregroundColor(.black)
                        .padding(10)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(Color.red.opacity(0.25))
                        .cornerRadius(8)
                }
            } else {
                Text("🎤 目前選擇的是麥克風，會直接收錄您說話與周圍環境的聲音，不會更動系統輸出裝置，維持您原本在聽的喇叭或耳機。\n如果要擷取系統播放的聲音（例如影片、會議錄影），請在上方改選「系統聲音」")
                    .foregroundColor(.black)
                    .padding(10)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.blue.opacity(0.15))
                    .cornerRadius(8)
            }

            // 開始 / 停止
            HStack {
                Button(transcriber.isRunning ? "停止聽抄" : "開始聽抄") {
                    if transcriber.isRunning {
                        showStopConfirmation = true
                    } else {
                        startTranscription()
                    }
                }
                .buttonStyle(.borderedProminent)
                .confirmationDialog(
                    "確定要停止聽抄嗎？",
                    isPresented: $showStopConfirmation,
                    titleVisibility: .visible
                ) {
                    Button("停止聽抄", role: .destructive) {
                        transcriber.stop()
                    }
                    Button("取消", role: .cancel) { }
                } message: {
                    Text("停止後，目前尚未定案的內容會強制寫入檔案，不會遺失。")
                }

                Button("在 Finder 中顯示逐字稿") {
                    if let url = transcriber.outputFileURL,
                       FileManager.default.fileExists(atPath: url.path) {
                        NSWorkspace.shared.activateFileViewerSelecting([url])
                    } else {
                        showNoTranscriptAlert = true
                    }
                }
            }

            if !transcriber.statusMessage.isEmpty {
                Text(transcriber.statusMessage)
                    .foregroundColor(.red)
            }

            Divider()

            if bilingualMode {
                // 雙語模式：兩個引擎各自的即時假設分開顯示
                Text("即時辨識（語言 A：\(displayName(for: localeA))）：")
                    .font(.headline)
                ScrollView {
                    Text(transcriber.liveTextA)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .textSelection(.enabled)
                }
                .padding(8)
                .frame(maxWidth: .infinity, minHeight: 36, maxHeight: 80, alignment: .leading)
                .background(Color.gray.opacity(0.1))
                .cornerRadius(6)

                Text("即時辨識（語言 B：\(displayName(for: localeB))）：")
                    .font(.headline)
                ScrollView {
                    Text(transcriber.liveTextB)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .textSelection(.enabled)
                }
                .padding(8)
                .frame(maxWidth: .infinity, minHeight: 36, maxHeight: 80, alignment: .leading)
                .background(Color.gray.opacity(0.1))
                .cornerRadius(6)
            } else {
                Text("即時辨識：")
                    .font(.headline)
                ScrollView {
                    Text(transcriber.liveText)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .textSelection(.enabled)
                }
                .padding(8)
                .frame(maxWidth: .infinity, minHeight: 40, maxHeight: 120, alignment: .leading)
                .background(Color.gray.opacity(0.1))
                .cornerRadius(6)
            }

            HStack {
                Text("已存檔內容：")
                    .font(.headline)
                if let url = transcriber.outputFileURL {
                    Text("(\(url.lastPathComponent))")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
            ScrollView {
                VStack(alignment: .leading, spacing: 4) {
                    ForEach(Array(transcriber.savedSentences.enumerated()), id: \.offset) { _, sentence in
                        Text(sentence)
                    }
                }
                .frame(maxWidth: .infinity, alignment: .leading)
            }
            .frame(minHeight: 200)
            .background(Color.gray.opacity(0.05))
            .cornerRadius(6)


        }
        .padding(20)
        .frame(minWidth: 560, minHeight: 640)
        .onAppear {
            loadAvailableLocales()
            reconcileSelectedInputDevice()
        }
        .alert("尚未有逐字稿內容", isPresented: $showNoTranscriptAlert) {
            Button("好，我知道了", role: .cancel) { }
        } message: {
            Text("請先按下「開始聽抄」並播放/說話，系統辨識出第一句話後，才會建立逐字稿檔案。")
        }
    }

    // MARK: - 開始聽抄

    private func startTranscription() {
        let outputDir = FileManager.default
            .urls(for: .documentDirectory, in: .userDomainMask)
            .first!

        if audioSourceIsSystemAudio {
            // 系統聲音來源：不切換任何系統輸出／輸入裝置，直接把使用者選的
            // 擷取來源交給 SpeechTranscriber，由它內部的 SystemAudioCapture
            // 透過 ScreenCaptureKit 直接擷取。
            let source = selectedSystemAudioSource
            if bilingualMode {
                transcriber.startBilingual(localeA: localeA, localeB: localeB, outputDirectory: outputDir, audioSource: .systemAudio(source))
            } else {
                transcriber.start(localeIdentifier: selectedLocale, outputDirectory: outputDir, audioSource: .systemAudio(source))
            }
            return
        }

        // 麥克風來源：不管使用者有沒有手動碰過選單，開始前一律重新對齊一次，
        // 確保 selectedInputDeviceID 反映「目前真的存在」的裝置，避免用到
        // 啟動當下還沒枚舉完成、或裝置已經拔掉的過期資料。
        reconcileSelectedInputDevice()

        // AudioDeviceID 0（kAudioObjectUnknown）不是有效裝置，
        // 絕對不能傳給 CoreAudio，否則會被 HAL 直接回絕。
        let deviceID = [selectedInputDeviceID, deviceManager.currentInputDeviceID, deviceManager.inputDevices.excludingInternalAggregates(by: \.name).first?.id]
            .compactMap { $0 }
            .first { $0 != 0 }

        Task {
            // 開始聽抄前，把系統預設輸入裝置自動切成使用者在選單上選的那個麥克風，
            // 使用者不需要自己再跑一趟「系統設定 > 聲音」。只有麥克風來源會執行
            // 這一段；系統聲音來源完全不會呼叫這裡的任何裝置切換邏輯。
            let allNames = deviceManager.inputDevices.map(\.name)
            let pickedName = deviceManager.inputDevices.first(where: { $0.id == deviceID })?.name ?? "nil"
            print("[Audio] 開始聽抄：deviceID=\(deviceID.map { String($0) } ?? "nil")，name=\(pickedName)，系統列出的輸入裝置=\(allNames)")

            var inputSwitchConfirmed = true
            if let deviceID {
                let inputOK = deviceManager.setDefaultInputDevice(deviceID)
                print("[Audio] 切換輸入裝置 → \(pickedName)：\(inputOK ? "成功" : "失敗")")
                if inputOK {
                    inputSwitchConfirmed = await deviceManager.waitForDefaultInputDeviceChange(expected: deviceID)
                    print("[Audio] 確認系統輸入裝置已真正切換完成：\(inputSwitchConfirmed)")
                }
            } else {
                print("[Audio] 沒有可用的輸入裝置 ID，略過切換輸入")
            }

            // 上面 waitForDefaultInputDeviceChange 已經確認系統「預設輸入裝置」
            // 真的切換完成了；但 HAL 發出通知的當下，硬體格式（sample rate 等）
            // 有時還要再幾十毫秒才完全穩定，所以保留一段很短的緩衝時間。
            // 如果上面等到逾時都沒收到確認通知，就用比較保守的緩衝時間，
            // 讓後面 SpeechTranscriber 啟動前系統有更多機會把格式穩定下來。
            let settleNanoseconds: UInt64 = inputSwitchConfirmed ? 80_000_000 : 300_000_000
            try? await Task.sleep(nanoseconds: settleNanoseconds)

            if bilingualMode {
                transcriber.startBilingual(localeA: localeA, localeB: localeB, outputDirectory: outputDir, audioSource: .microphone(deviceID: deviceID))
            } else {
                transcriber.start(localeIdentifier: selectedLocale, outputDirectory: outputDir, audioSource: .microphone(deviceID: deviceID))
            }
        }
    }

    // MARK: - 動態載入這台 Mac 目前支援語音辨識的所有語系

    private func loadAvailableLocales() {
        let supported = SFSpeechRecognizer.supportedLocales()
            .map { $0.identifier }
            .sorted { lhs, rhs in
                displayName(for: lhs).localizedStandardCompare(displayName(for: rhs)) == .orderedAscending
            }

        availableLocales = supported

        // 正規化比對（zh-TW / zh_TW 視為相同，大小寫也忽略），避免因格式差異比對失敗
        func normalize(_ s: String) -> String {
            s.replacingOccurrences(of: "_", with: "-").lowercased()
        }

        func firstMatch(_ target: String) -> String? {
            supported.first { normalize($0) == normalize(target) }
        }

        // 單語模式：如果上次存的選擇這台系統目前仍支援，就沿用；否則才套用預設邏輯
        let preferredCandidates = ["zh-TW", "zh-Hant-TW", "zh-Hant_TW", "zh_TW"]

        if let keep = firstMatch(selectedLocale) {
            selectedLocale = keep // 統一成系統實際回傳的字串格式，避免底線/大小寫差異
        } else if let match = preferredCandidates.compactMap({ firstMatch($0) }).first {
            selectedLocale = match
        } else if let match = firstMatch(Locale.current.identifier) {
            selectedLocale = match
        } else if let first = supported.first {
            selectedLocale = first
        }

        // 雙語模式：同樣優先沿用上次存下來的選擇
        if let keepA = firstMatch(localeA) {
            localeA = keepA
        } else if let matchA = firstMatch("zh-TW") ?? preferredCandidates.compactMap({ firstMatch($0) }).first {
            localeA = matchA
        } else if let first = supported.first {
            localeA = first
        }

        if let keepB = firstMatch(localeB) {
            localeB = keepB
        } else if let matchB = firstMatch("en-US") {
            localeB = matchB
        } else if let second = supported.first(where: { $0 != localeA }) {
            localeB = second
        }
    }

    // 把語系代碼（如 "zh-TW"）轉成人類看得懂的名稱（如 "中文（台灣）"）
    private func displayName(for code: String) -> String {
        Locale.current.localizedString(forIdentifier: code) ?? code
    }

    // MARK: - 系統聲音來源（v3.0 新增）

    /// 「螢幕錄製」授權目前是否已取得，用來決定畫面顯示綠字還是紅字提示
    private var isScreenRecordingAuthorized: Bool {
        SystemAudioCapture.hasScreenRecordingPermission()
    }

    /// 目前的擷取來源；v3.0 只支援「整個系統」。
    private var selectedSystemAudioSource: SystemAudioCaptureSource {
        .entireSystem
    }

    // MARK: - 麥克風輸入裝置

    /// 讓 `selectedInputDeviceID` 對齊目前真的存在的裝置清單：
    /// - 優先沿用使用者上次選過的裝置名稱（`selectedInputDeviceName`）
    /// - 找不到（例如裝置被拔掉、或第一次使用）就 fallback 用系統目前的預設輸入裝置
    /// - 兩者都找不到，就選清單第一個裝置
    /// 會在 App 啟動時、以及使用者按「重新整理」之後呼叫
    private func reconcileSelectedInputDevice() {
        if let match = deviceManager.inputDevices.excludingInternalAggregates(by: \.name).first(where: { $0.name == selectedInputDeviceName }) {
            selectedInputDeviceID = match.id
        } else if let currentID = deviceManager.currentInputDeviceID,
                  deviceManager.inputDevices.excludingInternalAggregates(by: \.name).contains(where: { $0.id == currentID }) {
            selectedInputDeviceID = currentID
        } else if let first = deviceManager.inputDevices.excludingInternalAggregates(by: \.name).first {
            selectedInputDeviceID = first.id
        }

        if let id = selectedInputDeviceID,
           let name = deviceManager.inputDevices.excludingInternalAggregates(by: \.name).first(where: { $0.id == id })?.name {
            selectedInputDeviceName = name
        }
    }
}

#Preview {
    ContentView()
}

using System.Windows;

namespace YTGrabWin.Features.Common;

/// <summary>
/// 對應「讀取資訊時顯示運行中訊息框，完成後自動消失」：
/// 無按鈕、非模態（用 Show 而非 ShowDialog，才不會擋住非同步作業的執行緒），
/// 由呼叫端在 try/finally 中自行控制顯示與關閉時機。
/// </summary>
public partial class LoadingWindow : Window
{
    public LoadingWindow(string message = "讀取中，請稍候...")
    {
        InitializeComponent();
        MessageText.Text = message;
    }
}

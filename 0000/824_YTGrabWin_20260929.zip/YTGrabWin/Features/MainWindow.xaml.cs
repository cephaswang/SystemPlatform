using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using YTGrabWin.Core;
using YTGrabWin.Features.Playlist;
using YTGrabWin.Features.Common;
using YTGrabWin.Features.Settings;
using YTGrabWin.Features.VideoInfo;

namespace YTGrabWin.Features;

/// <summary>
/// 對應企劃案四：主畫面邏輯。負責網址分流（單支/播放列表）、串接各子畫面。
/// </summary>
public partial class MainWindow : Window
{
    private readonly App.AppState _state = App.App.State;

    public MainWindow()
    {
        InitializeComponent();
        DownloadFolderTextBox.Text = _state.Settings.Current.DownloadFolder;
        DownloadQueue.Bind(_state.DownloadQueue);
        VideoInfo.DownloadRequested += VideoInfo_DownloadRequested;
    }

    /// <summary>
    /// 對應二、2.1：網址分流——單支影片用 --no-playlist -J，播放列表用 --flat-playlist --yes-playlist -J。
    /// 此處以「是否含播放列表參數/回應是否有 entries」判斷，實際規則沿用 macOS 版邏輯（見三、規格）。
    /// </summary>
    private async void UrlInput_UrlSubmitted(object? sender, string url)
    {
        // 對應「讀取資訊時顯示運行中訊息，完成後自動消失」：顯示無按鈕提示視窗，
        // 並把主視窗鎖住（IsEnabled = false），避免使用者在讀取期間重複送出
        // 同一網址（先前造成同一網址被連續讀取多次的操作情境，也一併避免）。
        var loading = new LoadingWindow("讀取影片資訊中，請稍候...") { Owner = this };
        IsEnabled = false;
        loading.Show();

        try
        {
            var playlistInfo = await _state.YtDlpClient.FetchPlaylistInfoAsync(url);
            if (playlistInfo is { Entries.Count: > 1 })
            {
                VideoInfo.Visibility = Visibility.Collapsed;
                Playlist.Visibility = Visibility.Visible;
                Playlist.LoadPlaylist(playlistInfo);
                return;
            }

            var videoInfo = await _state.YtDlpClient.FetchVideoInfoAsync(url);
            if (videoInfo is not null)
            {
                Playlist.Visibility = Visibility.Collapsed;
                VideoInfo.Visibility = Visibility.Visible;
                VideoInfo.LoadVideo(videoInfo, url);
            }
            else
            {
                MessageBox.Show("無法讀取此網址的影片資訊，請確認網址是否正確。", "錯誤",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        finally
        {
            // 對應「完成後訊息框消失」：不論成功、失敗或例外都要關閉提示視窗、恢復主視窗可互動。
            loading.Close();
            IsEnabled = true;
        }
    }

    /// <summary>單支影片：使用者在畫質/音訊清單選好格式後，建立下載任務並開始下載。</summary>
    private void VideoInfo_DownloadRequested(object? sender, VideoDownloadRequest request)
    {
        var outputTemplate = System.IO.Path.Combine(
            _state.Settings.Current.DownloadFolder, "%(title)s.%(ext)s");

        var task = new DownloadTask
        {
            Id = Guid.NewGuid().ToString(),
            Url = request.Url,
            Title = request.Title,
            FormatSelector = request.FormatSelector
        };
        _state.DownloadQueue.Enqueue(task);
        _ = _state.DownloadQueue.StartAsync(task, outputTemplate);
    }

    /// <summary>對應三、規格：播放列表勾選批次下載。</summary>
    private void Playlist_BatchDownloadRequested(object? sender, IReadOnlyList<PlaylistEntry> selectedEntries)
    {
        var outputTemplate = System.IO.Path.Combine(
            _state.Settings.Current.DownloadFolder, "%(playlist_index)s - %(title)s.%(ext)s");

        foreach (var entry in selectedEntries)
        {
            var task = new DownloadTask
            {
                Id = Guid.NewGuid().ToString(),
                Url = entry.Url,
                Title = entry.Title,
                FormatSelector = $"bv*[height<={_state.Settings.Current.DefaultPlaylistMaxQuality.TrimEnd('p')}]+ba/b"
            };
            _state.DownloadQueue.Enqueue(task);
            _ = _state.DownloadQueue.StartAsync(task, outputTemplate);
        }
    }

    /// <summary>點擊「下載資料夾：」文字按鈕，直接開啟目前設定的下載資料夾。</summary>
    private void OpenDownloadFolderButton_Click(object sender, RoutedEventArgs e)
    {
        ExplorerActions.OpenFolder(_state.Settings.Current.DownloadFolder);
    }

    private void SettingsButton_Click(object sender, RoutedEventArgs e)
    {
        var settingsWindow = new SettingsView { Owner = this };
        settingsWindow.ShowDialog();
        DownloadFolderTextBox.Text = _state.Settings.Current.DownloadFolder;
    }

    /// <summary>對應三、平台差異表：拖放網址，取代 macOS 拖放到 App 圖示。</summary>
    private void MainWindow_Drop(object sender, DragEventArgs e)
    {
        if (e.Data.GetDataPresent(DataFormats.Text))
        {
            var url = ((string)e.Data.GetData(DataFormats.Text)).Trim();
            UrlInput.SetUrl(url);
            UrlInput_UrlSubmitted(this, url);
        }
    }
}

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using YTGrabWin.Core;

namespace YTGrabWin.Features.Playlist;

/// <summary>可勾選的播放列表項目包裝類別，供 ListView 資料繫結使用。</summary>
public sealed class SelectablePlaylistEntry
{
    public required PlaylistEntry Entry { get; init; }
    public bool IsSelected { get; set; } = true;
}

/// <summary>
/// 對應企劃案四：播放列表模式，勾選清單＋批次動作列。
/// 對應第七章待確認事項：播放列表批次下載是否支援字幕、檔名是否加序號前綴
/// （此處先只處理畫質批次下載，字幕批次與序號前綴留待定案後於 MainWindow 的輸出樣板擴充）。
/// </summary>
public partial class PlaylistView : UserControl
{
    private readonly ObservableCollection<SelectablePlaylistEntry> _entries = new();
    private PlaylistInfo? _playlistInfo;

    /// <summary>使用者按下「批次下載選取項目」，回傳勾選的項目清單。</summary>
    public event EventHandler<IReadOnlyList<PlaylistEntry>>? BatchDownloadRequested;

    public PlaylistView()
    {
        InitializeComponent();
        EntriesListView.ItemsSource = _entries;
    }

    public void LoadPlaylist(PlaylistInfo playlistInfo)
    {
        _playlistInfo = playlistInfo;
        PlaylistTitleText.Text = $"{playlistInfo.Title}（共 {playlistInfo.Entries.Count} 支影片）";
        _entries.Clear();
        foreach (var entry in playlistInfo.Entries)
        {
            _entries.Add(new SelectablePlaylistEntry { Entry = entry, IsSelected = true });
        }
    }

    /// <summary>清空目前顯示的播放列表，回到尚未讀取任何清單的狀態。</summary>
    private void ClearButton_Click(object sender, RoutedEventArgs e)
    {
        _playlistInfo = null;
        _entries.Clear();
        PlaylistTitleText.Text = string.Empty;
    }

    /// <summary>對應一、1.1「播放列表勾選批次下載或純文字匯出」：把目前清單存成 .txt。</summary>
    private void ExportButton_Click(object sender, RoutedEventArgs e)
    {
        if (_playlistInfo is null || _entries.Count == 0)
        {
            MessageBox.Show("目前沒有可轉出的播放列表。", "提醒", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        var sb = new StringBuilder();
        sb.AppendLine(_playlistInfo.Title);
        sb.AppendLine($"共 {_entries.Count} 支影片");
        sb.AppendLine();
        for (var i = 0; i < _entries.Count; i++)
        {
            var entry = _entries[i].Entry;
            sb.AppendLine($"{i + 1}. {entry.Title}");
            sb.AppendLine(entry.Url);
            sb.AppendLine();
        }

        var downloadFolder = App.App.State.Settings.Current.DownloadFolder;
        Directory.CreateDirectory(downloadFolder);

        var safeTitle = SanitizeFileName(_playlistInfo.Title);
        var filePath = Path.Combine(downloadFolder, $"{safeTitle}_播放清單.txt");

        try
        {
            File.WriteAllText(filePath, sb.ToString(), Encoding.UTF8);
            ExplorerActions.ShowInExplorer(filePath);
        }
        catch (Exception ex)
        {
            MessageBox.Show($"轉出失敗：{ex.Message}", "錯誤", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    /// <summary>對應三、平台差異表：檔名去除 Windows 不允許的字元，避免轉出失敗。</summary>
    private static string SanitizeFileName(string name)
    {
        foreach (var invalidChar in Path.GetInvalidFileNameChars())
            name = name.Replace(invalidChar, '_');
        return name.Trim();
    }

    /// <summary>直接開啟目前設定的下載資料夾。</summary>
    private void OpenFolderButton_Click(object sender, RoutedEventArgs e)
    {
        ExplorerActions.OpenFolder(App.App.State.Settings.Current.DownloadFolder);
    }

    private void SelectAllButton_Click(object sender, RoutedEventArgs e)
    {
        foreach (var item in _entries) item.IsSelected = true;
        EntriesListView.Items.Refresh();
    }

    private void DeselectAllButton_Click(object sender, RoutedEventArgs e)
    {
        foreach (var item in _entries) item.IsSelected = false;
        EntriesListView.Items.Refresh();
    }

    private void BatchDownloadButton_Click(object sender, RoutedEventArgs e)
    {
        var selected = _entries.Where(x => x.IsSelected).Select(x => x.Entry).ToList();
        if (selected.Count == 0)
        {
            MessageBox.Show("請至少勾選一支影片。", "提醒", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }
        BatchDownloadRequested?.Invoke(this, selected);
    }
}

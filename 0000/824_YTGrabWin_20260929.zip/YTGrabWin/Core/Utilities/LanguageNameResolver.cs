using System;
using System.Collections.Generic;
using System.Globalization;

namespace YTGrabWin.Core;

/// <summary>
/// 對應企劃案二、2.2：語言名稱轉換。
/// 改進：
/// 1. 呼叫 CultureInfo.DisplayName 時暫時把 UI culture 設為 zh-TW，不依賴 Windows 顯示語言。
/// 2. 常見的 YouTube 代碼（zh-Hant、zh-Hans…）直接給固定名稱。
/// 3. 舊式代碼（iw、in、ji、jw）先轉成新代碼再查。
/// 4. `-orig` 後綴另外處理，標示為「原文」。
/// </summary>
public sealed class LanguageNameResolver
{
    private const string OriginalSuffix = "-orig";

    private static readonly CultureInfo TraditionalChinese = CultureInfo.GetCultureInfo("zh-TW");

    private static readonly Dictionary<string, string> Overrides = new(StringComparer.OrdinalIgnoreCase)
    {
        ["zh"] = "中文",
        ["zh-Hant"] = "中文（繁體）",
        ["zh-Hans"] = "中文（簡體）",
        ["zh-TW"] = "中文（台灣）",
        ["zh-CN"] = "中文（中國）",
        ["zh-HK"] = "中文（香港）",
    };

    private static readonly Dictionary<string, string> LegacyCodes = new(StringComparer.OrdinalIgnoreCase)
    {
        ["iw"] = "he",
        ["in"] = "id",
        ["ji"] = "yi",
        ["jw"] = "jv",
    };

    public string Resolve(string languageCode)
    {
        var isOriginal = languageCode.EndsWith(OriginalSuffix, StringComparison.OrdinalIgnoreCase);
        var baseCode = isOriginal
            ? languageCode[..^OriginalSuffix.Length]
            : languageCode;

        string displayName;
        if (Overrides.TryGetValue(baseCode, out var fixedName))
        {
            displayName = fixedName;
        }
        else
        {
            var lookupCode = LegacyCodes.TryGetValue(baseCode, out var modern) ? modern : baseCode;
            displayName = LookupDisplayName(lookupCode) ?? baseCode;
        }

        return isOriginal ? $"{displayName}（原文）" : displayName;
    }

    private static string? LookupDisplayName(string code)
    {
        var previous = CultureInfo.CurrentUICulture;
        try
        {
            CultureInfo.CurrentUICulture = TraditionalChinese;
            var name = CultureInfo.GetCultureInfo(code).DisplayName;
            return string.IsNullOrWhiteSpace(name) ? null : name;
        }
        catch (CultureNotFoundException)
        {
            // 對應五、風險：CultureInfo 資料可能不含冷門語言代碼，查不到時由呼叫端原樣顯示代碼。
            return null;
        }
        finally
        {
            CultureInfo.CurrentUICulture = previous;
        }
    }
}

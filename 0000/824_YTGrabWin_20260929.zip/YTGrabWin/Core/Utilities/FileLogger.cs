using System;
using System.IO;
using System.Text;

namespace YTGrabWin.Core;

/// <summary>
/// 對應企劃案 5.2：需要可稽核的日誌，協助排查「下載卡住/失敗但介面看不出原因」的問題。
/// 寫入位置：%LocalAppData%\YTGrabWin\logs\yyyy-MM-dd.log，每天一個檔案。
/// 用 lock 保護寫入，避免多個下載同時寫檔互相覆蓋或漏行。
/// </summary>
public static class FileLogger
{
    private static readonly object Lock = new();

    private static string LogDirectory => Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "YTGrabWin", "logs");

    private static string LogFilePath => Path.Combine(
        LogDirectory, $"{DateTime.Now:yyyy-MM-dd}.log");

    public static void Info(string category, string message) => Write("INFO", category, message);
    public static void Warn(string category, string message) => Write("WARN", category, message);
    public static void Error(string category, string message) => Write("ERROR", category, message);

    public static void Error(string category, string message, Exception ex) =>
        Write("ERROR", category, $"{message}{Environment.NewLine}{ex}");

    private static void Write(string level, string category, string message)
    {
        var line = $"{DateTime.Now:HH:mm:ss.fff} [{level}] [{category}] {message}";

        // 同步輸出到偵錯視窗，方便在 Visual Studio 內即時查看。
        System.Diagnostics.Debug.WriteLine(line);

        try
        {
            lock (Lock)
            {
               // Directory.CreateDirectory(LogDirectory);
               // File.AppendAllText(LogFilePath, line + Environment.NewLine, Encoding.UTF8);
            }
        }
        catch
        {
            // 日誌本身寫入失敗不應影響主功能（例如磁碟空間不足、權限問題）。
        }
    }

    /// <summary>方便使用者從「說明」選單直接開啟今天的日誌檔所在資料夾。</summary>
    public static void OpenLogFolder()
    {
        Directory.CreateDirectory(LogDirectory);
        System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo
        {
            FileName = LogDirectory,
            UseShellExecute = true
        });
    }
}

using System;
using System.IO;
using Microsoft.Win32;

namespace YTGrabWin.Core;

/// <summary>
/// 找出 firefox.exe 的位置。
/// 順序：使用者手動指定 → 登錄 App Paths → 常見安裝資料夾。找不到回傳 null。
/// 每個來源的偵測結果都會寫入日誌，方便排查「為什麼找到／找不到」。
/// </summary>
public static class FirefoxLocator
{
    private const string Tag = "FirefoxLocator";

    private static readonly string[] AppPathKeys =
    {
        @"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\firefox.exe",
        @"HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\App Paths\firefox.exe",
        @"HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\firefox.exe",
    };

    public static string? Find(string? userSpecifiedPath = null)
    {
        if (!string.IsNullOrWhiteSpace(userSpecifiedPath))
        {
            var exists = File.Exists(userSpecifiedPath);
            FileLogger.Debug(Tag, $"使用者指定: {userSpecifiedPath} -> {(exists ? "存在" : "不存在")}");
            if (exists) return userSpecifiedPath;
        }
        else
        {
            FileLogger.Debug(Tag, "使用者未指定 Firefox 路徑");
        }

        foreach (var key in AppPathKeys)
        {
            try
            {
                if (Registry.GetValue(key, null, null) is string value)
                {
                    var path = value.Trim().Trim('"');
                    var exists = File.Exists(path);
                    FileLogger.Debug(Tag, $"登錄 {key} = {path} -> {(exists ? "存在" : "不存在")}");
                    if (exists) return path;
                }
                else
                {
                    FileLogger.Debug(Tag, $"登錄 {key} -> 無值");
                }
            }
            catch (Exception ex)
            {
                // 登錄讀取失敗就試下一個來源。
                FileLogger.Debug(Tag, $"登錄 {key} 讀取失敗: {ex.Message}");
            }
        }

        var candidates = new[]
        {
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "Mozilla Firefox", "firefox.exe"),
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), "Mozilla Firefox", "firefox.exe"),
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Mozilla Firefox", "firefox.exe"),
        };

        foreach (var candidate in candidates)
        {
            var exists = File.Exists(candidate);
            FileLogger.Debug(Tag, $"常見位置 {candidate} -> {(exists ? "存在" : "不存在")}");
            if (exists) return candidate;
        }

        FileLogger.Warn(Tag, "所有來源都找不到 firefox.exe");
        return null;
    }
}

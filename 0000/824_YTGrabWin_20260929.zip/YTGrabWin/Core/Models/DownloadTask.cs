using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows;

namespace YTGrabWin.Core;

/// <summary>
/// 對應三、核心功能規格「下載佇列暫停/續傳/重試」的狀態機狀態。
/// </summary>
public enum DownloadTaskStatus
{
    Pending,
    Downloading,
    Paused,
    Completed,
    Failed,
    Canceled
}

/// <summary>
/// 對應企劃案 2.3：Core/Models/DownloadTask.cs。
/// 佇列中的單一下載任務，供 DownloadQueueManager 管理。
///
/// 對應企劃案 5.2：實作 INotifyPropertyChanged，讓 DownloadQueueView 的
/// ProgressBar／狀態文字（{Binding ProgressPercent}、{Binding Status}）能即時反映變化，
/// 而不是要等整個 ListView 項目重新產生才會更新。
/// 由於進度是從讀取 yt-dlp 輸出的背景執行緒回報（見 ProcessRunner／YTDLPClient），
/// PropertyChanged 一律透過 UI Dispatcher 送出，避免跨執行緒更新 WPF 繫結的例外或無反應。
/// </summary>
public sealed class DownloadTask : INotifyPropertyChanged
{
    public event PropertyChangedEventHandler? PropertyChanged;

    private void RaisePropertyChanged(string propertyName)
    {
        var dispatcher = Application.Current?.Dispatcher;
        if (dispatcher is null || dispatcher.CheckAccess())
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
        else
        {
            // 對應企劃案 5.2：進度回報來自背景執行緒，一律轉回 UI 執行緒觸發通知，
            // 避免 WPF 資料繫結因跨執行緒存取而更新失敗或丟出例外。
            dispatcher.BeginInvoke(() => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName)));
        }
    }

    private bool SetField<T>(ref T field, T value, [CallerMemberName] string? propertyName = null)
    {
        if (Equals(field, value)) return false;
        field = value;
        RaisePropertyChanged(propertyName!);
        return true;
    }

    public required string Id { get; init; } = Guid.NewGuid().ToString();
    public required string Url { get; init; }

    private string _title = string.Empty;
    public required string Title
    {
        get => _title;
        set => SetField(ref _title, value);
    }

    public required string FormatSelector { get; init; }
    public string? SubtitleLanguageCode { get; init; }

    private DownloadTaskStatus _status = DownloadTaskStatus.Pending;
    public DownloadTaskStatus Status
    {
        get => _status;
        set => SetField(ref _status, value);
    }

    private double _progressPercent;
    public double ProgressPercent
    {
        get => _progressPercent;
        set => SetField(ref _progressPercent, value);
    }

    private string? _finalFilePath;
    public string? FinalFilePath
    {
        get => _finalFilePath;
        set => SetField(ref _finalFilePath, value);
    }

    private string? _errorMessage;
    public string? ErrorMessage
    {
        get => _errorMessage;
        set => SetField(ref _errorMessage, value);
    }

    private int _retryCount;
    public int RetryCount
    {
        get => _retryCount;
        set => SetField(ref _retryCount, value);
    }

    /// <summary>對應第七章待確認事項：播放列表批次下載檔名是否加序號前綴。</summary>
    public int? PlaylistIndex { get; init; }
}

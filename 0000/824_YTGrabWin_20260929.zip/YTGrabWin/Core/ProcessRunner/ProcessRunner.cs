using System;
using System.Diagnostics;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace YTGrabWin.Core;

/// <summary>
/// 對應企劃案 2.1：`System.Diagnostics.Process` + 非同步讀取 StandardOutput/StandardError，
/// 對應 macOS 版的 `Foundation.Process` + `Pipe`。
/// 對應企劃案 5.2：`Process.OutputDataReceived` 事件模式同樣有「行程結束前緩衝區未讀完」的已知陷阱，
/// 因此改用雙背景執行緒以 ReadLineAsync 讀到 EOF 的做法，而非只訂閱 OutputDataReceived 事件，
/// 確保收得到最後一段輸出。
/// </summary>
public sealed class ProcessRunner
{
    public event EventHandler<string>? StandardOutputLineReceived;
    public event EventHandler<string>? StandardErrorLineReceived;

    /// <summary>
    /// 啟動子行程並以雙背景工作讀取 stdout/stderr 直到 EOF，回傳結束時的 ExitCode。
    /// </summary>
    public async Task<int> RunAsync(
        string fileName,
        string arguments,
        CancellationToken cancellationToken = default)
    {
        // 對應企劃案 5.2：記錄實際執行的完整指令列，方便使用者回報問題時直接複製到 cmd 重現。
        FileLogger.Info("ProcessRunner", $"啟動: \"{fileName}\" {arguments}");

        var startInfo = new ProcessStartInfo
        {
            FileName = fileName,
            Arguments = arguments,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            UseShellExecute = false,
            CreateNoWindow = true,
            StandardOutputEncoding = Encoding.UTF8,
            StandardErrorEncoding = Encoding.UTF8
        };

        using var process = Process.Start(startInfo)
            ?? throw new InvalidOperationException($"無法啟動行程：{fileName}");

        var stdoutTask = PumpLinesAsync(process.StandardOutput, StandardOutputLineReceived, cancellationToken);
        var stderrTask = PumpLinesAsync(process.StandardError, StandardErrorLineReceived, cancellationToken);

        using (cancellationToken.Register(() => TryKill(process)))
        {
            await Task.WhenAll(stdoutTask, stderrTask);
            await process.WaitForExitAsync(cancellationToken);
        }

        // 對應企劃案 5.2：ExitCode 不為 0 時記錄下來——這是「下載沒反應」最常見的線索，
        // 例如 yt-dlp 回傳非 0 但 stderr 訊息被截斷/沒顯示在介面上時，日誌仍留有完整紀錄。
        if (process.ExitCode != 0)
            FileLogger.Warn("ProcessRunner", $"結束，ExitCode={process.ExitCode}: \"{fileName}\" {arguments}");
        else
            FileLogger.Info("ProcessRunner", $"結束，ExitCode=0: \"{fileName}\"");

        return process.ExitCode;
    }

    private static async Task PumpLinesAsync(
        System.IO.StreamReader reader,
        EventHandler<string>? handler,
        CancellationToken cancellationToken)
    {
        // 讀到 EOF（ReadLineAsync 回傳 null）為止，確保行程結束前緩衝區的最後一段輸出不會遺失
        // （對應企劃案 5.2「readabilityHandler/串流讀取遺失末段輸出」的已知陷阱）。
        while (!cancellationToken.IsCancellationRequested)
        {
            var line = await reader.ReadLineAsync();
            if (line is null) break;

            // 對應企劃案 5.2：逐行留存 yt-dlp 的原始輸出（含 stderr 的警告/錯誤），
            // 供之後比對「介面顯示的狀態」與「行程實際回報的內容」是否一致。
            FileLogger.Info("ProcessRunner.Output", line);

            handler?.Invoke(null, line);
        }
    }

    private static void TryKill(Process process)
    {
        try
        {
            if (!process.HasExited) process.Kill(entireProcessTree: true);
        }
        catch (Exception ex)
        {
            // 對應企劃案 5.2：暫停/取消狀態誤判，Kill 失敗時交由上層狀態機重新確認行程狀態。
            FileLogger.Warn("ProcessRunner", $"TryKill 失敗: {ex.Message}");
        }
    }
}

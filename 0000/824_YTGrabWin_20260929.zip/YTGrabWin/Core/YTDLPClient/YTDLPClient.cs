using System;
using System.IO;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace YTGrabWin.Core;

/// <summary>
/// 對應企劃案二、2.1：核心引擎包裝層。與 macOS 版共用邏輯：
/// - `-J` / `--dump-json` 結構化資料驅動，不解析文字輸出
/// - `--no-playlist` / `--flat-playlist --yes-playlist` 網址分流
/// - `--progress-template` 自訂分隔符進度
/// - `--write-subs` / `--write-auto-subs` 字幕
/// - `--print after_move:%(filepath)s` 回報最終路徑
/// 這些是 yt-dlp 本身的行為，與作業系統無關，Windows 版僅換底層的 ProcessRunner 實作（見同檔）。
/// </summary>
public sealed class YTDLPClient : IDisposable
{
    private static string YtDlpPath => Path.Combine(AppContext.BaseDirectory, "Resources", "yt-dlp.exe");

    private readonly ProcessRunner _processRunner = new();

    /// <summary>
    /// 對應企劃案 5.1：yt-dlp 版本更新/下限，需內建自動檢查機制；
    /// `--print` 等旗標需要對應版本支援。
    /// </summary>
    public async Task<string> CheckVersionAsync(CancellationToken cancellationToken = default)
    {
        var output = new StringBuilder();
        var runner = new ProcessRunner();
        runner.StandardOutputLineReceived += (_, line) => output.AppendLine(line);
        await runner.RunAsync(YtDlpPath, "--version", cancellationToken);
        return output.ToString().Trim();
    }

    /// <summary>
    /// 讀取單一網址資訊，對應一、1.1「貼上網址讀取資訊」。
    /// 依網址是單支影片或播放列表分流：單支用 `--no-playlist -J`，
    /// 播放列表用 `--flat-playlist --yes-playlist -J`（見二、2.1）。
    /// </summary>
    public async Task<VideoInfo?> FetchVideoInfoAsync(string url, CancellationToken cancellationToken = default)
    {
        FileLogger.Info("YTDLPClient", $"FetchVideoInfoAsync: {url}");
        var jsonOutput = new StringBuilder();
        var runner = new ProcessRunner();
        runner.StandardOutputLineReceived += (_, line) => jsonOutput.AppendLine(line);

        var arguments = $"--no-playlist -J \"{url}\"";
        await runner.RunAsync(YtDlpPath, arguments, cancellationToken);

        var json = jsonOutput.ToString();
        if (string.IsNullOrWhiteSpace(json))
        {
            // 對應企劃案 5.2：讀取資訊失敗時，最常見原因是 yt-dlp 回傳的錯誤只在 stderr
            // （ProcessRunner.Output 日誌會有），stdout 這裡卻是空的，所以特別標記出來。
            FileLogger.Warn("YTDLPClient", $"FetchVideoInfoAsync 沒有取得 JSON 輸出: {url}");
            return null;
        }

        try
        {
            return JsonSerializer.Deserialize<VideoInfo>(json, JsonOptions);
        }
        catch (Exception ex)
        {
            FileLogger.Error("YTDLPClient", $"FetchVideoInfoAsync JSON 解析失敗: {url}", ex);
            return null;
        }
    }

    /// <summary>
    /// 讀取播放列表資訊，對應一、1.1「播放列表勾選批次下載」。
    /// </summary>
    public async Task<PlaylistInfo?> FetchPlaylistInfoAsync(string url, CancellationToken cancellationToken = default)
    {
        var jsonOutput = new StringBuilder();
        var runner = new ProcessRunner();
        runner.StandardOutputLineReceived += (_, line) => jsonOutput.AppendLine(line);

        var arguments = $"--flat-playlist --yes-playlist -J \"{url}\"";
        await runner.RunAsync(YtDlpPath, arguments, cancellationToken);

        var json = jsonOutput.ToString();
        if (string.IsNullOrWhiteSpace(json)) return null;

        return JsonSerializer.Deserialize<PlaylistInfo>(json, JsonOptions);
    }

    /// <summary>
    /// 下載指定格式／字幕。使用 `--progress-template` 自訂分隔符進度，供 DownloadQueueManager 解析。
    /// `--print after_move:%(filepath)s` 回報最終路徑（含轉檔/合併後的檔名）。
    /// </summary>
    public async Task<int> DownloadAsync(
        string url,
        string formatSelector,
        string outputTemplate,
        Action<double>? onProgress,
        Action<string>? onFinalFilePath,
        CancellationToken cancellationToken = default)
    {
        FileLogger.Info("YTDLPClient", $"DownloadAsync 開始: url={url}, format={formatSelector}, output={outputTemplate}");

        // 分隔符自訂避免與檔名或其他輸出混淆，與 macOS 版做法相同。
        const string progressDelimiter = "@@YTGRAB_PROGRESS@@";
        const string pathDelimiter = "@@YTGRAB_FILEPATH@@";

        var arguments =
            $"-f \"{formatSelector}\" " +
            $"-o \"{outputTemplate}\" " +
            // --print 會隱含 --quiet，因此要明確加 --progress 與 --newline，進度才會逐行輸出。
            $"--progress --newline " +
            $"--progress-template \"{progressDelimiter}%(progress._percent_str)s\" " +
            // 注意：--print-to-file ... "-" 並不會輸出到 stdout，而是建立一個檔名為 "-" 的檔案，
            // 導致 FinalFilePath 永遠取不到、任務被誤判失敗。改用 --print 才會印到 stdout。
            $"--print after_move:\"{pathDelimiter}%(filepath)s\" " +
            $"\"{url}\"";

        var runner = new ProcessRunner();
        runner.StandardOutputLineReceived += (_, line) =>
        {
            if (line.StartsWith(progressDelimiter))
            {
                var percentText = line[progressDelimiter.Length..].TrimEnd('%').Trim();
                if (double.TryParse(percentText, out var percent))
                    onProgress?.Invoke(percent);
            }
            else if (line.StartsWith(pathDelimiter))
            {
                onFinalFilePath?.Invoke(line[pathDelimiter.Length..].Trim());
            }
        };

        var exitCode = await runner.RunAsync(YtDlpPath, arguments, cancellationToken);

        // 對應企劃案 5.2：DownloadQueueManager 是以「有沒有收到 FinalFilePath」判斷成功與否，
        // 而不是只看 ExitCode，這裡記錄兩者，方便比對「ExitCode=0 但沒收到路徑」這類不一致的情況。
        FileLogger.Info("YTDLPClient", $"DownloadAsync 結束: url={url}, ExitCode={exitCode}");

        return exitCode;
    }

    /// <summary>
    /// 只下載字幕（不下載影片）。
    /// - 手動字幕用 `--write-subs`，自動字幕（含 -orig、自動翻譯）用 `--write-auto-subs`。
    /// - `--sub-format "srt/vtt/best" --convert-subs srt`：優先取 srt，否則轉成 srt（轉檔需要 ffmpeg，
    ///   yt-dlp 會在自己所在資料夾 Resources 找到 ffmpeg.exe）。
    /// - 檔名為 `影片標題.語言代碼.srt`，呼叫端以語言代碼比對找出產生的檔案。
    /// </summary>
    public async Task<int> DownloadSubtitleAsync(
        string url,
        string languageCode,
        bool isAutoGenerated,
        string outputTemplate,
        CancellationToken cancellationToken = default)
    {
        FileLogger.Info("YTDLPClient", $"DownloadSubtitleAsync 開始: url={url}, lang={languageCode}, auto={isAutoGenerated}");

        var arguments =
            "--no-playlist --skip-download --windows-filenames " +
            (isAutoGenerated ? "--write-auto-subs " : "--write-subs ") +
            $"--sub-langs \"{languageCode}\" " +
            "--sub-format \"srt/vtt/best\" --convert-subs srt " +
            $"-o \"{outputTemplate}\" " +
            $"\"{url}\"";

        var runner = new ProcessRunner();
        runner.StandardOutputLineReceived += (_, line) => FileLogger.Info("YTDLPClient", $"[subs] {line}");

        var exitCode = await runner.RunAsync(YtDlpPath, arguments, cancellationToken);
        FileLogger.Info("YTDLPClient", $"DownloadSubtitleAsync 結束: lang={languageCode}, ExitCode={exitCode}");
        return exitCode;
    }

    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNameCaseInsensitive = true
    };

    public void Dispose()
    {
        // 保留擴充點：若未來持有長生命週期的行程或連線，於此釋放。
    }
}

using System;
using System.IO;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using Microsoft.Win32;

namespace YTGrabWin.Core;

/// <summary>Native host 註冊結果。Ok=false 代表進階下載不可用；Warning 為仍可運作但需提醒的事項。</summary>
public sealed record NativeHostInstallResult(bool Ok, string? Error, string? Warning);

/// <summary>
/// 取代 macOS 的 install.sh：每次啟動外掛前自動執行，且可重複執行（冪等）。
/// 1. 把內嵌的 host.py / host.bat 寫到 %LOCALAPPDATA%\YTGrabWin\NativeHost（路徑固定，不受 bin\Debug 變動影響，也不依賴 csproj 複製檔案）
/// 2. 寫入 host_config.json（yt-dlp / ffmpeg 路徑、下載資料夾），host.py 由此讀取
/// 3. 產生 host manifest（path 指向 host.bat，allowed_extensions 取自外掛 manifest.json 的 gecko.id）
/// 4. 寫入登錄檔 HKCU\Software\Mozilla\NativeMessagingHosts\com.example.ytdlp（Windows 版 Firefox 只認登錄檔）
/// 5. 檢查是否有 Python 3（host.py 需要）
/// 此類別不會丟出例外，所有問題都以結果物件回報並寫入日誌。
/// </summary>
public static class NativeHostInstaller
{
    private const string Tag = "NativeHost";

    /// <summary>需與外掛 background.js 的 NATIVE_HOST_NAME 一致。</summary>
    public const string HostName = "com.example.ytdlp";

    /// <summary>讀不到外掛 manifest 時的預設值。</summary>
    private const string FallbackExtensionId = "video-analyzer@example.com";

    private const string RegistrySubKey = @"Software\Mozilla\NativeMessagingHosts\" + HostName;

    public static string InstallDir => Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "YTGrabWin", "NativeHost");

    public static NativeHostInstallResult EnsureInstalled(SettingsStore settings, string? extensionFolder)
    {
        try
        {
            // 1. 寫出 host 檔案（內容內嵌於 NativeHostFiles，不依賴外部檔案）
            Directory.CreateDirectory(InstallDir);
            WriteUtf8(Path.Combine(InstallDir, "host.py"), Normalize(NativeHostFiles.HostPy, "\n"));
            WriteUtf8(Path.Combine(InstallDir, "host.bat"), Normalize(NativeHostFiles.HostBat, "\r\n"));

            // 2. host_config.json
            var ytdlp = FindTool("yt-dlp.exe");
            var ffmpeg = FindTool("ffmpeg.exe");
            var config = new
            {
                ytdlpPath = ytdlp,
                ffmpegPath = ffmpeg,
                downloadDir = settings.Current.DownloadFolder
            };
            WriteUtf8(Path.Combine(InstallDir, "host_config.json"), Serialize(config));
            FileLogger.Info(Tag, $"yt-dlp={ytdlp ?? "(none)"}, ffmpeg={ffmpeg ?? "(none)"}, downloadDir={settings.Current.DownloadFolder}");

            // 3. manifest
            var hostBat = Path.Combine(InstallDir, "host.bat");
            var manifestPath = Path.Combine(InstallDir, HostName + ".json");
            var extensionId = ReadExtensionId(extensionFolder) ?? FallbackExtensionId;
            var manifest = new
            {
                name = HostName,
                description = "YTGrab Native Messaging Host（yt-dlp）",
                path = hostBat,
                type = "stdio",
                allowed_extensions = new[] { extensionId }
            };
            WriteUtf8(manifestPath, Serialize(manifest));
            FileLogger.Info(Tag, $"manifest 已寫入: {manifestPath} (allowed_extensions={extensionId})");

            // 4. 登錄檔（只有內容不同時才寫）
            using (var key = Registry.CurrentUser.CreateSubKey(RegistrySubKey))
            {
                var current = key.GetValue(null) as string;
                if (!string.Equals(current, manifestPath, StringComparison.OrdinalIgnoreCase))
                {
                    key.SetValue(null, manifestPath);
                    FileLogger.Info(Tag, $"登錄檔已寫入: HKCU\\{RegistrySubKey} = {manifestPath}");
                }
                else
                {
                    FileLogger.Debug(Tag, "登錄檔已是最新，略過");
                }
            }

            // 5. Python 檢查（不擋啟動，只提醒）
            string? warning = null;
            if (!HasPython())
            {
                warning = "找不到 Python 3（host.py 需要）。請安裝 Python 3 並勾選「Add python.exe to PATH」，然後重新啟動 YTGrab。";
                FileLogger.Warn(Tag, warning);
            }
            else if (ytdlp is null)
            {
                warning = "找不到 yt-dlp.exe（Resources\\yt-dlp.exe 或 PATH），進階下載將無法使用。";
                FileLogger.Warn(Tag, warning);
            }

            return new NativeHostInstallResult(true, null, warning);
        }
        catch (Exception ex)
        {
            FileLogger.Error(Tag, "註冊 Native host 失敗", ex);
            return new NativeHostInstallResult(false, $"註冊 Native host 失敗：{ex.Message}", null);
        }
    }

    private static string Normalize(string text, string newline) =>
        text.Replace("\r\n", "\n").Replace("\n", newline) + newline;

    private static NativeHostInstallResult Fail(string error)
    {
        FileLogger.Error(Tag, error);
        return new NativeHostInstallResult(false, error, null);
    }

    /// <summary>先找 App 內建（Resources\、App 根目錄），再找 PATH。</summary>
    private static string? FindTool(string exeName)
    {
        var candidates = new[]
        {
            Path.Combine(AppContext.BaseDirectory, "Resources", exeName),
            Path.Combine(AppContext.BaseDirectory, exeName),
        };
        foreach (var c in candidates)
            if (File.Exists(c)) return c;

        return FindOnPath(exeName);
    }

    private static string? FindOnPath(string exeName, bool skipWindowsApps = false)
    {
        var path = Environment.GetEnvironmentVariable("PATH") ?? string.Empty;
        foreach (var dir in path.Split(Path.PathSeparator, StringSplitOptions.RemoveEmptyEntries))
        {
            try
            {
                var d = dir.Trim().Trim('"');
                // Microsoft Store 的 python.exe 只是「導向商店」的空殼，不算已安裝。
                if (skipWindowsApps && d.Contains("WindowsApps", StringComparison.OrdinalIgnoreCase)) continue;
                var candidate = Path.Combine(d, exeName);
                if (File.Exists(candidate)) return candidate;
            }
            catch
            {
                // PATH 中有格式錯誤的項目時略過。
            }
        }
        return null;
    }

    private static bool HasPython() =>
        FindOnPath("py.exe") is not null || FindOnPath("python.exe", skipWindowsApps: true) is not null;

    /// <summary>從外掛 manifest.json 讀 gecko.id，確保與 allowed_extensions 一致。</summary>
    private static string? ReadExtensionId(string? extensionFolder)
    {
        if (string.IsNullOrWhiteSpace(extensionFolder)) return null;
        try
        {
            var file = Path.Combine(extensionFolder, "manifest.json");
            using var doc = JsonDocument.Parse(File.ReadAllText(file),
                new JsonDocumentOptions { CommentHandling = JsonCommentHandling.Skip, AllowTrailingCommas = true });
            if (doc.RootElement.TryGetProperty("browser_specific_settings", out var bss) &&
                bss.TryGetProperty("gecko", out var gecko) &&
                gecko.TryGetProperty("id", out var id))
                return id.GetString();
        }
        catch (Exception ex)
        {
            FileLogger.Warn(Tag, $"讀取外掛 ID 失敗，改用預設值: {ex.Message}");
        }
        return null;
    }

    private static string Serialize(object value) => JsonSerializer.Serialize(value, new JsonSerializerOptions
    {
        WriteIndented = true,
        DefaultIgnoreCondition = JsonIgnoreCondition.Never,
        Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping
    });

    /// <summary>一律寫成「無 BOM」的 UTF-8：Firefox 與 Python 讀到 BOM 都可能出問題。</summary>
    private static void WriteUtf8(string path, string content) =>
        File.WriteAllText(path, content, new UTF8Encoding(encoderShouldEmitUTF8Identifier: false));
}

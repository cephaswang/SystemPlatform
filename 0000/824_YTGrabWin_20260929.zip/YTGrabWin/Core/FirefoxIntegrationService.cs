using System;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace YTGrabWin.Core;

/// <summary>「Firefox 外掛」按鍵背後的狀態（外掛在本地端以 web-ext 執行，不經 AMO 簽署）。</summary>
public enum FirefoxIntegrationState
{
    /// <summary>找不到 Firefox。</summary>
    FirefoxNotFound,
    /// <summary>找不到 Node.js（npm.cmd）。</summary>
    NodeNotFound,
    /// <summary>找不到外掛資料夾（需含 manifest.json 與 package.json）。</summary>
    ExtensionFolderMissing,
    /// <summary>都齊了，可以啟動。</summary>
    ReadyToRun,
    /// <summary>web-ext 行程仍在執行（外掛已載入該 Firefox）。</summary>
    Running
}

/// <summary>
/// 以 `npm start`（web-ext run）在本地端啟動 Firefox 並載入外掛。
/// - 使用專用 Firefox Profile（%LOCALAPPDATA%\YTGrabWin\FirefoxProfile），登入狀態會保留。
/// - 外掛資料夾尚無 node_modules 時，先自動執行 `npm install`。
/// - web-ext 行程結束（關閉該 Firefox）即回到「可啟動」。
/// 狀態改變時觸發 <see cref="StatusChanged"/>（可能不在 UI 執行緒，UI 端請自行 Dispatcher）。
/// 除錯日誌：啟動前環境快照、完整命令列、web-ext 全部輸出、結束碼與存活時間，
/// 皆寫入 %LocalAppData%\YTGrabWin\logs\yyyy-MM-dd.log。
/// </summary>
public sealed class FirefoxIntegrationService
{
    private const string Tag = "FirefoxIntegration";
    private const string FirefoxDownloadUrl = "https://www.mozilla.org/firefox/new/";
    private const string NodeDownloadUrl = "https://nodejs.org/";
    private const string AboutDebuggingUrl = "about:debugging#/runtime/this-firefox";

    /// <summary>異常結束時，附在提示訊息裡的最後幾行輸出。</summary>
    private const int TailLineCount = 12;

    private readonly SettingsStore _settings;
    private Process? _runProcess;

    public event EventHandler? StatusChanged;

    /// <summary>web-ext 在啟動後很快就異常結束時觸發，參數為給使用者看的說明。</summary>
    public event EventHandler<string>? RunFailed;

    public string? FirefoxPath { get; private set; }
    public string? NpmPath { get; private set; }
    public string? ExtensionFolder { get; private set; }
    public FirefoxIntegrationState State { get; private set; } = FirefoxIntegrationState.FirefoxNotFound;

    /// <summary>Native host 註冊失敗或有需注意的事項（例如沒裝 Python）；沒有問題時為 null。UI 可顯示在按鍵提示。</summary>
    public string? NativeHostWarning { get; private set; }

    /// <summary>外掛資料夾還沒有 node_modules，首次啟動會先 npm install。</summary>
    public bool NeedsNpmInstall =>
        ExtensionFolder is not null && !Directory.Exists(Path.Combine(ExtensionFolder, "node_modules"));

    public bool IsRunning
    {
        get
        {
            try { return _runProcess is { HasExited: false }; }
            catch { return false; }
        }
    }

    public FirefoxIntegrationService(SettingsStore settings)
    {
        _settings = settings;
    }

    /// <summary>重新偵測 Firefox、npm、外掛資料夾，更新狀態並通知 UI。</summary>
    public FirefoxIntegrationState Refresh()
    {
        FirefoxPath = FirefoxLocator.Find(_settings.Current.FirefoxPath);
        NpmPath = FindNpm();
        ExtensionFolder = FindExtensionFolder();

        State = IsRunning ? FirefoxIntegrationState.Running
            : FirefoxPath is null ? FirefoxIntegrationState.FirefoxNotFound
            : NpmPath is null ? FirefoxIntegrationState.NodeNotFound
            : ExtensionFolder is null ? FirefoxIntegrationState.ExtensionFolderMissing
            : FirefoxIntegrationState.ReadyToRun;

        FileLogger.Info(Tag, $"Refresh: state={State}, firefox={FirefoxPath ?? "(none)"}, npm={NpmPath ?? "(none)"}, ext={ExtensionFolder ?? "(none)"}");
        StatusChanged?.Invoke(this, EventArgs.Empty);
        return State;
    }

    /// <summary>啟動 Firefox 並載入外掛。必要時先 npm install。回傳 (是否成功, 錯誤說明)。</summary>
    public async Task<(bool Ok, string? Error)> StartLocalExtensionAsync()
    {
        FileLogger.Info(Tag, "──── 使用者要求啟動外掛 ────");
        Refresh();

        // 取代 install.sh：自動註冊 Native Messaging host（冪等）。
        // 放在「已在執行中」判斷之前：Firefox 每次 connectNative 都會重讀登錄檔，
        // 所以外掛已開著時，再按一次按鍵也能補註冊，不必重開 Firefox。
        EnsureNativeHost();

        if (State == FirefoxIntegrationState.Running)
        {
            FileLogger.Info(Tag, "已在執行中，略過");
            return (true, null);
        }
        if (State != FirefoxIntegrationState.ReadyToRun)
        {
            FileLogger.Warn(Tag, $"無法啟動，目前狀態={State}");
            return (false, DescribeBlockingState());
        }

        try
        {
            LogEnvironmentSnapshot();

            if (NeedsNpmInstall)
            {
                FileLogger.Info(Tag, "首次啟動：執行 npm install");
                var exitCode = await RunNpmToCompletionAsync("install");
                if (exitCode != 0)
                    return (false, $"npm install 失敗（ExitCode={exitCode}）。\n詳細訊息請看記錄檔：{FileLogger.CurrentLogPath}");
            }

            StartWebExtRun();
            return (true, null);
        }
        catch (Exception ex)
        {
            FileLogger.Error(Tag, "啟動外掛失敗", ex);
            return (false, ex.Message);
        }
    }

    /// <summary>結束 web-ext 與它啟動的 Firefox。</summary>
    public void StopLocalExtension()
    {
        try
        {
            if (_runProcess is { HasExited: false } process)
            {
                FileLogger.Info(Tag, $"使用者要求停止外掛 (PID={process.Id})");
                process.Kill(entireProcessTree: true);
            }
            else
            {
                FileLogger.Info(Tag, "使用者要求停止外掛，但目前沒有執行中的 web-ext");
            }
        }
        catch (Exception ex)
        {
            FileLogger.Error(Tag, "停止外掛失敗", ex);
        }
        Refresh();
    }

    /// <summary>手動指定外掛資料夾（需含 manifest.json 與 package.json）。</summary>
    public bool TrySetExtensionFolder(string folder, out string? error)
    {
        if (!IsExtensionFolder(folder))
        {
            FileLogger.Warn(Tag, $"指定的外掛資料夾不合格: {folder}");
            error = "這個資料夾裡找不到 manifest.json 與 package.json，請選 video-analyzer-extension 資料夾。";
            return false;
        }

        FileLogger.Info(Tag, $"使用者指定外掛資料夾: {folder}");
        _settings.Current.FirefoxExtensionFolder = folder;
        SaveSettingsSafely();
        error = null;
        Refresh();
        return true;
    }

    /// <summary>開發用：以預設 Profile 開啟 about:debugging，可手動「載入暫時性附加元件」。</summary>
    public bool TryOpenAboutDebugging(out string? error)
    {
        if (FirefoxPath is null) { error = "找不到 Firefox。"; return false; }

        try
        {
            EnsureNativeHost();

            var psi = new ProcessStartInfo(FirefoxPath) { UseShellExecute = false };
            psi.ArgumentList.Add(AboutDebuggingUrl);
            Process.Start(psi);
            FileLogger.Info(Tag, $"已開啟 about:debugging: {FirefoxPath}");
            error = null;
            return true;
        }
        catch (Exception ex)
        {
            FileLogger.Error(Tag, "開啟 about:debugging 失敗", ex);
            error = ex.Message;
            return false;
        }
    }

    public bool TryOpenFirefoxDownloadPage(out string? error) => TryOpenUrl(FirefoxDownloadUrl, out error);

    public bool TryOpenNodeDownloadPage(out string? error) => TryOpenUrl(NodeDownloadUrl, out error);

    // ───────────── 內部 ─────────────

    /// <summary>確保 Native Messaging host 已註冊（產生 manifest、寫登錄檔、寫設定）。失敗不擋啟動，只記錄並保留 <see cref="NativeHostWarning"/>。</summary>
    private void EnsureNativeHost()
    {
        var result = NativeHostInstaller.EnsureInstalled(_settings, ExtensionFolder);
        NativeHostWarning = result.Ok ? result.Warning : result.Error;
        if (!result.Ok)
            FileLogger.Warn(Tag, $"Native host 註冊失敗（進階下載將無法使用，一般直連下載不受影響）: {result.Error}");
    }

    private void StartWebExtRun()
    {
        // 專用 Profile：登入狀態與 cookies 會保留在這個資料夾。
        var profileDir = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "YTGrabWin", "FirefoxProfile");
        Directory.CreateDirectory(profileDir);

        // `npm start -- <參數>`：「--」之後的參數會傳給 web-ext，且優先於 web-ext-config.cjs。
        var psi = CreateNpmStartInfo(
            "start", "--",
            "--firefox", FirefoxPath!,
            "--firefox-profile", profileDir,
            "--profile-create-if-missing",
            "--keep-profile-changes");

        LogCommandLine("web-ext", psi);

        // 保留最後幾行輸出（stdout + stderr），行程異常結束時直接顯示給使用者。
        var tail = new ConcurrentQueue<string>();
        void Remember(string line)
        {
            tail.Enqueue(line);
            while (tail.Count > TailLineCount && tail.TryDequeue(out _)) { }
        }

        var startedAt = DateTime.UtcNow;
        var process = new Process { StartInfo = psi, EnableRaisingEvents = true };
        process.OutputDataReceived += (_, e) =>
        {
            if (e.Data is null) return;
            FileLogger.Info("web-ext", e.Data);
            Remember(e.Data);
        };
        process.ErrorDataReceived += (_, e) =>
        {
            if (e.Data is null) return;
            FileLogger.Warn("web-ext", e.Data);
            Remember(e.Data);
        };
        process.Exited += (_, _) =>
        {
            // 無參數的 WaitForExit 會等非同步輸出讀完，避免最後幾行（通常就是錯誤原因）還沒寫進日誌就往下走。
            try { process.WaitForExit(); } catch { /* 行程已釋放 */ }

            int exitCode;
            try { exitCode = process.ExitCode; } catch { exitCode = -1; }
            var elapsed = DateTime.UtcNow - startedAt;
            FileLogger.Info(Tag, $"web-ext 已結束: ExitCode={exitCode}, 存活 {elapsed.TotalSeconds:F1} 秒");

            if (ReferenceEquals(_runProcess, process)) _runProcess = null;

            if (exitCode != 0 && elapsed < TimeSpan.FromMinutes(1))
            {
                var lastLines = string.Join(Environment.NewLine, tail.ToArray());
                FileLogger.Error(Tag, $"web-ext 啟動後很快就異常結束，最後輸出：{Environment.NewLine}{lastLines}");
                RunFailed?.Invoke(this,
                    $"外掛啟動後很快就結束了（ExitCode={exitCode}）。\n\n" +
                    (string.IsNullOrWhiteSpace(lastLines) ? "（web-ext 沒有輸出任何訊息）\n\n" : $"最後輸出：\n{lastLines}\n\n") +
                    $"完整記錄（標記為 web-ext 的幾行）：\n{FileLogger.CurrentLogPath}");
            }

            Refresh();
        };

        process.Start();
        process.BeginOutputReadLine();
        process.BeginErrorReadLine();
        _runProcess = process;
        FileLogger.Info(Tag, $"已啟動 web-ext: PID={process.Id}, profile={profileDir}");
        Refresh();
    }

    private async Task<int> RunNpmToCompletionAsync(params string[] args)
    {
        var psi = CreateNpmStartInfo(args);
        LogCommandLine("npm", psi);

        using var process = new Process { StartInfo = psi };
        process.OutputDataReceived += (_, e) => { if (e.Data is not null) FileLogger.Info("npm", e.Data); };
        process.ErrorDataReceived += (_, e) => { if (e.Data is not null) FileLogger.Warn("npm", e.Data); };
        var sw = Stopwatch.StartNew();
        process.Start();
        process.BeginOutputReadLine();
        process.BeginErrorReadLine();
        await process.WaitForExitAsync();
        FileLogger.Info(Tag, $"npm {string.Join(' ', args)} 結束: ExitCode={process.ExitCode}, 耗時 {sw.Elapsed.TotalSeconds:F1} 秒");
        return process.ExitCode;
    }

    private ProcessStartInfo CreateNpmStartInfo(params string[] args)
    {
        var psi = new ProcessStartInfo(NpmPath!)
        {
            WorkingDirectory = ExtensionFolder!,
            UseShellExecute = false,
            CreateNoWindow = true,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            StandardOutputEncoding = Encoding.UTF8,
            StandardErrorEncoding = Encoding.UTF8
        };
        foreach (var arg in args) psi.ArgumentList.Add(arg);
        return psi;
    }

    // ───────────── 除錯日誌輔助 ─────────────

    private static void LogCommandLine(string what, ProcessStartInfo psi)
    {
        // 參數用 [] 包起來，空白與引號問題一眼就能看出來。
        var args = string.Join(" ", psi.ArgumentList.Select(a => $"[{a}]"));
        FileLogger.Info(Tag, $"{what} 命令列: {psi.FileName} {args}");
        FileLogger.Info(Tag, $"{what} 工作目錄: {psi.WorkingDirectory}");
    }

    /// <summary>啟動前記錄環境：工具版本、外掛檔案、Profile 狀態、是否已有 firefox 在跑。</summary>
    private void LogEnvironmentSnapshot()
    {
        try
        {
            FileLogger.Info(Tag, $"環境: OS={Environment.OSVersion}, 64bit={Environment.Is64BitProcess}, user={Environment.UserName}");
            FileLogger.Info(Tag, $"Firefox: {FirefoxPath}, 版本={GetFileVersion(FirefoxPath)}");
            FileLogger.Info(Tag, $"npm: {NpmPath}");
            FileLogger.Info(Tag, $"node: {GetNodeVersion()}");

            var ext = ExtensionFolder!;
            FileLogger.Info(Tag, $"外掛資料夾: {ext}");
            FileLogger.Info(Tag,
                $"  manifest.json={File.Exists(Path.Combine(ext, "manifest.json"))}, " +
                $"package.json={File.Exists(Path.Combine(ext, "package.json"))}, " +
                $"web-ext-config.cjs={File.Exists(Path.Combine(ext, "web-ext-config.cjs"))}, " +
                $"node_modules={Directory.Exists(Path.Combine(ext, "node_modules"))}");
            FileLogger.Info(Tag, $"  web-ext 版本={GetInstalledWebExtVersion(ext)}");
            FileLogger.Info(Tag, $"  manifest 內容摘要: {SummarizeManifest(Path.Combine(ext, "manifest.json"))}");

            var profileDir = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "YTGrabWin", "FirefoxProfile");
            FileLogger.Info(Tag,
                $"Profile: {profileDir}, 存在={Directory.Exists(profileDir)}, " +
                $"parent.lock={File.Exists(Path.Combine(profileDir, "parent.lock"))}, " +
                $"lock={File.Exists(Path.Combine(profileDir, "lock"))}");

            var firefoxProcesses = Process.GetProcessesByName("firefox");
            FileLogger.Info(Tag, $"目前執行中的 firefox.exe 數量: {firefoxProcesses.Length}" +
                                 (firefoxProcesses.Length > 0 ? "（若其中有使用同一個 Profile，web-ext 會失敗）" : ""));
            foreach (var p in firefoxProcesses) p.Dispose();
        }
        catch (Exception ex)
        {
            // 環境快照只是輔助，失敗不應影響啟動。
            FileLogger.Warn(Tag, $"記錄環境時發生例外: {ex.Message}");
        }
    }

    private static string GetFileVersion(string? path)
    {
        try { return path is null ? "(none)" : FileVersionInfo.GetVersionInfo(path).ProductVersion ?? "(unknown)"; }
        catch (Exception ex) { return $"(讀取失敗: {ex.Message})"; }
    }

    private string GetNodeVersion()
    {
        try
        {
            // node.exe 通常和 npm.cmd 放在同一個資料夾。
            var nodeExe = Path.Combine(Path.GetDirectoryName(NpmPath!)!, "node.exe");
            if (!File.Exists(nodeExe)) return $"(找不到 {nodeExe})";

            var psi = new ProcessStartInfo(nodeExe, "--version")
            {
                UseShellExecute = false,
                CreateNoWindow = true,
                RedirectStandardOutput = true
            };
            using var p = Process.Start(psi)!;
            var output = p.StandardOutput.ReadToEnd().Trim();
            if (!p.WaitForExit(5000)) { try { p.Kill(); } catch { } return "(逾時)"; }
            return output;
        }
        catch (Exception ex)
        {
            return $"(讀取失敗: {ex.Message})";
        }
    }

    private static string GetInstalledWebExtVersion(string extensionFolder)
    {
        try
        {
            var file = Path.Combine(extensionFolder, "node_modules", "web-ext", "package.json");
            if (!File.Exists(file)) return "(node_modules 內沒有 web-ext)";
            var match = Regex.Match(File.ReadAllText(file), "\"version\"\\s*:\\s*\"([^\"]+)\"");
            return match.Success ? match.Groups[1].Value : "(無法解析)";
        }
        catch (Exception ex)
        {
            return $"(讀取失敗: {ex.Message})";
        }
    }

    /// <summary>只取 manifest 裡與啟動有關的欄位；同時能發現 JSON 語法錯誤。</summary>
    private static string SummarizeManifest(string manifestPath)
    {
        try
        {
            using var doc = System.Text.Json.JsonDocument.Parse(
                File.ReadAllText(manifestPath),
                new System.Text.Json.JsonDocumentOptions { CommentHandling = System.Text.Json.JsonCommentHandling.Skip, AllowTrailingCommas = true });
            var root = doc.RootElement;
            string Get(string name) => root.TryGetProperty(name, out var v) ? v.ToString() : "(無)";

            var geckoId = "(無)";
            if (root.TryGetProperty("browser_specific_settings", out var bss) &&
                bss.TryGetProperty("gecko", out var gecko) &&
                gecko.TryGetProperty("id", out var id))
                geckoId = id.ToString();

            return $"manifest_version={Get("manifest_version")}, version={Get("version")}, gecko.id={geckoId}";
        }
        catch (Exception ex)
        {
            return $"(manifest.json 解析失敗: {ex.Message})";
        }
    }

    private string DescribeBlockingState() => State switch
    {
        FirefoxIntegrationState.FirefoxNotFound => "找不到 Firefox。",
        FirefoxIntegrationState.NodeNotFound => "找不到 Node.js（npm）。本地執行外掛需要 Node.js，安裝後請重新啟動 YTGrab。",
        FirefoxIntegrationState.ExtensionFolderMissing => "找不到外掛資料夾（video-analyzer-extension）。請在按鍵上按右鍵，選「選擇外掛資料夾」。",
        _ => "目前無法啟動外掛。"
    };

    private static string? FindNpm()
    {
        var pathVariable = Environment.GetEnvironmentVariable("PATH") ?? string.Empty;
        foreach (var directory in pathVariable.Split(Path.PathSeparator, StringSplitOptions.RemoveEmptyEntries))
        {
            try
            {
                var candidate = Path.Combine(directory.Trim().Trim('"'), "npm.cmd");
                if (File.Exists(candidate))
                {
                    FileLogger.Debug(Tag, $"在 PATH 找到 npm: {candidate}");
                    return candidate;
                }
            }
            catch
            {
                // PATH 裡有格式不正確的項目時略過。
            }
        }

        var fallback = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "nodejs", "npm.cmd");
        var found = File.Exists(fallback);
        FileLogger.Debug(Tag, $"PATH 找不到 npm.cmd，備用位置 {fallback} -> {(found ? "存在" : "不存在")}");
        return found ? fallback : null;
    }

    /// <summary>手動指定的資料夾 → 部署位置（App 旁的 Firefox\video-analyzer-extension）→ 開發環境（往上層找 fireFoxPlug）。</summary>
    private string? FindExtensionFolder()
    {
        var configured = _settings.Current.FirefoxExtensionFolder;
        if (IsExtensionFolder(configured))
        {
            FileLogger.Debug(Tag, $"外掛資料夾（手動指定）: {configured}");
            return configured;
        }

        var deployed = Path.Combine(AppContext.BaseDirectory, "Firefox", "video-analyzer-extension");
        if (IsExtensionFolder(deployed))
        {
            FileLogger.Debug(Tag, $"外掛資料夾（部署位置）: {deployed}");
            return deployed;
        }

        var directory = new DirectoryInfo(AppContext.BaseDirectory);
        while (directory is not null)
        {
            var candidate = Path.Combine(directory.FullName, "fireFoxPlug", "video-analyzer-extension");
            if (IsExtensionFolder(candidate))
            {
                FileLogger.Debug(Tag, $"外掛資料夾（開發環境）: {candidate}");
                return candidate;
            }
            directory = directory.Parent;
        }

        FileLogger.Warn(Tag, $"找不到外掛資料夾（手動指定={configured ?? "(無)"}, 部署位置={deployed}）");
        return null;
    }

    private static bool IsExtensionFolder(string? path) =>
        !string.IsNullOrWhiteSpace(path) &&
        File.Exists(Path.Combine(path, "manifest.json")) &&
        File.Exists(Path.Combine(path, "package.json"));

    private static bool TryOpenUrl(string url, out string? error)
    {
        try
        {
            Process.Start(new ProcessStartInfo(url) { UseShellExecute = true });
            error = null;
            return true;
        }
        catch (Exception ex)
        {
            FileLogger.Error(Tag, $"開啟網頁失敗: {url}", ex);
            error = ex.Message;
            return false;
        }
    }

    private void SaveSettingsSafely()
    {
        try
        {
            _settings.Save();
        }
        catch (Exception ex)
        {
            FileLogger.Error(Tag, "儲存設定失敗", ex);
        }
    }
}

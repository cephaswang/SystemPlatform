rmdir /s /q obj
rmdir /s /q bin
dotnet build


C:\Users\1000\AppData\Local\YTGrabWin\logs\2026-09-29.log
# YTGrab for Windows × Firefox 外掛：整合企劃書

版本：v0.2 草案｜日期：2026-09-29

**v0.2 變更**：外掛確定在本地端運行（`npm start`／web-ext），不簽署、不上架 AMO。第五章按鍵流程、第六章、第九至十一章已配合修改。

**依據資料**：《Firefox 擴充功能開發企劃》、`video-analyzer-extension` 目錄清單（dir_plug.txt）、YTGrabWin 專案目錄與 README、已提供的 `VideoInfoView`、`YTDLPClient`、`SettingsStore` 等原始碼。

**尚未閱讀的內容**：`background.js`、`popup.js`、`host.py`、`manifest.json`、`DownloadTask.cs`、`DownloadQueueManager.cs`、`MainWindow.xaml.cs` 的實際內容。因此第二章的功能對照與第四章的訊息協定，是依企劃書描述推導，進入開發前需以原始碼核對（見附錄）。

---

## 一、目標與範圍

### 1.1 現況

| 項目 | Firefox 外掛 | YTGrabWin（Windows App） |
| --- | --- | --- |
| 定位 | 在瀏覽器內偵測頁面影片，一鍵送出下載 | 貼上網址、讀取資訊、選畫質／音訊／字幕、下載佇列 |
| 下載引擎 | 透過 Native Messaging 呼叫 `host.py` → yt-dlp（macOS 環境開發） | 內建 `yt-dlp.exe`、`ffmpeg.exe`，自有 ProcessRunner 與佇列 |
| 問題 | 兩邊各自呼叫 yt-dlp，設定、進度、相依套件、錯誤處理都是兩套 | 沒有瀏覽器端入口，使用者必須手動複製網址 |

### 1.2 整合目標

1. **單一下載引擎**：所有 yt-dlp 下載都由 YTGrabWin 執行。外掛負責在瀏覽器內「偵測」與「送出」，不再自己下載。
2. **App 端提供「Firefox 外掛」按鍵**：偵測 Firefox 與 Node.js，一鍵在本地端啟動 Firefox 並載入外掛，顯示執行狀態。
3. **外掛端提供「開啟 YTGrab」按鈕**：App 尚未執行時，可由瀏覽器把它叫起來。
4. **設定單一來源**：下載資料夾、檔名樣板、常用字幕語言等，以 App 的 `SettingsStore` 為準。

### 1.3 非目標（本階段不做）

- 不支援 Chrome／Edge（架構預留，之後可沿用同一橋接）。
- 不處理 DRM，不做規避平台保護的功能。
- 不改動 macOS 版 YTGrab 與既有 `host.py`（Mac 版維持原狀，日後可共用同一份協定）。

### 1.4 使用範圍提醒

沿用外掛企劃書第一章：工具應用範圍限定於自己擁有版權、明確公開授權（如 Creative Commons）或開放式媒體檔案；實際使用前需確認目標網站的使用條款。若日後改走 AMO 簽署，此點也會影響審核說明（見第六章）。

### 1.5 運行模式：本地端運行

外掛不經 AMO 簽署，由 App 在本機以 `npm start`（`web-ext run`）啟動一個載入該外掛的 Firefox。外掛只在該次 Firefox 執行期間有效，關閉即失效，下次再由按鍵啟動。此模式需要本機安裝 Node.js。

---

## 二、功能對照與整合後歸屬

| 功能 | 外掛現況 | YTGrabWin 現況 | 整合後歸屬 |
| --- | --- | --- | --- |
| 偵測頁面 `<video>`／`<source>` 直連網址 | 完成 | 無 | 外掛 |
| 一般直連檔下載（`downloads` API） | 完成 | 無 | 外掛保留（直連檔不必經過 App） |
| yt-dlp 進階下載 | 完成（經 `host.py`） | 完成 | **App** |
| 取得影片資訊（標題、時長、格式） | `GET_INFO` 已支援，popup 尚未使用 | `FetchVideoInfoAsync` 完成 | **App**；外掛送網址過去，由 App 顯示 |
| 下載佇列與進度 | 無（僅 FIFO 請求回應） | 有佇列（暫停、重試、取消） | **App**；進度回傳給外掛顯示 |
| 字幕下載 | 無 | 已可下載，尚未進佇列 | **App**（需先完成字幕進佇列） |
| 下載資料夾、檔名樣板 | 設定頁已做，未接回下載流程 | `SettingsStore` | **App 為準**；外掛設定頁只留瀏覽器端選項 |
| yt-dlp／ffmpeg 相依 | `install.sh` + Homebrew | 內建於 `Resources` | **App 內建**，外掛不再要求使用者另外安裝 |
| YouTube 所需 JS runtime（Deno） | 企劃書 7.6 已記載需要 | 尚未確認 | 待確認（見第十一章） |
| 多語系 | `_locales` 已有，介面仍寫死中文 | 中文介面 | 外掛接上 i18n（選配） |

---

## 三、整合架構

### 3.1 建議架構

```
Firefox 外掛（JS）
   │  Native Messaging（stdin/stdout，JSON）
   ▼
YTGrabBridge.exe（小型橋接程式，隨 App 安裝）
   │  具名管道（Named Pipe，僅限目前使用者）
   ▼
YTGrabWin.exe（下載佇列、設定、ProcessRunner）
   │
   ▼
yt-dlp.exe ＋ ffmpeg.exe（App 內建，唯一一份）
```

| 元件 | 職責 |
| --- | --- |
| 外掛 | 偵測頁面影片、顯示狀態與進度、送出「意圖」（例如：下載此頁、只要音訊、要字幕） |
| 橋接程式 | 被 Firefox 啟動；驗證訊息；App 未執行時負責啟動 App；在瀏覽器與 App 之間轉送訊息與進度事件 |
| App | 唯一的下載與設定擁有者；決定下載路徑、組 yt-dlp 參數、管理佇列 |

### 3.2 方案比較

| 方案 | 做法 | 優點 | 缺點 | 結論 |
| --- | --- | --- | --- | --- |
| A：橋接＋具名管道 | 外掛 → 橋接程式 → App | 單一引擎；App 可與外掛雙向溝通、回傳進度；無 Python 相依 | 多一個小程式要維護與簽章 | **建議** |
| B：移植 `host.py` 到 Windows | Windows 也用 Python host 直接呼叫 yt-dlp | 改動最少 | 使用者要有 Python；兩套引擎、兩套設定；佇列與進度無法共用 | 不建議 |
| C：自訂網址協定（`ytgrab://`） | 外掛開啟特殊網址喚起 App | 實作簡單、可喚起 App | 單向、無回傳、無法確認外掛連線狀態 | 作為「啟動 App」的備援 |

### 3.3 典型流程

1. 使用者在頁面按下外掛的下載按鈕。
2. 外掛把網址與意圖送給橋接程式。
3. 橋接程式檢查 App 是否在執行；沒有則啟動並等待管道就緒。
4. App 收到請求，依設定決定行為：先顯示影片資訊讓使用者選擇，或直接加入佇列。
5. 佇列進度以事件推回橋接程式，再傳回外掛，popup 顯示狀態。

App 已有 Mutex 防多開，第二個實例的情況由管道轉交，不再另開視窗。

---

## 四、訊息協定（概念層）

延續現有三種訊息（`CHECK_AVAILABLE`、`GET_INFO`、`DOWNLOAD`），並針對 Windows 整合擴充。

| 訊息 | 方向 | 用途 |
| --- | --- | --- |
| `HELLO` | 外掛 → App | 握手：外掛版本、協定版本、外掛 ID。App 據此更新「已連線」狀態 |
| `CHECK_AVAILABLE` | 外掛 → App | 回報 App、yt-dlp、ffmpeg 是否可用（取代原本檢查本機安裝） |
| `GET_INFO` | 外掛 → App | 請 App 讀取影片資訊；回傳精簡後的結果 |
| `ENQUEUE` | 外掛 → App | 加入佇列。種類：影片、音訊、字幕；附網址、標題、畫質偏好或字幕語言 |
| `QUEUE_EVENT` | App → 外掛 | 主動推播：任務加入、進度、完成、失敗 |
| `OPEN_APP` | 外掛 → App | 只要求把 App 叫到前景（外掛的「開啟 YTGrab」按鈕） |
| `OPEN_FOLDER` | 外掛 → App | 請 App 在檔案總管顯示已完成檔案 |

**協定設計原則**

1. **每則請求帶請求編號**。現行做法是以 FIFO 佇列比對回應，因為 Native Messaging 本身不帶編號；推播事件加入後這個做法會失效，必須改用編號。
2. **外掛只傳意圖，不傳 yt-dlp 參數**。所有參數由 App 組合，延續 `host.py` 以參數陣列而非 shell 字串呼叫的防注入精神。
3. **協定版本號**：握手時協商，版本不相容時 App 端按鍵顯示「需更新外掛」。
4. **回傳訊息控制大小**：Native Messaging 由本機程式傳給瀏覽器的單一訊息有 1 MB 上限，`GET_INFO` 只回傳必要欄位，不回完整 `-J` 內容。
5. **錯誤碼統一**：例如 App 未啟動、yt-dlp 不可用、網址不支援、使用者取消。

---

## 五、App 端「Firefox 外掛」按鍵與安裝精靈

### 5.1 放置位置

- **設定頁**新增「瀏覽器整合」區塊，放完整功能。
- **主視窗底列**（「設定」按鈕旁）放一顆狀態按鈕，帶狀態燈：灰＝未安裝、黃＝已註冊但外掛未連線、綠＝已連線。

### 5.2 按鍵狀態與行為

| 狀態 | 按鍵文字 | 燈號 | 左鍵點擊 |
| --- | --- | --- | --- |
| 找不到 Firefox | 取得 Firefox | 灰 | 開啟 Firefox 下載頁 |
| 找不到 Node.js | 需要 Node.js | 灰 | 開啟 Node.js 下載頁；安裝後需重新啟動 App |
| 找不到外掛資料夾 | 選擇外掛資料夾 | 灰 | 開啟資料夾選擇視窗 |
| 可啟動 | 啟動 Firefox 外掛 | 黃 | 執行 `npm start`（首次先 `npm install`） |
| 執行中 | 外掛執行中 | 綠 | 顯示說明；關閉該 Firefox 視窗即停止 |

右鍵選單：停止外掛（關閉該 Firefox）、選擇外掛資料夾、開發模式（開啟 `about:debugging` 手動載入）、重新偵測。

### 5.3 本地啟動流程

1. **偵測**：Firefox 由登錄與常見安裝位置尋找；Node.js 由環境變數 PATH 尋找 `npm.cmd`。
2. **尋找外掛資料夾**：依序為手動指定、App 旁的 `Firefox\video-analyzer-extension`、開發環境專案內的 `fireFoxPlug\video-analyzer-extension`。資料夾需同時有 `manifest.json` 與 `package.json`。
3. **首次安裝相依套件**：沒有 `node_modules` 時先執行 `npm install`，期間顯示等待視窗。
4. **啟動**：以 `npm start` 啟動，並指定 Firefox 路徑與專用 Profile。
5. **專用 Profile**：位於 `%LOCALAPPDATA%\YTGrabWin\FirefoxProfile`。web-ext 預設每次使用暫時 Profile，登入狀態不會保留，改用專用 Profile 後，網站登入狀態可持續使用。
6. **狀態追蹤**：web-ext 行程存活即為「執行中」；使用者關閉該 Firefox，行程結束，按鍵回到「可啟動」。啟動後很快異常結束時，提示使用者並指向記錄檔。

### 5.4 狀態偵測的限制

綠燈只代表「web-ext 行程執行中」，不代表外掛已與 App 連線。橋接完成後，改以外掛的握手（`HELLO`）作為「已連線」的依據。

### 5.5 外掛端對應功能

| 功能 | 說明 |
| --- | --- |
| 「開啟 YTGrab」按鈕 | popup 內，App 未執行時送出 `OPEN_APP` 喚起 |
| 未連線引導 | popup 偵測不到橋接時，顯示「請在 YTGrab 內按 Firefox 外掛 → 修復連線」 |
| 右鍵選單（Phase 5） | 「用 YTGrab 下載此連結／此頁」 |

---

## 六、外掛運行方式與打包（本地端）

1. **運行方式**：本地 web-ext，不簽署、不上架。Firefox 正式版對未簽署外掛只允許臨時載入，因此每次都由 App 按鍵啟動。
2. **環境需求**：Node.js（npm）；首次執行需要網路以安裝相依套件。Node.js 安裝後，App 需重新啟動才會讀到新的 PATH。
3. **正式化名稱**：目前 host 名稱 `com.example.ytdlp` 與外掛 ID `video-analyzer@example.com` 都是範本。整合前改成正式名稱，並確保 host 設定檔的 `allowed_extensions` 與 `manifest.json` 的 `browser_specific_settings.gecko.id` 一致；臨時載入時這個 ID 仍然有效。
4. **建置指令注意**：`readme_build.txt` 中的 `npm audit fix --force` 可能把套件強制升到不相容的版本，導致 `web-ext` 行為改變，建議改成先 `npm audit` 檢視，再手動處理。此外，`rm -rf` 為 macOS 指令，Windows 需改用對應指令。
5. **隨 App 出貨的位置**：外掛資料夾放在 App 旁的 `Firefox\video-analyzer-extension`，可含 `node_modules` 以避免首次執行時下載。
6. **不隨安裝檔出貨的內容**：`docs/`、`native-host/`（macOS 版）、`.DS_Store`。`docs/authentication_codes.txt` 檔名看起來像驗證碼或金鑰，我沒有讀過內容，請確認它不在版本控制，也不進安裝檔。
7. **保留選項**：日後若要提供給其他使用者一般安裝，再回到 AMO「未列出」簽署路線，屆時按鍵改為開啟簽署後的 `.xpi`。

---

## 七、設定、Cookies 與相依工具

### 7.1 設定單一來源

下載資料夾、檔名樣板、常用字幕語言以 `SettingsStore` 為準。外掛設定頁目前的「檔名樣板」尚未接回下載流程，整合後移交給 App；外掛只保留「自動重新掃描」等純瀏覽器端選項。

### 7.2 Cookies（選配，Phase 5）

可一併解決 YTGrabWin README 的待辦「Cookies 匯入」，有兩個方向：

| 方向 | 說明 | 注意 |
| --- | --- | --- |
| a. App 直接讀 Firefox Profile | 由 yt-dlp 的瀏覽器 cookies 功能讀取 | 需處理多 Profile 與 Profile 被鎖定的情況，外掛不參與 |
| b. 外掛匯出目前網域 cookies | 經橋接交給 App，用完即刪 | 涉及隱私，需使用者明確同意，預設關閉，日誌不得記錄 |

### 7.3 相依工具

- 只使用 App 內建的 `yt-dlp.exe` 與 `ffmpeg.exe`，避免兩個來源版本不一致。
- 外掛企劃書 7.6 指出 yt-dlp 新版解析 YouTube 需要 JavaScript runtime（Deno）。Windows 版 App 是否已處理需確認；若沒有，建議隨 App 內建或啟動時檢測並提示。

---

## 八、安全性

| 項目 | 做法 |
| --- | --- |
| 呼叫來源限制 | host 設定檔的 `allowed_extensions` 只允許正式外掛 ID |
| 管道存取 | 具名管道只允許目前使用者存取，名稱含使用者識別 |
| 動作白名單 | 只接受第四章列出的訊息；參數由 App 組合，不接受外掛傳來的原始 yt-dlp 參數 |
| 網址檢查 | 只接受 http／https；長度上限；其餘拒絕 |
| 下載路徑 | 由 App 決定，外掛不能指定任意路徑 |
| 敏感資料 | cookies 與帶權杖的網址不寫入日誌 |
| 簽章 | 橋接程式與 App 一併簽章，降低防毒與 SmartScreen 誤判 |

---

## 九、開發階段

| 階段 | 內容 | 驗收標準 |
| --- | --- | --- |
| Phase 0：前置盤點 | 閱讀外掛與 App 相關原始碼；正式化外掛 ID 與 host 名稱；清理敏感檔；決定發行路線；讓 `DownloadTask` 支援「種類」（影片、音訊、字幕），完成字幕進佇列 | 第十一章待確認項目定案；字幕能出現在下載佇列 |
| Phase 1：橋接最小可用 | 橋接程式、具名管道、手動註冊；外掛按鈕把網址送到 App | 在 Firefox 按外掛按鈕，App 自動填入網址並顯示影片資訊 |
| Phase 2：直送佇列與進度 | `ENQUEUE`、`QUEUE_EVENT`；外掛 popup 顯示進度；Windows 不再使用 `host.py` | 外掛送出的任務在 App 佇列完成，popup 同步顯示進度 |
| Phase 3：本地啟動按鍵 | App 端「Firefox 外掛」按鍵、狀態燈、停止與選擇資料夾；外掛端「開啟 YTGrab」 | 一次點擊即可啟動 Firefox 並載入外掛，關閉後回到可啟動 |
| Phase 4：安裝檔 | Inno Setup 隨附外掛資料夾、註冊與解除註冊 Native Messaging host；Node.js 相依提示 | 已安裝 Node.js 的 Windows 機器安裝後，按鍵可直接啟動外掛 |
| Phase 5：選配 | 右鍵選單、`GET_INFO` 預覽介面、Cookies、i18n 接上、Chrome／Edge | 依實際需求逐項驗收 |

---

## 十、風險與對策

| 風險 | 對策 |
| --- | --- |
| 發行路線若選 Microsoft Store（MSIX），套件化 App 寫入登錄與註冊 Native Messaging host 會受限 | 與 YTGrab 第七章的發行路線待確認連動；走 Store 時 Firefox 整合可能需限縮，或改由獨立安裝器負責註冊 |
| 本地運行需要 Node.js，且 Firefox 只臨時載入外掛 | 按鍵偵測 Node.js 並提示；每次由按鍵啟動；改給他人使用時再評估 AMO 簽署 |
| Firefox 版本差異（一般版、ESR、Developer Edition、Microsoft Store 版） | 先支援一般版，其餘實測後再決定；Store 版 Firefox 的 Native Messaging 行為需實測 |
| Node.js 安裝後 App 讀不到新的 PATH | 提示使用者重新啟動 App |
| `npm audit fix --force` 造成 web-ext 版本不相容 | 改成先檢視、再手動升級，並鎖定 `package-lock.json` |
| App 未執行時，外掛首次送出會有啟動延遲 | popup 顯示「啟動中」；橋接程式暫存訊息，管道就緒後重送 |
| 協定日後演進造成新舊版不相容 | 握手協商版本；App 端按鍵提示更新外掛 |
| 兩份 yt-dlp 版本不一致 | 只使用 App 內建版本 |
| 使用條款風險（含日後若上架 AMO 的審核） | 明確標示使用範圍；不提供繞過保護機制的預設功能 |

---

## 十一、待確認事項

- [ ] 「啟動 Firefox 外掛按鍵」的範圍：本企劃同時包含 App 端按鍵與外掛端「開啟 YTGrab」按鈕，是否符合預期
- [ ] 外掛送出後的預設行為：先在 App 顯示影片資訊讓使用者選擇（建議預設），或一鍵直接加入佇列（可做成設定選項）
- [ ] 外掛維持本地運行（不簽署）；日後若對外散布再評估 AMO 簽署
- [ ] 外掛資料夾隨 App 出貨的位置，以及是否預先包含 `node_modules`
- [ ] 正式外掛 ID 與 host 名稱
- [ ] 發行路線：獨立安裝檔（Inno Setup）或 Microsoft Store（MSIX）
- [ ] 支援的 Firefox 版本範圍（一般版、ESR、Developer Edition）
- [ ] YouTube 所需的 JavaScript runtime（Deno）是否隨 App 內建
- [ ] Cookies 是否納入，採用 7.2 的哪個方向
- [ ] App 未執行時是否自動啟動；是否需要系統匣常駐模式（與 YTGrab 待確認事項相同）
- [ ] macOS 版 YTGrab 是否日後沿用同一份訊息協定

---

## 附錄：進入 Phase 0 需要的檔案

| 檔案 | 用途 |
| --- | --- |
| `manifest.json`、`background/background.js`、`popup/popup.js` | 確認現有訊息流程與權限，設計外掛端改動 |
| `native-host/host.py`、`com.example.ytdlp.json`、`install.sh` | 確認現有協定與參數，作為橋接程式的規格依據 |
| `Core/Models/DownloadTask.cs`、`Core/DownloadQueue/DownloadQueueManager.cs` | 設計任務種類與字幕進佇列 |
| `Features/MainWindow.xaml.cs`、`App/App.xaml.cs` | 設計網址接收、管道服務與單一實例轉交 |
| `Features/Settings/SettingsView.xaml(.cs)` | 放置「瀏覽器整合」區塊 |
| `web-ext-config.cjs`、`package.json` | 確認 `npm start` 的實際參數，避免與 App 傳入的 Firefox 路徑與 Profile 衝突 |

#!/usr/bin/env python3
"""
host.py  (Windows / macOS 通用版)
Native Messaging Host：透過 stdin/stdout 與 Firefox 擴充功能通訊，
接收請求後呼叫 yt-dlp，並把結果回傳給擴充功能。

通訊協定：每則訊息 = 4 bytes 長度（原生位元組序）+ UTF-8 JSON。
安全性：只接受固定的三種指令；呼叫 yt-dlp 一律用參數陣列，不經 shell。

工具路徑與下載資料夾由 YTGrab App 每次啟動外掛時寫入同資料夾的 host_config.json：
  { "ytdlpPath": "...", "ffmpegPath": "...", "downloadDir": "..." }
沒有設定檔時退回到 PATH 搜尋。
"""

import json
import os
import shutil
import struct
import subprocess
import sys
import time

IS_WINDOWS = os.name == "nt"

if IS_WINDOWS:
    import msvcrt
    # stdin/stdout 必須是二進位模式，否則 0x0A/0x1A 等位元組會被改寫，訊息長度就會錯亂。
    msvcrt.setmode(sys.stdin.fileno(), os.O_BINARY)
    msvcrt.setmode(sys.stdout.fileno(), os.O_BINARY)

HERE = os.path.dirname(os.path.abspath(__file__))
LOG_PATH = os.path.join(HERE, "host.log")


def log(text):
    """寫入 host.log 方便排查（絕不能寫到 stdout）。"""
    try:
        with open(LOG_PATH, "a", encoding="utf-8") as f:
            f.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')} {text}\n")
    except OSError:
        pass


def load_config():
    try:
        with open(os.path.join(HERE, "host_config.json"), "r", encoding="utf-8-sig") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


CONFIG = load_config()


def find_tool(name, configured):
    if configured and os.path.exists(configured):
        return configured
    found = shutil.which(name)
    if found:
        return found
    if not IS_WINDOWS:
        fallback = f"/opt/homebrew/bin/{name}"
        if os.path.exists(fallback):
            return fallback
    return None


YTDLP_BIN = find_tool("yt-dlp", CONFIG.get("ytdlpPath"))
FFMPEG_BIN = find_tool("ffmpeg", CONFIG.get("ffmpegPath"))
DEFAULT_DOWNLOAD_DIR = CONFIG.get("downloadDir") or os.path.expanduser("~/Downloads")

MISSING_YTDLP = "找不到 yt-dlp（請確認 YTGrab 的 Resources\\yt-dlp.exe 存在，或已加入 PATH）"


# ---- Native Messaging I/O -------------------------------------------------

def read_message():
    raw_length = sys.stdin.buffer.read(4)
    if len(raw_length) < 4:
        sys.exit(0)  # Firefox 關閉了連線
    message_length = struct.unpack("=I", raw_length)[0]
    body = sys.stdin.buffer.read(message_length)
    return json.loads(body.decode("utf-8"))


def send_message(message_dict):
    encoded = json.dumps(message_dict).encode("utf-8")
    sys.stdout.buffer.write(struct.pack("=I", len(encoded)))
    sys.stdout.buffer.write(encoded)
    sys.stdout.buffer.flush()


# ---- 執行 yt-dlp ------------------------------------------------------------

def run_tool(command, timeout):
    env = os.environ.copy()
    # 讓 yt-dlp 以 UTF-8 輸出，避免中文標題在 Windows（cp950）下亂碼
    env["PYTHONUTF8"] = "1"
    env["PYTHONIOENCODING"] = "utf-8"

    kwargs = {}
    if IS_WINDOWS:
        kwargs["creationflags"] = subprocess.CREATE_NO_WINDOW  # 不要跳出黑色視窗

    return subprocess.run(
        command,
        capture_output=True,
        encoding="utf-8",
        errors="replace",
        timeout=timeout,
        env=env,
        stdin=subprocess.DEVNULL,  # 不能讓 yt-dlp 讀到本程式的 stdin（那是訊息通道）
        **kwargs,
    )


def is_http_url(url):
    return isinstance(url, str) and url.lower().startswith(("http://", "https://")) and len(url) < 4096


# ---- 指令處理 ---------------------------------------------------------------

def handle_check_available():
    return {
        "type": "CHECK_AVAILABLE_RESULT",
        "ytdlpAvailable": YTDLP_BIN is not None,
        "ffmpegAvailable": FFMPEG_BIN is not None,
    }


def handle_download(payload):
    url = payload.get("url")
    if not is_http_url(url):
        return {"type": "DOWNLOAD_RESULT", "ok": False, "error": "缺少或不合法的 url 參數"}
    if YTDLP_BIN is None:
        return {"type": "DOWNLOAD_RESULT", "ok": False, "error": MISSING_YTDLP}

    output_dir = payload.get("outputDir") or DEFAULT_DOWNLOAD_DIR
    video_format = payload.get("format")
    os.makedirs(output_dir, exist_ok=True)

    command = [YTDLP_BIN]
    if FFMPEG_BIN:
        command += ["--ffmpeg-location", FFMPEG_BIN]
    if video_format:
        command += ["-f", video_format]
    command += [
        "-o", os.path.join(output_dir, "%(title)s.%(ext)s"),
        "--no-playlist",
        url,
    ]

    log(f"DOWNLOAD {url}")
    try:
        result = run_tool(command, timeout=1800)
    except FileNotFoundError:
        return {"type": "DOWNLOAD_RESULT", "ok": False, "error": MISSING_YTDLP}
    except subprocess.TimeoutExpired:
        return {"type": "DOWNLOAD_RESULT", "ok": False, "error": "下載逾時"}

    if result.returncode != 0:
        return {"type": "DOWNLOAD_RESULT", "ok": False, "error": result.stderr.strip()[-2000:]}

    return {
        "type": "DOWNLOAD_RESULT",
        "ok": True,
        "stdout": result.stdout.strip()[-2000:],
        "outputDir": output_dir,
    }


def handle_get_info(payload):
    url = payload.get("url")
    if not is_http_url(url):
        return {"type": "INFO_RESULT", "ok": False, "error": "缺少或不合法的 url 參數"}
    if YTDLP_BIN is None:
        return {"type": "INFO_RESULT", "ok": False, "error": MISSING_YTDLP}

    try:
        result = run_tool([YTDLP_BIN, "--dump-json", "--no-playlist", url], timeout=60)
    except FileNotFoundError:
        return {"type": "INFO_RESULT", "ok": False, "error": MISSING_YTDLP}
    except subprocess.TimeoutExpired:
        return {"type": "INFO_RESULT", "ok": False, "error": "取得資訊逾時"}

    if result.returncode != 0:
        return {"type": "INFO_RESULT", "ok": False, "error": result.stderr.strip()[-2000:]}

    try:
        info = json.loads(result.stdout)
    except json.JSONDecodeError:
        return {"type": "INFO_RESULT", "ok": False, "error": "無法解析 yt-dlp 回傳資料"}

    return {
        "type": "INFO_RESULT",
        "ok": True,
        "title": info.get("title"),
        "duration": info.get("duration"),
        "formats": [
            {
                "formatId": f.get("format_id"),
                "ext": f.get("ext"),
                "resolution": f.get("resolution"),
                "filesize": f.get("filesize"),
            }
            for f in info.get("formats", [])[:200]  # 回傳單則訊息上限 1 MB
        ],
    }


# ---- 主迴圈 ---------------------------------------------------------------

def main():
    log(f"host 啟動: python={sys.version.split()[0]}, yt-dlp={YTDLP_BIN}, ffmpeg={FFMPEG_BIN}, dir={DEFAULT_DOWNLOAD_DIR}")
    while True:
        message = read_message()
        message_type = message.get("type")

        if message_type == "CHECK_AVAILABLE":
            response = handle_check_available()
        elif message_type == "DOWNLOAD":
            response = handle_download(message)
        elif message_type == "GET_INFO":
            response = handle_get_info(message)
        else:
            response = {"type": "ERROR", "error": f"未知的指令類型: {message_type}"}

        send_message(response)


if __name__ == "__main__":
    try:
        main()
    except SystemExit:
        raise
    except Exception as exc:  # noqa: BLE001
        log(f"未預期的錯誤: {exc!r}")
        raise

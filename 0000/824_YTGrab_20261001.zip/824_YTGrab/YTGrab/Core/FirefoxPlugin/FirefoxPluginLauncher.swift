//
//  FirefoxPluginLauncher.swift
//  YTGrab / Core/FirefoxPlugin
//
//  「Firefox 外掛」按鍵的主邏輯：
//    檢查環境 → NativeHostInstaller.install → npx web-ext run（用專屬 profile 開 Firefox）
//  Firefox 關閉時 web-ext 會自行結束，狀態回到 idle。
//
//  僅 DMG（公證）版；上架版整檔排除。
//

#if !APPSTORE
import SwiftUI
import AppKit
import Combine

@MainActor
final class FirefoxPluginLauncher: ObservableObject {

    enum State: Equatable {
        case idle
        case preparing
        case running
        case failed(String)
    }

    enum LauncherError: LocalizedError {
        case firefoxNotFound
        case nodeNotFound
        case pythonNotFound
        case ytdlpMissing(String)

        var errorDescription: String? {
            switch self {
            case .firefoxNotFound:
                return "找不到 Firefox，請安裝或在設定頁指定路徑。"
            case .nodeNotFound:
                return "找不到 node／npx，請先在終端機執行：brew install node"
            case .pythonNotFound:
                return "找不到可用的 python3，請先安裝 Xcode 命令列工具（xcode-select --install）或 brew install python。"
            case .ytdlpMissing(let path):
                return "找不到 yt-dlp：\(path)"
            }
        }
    }

    @Published private(set) var state: State = .idle
    @Published private(set) var recentLog: [String] = []
    @Published var firefoxPath: String {
        didSet { UserDefaults.standard.set(firefoxPath, forKey: Self.firefoxKey) }
    }

    private var process: Process?
    private var stoppedByUser = false
    private static let firefoxKey = "firefoxBinaryPath"

    init() {
        let saved = UserDefaults.standard.string(forKey: Self.firefoxKey) ?? ""
        firefoxPath = saved.isEmpty ? (Self.detectFirefox() ?? "") : saved
    }

    var isBusy: Bool { state == .preparing || state == .running }

    // MARK: - 啟動 / 停止

    func start(ytdlpPath: String, ffmpegPath: String, downloadDir: URL) async {
        guard !isBusy else { return }
        state = .preparing
        recentLog = []
        stoppedByUser = false

        do {
            guard let firefox = Self.resolveFirefox(firefoxPath) else { throw LauncherError.firefoxNotFound }
            guard let npx = Self.findNPX() else { throw LauncherError.nodeNotFound }
            guard FileManager.default.isExecutableFile(atPath: ytdlpPath) else {
                throw LauncherError.ytdlpMissing(ytdlpPath)
            }
            // host.py 的 shebang 是 env python3，先確認真的跑得起來
            do {
                _ = try await ProcessRunner.run(executablePath: "/usr/bin/env", arguments: ["python3", "--version"])
            } catch {
                throw LauncherError.pythonNotFound
            }

            let layout = try NativeHostInstaller.install(
                ytdlpPath: ytdlpPath,
                ffmpegPath: ffmpegPath,
                downloadDir: downloadDir
            )

            let arguments = [
                "--yes", "web-ext@8", "run",
                "--no-config-discovery",
                "--source-dir", layout.extensionDir.path,
                "--firefox", firefox,
                "--firefox-profile", layout.profileDir.path,
                "--profile-create-if-missing",
                "--keep-profile-changes",
                "--no-reload"
            ]

            let launched = ProcessRunner.runStreaming(
                executablePath: npx,
                arguments: arguments,
                onLine: { [weak self] line in
                    Task { @MainActor in self?.appendLog(line) }
                },
                onCompletion: { [weak self] result in
                    Task { @MainActor in self?.finished(result) }
                }
            )
            if let launched {
                process = launched
                state = .running
            }
            // launched == nil 時，onCompletion 已帶著失敗原因呼叫 finished
        } catch {
            state = .failed(error.localizedDescription)
        }
    }

    func stop() {
        stoppedByUser = true
        process?.terminate()
    }

    private func appendLog(_ line: String) {
        recentLog.append(line)
        if recentLog.count > 50 { recentLog.removeFirst(recentLog.count - 50) }
    }

    private func finished(_ result: Result<Void, ProcessRunnerError>) {
        process = nil
        switch result {
        case .success:
            state = .idle                       // 使用者關閉了 Firefox
        case .failure(let error):
            if stoppedByUser {
                state = .idle
            } else {
                let text = error.localizedDescription
                state = .failed(String(text.suffix(400)))
            }
        }
    }

    // MARK: - 找工具

    static func detectFirefox() -> String? {
        let home = NSHomeDirectory()
        let candidates = [
            "/Applications/Firefox.app/Contents/MacOS/firefox",
            "/Applications/Firefox Developer Edition.app/Contents/MacOS/firefox",
            "\(home)/Applications/Firefox.app/Contents/MacOS/firefox"
        ]
        return candidates.first { FileManager.default.isExecutableFile(atPath: $0) }
    }

    /// 接受「Firefox.app」或裡面的 firefox 執行檔兩種寫法。
    static func resolveFirefox(_ path: String) -> String? {
        var p = path.trimmingCharacters(in: .whitespaces)
        if p.isEmpty { return detectFirefox() }
        if p.hasSuffix(".app") { p += "/Contents/MacOS/firefox" }
        return FileManager.default.isExecutableFile(atPath: p) ? p : nil
    }

    static func findNPX() -> String? {
        let home = NSHomeDirectory()
        let candidates = [
            "/opt/homebrew/bin/npx",
            "/usr/local/bin/npx",
            "\(home)/.volta/bin/npx"
        ]
        return candidates.first { FileManager.default.isExecutableFile(atPath: $0) }
    }
}

// MARK: - 主畫面按鍵

struct FirefoxPluginButton: View {
    @ObservedObject var launcher: FirefoxPluginLauncher
    @EnvironmentObject private var appState: AppState

    var body: some View {
        HStack(spacing: 10) {
            Button {
                if launcher.state == .running {
                    launcher.stop()
                } else {
                    Task {
                        await launcher.start(
                            ytdlpPath: appState.ytdlpBinaryPath,
                            ffmpegPath: appState.ffmpegBinaryPath,
                            downloadDir: appState.downloadDirectory
                        )
                    }
                }
            } label: {
                Label(title, systemImage: launcher.state == .running ? "stop.circle" : "safari")
            }
            .buttonStyle(.borderedProminent)
            .disabled(launcher.state == .preparing)

            if launcher.state == .preparing {
                ProgressView().controlSize(.small)
            }
            if case .failed(let message) = launcher.state {
                Text(message)
                    .font(.caption)
                    .foregroundStyle(.red)
                    .lineLimit(3)
                    .textSelection(.enabled)
            }
        }
    }

    private var title: String {
        switch launcher.state {
        case .idle, .failed: return "Firefox 外掛"
        case .preparing:     return "啟動中…"
        case .running:       return "停止 Firefox 外掛"
        }
    }
}

// MARK: - 設定頁區塊

struct FirefoxPluginSettingsSection: View {
    @ObservedObject var launcher: FirefoxPluginLauncher

    var body: some View {
        Section("Firefox 外掛") {
            HStack {
                Text("Firefox 路徑")
                Spacer()
                TextField("", text: $launcher.firefoxPath)
                    .textFieldStyle(.roundedBorder)
                    .multilineTextAlignment(.trailing)
                    .frame(maxWidth: 260)
                Button("選擇…") { chooseFirefox() }
            }
            Text("需要 node（brew install node）與 python3。外掛使用專屬的 Firefox 設定檔，第一次啟動請在其中登入需要的網站。")
                .font(.caption)
                .foregroundStyle(.secondary)
        }
    }

    private func chooseFirefox() {
        let panel = NSOpenPanel()
        panel.canChooseFiles = true
        panel.canChooseDirectories = false
        panel.allowsMultipleSelection = false
        panel.directoryURL = URL(fileURLWithPath: "/Applications")
        panel.prompt = "選擇 Firefox"
        if panel.runModal() == .OK, let url = panel.url {
            launcher.firefoxPath = url.path
        }
    }
}
#endif

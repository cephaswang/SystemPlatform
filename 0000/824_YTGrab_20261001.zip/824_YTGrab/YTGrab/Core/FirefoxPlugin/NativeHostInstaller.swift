//
//  NativeHostInstaller.swift
//  YTGrab / Core/FirefoxPlugin
//
//  取代 install.sh：每次按「Firefox 外掛」時執行，全部是檔案操作，不經 shell。
//   1. 把 App 內的 FirefoxPlugin 複製到 ~/Library/Application Support/YTGrab/FirefoxPlugin
//      （App 包內唯讀，host 需要寫 host.log / host_config.json，所以要搬出來）
//   2. 寫入 host_config.json（yt-dlp / ffmpeg 路徑、下載資料夾）
//   3. 註冊 Native Messaging manifest 到 Firefox 的 NativeMessagingHosts
//
//  僅 DMG（公證）版；上架版 Sandbox 不允許，整檔排除。
//

#if !APPSTORE
import Foundation
import Combine

enum NativeHostInstaller {

    static let hostName = "com.example.ytdlp"

    struct Layout {
        let root: URL
        let extensionDir: URL
        let hostDir: URL
        let profileDir: URL
        var hostScript: URL { hostDir.appendingPathComponent("host.py") }
    }

    enum InstallError: LocalizedError {
        case bundleMissing
        case invalidTemplate

        var errorDescription: String? {
            switch self {
            case .bundleMissing:
                return "App 內找不到 FirefoxPlugin 資料夾（請確認已加入 Copy Bundle Resources）。"
            case .invalidTemplate:
                return "com.example.ytdlp.json 範本格式錯誤。"
            }
        }
    }

    static var layout: Layout {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        let root = base.appendingPathComponent("YTGrab/FirefoxPlugin", isDirectory: true)
        return Layout(
            root: root,
            extensionDir: root.appendingPathComponent("extension", isDirectory: true),
            hostDir: root.appendingPathComponent("host", isDirectory: true),
            profileDir: base.appendingPathComponent("YTGrab/FirefoxProfile", isDirectory: true)
        )
    }

    /// Firefox 讀取 Native Messaging manifest 的位置（macOS）。
    private static var nativeMessagingDirectory: URL {
        FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("Mozilla/NativeMessagingHosts", isDirectory: true)
    }

    @discardableResult
    static func install(ytdlpPath: String, ffmpegPath: String, downloadDir: URL) throws -> Layout {
        let fm = FileManager.default

        guard let bundled = Bundle.main.resourceURL?
            .appendingPathComponent("FirefoxPlugin", isDirectory: true),
              fm.fileExists(atPath: bundled.path) else {
            throw InstallError.bundleMissing
        }

        let layout = self.layout
        try fm.createDirectory(at: layout.hostDir, withIntermediateDirectories: true)
        try fm.createDirectory(at: layout.profileDir, withIntermediateDirectories: true)

        // 1. 外掛：整個資料夾覆寫，確保與 App 版本一致
        try replaceItem(
            from: bundled.appendingPathComponent("extension", isDirectory: true),
            to: layout.extensionDir
        )

        // 2. host 檔案：逐一覆寫，保留既有的 host.log / host_config.json
        let hostSource = bundled.appendingPathComponent("host", isDirectory: true)
        let keep: Set<String> = ["host.log", "host_config.json"]
        for name in try fm.contentsOfDirectory(atPath: hostSource.path)
        where !name.hasPrefix(".") && !keep.contains(name) {
            try replaceItem(
                from: hostSource.appendingPathComponent(name),
                to: layout.hostDir.appendingPathComponent(name)
            )
        }
        try fm.setAttributes([.posixPermissions: 0o755], ofItemAtPath: layout.hostScript.path)

        // 3. host_config.json：host.py 啟動時讀取
        let config: [String: String] = [
            "ytdlpPath": ytdlpPath,
            "ffmpegPath": ffmpegPath,
            "downloadDir": downloadDir.path
        ]
        let configData = try JSONSerialization.data(
            withJSONObject: config,
            options: [.prettyPrinted, .withoutEscapingSlashes]
        )
        try configData.write(
            to: layout.hostDir.appendingPathComponent("host_config.json"),
            options: .atomic
        )

        // 4. Native Messaging manifest：path 換成 host.py 的絕對路徑
        let templateURL = layout.hostDir.appendingPathComponent("\(hostName).json")
        guard var manifest = try JSONSerialization.jsonObject(
            with: Data(contentsOf: templateURL)
        ) as? [String: Any] else {
            throw InstallError.invalidTemplate
        }
        manifest["path"] = layout.hostScript.path

        try fm.createDirectory(at: nativeMessagingDirectory, withIntermediateDirectories: true)
        let manifestData = try JSONSerialization.data(
            withJSONObject: manifest,
            options: [.prettyPrinted, .withoutEscapingSlashes]
        )
        try manifestData.write(
            to: nativeMessagingDirectory.appendingPathComponent("\(hostName).json"),
            options: .atomic
        )

        return layout
    }

    private static func replaceItem(from source: URL, to destination: URL) throws {
        let fm = FileManager.default
        if fm.fileExists(atPath: destination.path) {
            try fm.removeItem(at: destination)
        }
        try fm.copyItem(at: source, to: destination)
    }
}
#endif

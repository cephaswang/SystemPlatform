@echo off
chcp 65001 >nul
setlocal

rem ============================================================
rem  sync-native-host.bat
rem  手動同步：把開發資料夾裡的 Native Host 程式檔案複製到
rem  YTGrab 桌面版實際執行的位置（%LocalAppData%\YTGrabWin\NativeHost\）。
rem
rem  只複製「程式邏輯」檔案（host.py／host.bat），
rem  不動 host_config.json（那是 YTGrab 桌面版寫入的實際工具路徑，
rem  不能被覆蓋，否則 yt-dlp／ffmpeg 路徑會消失）、
rem  也不動 com.example.ytdlp.json（那是已經填好絕對路徑的正式設定檔，
rem  來源那份還是 REPLACE_WITH_ABSOLUTE_PATH 的範本，蓋過去會壞掉）。
rem ============================================================

set "SRC=C:\Users\1000\Documents\2026workspace\YTGrabWin\fireFoxPlug\yt-dlp"
set "DST=%LocalAppData%\YTGrabWin\NativeHost"

if not exist "%DST%" (
    echo [錯誤] 找不到目的資料夾：%DST%
    echo 請先透過 YTGrab 的「啟動 Firefox 外掛」按鍵執行過一次，讓它建立這個資料夾。
    pause
    exit /b 1
)

echo 來源：%SRC%
echo 目的：%DST%
echo.

copy /Y "%SRC%\host.py" "%DST%\host.py" >nul && echo [OK] host.py 已同步 || echo [失敗] host.py
copy /Y "%SRC%\host.bat" "%DST%\host.bat" >nul && echo [OK] host.bat 已同步 || echo [失敗] host.bat

echo.
echo 完成。若 Firefox 目前仍在執行外掛，請到 about:debugging 重新載入
echo 擴充功能，或完全關閉 Firefox 再重開，讓 Native Host 行程重新啟動
echo （host.py 是常駐行程，改完檔案不會自動套用到正在跑的那個）。
echo.
pause

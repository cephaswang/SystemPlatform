<#
    watch-native-host.ps1

    自動同步：持續監看開發資料夾裡的 host.py / host.bat，
    只要檔案一被儲存就自動複製到 YTGrab 桌面版實際執行 Native Host 的位置
    （%LocalAppData%\YTGrabWin\NativeHost\），不用每次改完手動跑 sync-native-host.bat。

    用法：
        1. 在 PowerShell 執行（第一次可能要先解除執行原則限制，見下方說明）：
               .\watch-native-host.ps1
        2. 保持這個視窗開著，開發期間就讓它一直跑。
        3. 之後你在編輯器裡儲存 host.py，這個視窗會立刻印出同步訊息。
        4. 要停止就直接關掉這個 PowerShell 視窗，或按 Ctrl+C。

    如果執行時出現「不能載入指令碼，因為這個系統上已停用指令碼執行」，
    先以系統管理員身分開 PowerShell，執行一次：
        Set-ExecutionPolicy -Scope CurrentUser RemoteSigned
    再重新執行這個腳本即可。

    注意：這只同步「程式邏輯」檔案（host.py／host.bat）。
    host_config.json（YTGrab 寫入的實際工具路徑）與
    com.example.ytdlp.json（已填好絕對路徑的正式設定檔）不會被動到，
    避免蓋掉正式運作所需的設定。
#>

$SourceDir = "C:\Users\1000\Documents\2026workspace\YTGrabWin\fireFoxPlug\yt-dlp"
$DestDir   = Join-Path $env:LocalAppData "YTGrabWin\NativeHost"
$FilesToSync = @("host.py", "host.bat")

if (-not (Test-Path $DestDir)) {
    Write-Host "[錯誤] 找不到目的資料夾：$DestDir" -ForegroundColor Red
    Write-Host "請先透過 YTGrab 的「啟動 Firefox 外掛」按鍵執行過一次，讓它建立這個資料夾。" -ForegroundColor Yellow
    exit 1
}

function Sync-File {
    param([string]$FileName)

    $srcPath = Join-Path $SourceDir $FileName
    $dstPath = Join-Path $DestDir $FileName

    if (-not (Test-Path $srcPath)) { return }

    try {
        Copy-Item -Path $srcPath -Destination $dstPath -Force
        $timestamp = Get-Date -Format "HH:mm:ss"
        Write-Host "[$timestamp] 已同步：$FileName -> $dstPath" -ForegroundColor Green
    }
    catch {
        Write-Host "[失敗] 同步 $FileName 時發生錯誤：$($_.Exception.Message)" -ForegroundColor Red
    }
}

# 啟動時先同步一次目前的內容，避免「開始監看之後才算數」的空窗期。
Write-Host "初次同步..." -ForegroundColor Cyan
foreach ($file in $FilesToSync) { Sync-File -FileName $file }

Write-Host ""
Write-Host "開始監看變更：$SourceDir" -ForegroundColor Cyan
Write-Host "（只監看 host.py / host.bat；Ctrl+C 結束）" -ForegroundColor DarkGray
Write-Host ""

$watcher = New-Object System.IO.FileSystemWatcher
$watcher.Path = $SourceDir
$watcher.Filter = "*.*"
$watcher.NotifyFilter = [System.IO.NotifyFilters]::LastWrite -bor [System.IO.NotifyFilters]::FileName
$watcher.EnableRaisingEvents = $true

# 防止編輯器一次儲存觸發多個事件、造成短時間內重複複製。
$lastSyncTime = @{}
$DebounceMilliseconds = 300

$action = {
    param($sourceEventArgs)
    $changedFile = $sourceEventArgs.Name

    if ($FilesToSync -notcontains $changedFile) { return }

    $now = Get-Date
    $key = $changedFile
    if ($script:lastSyncTime.ContainsKey($key)) {
        $elapsed = ($now - $script:lastSyncTime[$key]).TotalMilliseconds
        if ($elapsed -lt $script:DebounceMilliseconds) { return }
    }
    $script:lastSyncTime[$key] = $now

    # 檔案儲存瞬間可能還在寫入，稍微等一下再複製，避免複製到寫一半的內容。
    Start-Sleep -Milliseconds 150
    & $script:SyncFileFunc -FileName $changedFile
}

# 讓上面的 scriptblock 能存取到外層的變數與函式。
$script:SourceDir = $SourceDir
$script:DestDir = $DestDir
$script:FilesToSync = $FilesToSync
$script:lastSyncTime = $lastSyncTime
$script:DebounceMilliseconds = $DebounceMilliseconds
$script:SyncFileFunc = ${function:Sync-File}

Register-ObjectEvent -InputObject $watcher -EventName Changed -Action $action | Out-Null
Register-ObjectEvent -InputObject $watcher -EventName Created -Action $action | Out-Null

try {
    while ($true) { Start-Sleep -Seconds 1 }
}
finally {
    $watcher.Dispose()
    Write-Host "已停止監看。" -ForegroundColor Yellow
}

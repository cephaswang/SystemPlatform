@echo off
rem Native Messaging launcher for Windows.
rem Firefox cannot run .py directly, so it starts this file, which starts host.py.
rem IMPORTANT: never print anything to stdout here; stdout is the message channel.
setlocal
set "DIR=%~dp0"

where py >nul 2>nul
if not errorlevel 1 (
  py -3 "%DIR%host.py"
  exit /b
)

where python >nul 2>nul
if not errorlevel 1 (
  python "%DIR%host.py"
  exit /b
)

exit /b 9009

// web-ext 設定檔
// 文件：https://extensionworkshop.com/documentation/develop/getting-started-with-web-ext/

module.exports = {
  // 顯示 web-ext 詳細訊息（除錯用）。YTGrab 會把輸出寫入 %LocalAppData%\YTGrabWin\logs，
  // 排查完成後可改回 false。
  verbose: true,

  // 執行 `npm start` (web-ext run) 時套用
  run: {
    // YTGrab 啟動時會用 --firefox 傳入實際路徑，命令列參數優先於這裡的設定。
    // 單獨在終端機執行 `npm start` 時才會用到這個值。
    firefox: "firefox",
    startUrl: ["about:debugging#/runtime/this-firefox"],
    browserConsole: false, // 改為 true 可看到瀏覽器主控台（含大量無關的內部訊息）
    reload: true
  },

  // 執行 `npm run build` (web-ext build) 時套用
  build: {
    overwriteDest: true
  },

  // 執行 `npm run lint` (web-ext lint) 時套用
  lint: {
    warningsAsErrors: false
  },

  // 執行 `npm run sign` (web-ext sign) 時套用
  // apiKey / apiSecret 建議透過環境變數帶入，不要寫死在此檔案：
  //   set WEB_EXT_API_KEY=xxx & set WEB_EXT_API_SECRET=xxx & npm run sign
  sign: {
    channel: "unlisted"
  },

  // 打包／執行時要忽略的檔案
  ignoreFiles: [
    "package.json",
    "package-lock.json",
    "web-ext-config.cjs",
    "README.md",
    "native-host/**",
    "node_modules/**",
    ".git/**"
  ],

  sourceDir: "."
};

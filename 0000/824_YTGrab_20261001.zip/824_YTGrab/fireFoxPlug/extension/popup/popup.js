/**
 * popup.js
 * 向 background 要求目前分頁偵測到的影片清單，並渲染成列表；
 * 使用者點擊下載按鈕時，請求 background 觸發下載。
 *
 * 兩種開啟方式：
 * 1. 工具列 popup（或快捷鍵觸發）：目標分頁 = 目前視窗的作用中分頁。
 * 2. 獨立小視窗（沒有工具列時的後備方案）：網址帶 ?tabId=xxx，
 *    目標分頁 = 該 tabId（因為此時「目前視窗」是 popup 視窗本身）。
 */

const listEl = document.getElementById("video-list");
const emptyStateEl = document.getElementById("empty-state");
const refreshBtn = document.getElementById("refresh-btn");
const optionsLink = document.getElementById("options-link");

const ytdlpStatusEl = document.getElementById("ytdlp-status");
const ytdlpDownloadBtn = document.getElementById("ytdlp-download-btn");
const ytdlpResultEl = document.getElementById("ytdlp-result");

const shortcutTextEl = document.getElementById("shortcut-text");
const shortcutChangeLink = document.getElementById("shortcut-change-link");

/** 獨立視窗模式帶入的來源分頁 ID；工具列 popup 模式為 null。 */
const TARGET_TAB_ID = (() => {
  const value = Number(new URLSearchParams(location.search).get("tabId"));
  return Number.isInteger(value) && value > 0 ? value : null;
})();

function loadVideos() {
  browser.runtime
    .sendMessage({ type: "GET_VIDEOS_FOR_ACTIVE_TAB", tabId: TARGET_TAB_ID })
    .then((response) => {
      renderVideos((response && response.videos) || []);
    });
}

function renderVideos(videos) {
  listEl.innerHTML = "";

  if (videos.length === 0) {
    emptyStateEl.style.display = "block";
    return;
  }

  emptyStateEl.style.display = "none";

  videos.forEach((video, index) => {
    const li = document.createElement("li");
    li.className = "video-item";

    const meta = document.createElement("div");
    meta.className = "video-meta";
    meta.textContent = buildMetaText(video);

    const actions = document.createElement("div");
    actions.className = "video-actions";

    const downloadBtn = document.createElement("button");
    downloadBtn.type = "button";
    downloadBtn.className = "download-btn";
    downloadBtn.textContent = "下載";
    downloadBtn.addEventListener("click", () => {
      handleDownload(video, index, downloadBtn);
    });

    actions.appendChild(downloadBtn);
    li.appendChild(meta);
    li.appendChild(actions);
    listEl.appendChild(li);
  });
}

function buildMetaText(video) {
  const parts = [];
  if (video.guessedExt && video.guessedExt !== "unknown") {
    parts.push(video.guessedExt.toUpperCase());
  }
  if (video.width && video.height) {
    parts.push(`${video.width}×${video.height}`);
  }
  if (video.duration) {
    parts.push(formatDuration(video.duration));
  }
  return parts.length > 0 ? parts.join(" · ") : video.url;
}

function formatDuration(seconds) {
  const total = Math.round(seconds);
  const m = Math.floor(total / 60);
  const s = total % 60;
  return `${m}:${String(s).padStart(2, "0")}`;
}

function handleDownload(video, index, buttonEl) {
  buttonEl.disabled = true;
  buttonEl.textContent = "下載中...";

  const filename = suggestFilename(video, index);

  browser.runtime
    .sendMessage({
      type: "DOWNLOAD_VIDEO",
      url: video.url,
      filename
    })
    .then((result) => {
      if (result && result.ok) {
        buttonEl.textContent = "已加入下載";
      } else {
        buttonEl.textContent = "失敗";
        buttonEl.disabled = false;
      }
    });
}

function suggestFilename(video, index) {
  const safeTitle = (video.pageTitle || "video")
    .replace(/[\\/:*?"<>|]/g, "_")
    .slice(0, 60);
  const ext = video.guessedExt !== "unknown" ? video.guessedExt : "mp4";
  return `${safeTitle}-${index + 1}.${ext}`;
}

refreshBtn.addEventListener("click", loadVideos);

optionsLink.addEventListener("click", (event) => {
  event.preventDefault();
  browser.runtime.openOptionsPage();
});

// ---- 進階下載（透過 Native Messaging 呼叫本機 yt-dlp）--------------------

function checkYtdlpAvailability() {
  ytdlpStatusEl.textContent = "檢查本機 yt-dlp 狀態中...";
  ytdlpStatusEl.className = "ytdlp-status";

  browser.runtime
    .sendMessage({ type: "YTDLP_CHECK_AVAILABLE" })
    .then((response) => {
      if (response && response.ytdlpAvailable) {
        ytdlpStatusEl.textContent = response.ffmpegAvailable
          ? "已偵測到本機 yt-dlp 與 ffmpeg。"
          : "已偵測到本機 yt-dlp（未偵測到 ffmpeg，部分格式可能無法合併）。";
        ytdlpStatusEl.classList.add("available");
        ytdlpDownloadBtn.disabled = false;
      } else {
        const reason = response && response.error ? `（${response.error}）` : "";
        ytdlpStatusEl.textContent = `找不到本機 yt-dlp host${reason}，請從 YTGrab 的「Firefox 外掛」按鍵啟動（會自動完成註冊）。`;
        ytdlpStatusEl.classList.add("unavailable");
        ytdlpDownloadBtn.disabled = true;
      }
    })
    .catch((error) => {
      ytdlpStatusEl.textContent = `檢查失敗：${error.message}`;
      ytdlpStatusEl.classList.add("unavailable");
      ytdlpDownloadBtn.disabled = true;
    });
}

/** 讀取使用者在「影片 MP4／音訊 MP3／音訊 M4A」單選鈕中選擇的輸出格式。 */
function getSelectedOutputFormat() {
  const checked = document.querySelector('input[name="output-format"]:checked');
  return checked ? checked.value : "video-mp4";
}

/** 取得要下載的分頁網址：獨立視窗模式用帶入的 tabId，否則用目前視窗的作用中分頁。 */
function getActiveTabUrl() {
  if (TARGET_TAB_ID !== null) {
    return browser.tabs
      .get(TARGET_TAB_ID)
      .then((tab) => tab.url || null)
      .catch(() => {
        throw new Error("來源分頁已關閉，請重新按快捷鍵開啟");
      });
  }
  return browser.tabs
    .query({ active: true, currentWindow: true })
    .then((tabs) => (tabs.length > 0 ? tabs[0].url : null));
}

function handleYtdlpDownload() {
  ytdlpResultEl.textContent = "";
  ytdlpResultEl.className = "ytdlp-result";
  ytdlpDownloadBtn.disabled = true;
  ytdlpDownloadBtn.textContent = "下載中...（可關閉此視窗，完成後會通知）";

  const outputFormat = getSelectedOutputFormat();
  console.log("[popup] YTDLP_DOWNLOAD 送出", { outputFormat, tabId: TARGET_TAB_ID });

  getActiveTabUrl()
    .then((url) => {
      if (!url) {
        throw new Error("無法取得目前分頁網址");
      }
      return browser.runtime.sendMessage({
        type: "YTDLP_DOWNLOAD",
        url,
        outputFormat,
        tabId: TARGET_TAB_ID
      });
    })
    .then((result) => {
      console.log("[popup] YTDLP_DOWNLOAD 回應", result);
      if (result && result.ok) {
        ytdlpResultEl.textContent = `下載完成，已儲存至：${result.outputDir}`;
        ytdlpResultEl.classList.add("ok");
      } else {
        const message = (result && result.error) || "下載失敗（未知錯誤）";
        ytdlpResultEl.textContent = message;
        ytdlpResultEl.classList.add("error");
      }
    })
    .catch((error) => {
      ytdlpResultEl.textContent = error.message;
      ytdlpResultEl.classList.add("error");
    })
    .finally(() => {
      ytdlpDownloadBtn.disabled = false;
      ytdlpDownloadBtn.textContent = "分析並下載目前頁面";
    });
}

ytdlpDownloadBtn.addEventListener("click", handleYtdlpDownload);

// ---- 還原背景下載狀態（popup 關閉後重新開啟時）---------------------------

let statusTimer = null;
let wasActive = false;

function renderDownloadStatus(status) {
  if (!status) return;

  if (status.active) {
    wasActive = true;
    ytdlpDownloadBtn.disabled = true;
    ytdlpDownloadBtn.textContent = "背景下載中...（可關閉此視窗）";
    if (!statusTimer) {
      statusTimer = setInterval(syncDownloadStatus, 2000);
    }
    return;
  }

  if (statusTimer) {
    clearInterval(statusTimer);
    statusTimer = null;
  }
  if (wasActive) {
    wasActive = false;
    ytdlpDownloadBtn.disabled = false;
  }
  ytdlpDownloadBtn.textContent = "分析並下載目前頁面";

  // 顯示 30 分鐘內的最近一次結果（避免蓋掉本次操作剛顯示的訊息）
  const last = status.last;
  if (last && Date.now() - last.finishedAt < 30 * 60 * 1000 && !ytdlpResultEl.textContent) {
    ytdlpResultEl.textContent = last.ok
      ? `上次下載完成。${last.message}`
      : `上次下載失敗：${last.message}`;
    ytdlpResultEl.className = `ytdlp-result ${last.ok ? "ok" : "error"}`;
  }
}

function syncDownloadStatus() {
  browser.runtime
    .sendMessage({ type: "YTDLP_GET_STATUS" })
    .then(renderDownloadStatus)
    .catch(() => {});
}

// ---- 快捷鍵說明 ----------------------------------------------------------

const IS_MAC = /Mac/i.test(navigator.platform || navigator.userAgent);

/** 把 Firefox 回傳的快捷鍵字串（如 "MacCtrl+Shift+Y"）轉成使用者看得懂的鍵名。 */
function prettyShortcut(shortcut) {
  return shortcut
    .split("+")
    .map((key) => {
      if (IS_MAC) {
        if (key === "MacCtrl") return "Control";
        if (key === "Ctrl") return "Command";
        if (key === "Alt") return "Option";
      }
      return key;
    })
    .join(" + ");
}

function renderShortcutHint() {
  const render = (shortcut) => {
    shortcutTextEl.textContent = "";
    if (shortcut) {
      shortcutTextEl.append("快捷鍵 ");
      const kbd = document.createElement("kbd");
      kbd.textContent = prettyShortcut(shortcut);
      shortcutTextEl.append(kbd, " 可開啟此視窗。");
    } else {
      shortcutTextEl.textContent = "尚未設定快捷鍵，可在下方自訂。";
    }
  };

  browser.runtime
    .sendMessage({ type: "GET_SHORTCUT" })
    .then((response) => {
      if (!response) {
        shortcutTextEl.textContent =
          "background.js 沒有回應（可能還是舊版，請換成新版並重新載入擴充功能）。";
        return;
      }
      if (response.error) {
        shortcutTextEl.textContent = `無法讀取快捷鍵：${response.error}`;
        return;
      }
      render(response.shortcut);
    })
    .catch(() => {
      shortcutTextEl.textContent = "無法讀取快捷鍵設定。";
    });
}

shortcutChangeLink.addEventListener("click", (event) => {
  event.preventDefault();
  browser.runtime
    .sendMessage({ type: "OPEN_SHORTCUT_SETTINGS" })
    .then((result) => {
      if (!result || !result.ok) showShortcutFallback();
    })
    .catch(() => showShortcutFallback());
});

function showShortcutFallback() {
  shortcutTextEl.textContent =
    "請到 about:addons → 齒輪 → 管理擴充功能快捷鍵 修改。";
}

document.addEventListener("DOMContentLoaded", () => {
  renderShortcutHint();
  loadVideos();
  checkYtdlpAvailability();
  syncDownloadStatus();
});

/**
 * background.js
 * 常駐背景腳本：
 * 1. 接收來自 content script 的「偵測到影片」訊息，暫存於各分頁對應的清單。
 * 2. 接收來自 popup 的「下載」請求，透過 downloads API 觸發下載
 *    （僅處理頁面 DOM 中直接暴露的影片網址）。
 * 3. 接收來自 popup 的「進階下載」請求，透過 Native Messaging 呼叫本機
 *    host.py，再由它呼叫 yt-dlp（請從 YTGrab 的「Firefox 外掛」按鍵啟動，
 *    會自動完成 host 註冊）。
 * 4. 進階下載的狀態由本腳本負責追蹤：即使 popup 已關閉，仍會更新工具列徽章
 *    （… 下載中／✓ 完成／! 失敗）並發出系統通知。
 * 5. 快捷鍵（commands: open-popup）：一般視窗直接開啟工具列 popup；
 *    若視窗沒有工具列（例如網頁開出的彈出視窗），改開獨立的小視窗。
 *
 * 注意：本腳本本身不會嘗試繞過任何平台的 DRM 或授權保護機制；
 * 進階下載是否合法，取決於使用者對該網址內容的實際權利與該平台服務條款。
 */

const NATIVE_HOST_NAME = "com.example.ytdlp";

const BADGE_COLOR_VIDEOS = "#2b7de9";
const BADGE_COLOR_BUSY = "#e69500";
const BADGE_COLOR_OK = "#2e9e4f";
const BADGE_COLOR_ERROR = "#d93025";

// 獨立小視窗（後備方案）的尺寸
const STANDALONE_WIDTH = 440;
const STANDALONE_HEIGHT = 680;

// 分頁 ID -> 偵測到的影片清單
const tabVideoMap = new Map();

// ---- 進階下載狀態（popup 關閉後仍保留）------------------------------------

// 進行中的 yt-dlp 下載數量
let activeDownloads = 0;
// 最近一次 yt-dlp 下載結果：{ ok, message, title, finishedAt }
let lastDownloadResult = null;
// 下載期間要蓋過「影片數量」的徽章：tabId -> true
const badgeOverride = new Map();

// ---- Native Messaging（與本機 yt-dlp host 通訊）--------------------------

let nativePort = null;
// FIFO 佇列：host.py 採一收一送、依序處理，因此用佇列依序比對回應與請求
let pendingNativeRequests = [];

function getNativePort() {
  if (nativePort) return nativePort;

  nativePort = browser.runtime.connectNative(NATIVE_HOST_NAME);

  nativePort.onMessage.addListener((response) => {
    const pending = pendingNativeRequests.shift();
    if (pending) pending.resolve(response);
  });

  nativePort.onDisconnect.addListener(() => {
    const error = browser.runtime.lastError
      ? browser.runtime.lastError.message
      : "Native host 已中斷連線（請從 YTGrab 的「Firefox 外掛」按鍵啟動，會自動完成註冊）";

    // 連線中斷時，讓所有還在等待的請求都收到錯誤，避免卡死
    pendingNativeRequests.forEach((pending) => pending.reject(new Error(error)));
    pendingNativeRequests = [];
    nativePort = null;
  });

  return nativePort;
}

function sendNativeRequest(message) {
  return new Promise((resolve, reject) => {
    let port;
    try {
      port = getNativePort();
    } catch (error) {
      reject(error);
      return;
    }
    pendingNativeRequests.push({ resolve, reject });
    port.postMessage(message);
  });
}

// ---- 訊息路由 ------------------------------------------------------------

browser.runtime.onMessage.addListener((message, sender) => {
  const tabId = sender.tab ? sender.tab.id : null;

  switch (message.type) {
    case "VIDEOS_DETECTED": {
      if (tabId !== null) {
        tabVideoMap.set(tabId, message.videos || []);
        updateBadge(tabId, message.videos ? message.videos.length : 0);
      }
      return Promise.resolve({ ok: true });
    }

    case "GET_VIDEOS_FOR_ACTIVE_TAB": {
      // 獨立視窗模式下，popup 會帶上來源分頁 ID（message.tabId）
      return getActiveTabId(message.tabId).then((activeTabId) => {
        return {
          tabId: activeTabId,
          videos: tabVideoMap.get(activeTabId) || []
        };
      });
    }

    case "DOWNLOAD_VIDEO": {
      return downloadVideo(message.url, message.filename);
    }

    case "YTDLP_CHECK_AVAILABLE": {
      // host.py 一次只處理一件事；下載進行中若再送檢查請求，會排在下載後面
      // 卡到下載結束。下載能開始就代表 yt-dlp 可用，直接回覆即可。
      if (activeDownloads > 0) {
        return Promise.resolve({
          type: "CHECK_AVAILABLE_RESULT",
          ytdlpAvailable: true,
          ffmpegAvailable: true
        });
      }
      return sendNativeRequest({ type: "CHECK_AVAILABLE" }).catch((error) => ({
        type: "CHECK_AVAILABLE_RESULT",
        ytdlpAvailable: false,
        ffmpegAvailable: false,
        error: error.message
      }));
    }

    case "YTDLP_GET_INFO": {
      return sendNativeRequest({
        type: "GET_INFO",
        url: message.url
      }).catch((error) => ({
        type: "INFO_RESULT",
        ok: false,
        error: error.message
      }));
    }

    case "YTDLP_GET_STATUS": {
      // popup 重新開啟時用來還原畫面：是否有下載進行中、上一次的結果
      return Promise.resolve({
        active: activeDownloads > 0,
        last: lastDownloadResult
      });
    }

    case "YTDLP_DOWNLOAD": {
      return startYtdlpDownload(message);
    }

    case "GET_SHORTCUT": {
      // browser.commands 在 popup 頁面不可用，改由 background 讀取後回傳
      if (!browser.commands || !browser.commands.getAll) {
        return Promise.resolve({
          shortcut: "",
          error: "manifest.json 沒有 commands 設定（請換成新版 manifest 並重新載入）"
        });
      }
      return browser.commands
        .getAll()
        .then((commands) => {
          const cmd = commands.find((c) => c.name === "open-popup");
          if (!cmd) {
            return { shortcut: "", error: "找不到 open-popup 指令（manifest 的 commands 名稱不符）" };
          }
          return { shortcut: cmd.shortcut || "" };
        })
        .catch((error) => ({ shortcut: "", error: error.message }));
    }

    case "OPEN_SHORTCUT_SETTINGS": {
      if (browser.commands && browser.commands.openShortcutSettings) {
        return browser.commands
          .openShortcutSettings()
          .then(() => ({ ok: true }))
          .catch((error) => ({ ok: false, error: error.message }));
      }
      return Promise.resolve({ ok: false });
    }

    default:
      return undefined;
  }
});

// ---- 快捷鍵：開啟 popup（沒有工具列時改開獨立視窗）------------------------

// 目前開著的獨立小視窗 ID（避免重複開啟）
let standaloneWindowId = null;

browser.windows.onRemoved.addListener((windowId) => {
  if (windowId === standaloneWindowId) standaloneWindowId = null;
});

browser.commands.onCommand.addListener((command, tab) => {
  if (command !== "open-popup") return;

  // openPopup 必須在使用者操作的同步呼叫鏈中執行，所以先不要 await 任何東西。
  // 一般視窗：成功就直接顯示工具列 popup。
  // 沒有工具列的視窗（popup／app 類型視窗）：會被拒絕，改走後備方案。
  let attempt;
  try {
    attempt = Promise.resolve(browser.browserAction.openPopup());
  } catch (error) {
    attempt = Promise.reject(error);
  }

  attempt.catch(() => openStandaloneWindow(tab));
});

/**
 * 後備方案：開一個獨立的小視窗顯示 popup 頁面，並把來源分頁 ID 帶進去。
 * 若按快捷鍵時焦點就在這個獨立視窗上，視為「切換」，直接關閉它。
 */
async function openStandaloneWindow(commandTab) {
  try {
    const popupUrl = browser.runtime.getURL("popup/popup.html");

    // 找出使用者目前正在看的分頁
    let target = commandTab;
    if (!target || (target.url && target.url.startsWith(popupUrl))) {
      const tabs = await browser.tabs.query({ active: true, lastFocusedWindow: true });
      target = tabs[0] || null;
    }

    // 焦點在獨立視窗本身：關閉它（切換行為）
    if (target && target.url && target.url.startsWith(popupUrl)) {
      await browser.windows.remove(target.windowId);
      return;
    }

    // 已經開著：關掉舊的，用新的來源分頁重新開
    if (standaloneWindowId !== null) {
      await browser.windows.remove(standaloneWindowId).catch(() => {});
      standaloneWindowId = null;
    }

    const url = target ? `${popupUrl}?tabId=${target.id}` : popupUrl;
    const created = await browser.windows.create({
      url,
      type: "popup",
      width: STANDALONE_WIDTH,
      height: STANDALONE_HEIGHT
    });
    standaloneWindowId = created.id;
  } catch (error) {
    console.error("[background] 開啟獨立視窗失敗", error);
  }
}

// ---- 進階下載：背景追蹤 + 徽章 + 通知 --------------------------------------

async function startYtdlpDownload(message) {
  // 獨立視窗模式下，來源分頁由 popup 帶入（message.tabId）
  const tabId = await getActiveTabId(message.tabId).catch(() => null);
  const title = await getTabTitle(tabId);

  const nativeRequest = {
    type: "DOWNLOAD",
    url: message.url,
    outputDir: message.outputDir,
    format: message.format,
    // "video-mp4" | "audio-mp3" | "audio-m4a"，由 host.py 轉成對應的 yt-dlp 參數
    outputFormat: message.outputFormat
  };
  console.log("[background] 轉發給 Native Host", nativeRequest);

  activeDownloads += 1;
  lastDownloadResult = null;
  if (tabId !== null) setDownloadBadge(tabId, "…", BADGE_COLOR_BUSY);

  let response;
  try {
    response = await sendNativeRequest(nativeRequest);
    console.log("[background] Native Host 回應", response);
  } catch (error) {
    console.error("[background] Native Host 呼叫失敗", error);
    response = { type: "DOWNLOAD_RESULT", ok: false, error: error.message };
  } finally {
    activeDownloads -= 1;
  }

  const ok = Boolean(response && response.ok);
  const detail = ok
    ? `已儲存至：${response.outputDir}`
    : summarizeError(response && response.error);

  lastDownloadResult = { ok, message: detail, title, finishedAt: Date.now() };

  if (tabId !== null) {
    setDownloadBadge(tabId, ok ? "✓" : "!", ok ? BADGE_COLOR_OK : BADGE_COLOR_ERROR);
    // 成功 10 秒後、失敗 30 秒後，徽章恢復成影片數量
    setTimeout(() => clearDownloadBadge(tabId), ok ? 10000 : 30000);
  }
  notifyDownloadResult(ok, title, detail);

  return response;
}

function notifyDownloadResult(ok, title, detail) {
  if (!browser.notifications) return;
  const body = title ? `${shorten(title, 60)}\n${detail}` : detail;
  browser.notifications
    .create(`ytdlp-${Date.now()}`, {
      type: "basic",
      iconUrl: browser.runtime.getURL("icons/icon-128.png"),
      title: ok ? "下載完成" : "下載失敗",
      message: body
    })
    .catch((error) => console.warn("[background] 通知失敗", error));
}

/** 從 yt-dlp 的 stderr 取出最後一行 ERROR，太長就截短。 */
function summarizeError(text) {
  if (!text) return "未知錯誤";
  const lines = String(text)
    .split("\n")
    .map((line) => line.trim())
    .filter(Boolean);
  const errorLine =
    [...lines].reverse().find((line) => line.includes("ERROR")) ||
    lines[lines.length - 1] ||
    "未知錯誤";
  return shorten(errorLine, 150);
}

function shorten(text, max) {
  return text.length > max ? `${text.slice(0, max - 1)}…` : text;
}

function getTabTitle(tabId) {
  if (tabId === null || tabId === undefined) return Promise.resolve("");
  return browser.tabs
    .get(tabId)
    .then((tab) => tab.title || "")
    .catch(() => "");
}

// ---- 分頁事件 ------------------------------------------------------------

// 分頁關閉時清除暫存資料，避免記憶體累積
browser.tabs.onRemoved.addListener((tabId) => {
  tabVideoMap.delete(tabId);
  badgeOverride.delete(tabId);
});

// 分頁重新導向 / 重新整理時清除舊資料
browser.webNavigation.onCommitted.addListener((details) => {
  if (details.frameId === 0) {
    tabVideoMap.delete(details.tabId);
    updateBadge(details.tabId, 0);
  }
});

/**
 * 取得目標分頁 ID。
 * 有指定 preferredTabId（獨立視窗模式）且該分頁還在時優先使用；
 * 否則退回「目前視窗的作用中分頁」。
 */
function getActiveTabId(preferredTabId) {
  if (Number.isInteger(preferredTabId) && preferredTabId > 0) {
    return browser.tabs
      .get(preferredTabId)
      .then((tab) => tab.id)
      .catch(() => queryActiveTabId());
  }
  return queryActiveTabId();
}

function queryActiveTabId() {
  return browser.tabs
    .query({ active: true, currentWindow: true })
    .then((tabs) => (tabs.length > 0 ? tabs[0].id : null));
}

// ---- 徽章 ----------------------------------------------------------------

function applyBadge(tabId, text, color) {
  Promise.resolve(browser.browserAction.setBadgeText({ tabId, text })).catch(() => {});
  Promise.resolve(
    browser.browserAction.setBadgeBackgroundColor({ tabId, color })
  ).catch(() => {});
}

/** 影片數量徽章；該分頁正在顯示下載狀態時不覆蓋。 */
function updateBadge(tabId, count) {
  if (badgeOverride.has(tabId)) return;
  applyBadge(tabId, count > 0 ? String(count) : "", BADGE_COLOR_VIDEOS);
}

function setDownloadBadge(tabId, text, color) {
  badgeOverride.set(tabId, true);
  applyBadge(tabId, text, color);
}

function clearDownloadBadge(tabId) {
  badgeOverride.delete(tabId);
  const count = (tabVideoMap.get(tabId) || []).length;
  applyBadge(tabId, count > 0 ? String(count) : "", BADGE_COLOR_VIDEOS);
}

// ---- 一般下載（downloads API）---------------------------------------------

function downloadVideo(url, filename) {
  return browser.downloads
    .download({
      url,
      filename,
      saveAs: false
    })
    .then((downloadId) => ({ ok: true, downloadId }))
    .catch((error) => ({ ok: false, error: error.message }));
}

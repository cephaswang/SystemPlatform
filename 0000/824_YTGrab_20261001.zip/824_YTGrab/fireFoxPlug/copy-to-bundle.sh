#!/usr/bin/env bash
# Xcode Run Script 呼叫：把外掛與 host 複製進 App 的 Contents/Resources/FirefoxPlugin/
# 只複製必要檔案，排除 node_modules、打包產物、Windows 腳本等。
set -euo pipefail

SRC="$SRCROOT/fireFoxPlug"
DEST="$TARGET_BUILD_DIR/$UNLOCALIZED_RESOURCES_FOLDER_PATH/FirefoxPlugin"
mkdir -p "$DEST"

rsync -a --delete \
  --exclude '.DS_Store' --exclude 'node_modules' --exclude 'web-ext-artifacts' \
  --exclude 'package*.json' --exclude 'web-ext-config.cjs' --exclude 'README.md' \
  "$SRC/extension/" "$DEST/extension/"

rsync -a --delete \
  --exclude '.DS_Store' --exclude '*.bat' --exclude '*.ps1' --exclude 'install.sh' \
  --exclude 'host.log' --exclude 'host_config.json' \
  "$SRC/host/" "$DEST/host/"

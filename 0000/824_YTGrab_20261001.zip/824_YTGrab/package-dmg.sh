#!/usr/bin/env bash
#
# package-dmg.sh — YTGrab（含 Firefox 外掛）獨立分發版 DMG 打包
#
# 放在專案根目錄（與 YTGrab.xcodeproj、fireFoxPlug 同層）。
#
# 三種模式：
#   bash package-dmg.sh                 未簽章（ad-hoc）DMG，自己測試用
#   bash package-dmg.sh --sign          Developer ID 簽章（Hardened Runtime），不公證
#   bash package-dmg.sh --notarize      簽章 + 公證 + staple，可對外發布
#
# 選項：
#   --clean     先刪除 build/ 內的舊 archive 與暫存
#
# 環境變數（皆可省略）：
#   SIGN_IDENTITY   簽章身分，例如 "Developer ID Application: Your Name (TEAMID)"
#                   省略時自動使用鑰匙圈中第一個 Developer ID Application
#   NOTARY_PROFILE  notarytool 的鑰匙圈設定檔名稱（--notarize 必填）。第一次先建立：
#                     xcrun notarytool store-credentials "YTGrab-notary" \
#                       --apple-id "you@example.com" --team-id "TEAMID" \
#                       --password "app-specific-password"
#                   之後 NOTARY_PROFILE=YTGrab-notary
#   SCHEME          預設 YTGrab
#   CONFIGURATION   預設 Release
#
# 產出：build/YTGrab.dmg
#
# 注意：此腳本是「獨立分發（DMG）」專用。上架 App Store 請用 scripts/build-appstore.sh。

set -euo pipefail

# ---------------------------------------------------------------------------
# 參數
# ---------------------------------------------------------------------------
MODE="unsigned"
DO_CLEAN=0
for arg in "$@"; do
  case "$arg" in
    --sign)      [[ "$MODE" == "notarize" ]] || MODE="sign" ;;
    --notarize)  MODE="notarize" ;;
    --clean)     DO_CLEAN=1 ;;
    -h|--help)   sed -n '2,32p' "$0"; exit 0 ;;
    *) echo "未知參數：${arg}（可用：--sign --notarize --clean）"; exit 1 ;;
  esac
done

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"

SCHEME="${SCHEME:-YTGrab}"
CONFIGURATION="${CONFIGURATION:-Release}"
PROJECT="YTGrab.xcodeproj"
BUILD_DIR="$ROOT/build"
ARCHIVE="$BUILD_DIR/YTGrab.xcarchive"
STAGING="$BUILD_DIR/dmg-staging"
DMG="$BUILD_DIR/YTGrab.dmg"
APP_NAME="YTGrab.app"
WORK_APP="$BUILD_DIR/$APP_NAME"
TMP_ENT="$BUILD_DIR/helpers.entitlements"

step() { echo; echo "==> $*"; }
fail() { echo "錯誤：$*" >&2; exit 1; }
warn() { echo "警告：$*" >&2; }

# ---------------------------------------------------------------------------
# 前置檢查
# ---------------------------------------------------------------------------
step "前置檢查（模式：${MODE}）"

[[ -d "$PROJECT" ]] || fail "找不到 ${PROJECT}，請把腳本放在專案根目錄。"
[[ -x fireFoxPlug/copy-to-bundle.sh ]] || fail "找不到可執行的 fireFoxPlug/copy-to-bundle.sh（先執行 apply-firefox-plugin.sh）。"
command -v xcodebuild >/dev/null || fail "找不到 xcodebuild，請安裝 Xcode。"
command -v hdiutil >/dev/null || fail "找不到 hdiutil。"

IDENTITY="-"
if [[ "$MODE" != "unsigned" ]]; then
  IDENTITY="${SIGN_IDENTITY:-}"
  if [[ -z "$IDENTITY" ]]; then
    IDENTITY="$(security find-identity -v -p codesigning \
      | awk -F'"' '/Developer ID Application/ {print $2; exit}')"
  fi
  [[ -n "$IDENTITY" ]] || fail "鑰匙圈找不到「Developer ID Application」憑證，請安裝或設定 SIGN_IDENTITY。"
  echo "   簽章身分：$IDENTITY"
fi
if [[ "$MODE" == "notarize" ]]; then
  [[ -n "${NOTARY_PROFILE:-}" ]] || fail "--notarize 需要設定 NOTARY_PROFILE（見腳本開頭說明）。"
  xcrun notarytool --version >/dev/null 2>&1 || fail "找不到 notarytool（需要 Xcode 13 以上）。"
fi

BUILD_SETTINGS="$(xcodebuild -project "$PROJECT" -scheme "$SCHEME" -configuration "$CONFIGURATION" \
  -showBuildSettings 2>/dev/null || true)"
[[ -n "$BUILD_SETTINGS" ]] || fail "讀不到 scheme「${SCHEME}」的建置設定，請確認 scheme 名稱（可用 SCHEME=... 指定）。"

setting() {
  printf '%s\n' "$BUILD_SETTINGS" | awk -F' = ' -v k="$1" '$1 ~ "^ *"k"$" {v=$2} END {print v}'
}

# 獨立分發版不能是 APPSTORE 編譯條件，否則 Firefox 外掛功能會被整個排除
CONDITIONS="$(setting SWIFT_ACTIVE_COMPILATION_CONDITIONS)"
if [[ " $CONDITIONS " == *" APPSTORE "* ]]; then
  fail "$CONFIGURATION 設定含有 APPSTORE 編譯條件，Firefox 外掛功能會被排除。請改用不含 APPSTORE 的 Configuration。"
fi

# 有指定 entitlements 檔時，確認沒有開啟 App Sandbox
APP_ENT=""
ENT_REL="$(setting CODE_SIGN_ENTITLEMENTS)"
if [[ -n "$ENT_REL" && -f "$ROOT/$ENT_REL" ]]; then
  APP_ENT="$ROOT/$ENT_REL"
  if [[ "$(/usr/libexec/PlistBuddy -c 'Print :com.apple.security.app-sandbox' "$APP_ENT" 2>/dev/null || true)" == "true" ]]; then
    fail "$ENT_REL 啟用了 App Sandbox，Firefox 外掛無法運作。請在 DMG 版移除 App Sandbox。"
  fi
  echo "   App entitlements：$ENT_REL"
fi

# ---------------------------------------------------------------------------
# 建置（一律先以未簽章建置，之後手動簽章，流程單純可控）
# ---------------------------------------------------------------------------
step "建置 Archive"
mkdir -p "$BUILD_DIR"
if [[ $DO_CLEAN -eq 1 ]]; then
  rm -rf "$ARCHIVE" "$STAGING" "$WORK_APP" "$DMG" "$TMP_ENT"
fi
rm -rf "$ARCHIVE" "$STAGING" "$WORK_APP" "$TMP_ENT"

xcodebuild archive \
  -project "$PROJECT" \
  -scheme "$SCHEME" \
  -configuration "$CONFIGURATION" \
  -archivePath "$ARCHIVE" \
  CODE_SIGNING_ALLOWED=NO \
  CODE_SIGNING_REQUIRED=NO \
  CODE_SIGN_IDENTITY="" \
  ENABLE_APP_SANDBOX=NO \
  ENABLE_USER_SCRIPT_SANDBOXING=NO \
  | tail -n 25

SRC_APP="$ARCHIVE/Products/Applications/$APP_NAME"
[[ -d "$SRC_APP" ]] || fail "Archive 內找不到 ${APP_NAME}（${SRC_APP}）。"
ditto "$SRC_APP" "$WORK_APP"
APP="$WORK_APP"

# ---------------------------------------------------------------------------
# 驗證 App 內容（Firefox 外掛、Helpers、多餘檔案）
# ---------------------------------------------------------------------------
step "驗證 App 內容"
RES="$APP/Contents/Resources"
PLUGIN="$RES/FirefoxPlugin"

check_file() { [[ -f "$1" ]] || fail "缺少 ${1#$APP/}"; }
check_file "$PLUGIN/extension/manifest.json"
check_file "$PLUGIN/extension/background/background.js"
check_file "$PLUGIN/extension/popup/popup.js"
check_file "$PLUGIN/host/host.py"
check_file "$PLUGIN/host/com.example.ytdlp.json"
echo "   ✓ FirefoxPlugin/{extension,host} 完整"

# Native host 設定檔的外掛 ID 必須與 manifest 一致
EXT_ID="$(plutil -extract browser_specific_settings.gecko.id raw -o - "$PLUGIN/extension/manifest.json" 2>/dev/null || true)"
[[ -n "$EXT_ID" ]] || fail "manifest.json 讀不到 browser_specific_settings.gecko.id。"
if ! grep -q "\"$EXT_ID\"" "$PLUGIN/host/com.example.ytdlp.json"; then
  fail "外掛 ID（${EXT_ID}）不在 com.example.ytdlp.json 的 allowed_extensions 內。"
fi
echo "   ✓ 外掛 ID 一致：$EXT_ID"

# 不該出現的檔案
for junk in package.json package-lock.json web-ext-config.cjs README.md; do
  [[ ! -e "$PLUGIN/extension/$junk" ]] || fail "外掛內含不該打包的檔案：${junk}（檢查 copy-to-bundle.sh）"
done
if [[ -n "$(find "$PLUGIN" \( -name "*.bat" -o -name "*.ps1" -o -name "install.sh" -o -name ".DS_Store" \))" ]]; then
  fail "FirefoxPlugin 內含 Windows 腳本、install.sh 或 .DS_Store（檢查 copy-to-bundle.sh）"
fi
echo "   ✓ 沒有多餘檔案"

# 資源根層不應有被攤平的外掛檔案（fireFoxPlug 被誤加入 Copy Bundle Resources 的徵兆）
for stray in messages.json manifest.json popup.js background.js; do
  [[ ! -e "$RES/$stray" ]] || fail "Resources 根層出現 ${stray}，fireFoxPlug 疑似被加入 Copy Bundle Resources。"
done

if [[ -n "$(find "$RES" \( -name "*企劃案*" -o -name "*.md" \))" ]]; then
  warn "Resources 內含 .md／企劃案文件，正式發布前建議自 Copy Bundle Resources 移除。"
fi

HELPERS="$APP/Contents/Helpers"
if [[ -d "$HELPERS" ]]; then
  for tool in yt-dlp ffmpeg; do
    if [[ -x "$HELPERS/$tool" || -x "$HELPERS/${tool}_macos" ]]; then
      echo "   ✓ Helpers/$tool"
    else
      warn "Helpers 內找不到 ${tool}，App 需仰賴使用者自行指定路徑。"
    fi
  done
else
  warn "找不到 Contents/Helpers，yt-dlp／ffmpeg 未內建。"
fi

# ---------------------------------------------------------------------------
# 簽章
# ---------------------------------------------------------------------------
# 內建的 yt-dlp（PyInstaller）、deno（V8）在 Hardened Runtime 下需要這些例外
cat > "$TMP_ENT" <<'PLIST'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>com.apple.security.cs.allow-jit</key><true/>
  <key>com.apple.security.cs.allow-unsigned-executable-memory</key><true/>
  <key>com.apple.security.cs.disable-library-validation</key><true/>
</dict>
</plist>
PLIST

sign_file() {   # sign_file <檔案> [entitlements]
  local f="$1" ent="${2:-}"
  if [[ "$MODE" == "unsigned" ]]; then
    codesign --force --sign - "$f"
  elif [[ -n "$ent" ]]; then
    codesign --force --timestamp --options runtime --entitlements "$ent" --sign "$IDENTITY" "$f"
  else
    codesign --force --timestamp --options runtime --sign "$IDENTITY" "$f"
  fi
}

step "簽章內部執行檔（由內而外）"
MAIN_EXEC="$APP/Contents/MacOS/YTGrab"
COUNT=0
while IFS= read -r -d '' f; do
  [[ "$f" == "$MAIN_EXEC" ]] && continue
  if [[ "$(file -b "$f")" == *Mach-O* ]]; then
    if [[ "$f" == "$HELPERS/"* ]]; then
      sign_file "$f" "$TMP_ENT"
    else
      sign_file "$f"
    fi
    echo "   已簽章：${f#$APP/}"
    COUNT=$((COUNT + 1))
  fi
done < <(find "$APP/Contents" -type f -print0)
echo "   共 $COUNT 個"

step "簽章 App 本體"
sign_file "$APP" "$APP_ENT"
codesign --verify --deep --strict --verbose=2 "$APP"

# ---------------------------------------------------------------------------
# 公證（App）
# ---------------------------------------------------------------------------
notarize() {   # notarize <zip 或 dmg>
  xcrun notarytool submit "$1" --keychain-profile "$NOTARY_PROFILE" --wait
}

if [[ "$MODE" == "notarize" ]]; then
  step "公證 App（通常需要數分鐘）"
  APP_ZIP="$BUILD_DIR/YTGrab-notary.zip"
  rm -f "$APP_ZIP"
  ditto -c -k --keepParent "$APP" "$APP_ZIP"
  notarize "$APP_ZIP"
  rm -f "$APP_ZIP"
  xcrun stapler staple "$APP"
fi

# ---------------------------------------------------------------------------
# 製作 DMG
# ---------------------------------------------------------------------------
step "製作 DMG"
rm -rf "$STAGING" "$DMG"
mkdir -p "$STAGING"
ditto "$APP" "$STAGING/$APP_NAME"
ln -s /Applications "$STAGING/Applications"
hdiutil create -volname "YTGrab" -srcfolder "$STAGING" -ov -format UDZO "$DMG" >/dev/null
rm -rf "$STAGING"

if [[ "$MODE" != "unsigned" ]]; then
  codesign --force --timestamp --sign "$IDENTITY" "$DMG"
fi

if [[ "$MODE" == "notarize" ]]; then
  step "公證 DMG"
  notarize "$DMG"
  xcrun stapler staple "$DMG"
fi

# ---------------------------------------------------------------------------
# 收尾檢查
# ---------------------------------------------------------------------------
step "收尾檢查"
rm -f "$TMP_ENT"
if [[ "$MODE" == "notarize" ]]; then
  xcrun stapler validate "$DMG"
  spctl -a -t open --context context:primary-signature -vv "$DMG" || warn "spctl 對 DMG 檢查未通過，請確認公證結果。"
  spctl -a -t exec -vv "$WORK_APP" || warn "spctl 對 App 檢查未通過，請確認公證結果。"
fi

VERSION="$(plutil -extract CFBundleShortVersionString raw "$APP/Contents/Info.plist" 2>/dev/null || echo '?')"
BUILDNO="$(plutil -extract CFBundleVersion raw "$APP/Contents/Info.plist" 2>/dev/null || echo '?')"

echo
echo "完成（模式：${MODE}）"
echo "  版本：$VERSION ($BUILDNO)"
echo "  檔案：$DMG"
echo "  大小：$(du -h "$DMG" | cut -f1)"
echo "  SHA256：$(shasum -a 256 "$DMG" | cut -d' ' -f1)"
if [[ "$MODE" == "unsigned" ]]; then
  echo
  echo "這是未簽章版本：其他 Mac 開啟時會被 Gatekeeper 擋下，"
  echo "需要在「系統設定 → 隱私權與安全性」按「強制打開」，僅供自己測試。"
fi

#!/usr/bin/env bash
#
# apply-firefox-plugin.sh
# 一次完成「Firefox 外掛」按鍵的檔案整合（可重複執行，已套用的項目會略過）：
#   1. 把兩個 Swift 檔從 fireFoxPlug/Core/FirefoxPlugin 搬到 YTGrab/Core/FirefoxPlugin
#   2. 修改 AppState.swift / RootView.swift / SettingsView.swift
#   3. 修正 host.py 裡殘留的 Windows 錯誤訊息
#   4. 產生 fireFoxPlug/copy-to-bundle.sh（給 Xcode Run Script 呼叫，只複製必要檔案進 App）
#
# 使用方式：
#   cd <含有 YTGrab.xcodeproj、YTGrab、fireFoxPlug 的資料夾>
#   bash apply-firefox-plugin.sh
#
# 修改前的原檔會備份到 .patch-backup/<時間>/（在 YTGrab 資料夾外，不會被 Xcode 收進專案）。

set -euo pipefail

ROOT="${1:-$(pwd)}"
cd "$ROOT"

if [[ ! -d YTGrab.xcodeproj || ! -d YTGrab || ! -d fireFoxPlug ]]; then
  echo "錯誤：請在同時含有 YTGrab.xcodeproj、YTGrab、fireFoxPlug 的資料夾執行。"
  exit 1
fi

BACKUP="$ROOT/.patch-backup/$(date +%Y%m%d-%H%M%S)"

backup() {
  mkdir -p "$BACKUP/$(dirname "$1")"
  cp "$1" "$BACKUP/$1"
}

# patch_file <檔案> <已套用的判斷字串> <perl 取代式>
patch_file() {
  local file="$1" marker="$2" expr="$3"
  if [[ ! -f "$file" ]]; then
    echo "   錯誤：找不到 $file"
    exit 1
  fi
  if grep -qF "$marker" "$file"; then
    echo "   略過（已套用）：$file"
    return
  fi
  backup "$file"
  perl -0pi -e "$expr" "$file"
  if ! grep -qF "$marker" "$file"; then
    cp "$BACKUP/$file" "$file"
    echo "   錯誤：$file 找不到插入點（檔案內容可能與預期不同），已還原，請改用手動方式。"
    exit 1
  fi
  echo "   已修改：$file"
}

# ---------------------------------------------------------------------------
echo "==> 1/4 搬移 Swift 檔案"
SRC_SWIFT="fireFoxPlug/Core/FirefoxPlugin"
DST_SWIFT="YTGrab/Core/FirefoxPlugin"
mkdir -p "$DST_SWIFT"
for f in FirefoxPluginLauncher.swift NativeHostInstaller.swift; do
  if [[ -f "$SRC_SWIFT/$f" ]]; then
    mv "$SRC_SWIFT/$f" "$DST_SWIFT/$f"
    echo "   已移動：$f"
  elif [[ -f "$DST_SWIFT/$f" ]]; then
    echo "   略過（已在目的地）：$f"
  else
    echo "   錯誤：找不到 $f"
    exit 1
  fi
done
rmdir "$SRC_SWIFT" 2>/dev/null || true
rmdir "fireFoxPlug/Core" 2>/dev/null || true

# ---------------------------------------------------------------------------
echo "==> 2/4 修改既有 Swift 檔"

# AppState：加入啟動器實例
patch_file "YTGrab/App/AppState.swift" "FirefoxPluginLauncher()" \
's{(let ytdlpUpdater = YTDLPUpdater\(\)\n)}{$1\n    #if !APPSTORE\n    // Firefox 外掛啟動器（僅獨立分發版；上架版不含）\n    let firefoxPlugin = FirefoxPluginLauncher()\n    #endif\n}'

# RootView：在「開啟下載資料夾」前面加按鍵
patch_file "YTGrab/Features/RootView.swift" "FirefoxPluginButton" \
's{\n([ \t]*)Spacer\(\)\n([ \t]*Button\("開啟下載資料夾"\))}{\n$1#if !APPSTORE\n$1FirefoxPluginButton(launcher: appState.firefoxPlugin)\n$1#endif\n$1Spacer()\n$2}'

# SettingsView：在 Cookies 區塊前加 Firefox 區塊
patch_file "YTGrab/Features/Settings/SettingsView.swift" "FirefoxPluginSettingsSection" \
's{\n([ \t]*)(Section\("Cookies"\) \{)}{\n$1#if !APPSTORE\n$1FirefoxPluginSettingsSection(launcher: appState.firefoxPlugin)\n$1#endif\n\n$1$2}'

# ---------------------------------------------------------------------------
echo "==> 3/4 修正 host.py 的錯誤訊息"
HOST_PY="fireFoxPlug/host/host.py"
if [[ -f "$HOST_PY" ]]; then
  if grep -qF "YTGrab 內建的 yt-dlp" "$HOST_PY"; then
    echo "   略過（已修正）：$HOST_PY"
  else
    backup "$HOST_PY"
    perl -0pi -e 's{MISSING_YTDLP = ".*"}{MISSING_YTDLP = "找不到 yt-dlp（請確認 YTGrab 內建的 yt-dlp 存在，或已加入 PATH）"}' "$HOST_PY"
    echo "   已修改：$HOST_PY"
  fi
else
  echo "   略過：找不到 $HOST_PY"
fi

# ---------------------------------------------------------------------------
echo "==> 4/4 產生 fireFoxPlug/copy-to-bundle.sh"
cat > fireFoxPlug/copy-to-bundle.sh <<'COPY_SCRIPT'
#!/usr/bin/env bash
# Xcode Run Script 呼叫：把外掛與 host 複製進 App 的 Contents/Resources/FirefoxPlugin/
# 只複製必要檔案，排除 node_modules、打包產物、Windows 腳本等。
set -euo pipefail

SRC="$SRCROOT/fireFoxPlug"
DEST="$TARGET_BUILD_DIR/$UNLOCALIZED_RESOURCES_FOLDER_PATH/FirefoxPlugin"
mkdir -p "$DEST"

rsync -a --delete \
  --exclude '.DS_Store' --exclude 'node_modules' --exclude 'web-ext-artifacts' \
  --exclude 'package*.json' --exclude 'web-ext-config.cjs' --exclude 'README.md' \
  "$SRC/extension/" "$DEST/extension/"

rsync -a --delete \
  --exclude '.DS_Store' --exclude '*.bat' --exclude '*.ps1' --exclude 'install.sh' \
  --exclude 'host.log' --exclude 'host_config.json' \
  "$SRC/host/" "$DEST/host/"
COPY_SCRIPT
chmod +x fireFoxPlug/copy-to-bundle.sh
echo "   已建立"

# ---------------------------------------------------------------------------
echo
echo "================ 自動部分完成，剩下 3 個 Xcode 手動步驟 ================"
if grep -q "PBXFileSystemSynchronizedRootGroup" YTGrab.xcodeproj/project.pbxproj; then
  echo "• Swift 檔：專案使用自動同步資料夾，已自動納入編譯，不需處理。"
else
  echo "• Swift 檔：請在 Xcode 對 Core 群組按右鍵 → Add Files，加入 Core/FirefoxPlugin 內兩個檔案（Target 勾 YTGrab）。"
fi
cat <<'MANUAL'

1) 新增 Run Script（一次性）
   Target YTGrab → Build Phases → 左上「+」→ New Run Script Phase
   • 拖到 Copy Bundle Resources 之後
   • Shell：/bin/bash
   • 內容只要一行：
       "$SRCROOT/fireFoxPlug/copy-to-bundle.sh"
   • 取消勾選 "Based on dependency analysis"

2) Build Settings → 搜尋 "User Script Sandboxing" → 設為 No

3) Signing & Capabilities → 移除 App Sandbox（DMG 版）
   （上架版 Scheme 維持有 APPSTORE 編譯旗標即可，Firefox 功能會被排除）

完成後 Build，右鍵 YTGrab.app → 顯示套件內容，確認
Contents/Resources/FirefoxPlugin/ 底下只有 extension/ 與 host/。
MANUAL

#!/bin/bash
# YTGrab 打包腳本（未簽章版）：Archive -> 匯出 .app -> 打包 dmg
# 不做 code signing / notarization，使用者開啟時會看到 Gatekeeper 警告，
# 需自行右鍵開啟或執行 xattr -cr 才能執行（見腳本最下方說明，可附給使用者）。

set -euo pipefail

# ========== 設定區 ==========
APP_NAME="YTGrab"
SCHEME="YTGrab"
PROJECT="YTGrab.xcodeproj"

BUILD_DIR="./build"
ARCHIVE_PATH="${BUILD_DIR}/${APP_NAME}.xcarchive"
EXPORT_PATH="${BUILD_DIR}/export"
APP_PATH="${EXPORT_PATH}/${APP_NAME}.app"
DMG_PATH="${BUILD_DIR}/${APP_NAME}.dmg"
EXPORT_OPTIONS_PLIST="${BUILD_DIR}/ExportOptions.plist"
# =============================

mkdir -p "${BUILD_DIR}"

echo "==> 1. 產生 ExportOptions.plist（若尚未存在，設定為不簽章）"
if [ ! -f "${EXPORT_OPTIONS_PLIST}" ]; then
  cat > "${EXPORT_OPTIONS_PLIST}" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>method</key>
    <string>developer-id</string>
    <key>signingStyle</key>
    <string>manual</string>
    <key>signingCertificate</key>
    <string>-</string>
</dict>
</plist>
EOF
fi

echo "==> 2. Archive（Debug/Release 皆可，這裡用 Release）"
xcodebuild -project "${PROJECT}" -scheme "${SCHEME}" \
  -configuration Release \
  CODE_SIGN_IDENTITY="" CODE_SIGNING_REQUIRED=NO CODE_SIGNING_ALLOWED=NO \
  -archivePath "${ARCHIVE_PATH}" archive

echo "==> 3. 直接從 archive 取出 .app（不走 exportArchive，避免要求簽章）"
rm -rf "${EXPORT_PATH}"
mkdir -p "${EXPORT_PATH}"
cp -R "${ARCHIVE_PATH}/Products/Applications/${APP_NAME}.app" "${EXPORT_PATH}/"

echo "==> 4. 打包成 dmg"
rm -f "${DMG_PATH}"
hdiutil create -volname "${APP_NAME}" -srcfolder "${EXPORT_PATH}" \
  -ov -format UDZO "${DMG_PATH}"

echo ""
echo "完成！可發佈的檔案：${DMG_PATH}"
echo "（未簽章、未公證，使用者開啟時會看到安全性警告，請把下方說明一併附給使用者）"
echo ""
echo "======================================================"
echo "給使用者的開啟方式（因為 App 未經過 Apple 公證）："
echo ""
echo "方法一（推薦，圖形介面）："
echo "  1. 把 App 拖進「應用程式」資料夾"
echo "  2. 在 Finder 中「按住 Control 點一下」App 圖示（或滑鼠右鍵）"
echo "  3. 選單選「打開」，跳出的警告視窗中再按一次「打開」"
echo "  （之後就能正常雙擊開啟，不會再跳這個警告）"
echo ""
echo "方法二（終端機指令，一次解決）："
echo "  xattr -cr /Applications/${APP_NAME}.app"
echo "======================================================"

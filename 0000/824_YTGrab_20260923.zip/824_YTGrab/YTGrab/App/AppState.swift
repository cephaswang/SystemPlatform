import Foundation
import Combine

@MainActor
final class AppState: ObservableObject {
    @Published var ytdlpBinaryPath: String {
        didSet {
            UserDefaults.standard.set(ytdlpBinaryPath, forKey: Self.customPathKey)
            client.updateBinaryPath(ytdlpBinaryPath)
        }
    }
    // MARK: - 新增：ffmpeg 路徑（供 HowTo.mov → mp4 轉檔功能使用）
    @Published var ffmpegBinaryPath: String {
        didSet {
            UserDefaults.standard.set(ffmpegBinaryPath, forKey: Self.ffmpegPathKey)
            conversionQueueManager.ffmpegPath = ffmpegBinaryPath
        }
    }
    /// 轉檔成功後是否刪除原始 .mov，設定頁的開關會綁定這個值
    @Published var deleteSourceMovAfterConversion = false

    @Published var downloadDirectory: URL
    @Published var currentVideoInfo: VideoInfo?
    @Published var currentPlaylist: PlaylistInfo?
    /// 網址同時帶有影片與 list= 時，暫存起來等使用者選「單支影片 / 整個播放列表」。
    @Published var pendingChoiceURL: String?
    @Published var isFetchingInfo = false
    @Published var fetchErrorMessage: String?

    let client: YTDLPClient
    let queueManager: DownloadQueueManager
    let conversionQueueManager: ConversionQueueManager

    private static let customPathKey = "ytdlpBinaryPath"
    private static let ffmpegPathKey = "ffmpegBinaryPath"

    /// 依序嘗試常見安裝位置：
    /// 1. App Bundle 內建（正式打包後）
    /// 2. 使用者在設定頁手動指定過的路徑（存在 UserDefaults）
    /// 3. Homebrew Apple Silicon 預設路徑
    /// 4. Homebrew Intel / 傳統 macOS 常見路徑
    /// 5. 系統路徑
    private static func resolveYTDLPPath() -> String {
        let fileManager = FileManager.default

        if let bundledPath = Bundle.main.path(forResource: "yt-dlp", ofType: nil),
           fileManager.isExecutableFile(atPath: bundledPath) {
            return bundledPath
        }

        if let savedPath = UserDefaults.standard.string(forKey: customPathKey),
           fileManager.isExecutableFile(atPath: savedPath) {
            return savedPath
        }

        let candidates = [
            "/opt/homebrew/bin/yt-dlp",   // Apple Silicon Homebrew
            "/usr/local/bin/yt-dlp",      // Intel Homebrew / 常見手動安裝路徑
            "/usr/bin/yt-dlp",
            "/opt/local/bin/yt-dlp"       // MacPorts
        ]
        for path in candidates where fileManager.isExecutableFile(atPath: path) {
            return path
        }

        // 都找不到時，仍回傳最常見的路徑當預設值，讓使用者在設定頁看到並可以修正
        return candidates.first!
    }

    /// 跟 resolveYTDLPPath 邏輯完全比照，只是找的是 ffmpeg。
    private static func resolveFFmpegPath() -> String {
        let fileManager = FileManager.default

        if let bundledPath = Bundle.main.path(forResource: "ffmpeg", ofType: nil),
           fileManager.isExecutableFile(atPath: bundledPath) {
            return bundledPath
        }

        if let savedPath = UserDefaults.standard.string(forKey: ffmpegPathKey),
           fileManager.isExecutableFile(atPath: savedPath) {
            return savedPath
        }

        let candidates = [
            "/opt/homebrew/bin/ffmpeg",
            "/usr/local/bin/ffmpeg",
            "/usr/bin/ffmpeg",
            "/opt/local/bin/ffmpeg"
        ]
        for path in candidates where fileManager.isExecutableFile(atPath: path) {
            return path
        }

        return candidates.first!
    }

    init() {
        let resolvedPath = Self.resolveYTDLPPath()
        let resolvedFFmpegPath = Self.resolveFFmpegPath()

        self.ytdlpBinaryPath = resolvedPath
        self.ffmpegBinaryPath = resolvedFFmpegPath
        self.downloadDirectory = FileManager.default.urls(for: .downloadsDirectory, in: .userDomainMask).first
            ?? FileManager.default.homeDirectoryForCurrentUser

        let client = YTDLPClient(binaryPath: resolvedPath)
        self.client = client
        self.queueManager = DownloadQueueManager(client: client)
        self.conversionQueueManager = ConversionQueueManager(ffmpegPath: resolvedFFmpegPath)
    }

    private enum URLKind {
        case video              // 一般單支影片
        case videoInPlaylist    // watch?v=...&list=...：要問使用者想抓哪一個
        case playlist           // /playlist?list=...：一定是整個列表
    }

    private func classify(_ urlString: String) -> URLKind {
        guard client.urlContainsPlaylistReference(urlString) else { return .video }
        let path = URLComponents(string: urlString)?.path ?? ""
        return path.hasPrefix("/playlist") ? .playlist : .videoInPlaylist
    }

    private func resetResults() {
        currentVideoInfo = nil
        currentPlaylist = nil
        pendingChoiceURL = nil
        fetchErrorMessage = nil
    }

    /// URLInputView 的入口：依網址類型分流。
    func fetchInfo(for urlString: String) async {
        switch classify(urlString) {
        case .video:
            await fetchVideo(url: urlString)
        case .playlist:
            await fetchPlaylist(url: urlString)
        case .videoInPlaylist:
            resetResults()
            pendingChoiceURL = urlString
        }
    }

    /// 只解析單支影片（YTDLPClient 會加 --no-playlist）。
    func fetchVideo(url: String) async {
        resetResults()
        isFetchingInfo = true
        defer { isFetchingInfo = false }

        do {
            currentVideoInfo = try await client.fetchVideoInfo(url: url)
        } catch {
            fetchErrorMessage = error.localizedDescription
        }
    }

    /// 解析整個播放列表（flat-playlist，只取項目清單）。
    func fetchPlaylist(url: String) async {
        resetResults()
        isFetchingInfo = true
        defer { isFetchingInfo = false }

        do {
            currentPlaylist = try await client.fetchPlaylist(url: url)
        } catch {
            fetchErrorMessage = error.localizedDescription
        }
    }

    // MARK: - 新增：HowTo.mov → mp4 轉檔

    /// 供 TaskFileButtons 的「轉成 MP4」按鍵、以及選單「轉換影片為 MP4…」呼叫，
    /// 兩種入口共用同一份邏輯：目標檔案放在同一個資料夾，副檔名換成 .mp4。
    /// 來源不限於 .mov，任何 ffmpeg 讀得懂的影片格式都適用。
    func convertToMP4(sourceURL: URL) {
        var targetURL = sourceURL.deletingPathExtension().appendingPathExtension("mp4")
        // 來源本身就是 .mp4 時，上面那行算出來的路徑會跟原檔一樣，
        // 用 -y 覆寫的話等於把原檔洗掉，這裡改成另存一份帶後綴的檔名。
        if targetURL.path == sourceURL.path {
            targetURL = sourceURL.deletingPathExtension().appendingPathExtension("converted.mp4")
        }
        let task = ConversionTask(
            sourceURL: sourceURL,
            targetURL: targetURL,
            deleteSourceOnSuccess: deleteSourceMovAfterConversion
        )
        conversionQueueManager.enqueue(task)
    }

    /// 供 SettingsView 顯示 ffmpeg 版本，用法比照 client.fetchVersion()。
    func fetchFFmpegVersion() async -> String {
        do {
            let output = try await ProcessRunner.run(executablePath: ffmpegBinaryPath, arguments: ["-version"])
            // 第一行類似 "ffmpeg version 6.1.1 Copyright (c) ..."，只取到第一個換行前的內容即可
            return output.split(separator: "\n").first.map(String.init) ?? output
        } catch {
            return "無法取得（\(error.localizedDescription)）"
        }
    }
}

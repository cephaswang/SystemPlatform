using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Channels;
using System.Threading.Tasks;
using DictationHelperWin.Modules.ImportTranscribe.Services;
using DictationHelperWin.Shared;
using NAudio.CoreAudioApi;
using NAudio.Wave;
using NAudio.Wave.SampleProviders;
using Whisper.net;

namespace DictationHelperWin.Modules.LiveDictation;

public sealed class TranscriptSegmentEventArgs : EventArgs
{
    public required string Text { get; init; }
    public required TimeSpan Timestamp { get; init; }
}

/// <summary>
/// 聽抄模式的辨識核心（v0.6：由 Windows.Media.SpeechRecognition 改為本機 Whisper）。
///
/// 管線：
///   系統聲音：WasapiLoopbackCapture（抓預設播放裝置正在播放的聲音）
///   麥克風　：WasapiCapture（依所選裝置 ID 直接開啟）
///   → 轉 16kHz 單聲道 float → LiveSegmenter（能量式 VAD 分段）
///   → 佇列 → 單一工作執行緒以 Whisper 辨識 → 寫檔＋SegmentTranscribed 事件。
///
/// v0.6：系統聲音改用 Loopback，不再需要 VB-Audio Virtual Cable、不切換任何系統預設裝置、
/// 也不需要「監聽這個裝置」設定（後者設錯會造成回授迴圈）。
/// 對外 API（GetAvailableLanguages／StartAsync／StopAsync／兩個事件）與舊版相容，DictationView 不需改動呼叫方式。
/// </summary>
public sealed class SpeechTranscriber : IDisposable
{
    private readonly AudioDeviceManager _deviceManager; // 保留建構參數相容性；Loopback 路線已不使用
    private readonly WhisperModelManager _modelManager = new();

    // ---- 單次聽抄的狀態 ----
    private WasapiCapture? _capture;
    private BufferedWaveProvider? _bufferProvider;
    private ISampleProvider? _monoResampler;
    private readonly float[] _readBuf = new float[3200];
    private LiveSegmenter? _segmenter;
    private System.Threading.Timer? _timer;
    private int _tickCount;

    private Channel<PendingSegment>? _queue;
    private Task? _worker;
    private CancellationTokenSource? _cts;
    private WhisperProcessor? _processor;
    private string[] _promptClauses = Array.Empty<string>();
    private int _pendingCount;
    private int _segmentIndex;

    private StreamWriter? _transcriptWriter;
    private string? _transcriptFilePath;
    private DateTime _sessionStartTime;

    private sealed record PendingSegment(float[] Samples, DateTime StartTime);

    /// <summary>
    /// 除錯用：把每一段送給 Whisper 的音訊存成 wav（%LOCALAPPDATA%\DictationHelperWin\logs\segments），
    /// 可直接播放確認 Whisper 收到的到底是什麼聲音。確認完畢後改成 false。
    /// </summary>
    public static bool DumpSegments { get; set; } = false;

    private static string SegmentDumpDirectory => Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "DictationHelperWin", "logs", "segments");

    private void SaveDebugWav(PendingSegment seg)
    {
        try
        {
            Directory.CreateDirectory(SegmentDumpDirectory);
            var path = Path.Combine(SegmentDumpDirectory, $"seg_{seg.StartTime:HHmmss}_{_segmentIndex}.wav");
            using var writer = new WaveFileWriter(path, new WaveFormat(LiveSegmenter.SampleRate, 16, 1));
            writer.WriteSamples(seg.Samples, 0, seg.Samples.Length);
            DebugLog.Info($"已存下除錯音訊：{path}");
        }
        catch (Exception ex)
        {
            DebugLog.Error("存除錯音訊失敗", ex);
        }
    }

    private static void CleanOldDebugWavs()
    {
        try
        {
            if (!Directory.Exists(SegmentDumpDirectory)) return;
            foreach (var f in Directory.GetFiles(SegmentDumpDirectory, "seg_*.wav"))
                if (File.GetLastWriteTime(f) < DateTime.Now.AddDays(-2)) File.Delete(f);
        }
        catch { /* 忽略 */ }
    }

    /// <summary>已辨識完成、寫入檔案的逐字稿片段（可能來自背景執行緒，UI 端請自行 Dispatch）。</summary>
    public event EventHandler<TranscriptSegmentEventArgs>? SegmentTranscribed;

    /// <summary>辨識進度訊息（例如「第 3 段，佇列中 1 段」），供 UI 顯示狀態。</summary>
    public event EventHandler<string>? PartialTextUpdated;

    /// <summary>保留欄位：雙語模式（隱藏功能）尚未在 Whisper 路線實作。</summary>
    public bool DualLanguageModeEnabled { get; set; }

    public SpeechTranscriber(AudioDeviceManager deviceManager)
    {
        _deviceManager = deviceManager;
    }

    /// <summary>Whisper 是多語模型：語系清單固定，與系統語言包無關。回傳顯示名稱（與舊版相同型別）。</summary>
    public IReadOnlyList<string> GetAvailableLanguages() =>
        WhisperRuntime.Languages.Select(l => l.DisplayName).ToArray();

    public async Task<string> StartAsync(AudioSourceOption source, string language)
    {
        _sessionStartTime = DateTime.Now;
        _pendingCount = 0;
        _segmentIndex = 0;
        if (DumpSegments) CleanOldDebugWavs();

        DebugLog.Info($"===== 開始聽抄（Whisper）===== 來源={source.DisplayName}（{source.Kind}，DeviceId={source.DeviceId ?? "無"}），語系={language}");
        PermissionManager.LogPrivacyState();

        var option = WhisperRuntime.FindByDisplayName(language)
            ?? throw new InvalidOperationException($"不支援的辨識語系：{language}");
        var languageTag = option.Tag;

        if (!_modelManager.IsModelInstalled)
            throw new InvalidOperationException("尚未下載 Whisper 語音辨識模型，請先下載後再開始聽抄。");

        // 1) 先載入模型並建立 processor（耗時數秒）。
        try
        {
            _processor = await Task.Run(() =>
            {
                var factory = WhisperRuntime.GetFactory(_modelManager.ModelPath);
                var builder = factory.CreateBuilder().WithLanguage(WhisperRuntime.ToWhisperLanguage(languageTag));
                var prompt = BuildPrompt(languageTag);
                _promptClauses = SplitClauses(prompt);
                DebugLog.Info($"Whisper 初始提示詞：{prompt ?? "（無）"}");
                if (prompt is not null) builder = builder.WithPrompt(prompt);
                return builder.Build();
            });
        }
        catch (Exception ex)
        {
            DebugLog.Error("建立 Whisper processor 失敗", ex);
            throw new InvalidOperationException(
                $"載入 Whisper 模型失敗：{ex.Message}\n（常見原因：缺少 Whisper.net.Runtime 原生檔、模型檔損毀、記憶體不足。）", ex);
        }

        // 2) 逐字稿檔案
        var fileName = $"聽抄_{_sessionStartTime:yyyyMMdd_HHmmss}.txt";
        var documentsPath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
        _transcriptFilePath = Path.Combine(documentsPath, "聽抄小幫手", fileName);
        Directory.CreateDirectory(Path.GetDirectoryName(_transcriptFilePath)!);
        _transcriptWriter = new StreamWriter(_transcriptFilePath, append: false) { AutoFlush = true };
        DebugLog.Info($"逐字稿檔案：{_transcriptFilePath}");

        try
        {
            // 3) 分段器＋佇列＋工作執行緒
            _segmenter = new LiveSegmenter();
            _segmenter.SegmentReady += OnSegmentReady;
            _queue = Channel.CreateUnbounded<PendingSegment>(new UnboundedChannelOptions { SingleReader = true });
            _cts = new CancellationTokenSource();
            var reader = _queue.Reader;
            var ct = _cts.Token;
            _worker = Task.Run(() => RunWorkerAsync(reader, ct));

            // 4) 開始擷取
            StartCapture(source);

            _tickCount = 0;
            _timer = new System.Threading.Timer(_ => OnTimer(), null, 250, 250);
            DebugLog.Info("聽抄已啟動（擷取＋分段＋Whisper 工作執行緒）");
        }
        catch (Exception ex)
        {
            DebugLog.Error($"啟動聽抄失敗（HResult=0x{ex.HResult:X8}）", ex);
            await CleanupAsync(waitForWorker: false);
            throw;
        }

        return _transcriptFilePath;
    }

    // ================= 擷取與轉換 =================

    private void StartCapture(AudioSourceOption source)
    {
        MMDevice device;
        if (source.Kind == AudioSourceKind.SystemLoopback)
        {
            // 系統聲音：Loopback 抓「預設播放裝置」正在播放的內容。
            using var enumerator = new MMDeviceEnumerator();
            device = enumerator.GetDefaultAudioEndpoint(DataFlow.Render, Role.Console);
            DebugLog.Info($"系統聲音（Loopback）播放裝置：{device.FriendlyName}（{device.ID}）");

            // 舊版（VB-CABLE 路線）異常結束時，預設播放可能被留在 CABLE Input：那樣抓到的是一片靜音。
            if (device.FriendlyName.Contains("CABLE", StringComparison.OrdinalIgnoreCase))
            {
                device.Dispose();
                throw new InvalidOperationException(
                    "目前系統預設播放裝置是 VB-Audio Virtual Cable（CABLE Input），抓不到實際聲音。\n" +
                    "請到 Windows「聲音」設定，把預設播放裝置改回你的喇叭或耳機後再試一次。");
            }
            _capture = new WasapiLoopbackCapture(device);
        }
        else
        {
            device = ResolveCaptureDevice(source);
            DebugLog.Info($"擷取裝置：{device.FriendlyName}（{device.ID}）");
            _capture = new WasapiCapture(device);
        }
        var fmt = _capture.WaveFormat;
        DebugLog.Info($"擷取格式：{fmt.SampleRate} Hz，{fmt.Channels} 聲道，{fmt.BitsPerSample} bit，{fmt.Encoding}");

        _bufferProvider = new BufferedWaveProvider(fmt)
        {
            DiscardOnBufferOverflow = true,
            ReadFully = false,
            BufferDuration = TimeSpan.FromSeconds(5)
        };

        ISampleProvider samples = _bufferProvider.ToSampleProvider();
        if (fmt.Channels > 1) samples = new DownmixSampleProvider(samples);
        _monoResampler = new WdlResamplingSampleProvider(samples, LiveSegmenter.SampleRate);

        _capture.DataAvailable += OnDataAvailable;
        _capture.RecordingStopped += OnRecordingStopped;
        _capture.StartRecording();
    }

    /// <summary>麥克風：先用 DeviceId 比對；找不到就用系統預設錄音裝置。</summary>
    private static MMDevice ResolveCaptureDevice(AudioSourceOption source)
    {
        var wantedId = source.DeviceId;
        using var enumerator = new MMDeviceEnumerator();

        if (!string.IsNullOrEmpty(wantedId))
        {
            MMDevice? match = null;
            foreach (var d in enumerator.EnumerateAudioEndPoints(DataFlow.Capture, DeviceState.Active))
            {
                var hit = match is null &&
                          (d.ID.Contains(wantedId, StringComparison.OrdinalIgnoreCase) ||
                           wantedId.Contains(d.ID, StringComparison.OrdinalIgnoreCase));
                if (hit) match = d; else d.Dispose();
            }
            if (match is not null) return match;
            DebugLog.Warn($"找不到 ID 相符的錄音裝置（{wantedId}），改用系統預設錄音裝置");
        }

        return enumerator.GetDefaultAudioEndpoint(DataFlow.Capture, Role.Console);
    }

    private void OnDataAvailable(object? sender, WaveInEventArgs e)
    {
        try
        {
            var buffer = _bufferProvider;
            var resampler = _monoResampler;
            var segmenter = _segmenter;
            if (buffer is null || resampler is null || segmenter is null) return;

            buffer.AddSamples(e.Buffer, 0, e.BytesRecorded);
            int n;
            while ((n = resampler.Read(_readBuf, 0, _readBuf.Length)) > 0)
                segmenter.AddSamples(_readBuf, n);
        }
        catch (Exception ex)
        {
            DebugLog.Error("處理擷取資料時發生例外", ex);
        }
    }

    private void OnRecordingStopped(object? sender, StoppedEventArgs e)
    {
        if (e.Exception is not null)
            DebugLog.Error("音訊擷取意外停止（裝置被移除或被獨占？）", e.Exception);
    }

    private void OnTimer()
    {
        try
        {
            _segmenter?.Tick();

            // 每 5 秒記錄一次音量統計：samples=0 代表根本沒收到資料；maxRms 遠低於 0.01 代表音量太小。
            if (++_tickCount % 20 == 0 && _segmenter is not null)
            {
                var (maxRms, samples, voiced) = _segmenter.TakeStats();
                DebugLog.Info($"音訊統計（5 秒）：樣本={samples:N0}，最大 RMS={maxRms:F4}，有聲影格={voiced}");
                if (samples == 0) DebugLog.Info("5 秒內沒有收到音訊資料（系統聲音在沒有播放時不會送資料，屬正常）");
            }
        }
        catch (Exception ex)
        {
            DebugLog.Error("計時器處理失敗", ex);
        }
    }

    // ================= 分段 → Whisper =================

    private void OnSegmentReady(float[] samples, DateTime startTime)
    {
        var queue = _queue;
        if (queue is null) return;
        if (!queue.Writer.TryWrite(new PendingSegment(samples, startTime))) return;

        var pending = Interlocked.Increment(ref _pendingCount);
        if (pending > 3) DebugLog.Warn($"辨識佇列累積 {pending} 段，模型可能跟不上即時速度（可改用較小的模型）");
        PartialTextUpdated?.Invoke(this, $"第 {_segmentIndex + pending} 段，佇列 {pending}");
    }

    private async Task RunWorkerAsync(ChannelReader<PendingSegment> reader, CancellationToken ct)
    {
        var processor = _processor!;
        try
        {
            await foreach (var seg in reader.ReadAllAsync(ct))
            {
                try
                {
                    await TranscribeOneAsync(processor, seg, ct);
                }
                catch (OperationCanceledException) { throw; }
                catch (Exception ex)
                {
                    DebugLog.Error("Whisper 辨識單一段落失敗", ex);
                }
                finally
                {
                    Interlocked.Decrement(ref _pendingCount);
                    _segmentIndex++;
                }
            }
        }
        catch (OperationCanceledException)
        {
            DebugLog.Info("辨識工作已取消");
        }
    }

    private async Task TranscribeOneAsync(WhisperProcessor processor, PendingSegment seg, CancellationToken ct)
    {
        var started = DateTime.Now;
        var count = 0;
        if (DumpSegments) SaveDebugWav(seg);
        await foreach (var result in processor.ProcessAsync(seg.Samples, ct))
        {
            var text = StripPromptEcho(result.Text?.Trim());
            if (IsNoise(text))
            {
                DebugLog.Info($"略過非語音／幻覺文字：{text}");
                continue;
            }

            var ts = seg.StartTime - _sessionStartTime + result.Start;
            if (ts < TimeSpan.Zero) ts = TimeSpan.Zero;
            OnFinalSegment(text!, ts);
            count++;
        }
        DebugLog.Info($"Whisper 辨識完成：音訊 {seg.Samples.Length / (double)LiveSegmenter.SampleRate:F1} 秒，" +
                      $"耗時 {(DateTime.Now - started).TotalSeconds:F1} 秒，輸出 {count} 句");
    }

    /// <summary>
    /// 自訂詞彙檔：%LOCALAPPDATA%\DictationHelperWin\vocabulary.txt。
    /// 一行一個詞（或用逗號、頓號分隔），# 開頭為註解。會附加在初始提示詞後面，
    /// 用來提高專有名詞的辨識率（例如「耶和華」被聽成「一和華」）。內容請控制在約 100 字以內。
    /// </summary>
    private static string VocabularyPath => Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "DictationHelperWin", "vocabulary.txt");

    private static string? BuildPrompt(string languageTag)
    {
        var prompt = WhisperRuntime.GetInitialPrompt(languageTag);
        try
        {
            if (File.Exists(VocabularyPath))
            {
                var terms = File.ReadAllLines(VocabularyPath)
                    .Where(l => !l.TrimStart().StartsWith('#'))
                    .SelectMany(l => l.Split(',', '，', '、'))
                    .Select(t => t.Trim())
                    .Where(t => t.Length > 0)
                    .Distinct()
                    .ToArray();
                if (terms.Length > 0)
                {
                    var vocab = "常見詞彙：" + string.Join("、", terms);
                    if (vocab.Length > 150) vocab = vocab[..150];
                    prompt = (prompt ?? string.Empty) + vocab + "。";
                    DebugLog.Info($"已載入自訂詞彙 {terms.Length} 個");
                }
            }
        }
        catch (Exception ex)
        {
            DebugLog.Warn($"讀取自訂詞彙檔失敗：{ex.Message}");
        }
        return prompt;
    }

    private static string[] SplitClauses(string? prompt) =>
        string.IsNullOrEmpty(prompt)
            ? Array.Empty<string>()
            : prompt.Split('，', ',', '。', '.').Select(c => c.Trim()).Where(c => c.Length >= 6).ToArray();

    /// <summary>
    /// Whisper 有時會把初始提示詞的片段混進真實辨識結果（例如「按時和，請使用繁體中文與標點符號。」）。
    /// 這裡把整句提示詞子句從文字中移除，剩下的部分才是真的辨識內容。
    /// </summary>
    private string? StripPromptEcho(string? text)
    {
        if (string.IsNullOrEmpty(text)) return text;
        var cleaned = text;
        foreach (var clause in _promptClauses)
            cleaned = cleaned.Replace(clause, string.Empty, StringComparison.Ordinal);
        if (!ReferenceEquals(cleaned, text) && cleaned != text)
        {
            cleaned = cleaned.Trim(' ', ',', '，', '。', '.', '、', ':', '：');
            DebugLog.Info($"移除提示詞回吐：「{text}」→「{cleaned}」");
        }
        return cleaned;
    }

    /// <summary>過濾空白、只有標點、[BLANK_AUDIO]／(音樂)／♪ 之類標記，以及 Whisper 回吐提示詞的情況。</summary>
    private bool IsNoise(string? text)
    {
        if (string.IsNullOrWhiteSpace(text)) return true;
        if (text.All(c => char.IsPunctuation(c) || char.IsWhiteSpace(c) || char.IsSymbol(c))) return true;
        if ((text.StartsWith('[') && text.EndsWith(']')) ||
            (text.StartsWith('(') && text.EndsWith(')')) ||
            (text.StartsWith('（') && text.EndsWith('）')) ||
            text.StartsWith('♪')) return true;
        foreach (var h in KnownHallucinations)
            if (text.Contains(h, StringComparison.OrdinalIgnoreCase)) return true;
        return false;
    }

    /// <summary>Whisper 在雜音／音樂／靜音上常見的幻覺字幕（訓練資料裡的片尾字幕）。</summary>
    private static readonly string[] KnownHallucinations =
    {
        "字幕製作", "字幕制作", "字幕由", "字幕志願者", "字幕志愿者",
        "感謝觀看", "感谢观看", "謝謝收看", "請不吝點贊", "请不吝点赞",
        "Thanks for watching", "Thank you for watching", "Subtitles by", "Amara.org"
    };

    private void OnFinalSegment(string text, TimeSpan timestamp)
    {
        DebugLog.Info($"辨識結果 [{timestamp:hh\\:mm\\:ss}] {text}");
        _transcriptWriter?.WriteLine($"[{timestamp:hh\\:mm\\:ss}] {text}");
        SegmentTranscribed?.Invoke(this, new TranscriptSegmentEventArgs { Text = text, Timestamp = timestamp });
    }

    // ================= 停止與清理 =================

    /// <summary>
    /// 停止聽抄。flushPending=true：把進行中的語音送出，並等佇列裡的段落都辨識完才返回；
    /// false：直接丟棄尚未辨識的內容。
    /// </summary>
    public async Task StopAsync(bool flushPending)
    {
        DebugLog.Info($"===== 停止聽抄 ===== flushPending={flushPending}，佇列中={_pendingCount} 段");

        StopCapture();
        _timer?.Dispose();
        _timer = null;

        if (flushPending) _segmenter?.Flush();
        _queue?.Writer.TryComplete();
        if (!flushPending) _cts?.Cancel();

        await CleanupAsync(waitForWorker: true);

        DebugLog.Info("停止聽抄流程完成");
    }

    private void StopCapture()
    {
        var capture = _capture;
        _capture = null;
        if (capture is null) return;
        try
        {
            capture.DataAvailable -= OnDataAvailable;
            capture.RecordingStopped -= OnRecordingStopped;
            capture.StopRecording();
        }
        catch (Exception ex) { DebugLog.Error("停止擷取失敗", ex); }
        finally { capture.Dispose(); }
        _bufferProvider = null;
        _monoResampler = null;
    }

    private async Task CleanupAsync(bool waitForWorker)
    {
        StopCapture();
        _timer?.Dispose();
        _timer = null;

        if (_segmenter is not null) _segmenter.SegmentReady -= OnSegmentReady;
        _queue?.Writer.TryComplete();
        if (!waitForWorker) _cts?.Cancel();

        if (_worker is not null)
        {
            try { await _worker; }
            catch (Exception ex) { DebugLog.Error("等待辨識工作結束時發生例外", ex); }
        }

        _processor?.Dispose();
        _processor = null;
        _worker = null;
        _queue = null;
        _segmenter = null;
        _cts?.Dispose();
        _cts = null;

        _transcriptWriter?.Flush();
        _transcriptWriter?.Dispose();
        _transcriptWriter = null;
    }

    public void Dispose()
    {
        StopCapture();
        _timer?.Dispose();
        _cts?.Cancel();
        _processor?.Dispose();
        _transcriptWriter?.Dispose();
    }

    /// <summary>多聲道平均成單聲道。</summary>
    private sealed class DownmixSampleProvider : ISampleProvider
    {
        private readonly ISampleProvider _source;
        private readonly int _channels;
        private float[] _buf = Array.Empty<float>();

        public DownmixSampleProvider(ISampleProvider source)
        {
            _source = source;
            _channels = source.WaveFormat.Channels;
            WaveFormat = WaveFormat.CreateIeeeFloatWaveFormat(source.WaveFormat.SampleRate, 1);
        }

        public WaveFormat WaveFormat { get; }

        public int Read(float[] buffer, int offset, int count)
        {
            var need = count * _channels;
            if (_buf.Length < need) _buf = new float[need];
            var read = _source.Read(_buf, 0, need);
            var frames = read / _channels;
            for (var i = 0; i < frames; i++)
            {
                float sum = 0;
                for (var c = 0; c < _channels; c++) sum += _buf[i * _channels + c];
                buffer[offset + i] = sum / _channels;
            }
            return frames;
        }
    }
}

using System;
using System.Threading;
using DictationHelperWin.Shared;
using NAudio.CoreAudioApi;

namespace DictationHelperWin.Modules.LiveDictation;

/// <summary>
/// 診斷用：聽抄期間每秒讀取「預設播放裝置」與「預設錄音裝置」的峰值音量（0.0～1.0），寫入除錯記錄。
/// 用來判斷「畫面沒有文字」是因為聲音根本沒進來，還是辨識器沒有反應：
///   - 播放峰值 &gt; 0、錄音峰值 = 0：聲音有播放，但沒有被轉送到錄音裝置（預設裝置切換無效，或 VB-CABLE 沒轉送）。
///   - 兩者都是 0：沒有任何聲音（來源程式沒有播放，或播放沒有走預設裝置）。
///   - 錄音峰值 &gt; 0 但沒有辨識結果：問題在辨識器（權限、網路、語言包、Session 已結束）。
/// 不影響主流程：所有例外都吞掉。
/// </summary>
public sealed class AudioLevelProbe : IDisposable
{
    private readonly MMDeviceEnumerator _enumerator = new();
    private Timer? _timer;
    private int _tick;
    private int _silentSeconds;
    private float _maxRender;
    private float _maxCapture;
    private string? _lastRenderName;
    private string? _lastCaptureName;
    private bool _warned;

    public void Start()
    {
        DebugLog.Info("音量偵測開始（每秒取樣，每 5 秒摘要一次）");
        _timer = new Timer(_ => Sample(), null, TimeSpan.FromSeconds(1), TimeSpan.FromSeconds(1));
    }

    private void Sample()
    {
        try
        {
            float render = 0, capture = 0;
            string? renderName = null, captureName = null;

            try
            {
                var d = _enumerator.GetDefaultAudioEndpoint(DataFlow.Render, Role.Console);
                renderName = d.FriendlyName;
                render = d.AudioMeterInformation.MasterPeakValue;
            }
            catch (Exception ex) { DebugLog.Warn($"讀取預設播放裝置音量失敗：{ex.Message}"); }

            try
            {
                var d = _enumerator.GetDefaultAudioEndpoint(DataFlow.Capture, Role.Console);
                captureName = d.FriendlyName;
                capture = d.AudioMeterInformation.MasterPeakValue;
            }
            catch (Exception ex) { DebugLog.Warn($"讀取預設錄音裝置音量失敗：{ex.Message}"); }

            if (renderName != _lastRenderName || captureName != _lastCaptureName)
            {
                DebugLog.Info($"目前預設播放裝置：{renderName ?? "無"}；預設錄音裝置：{captureName ?? "無"}");
                _lastRenderName = renderName;
                _lastCaptureName = captureName;
            }

            _tick++;
            _maxRender = Math.Max(_maxRender, render);
            _maxCapture = Math.Max(_maxCapture, capture);
            _silentSeconds = (render < 0.001f && capture < 0.001f) ? _silentSeconds + 1 : 0;

            if (_tick % 5 == 0)
            {
                DebugLog.Info($"[音量] 近 5 秒峰值：播放={_maxRender:F3}，錄音={_maxCapture:F3}");

                if (!_warned && _tick >= 10)
                {
                    if (_maxRender >= 0.001f && _maxCapture < 0.001f)
                    {
                        DebugLog.Warn("有聲音播放到預設播放裝置，但預設錄音裝置收不到：請檢查預設裝置是否真的切到 CABLE Input/CABLE Output。");
                        _warned = true;
                    }
                    else if (_silentSeconds >= 10)
                    {
                        DebugLog.Warn("連續 10 秒沒有任何聲音：來源程式可能沒有播放，或沒有使用系統預設播放裝置。");
                        _warned = true;
                    }
                }
                _maxRender = 0;
                _maxCapture = 0;
            }
        }
        catch
        {
            // 診斷用途，不影響主流程。
        }
    }

    public void Dispose()
    {
        _timer?.Dispose();
        _timer = null;
        _enumerator.Dispose();
        DebugLog.Info("音量偵測結束");
    }
}

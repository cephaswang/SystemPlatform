using System;
using System.Collections.Generic;
using DictationHelperWin.Shared;

namespace DictationHelperWin.Modules.LiveDictation;

/// <summary>
/// 即時語音分段器（能量式 VAD）：輸入 16kHz 單聲道 float 樣本，偵測「開始說話 → 停頓」後，
/// 把一段語音（含前後少量緩衝）交給 SegmentReady，再由 Whisper 辨識。
/// - 每 30 毫秒為一個影格，RMS ≥ VoiceThreshold 視為有聲。
/// - 有聲後連續靜音達 EndSilence，或片段達 MaxSegment，就結束該段。
/// - 有聲時間不足 MinVoice 的片段視為雜訊丟棄（避免 Whisper 對雜音產生幻覺文字）。
/// - Tick() 需定時呼叫：系統聲音（Loopback）在沒有聲音播放時完全不會送資料進來，
///   若只靠新資料驅動，說完最後一句後就永遠不會結束該段。
/// 執行緒安全（擷取執行緒呼叫 AddSamples，計時器執行緒呼叫 Tick）。
/// </summary>
public sealed class LiveSegmenter
{
    public const int SampleRate = 16000;
    private const int FrameSamples = 480; // 30 ms
    private const double FrameMs = 30.0;

    public float VoiceThreshold { get; set; } = 0.01f;
    public TimeSpan EndSilence { get; set; } = TimeSpan.FromMilliseconds(700);
    public TimeSpan MaxSegment { get; set; } = TimeSpan.FromSeconds(20);
    public TimeSpan PreRoll { get; set; } = TimeSpan.FromMilliseconds(300);
    public TimeSpan MinVoice { get; set; } = TimeSpan.FromMilliseconds(300);

    /// <summary>一段語音完成：樣本（16kHz 單聲道）與這段語音開始的本機時間。</summary>
    public event Action<float[], DateTime>? SegmentReady;

    private readonly object _gate = new();
    private readonly List<float> _frameBuf = new();
    private readonly Queue<float[]> _preRoll = new();
    private readonly List<float> _segment = new();

    private bool _inSpeech;
    private int _voicedFrames;
    private int _silenceFrames;
    private DateTime _segmentStart;
    private DateTime _lastVoiceTime;

    private float _maxRms;
    private long _samples;
    private int _voicedFramesStat;

    public void AddSamples(float[] data, int count)
    {
        lock (_gate)
        {
            _samples += count;
            for (var i = 0; i < count; i++) _frameBuf.Add(data[i]);

            while (_frameBuf.Count >= FrameSamples)
            {
                var frame = _frameBuf.GetRange(0, FrameSamples).ToArray();
                _frameBuf.RemoveRange(0, FrameSamples);
                ProcessFrame(frame);
            }
        }
    }

    private void ProcessFrame(float[] frame)
    {
        double sum = 0;
        for (var i = 0; i < frame.Length; i++) sum += frame[i] * frame[i];
        var rms = (float)Math.Sqrt(sum / frame.Length);
        if (rms > _maxRms) _maxRms = rms;

        var voiced = rms >= VoiceThreshold;
        if (voiced) _voicedFramesStat++;

        if (!_inSpeech)
        {
            if (voiced)
            {
                _inSpeech = true;
                _segment.Clear();
                var preRollMs = _preRoll.Count * FrameMs;
                foreach (var f in _preRoll) _segment.AddRange(f);
                _preRoll.Clear();
                _segment.AddRange(frame);
                _voicedFrames = 1;
                _silenceFrames = 0;
                _lastVoiceTime = DateTime.Now;
                _segmentStart = _lastVoiceTime - TimeSpan.FromMilliseconds(preRollMs);
            }
            else
            {
                _preRoll.Enqueue(frame);
                var maxFrames = (int)(PreRoll.TotalMilliseconds / FrameMs);
                while (_preRoll.Count > maxFrames) _preRoll.Dequeue();
            }
            return;
        }

        _segment.AddRange(frame);
        if (voiced)
        {
            _voicedFrames++;
            _silenceFrames = 0;
            _lastVoiceTime = DateTime.Now;
        }
        else
        {
            _silenceFrames++;
        }

        if (_silenceFrames * FrameMs >= EndSilence.TotalMilliseconds)
            Finish("停頓");
        else if (_segment.Count >= MaxSegment.TotalSeconds * SampleRate)
            Finish("達到長度上限");
    }

    /// <summary>定時呼叫（建議 250 ms）：處理「沒有新資料進來」時的段落結束。</summary>
    public void Tick()
    {
        lock (_gate)
        {
            if (_inSpeech && DateTime.Now - _lastVoiceTime >= EndSilence + TimeSpan.FromMilliseconds(250))
                Finish("無新資料（逾時）");
        }
    }

    /// <summary>停止時呼叫：把進行中的語音當作一段送出。</summary>
    public void Flush()
    {
        lock (_gate)
        {
            if (_inSpeech) Finish("停止聽抄");
        }
    }

    private void Finish(string reason)
    {
        var voicedMs = _voicedFrames * FrameMs;
        if (voicedMs >= MinVoice.TotalMilliseconds)
        {
            var samples = _segment.ToArray();
            DebugLog.Info($"分段：{samples.Length / (double)SampleRate:F1} 秒（有聲 {voicedMs / 1000:F1} 秒），原因={reason}");
            SegmentReady?.Invoke(samples, _segmentStart);
        }
        else
        {
            DebugLog.Info($"丟棄過短的雜訊片段（有聲 {voicedMs:F0} ms），原因={reason}");
        }

        _segment.Clear();
        _preRoll.Clear();
        _inSpeech = false;
        _voicedFrames = 0;
        _silenceFrames = 0;
    }

    /// <summary>取得並重置統計（供除錯記錄）：最大 RMS、收到的樣本數、有聲影格數。</summary>
    public (float MaxRms, long Samples, int VoicedFrames) TakeStats()
    {
        lock (_gate)
        {
            var result = (_maxRms, _samples, _voicedFramesStat);
            _maxRms = 0;
            _samples = 0;
            _voicedFramesStat = 0;
            return result;
        }
    }
}

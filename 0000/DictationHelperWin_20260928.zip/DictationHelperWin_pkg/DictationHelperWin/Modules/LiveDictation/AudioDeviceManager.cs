using System;
using System.Collections.Generic;
using System.Linq;
using DictationHelperWin.Shared;
using NAudio.CoreAudioApi;
using NAudio.Wave;

namespace DictationHelperWin.Modules.LiveDictation;

/// <summary>聲音來源種類：麥克風（輸入裝置）或系統聲音（v0.6 起用 WasapiLoopbackCapture 擷取預設播放裝置）。</summary>
public enum AudioSourceKind
{
    Microphone,
    SystemLoopback
}

/// <summary>
/// 聲音來源選單的資料項目。
/// v0.6：「系統聲音」由 WasapiLoopbackCapture 直接擷取預設播放裝置，不再依賴 VB-Audio Virtual Cable，
/// 因此一般情況下 IsAvailable 恆為 true；欄位保留供之後有其他來源可能不可用時使用。
/// </summary>
public sealed record AudioSourceOption(
    string DisplayName,
    AudioSourceKind Kind,
    string? DeviceId,
    bool IsAvailable = true,
    string? UnavailableReason = null);

/// <summary>
/// 音訊裝置列舉（v0.6）。
/// - 系統聲音：由 SpeechTranscriber 以 WasapiLoopbackCapture 擷取預設播放裝置，不需任何虛擬裝置。
/// - 麥克風：列出啟用中的輸入裝置，並排除 VB-Audio Virtual Cable 的 CABLE Output（避免被誤選）。
/// - TryGetVbCableDeviceIds 為舊版（v0.3～v0.5）遺留的偵測，聽抄已不使用；保留給設定頁的相容檢查。
/// </summary>
public sealed class AudioDeviceManager : IDisposable
{
    private readonly MMDeviceEnumerator _enumerator = new();

    /// <summary>列出「系統聲音」選項＋目前所有「真實」輸入裝置（排除 VB-CABLE 的虛擬裝置）。</summary>
    public IReadOnlyList<AudioSourceOption> GetAvailableSources()
    {
        var options = new List<AudioSourceOption>();
        LogAllEndpoints();

        options.Add(new AudioSourceOption(
            DisplayName: "系統聲音（擷取電腦正在播放的聲音，例如會議、影片、音樂）",
            Kind: AudioSourceKind.SystemLoopback,
            DeviceId: null));

        foreach (var device in _enumerator.EnumerateAudioEndPoints(DataFlow.Capture, DeviceState.Active))
        {
            // 排除 VB-CABLE 自己的 CABLE Output，它不是一支給人使用的實體麥克風。
            if (IsVbCableDeviceName(device.FriendlyName))
            {
                DebugLog.Info($"麥克風選單排除虛擬裝置：{device.FriendlyName}");
                continue;
            }

            options.Add(new AudioSourceOption(
                $"麥克風：{device.FriendlyName}",
                AudioSourceKind.Microphone,
                device.ID));
        }

        DebugLog.Info($"聲音來源選單共 {options.Count} 項");
        return options;
    }

    /// <summary>診斷用：列出所有啟用中的播放／錄音裝置與目前的預設裝置。</summary>
    private void LogAllEndpoints()
    {
        try
        {
            foreach (var flow in new[] { DataFlow.Render, DataFlow.Capture })
            {
                var names = _enumerator.EnumerateAudioEndPoints(flow, DeviceState.Active)
                    .Select(d => d.FriendlyName + " [" + d.ID + "]");
                DebugLog.Info($"啟用中的{(flow == DataFlow.Render ? "播放" : "錄音")}裝置：{string.Join(" | ", names)}");

                var def = _enumerator.GetDefaultAudioEndpoint(flow, Role.Console);
                DebugLog.Info($"預設{(flow == DataFlow.Render ? "播放" : "錄音")}裝置：{def.FriendlyName}");
            }
        }
        catch (Exception ex)
        {
            DebugLog.Warn($"列舉音訊裝置失敗：{ex.Message}");
        }
    }

    /// <summary>
    /// （舊版遺留，聽抄已不使用）偵測 VB-Audio Virtual Cable 是否已安裝，並回傳
    /// CABLE Input（播放）與 CABLE Output（錄音）的裝置 ID。以裝置名稱比對。
    /// </summary>
    public bool TryGetVbCableDeviceIds(out string? cableInputDeviceId, out string? cableOutputDeviceId)
    {
        cableInputDeviceId = _enumerator
            .EnumerateAudioEndPoints(DataFlow.Render, DeviceState.Active)
            .FirstOrDefault(d => d.FriendlyName.Contains("CABLE Input", StringComparison.OrdinalIgnoreCase))
            ?.ID;

        cableOutputDeviceId = _enumerator
            .EnumerateAudioEndPoints(DataFlow.Capture, DeviceState.Active)
            .FirstOrDefault(d => d.FriendlyName.Contains("CABLE Output", StringComparison.OrdinalIgnoreCase))
            ?.ID;

        DebugLog.Info($"VB-CABLE 偵測：Input={cableInputDeviceId ?? "找不到"}；Output={cableOutputDeviceId ?? "找不到"}");
        return cableInputDeviceId is not null && cableOutputDeviceId is not null;
    }

    private static bool IsVbCableDeviceName(string friendlyName) =>
        friendlyName.Contains("VB-Audio Virtual Cable", StringComparison.OrdinalIgnoreCase) ||
        friendlyName.Contains("CABLE Input", StringComparison.OrdinalIgnoreCase) ||
        friendlyName.Contains("CABLE Output", StringComparison.OrdinalIgnoreCase);

    /// <summary>對指定輸入裝置建立 WasapiCapture（目前聽抄由 SpeechTranscriber 自行建立擷取，這支保留備用）。</summary>
    public IWaveIn CreateMicrophoneCapture(string deviceId)
    {
        var device = _enumerator.GetDevice(deviceId);
        return new WasapiCapture(device);
    }

    public void Dispose()
    {
        _enumerator.Dispose();
    }
}

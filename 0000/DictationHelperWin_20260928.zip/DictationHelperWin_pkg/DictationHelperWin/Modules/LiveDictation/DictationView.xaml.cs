using System;
using System.Windows;
using System.Windows.Input;
using DictationHelperWin.Modules.ImportTranscribe.Services;
using DictationHelperWin.Shared;

namespace DictationHelperWin.Modules.LiveDictation;

/// <summary>
/// 對應企劃書二、2.3：模式二 聽抄（即時轉錄）的畫面邏輯。
/// v0.6：辨識改為本機 Whisper；開始前需確認模型已下載，停止時要等佇列辨識完。
/// </summary>
public partial class DictationView : Window
{
    private readonly SpeechTranscriber _transcriber = App.App.State.SpeechTranscriber;
    private readonly WhisperModelManager _modelManager = new();
    private bool _isDictating;
    private string? _currentTranscriptFilePath;

    public DictationView()
    {
        InitializeComponent();
        DebugLog.Info($"聽抄畫面開啟；記錄檔：{DebugLog.CurrentLogPath}");

        AudioSourceComboBox.ItemsSource = App.App.State.AudioDeviceManager.GetAvailableSources();
        LanguageComboBox.ItemsSource = _transcriber.GetAvailableLanguages();

        _transcriber.SegmentTranscribed += OnSegmentTranscribed;
        _transcriber.PartialTextUpdated += OnPartialTextUpdated;

        InputBindings.Add(new KeyBinding(
            new RelayCommand(_ => ShowInExplorerButton_Click(this, new RoutedEventArgs())),
            Key.E, ModifierKeys.Control));

        Closing += DictationView_Closing;
    }

    // 事件來自背景辨識執行緒；用 BeginInvoke 避免與 UI 執行緒互相等待。
    private void OnSegmentTranscribed(object? sender, TranscriptSegmentEventArgs e)
    {
        Dispatcher.BeginInvoke(() =>
        {
            TranscriptTextBox.AppendText($"[{e.Timestamp:hh\\:mm\\:ss}] {e.Text}\n");
            TranscriptTextBox.ScrollToEnd();
            if (_isDictating) StatusText.Text = "聽抄中…";
        });
    }

    private void OnPartialTextUpdated(object? sender, string message)
    {
        Dispatcher.BeginInvoke(() =>
        {
            if (_isDictating) StatusText.Text = $"辨識中… {message}";
        });
    }

    /// <summary>模型未安裝時，詢問並下載（與匯入模式相同的模型與位置）。回傳 true 表示模型可用。</summary>
    private async System.Threading.Tasks.Task<bool> EnsureModelReadyAsync()
    {
        if (_modelManager.IsModelInstalled) return true;

        var ask = MessageBox.Show(
            $"聽抄需要 Whisper 語音辨識模型（{WhisperModelManager.ModelName}，{WhisperModelManager.ApproxSizeText}）。\n" +
            "只需下載一次，之後可離線使用。要現在下載嗎？",
            "需要下載模型", MessageBoxButton.YesNo, MessageBoxImage.Question);
        if (ask != MessageBoxResult.Yes) return false;

        try
        {
            var progress = new Progress<double>(p => StatusText.Text = $"下載模型中… {p:P0}");
            await _modelManager.EnsureModelAsync(progress);
            return true;
        }
        catch (Exception ex)
        {
            DebugLog.Error("聽抄：模型下載失敗", ex);
            MessageBox.Show($"模型下載失敗：{ex.Message}\n\n詳細資訊已寫入記錄檔：\n{DebugLog.CurrentLogPath}",
                "下載失敗", MessageBoxButton.OK, MessageBoxImage.Error);
            return false;
        }
    }

    private async void StartStopButton_Click(object sender, RoutedEventArgs e)
    {
        DebugLog.Info($"按下開始／停止按鈕：目前聽抄中={_isDictating}");
        if (!_isDictating)
        {
            var source = AudioSourceComboBox.SelectedItem as AudioSourceOption;
            var language = LanguageComboBox.SelectedItem as string;
            if (source is null || language is null)
            {
                DebugLog.Warn($"尚未選擇來源或語系：來源={(source?.DisplayName ?? "無")}，語系={(language ?? "無")}");
                MessageBox.Show("請先選擇聲音來源與語系。", "提醒", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // v0.6：系統聲音改用 WasapiLoopbackCapture，不再依賴 VB-CABLE，所以不套用 IsAvailable 檢查。
            if (!source.IsAvailable && source.Kind != AudioSourceKind.SystemLoopback)
            {
                DebugLog.Warn($"來源不可用：{source.DisplayName}；原因={source.UnavailableReason}");
                MessageBox.Show(
                    source.UnavailableReason ?? "此聲音來源目前無法使用。",
                    "尚未就緒", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            StartStopButton.IsEnabled = false;
            try
            {
                if (!await EnsureModelReadyAsync())
                {
                    StatusText.Text = "已取消";
                    return;
                }

                StatusText.Text = "載入模型中…（首次約需數秒）";
                _currentTranscriptFilePath = await _transcriber.StartAsync(source, language);
            }
            catch (InvalidOperationException ex)
            {
                DebugLog.Error("StartAsync 丟出 InvalidOperationException", ex);
                StatusText.Text = "無法開始";
                MessageBox.Show(ex.Message, "無法開始聽抄", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            catch (Exception ex)
            {
                DebugLog.Error($"StartAsync 發生未預期例外（HResult=0x{ex.HResult:X8}）", ex);
                StatusText.Text = "無法開始";
                MessageBox.Show($"無法開始聽抄：{ex.Message}\n\n詳細資訊已寫入記錄檔：\n{DebugLog.CurrentLogPath}",
                    "無法開始聽抄", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            finally
            {
                StartStopButton.IsEnabled = true;
            }

            DebugLog.Info($"聽抄已開始，逐字稿：{_currentTranscriptFilePath}");
            _isDictating = true;
            StartStopButton.Content = "停止聽抄";
            AudioSourceComboBox.IsEnabled = false;
            LanguageComboBox.IsEnabled = false;
            StatusText.Text = "聽抄中…";
        }
        else
        {
            var confirm = MessageBox.Show("確定要停止聽抄嗎？未定案的內容將會強制寫入檔案。",
                "確認停止", MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (confirm != MessageBoxResult.Yes)
            {
                DebugLog.Info("使用者取消停止");
                return;
            }

            StartStopButton.IsEnabled = false;
            StatusText.Text = "正在辨識最後的內容…";
            try
            {
                await _transcriber.StopAsync(flushPending: true);
            }
            catch (Exception ex)
            {
                DebugLog.Error("StopAsync 失敗", ex);
            }
            finally
            {
                StartStopButton.IsEnabled = true;
            }
            DebugLog.Info("聽抄已停止（UI）");

            _isDictating = false;
            StartStopButton.Content = "開始聽抄";
            AudioSourceComboBox.IsEnabled = true;
            LanguageComboBox.IsEnabled = true;
            StatusText.Text = "已停止";
        }
    }

    private void ShowInExplorerButton_Click(object sender, RoutedEventArgs e)
    {
        if (_currentTranscriptFilePath is not null)
        {
            ExplorerActions.ShowFileInExplorer(_currentTranscriptFilePath);
        }
    }

    private async void DictationView_Closing(object? sender, System.ComponentModel.CancelEventArgs e)
    {
        DebugLog.Info($"聽抄畫面關閉中；聽抄中={_isDictating}");
        if (_isDictating)
        {
            _isDictating = false;
            try { await _transcriber.StopAsync(flushPending: true); }
            catch (Exception ex) { DebugLog.Error("關閉視窗時 StopAsync 失敗", ex); }
        }
    }
}

/// <summary>簡易 ICommand 實作，供快捷鍵綁定使用。</summary>
internal sealed class RelayCommand : ICommand
{
    private readonly Action<object?> _execute;
    public RelayCommand(Action<object?> execute) => _execute = execute;
    public event EventHandler? CanExecuteChanged { add { } remove { } }
    public bool CanExecute(object? parameter) => true;
    public void Execute(object? parameter) => _execute(parameter);
}

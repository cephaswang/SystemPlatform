namespace DictationHelperWin.Modules.ImportTranscribe.Models;

/// <summary>
/// 語系選項：Tag 為語系代碼（前五項沿用 BCP-47，如 zh-TW；其餘語言用 Whisper 語言碼，如 fr、th，
/// 轉成 Whisper 內部語言碼的規則見 WhisperRuntime.ToWhisperLanguage），
/// DisplayName 為下拉選單顯示名稱（各語言之間必須唯一，WhisperRuntime.FindByDisplayName 以名稱比對）。
/// 完整清單由 WhisperRuntime.Languages 提供。
/// </summary>
public sealed record LanguageOption(string Tag, string DisplayName);

public static class LanguageDefaults
{
    /// <summary>App 全域預設匯入語系（之後可由 SettingsView 覆寫並記住上次選擇）。</summary>
    public const string Tag = "zh-TW";
}

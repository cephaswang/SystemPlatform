using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using DictationHelperWin.Shared;

namespace DictationHelperWin.Modules.ImportTranscribe.Models;

public enum AudioFileStatus
{
    Pending,
    Converting,
    Transcribing,
    Completed,
    Failed,
    /// <summary>該檔所選語系不在辨識引擎支援清單內；更換語系後會回到 Pending。</summary>
    LanguageUnavailable
}

/// <summary>
/// 對應企劃書 2.2：音檔清單（狀態＋長度，可新增刪除）；每個音檔可各自設定語系。
/// 支援格式：mp3／m4a／wav／webm（一律先用 ffmpeg 轉成 16kHz 單聲道 wav 再辨識）。
/// 實作 INotifyPropertyChanged，讓清單中的長度、狀態文字與語系下拉選單的可用狀態能即時更新。
/// </summary>
public sealed class AudioFile : INotifyPropertyChanged
{
    private string _language = LanguageDefaults.Tag;
    private AudioFileStatus _status = AudioFileStatus.Pending;
    private TimeSpan _duration;
    private string? _errorMessage;

    public event PropertyChangedEventHandler? PropertyChanged;

    public required string FilePath { get; init; }
    public string FileName => System.IO.Path.GetFileName(FilePath);
    public string? ConvertedFilePath { get; set; }
    public ObservableCollection<TranscriptSegment> Segments { get; } = new();

    public TimeSpan Duration
    {
        get => _duration;
        set
        {
            if (_duration == value) return;
            _duration = value;
            Raise(nameof(Duration));
        }
    }

    /// <summary>失敗時的原因，供清單狀態欄的提示文字顯示。</summary>
    public string? ErrorMessage
    {
        get => _errorMessage;
        set
        {
            if (_errorMessage == value) return;
            _errorMessage = value;
            if (value is not null)
                DebugLog.Warn($"[{FileName}] ErrorMessage：{value}");
            Raise(nameof(ErrorMessage));
        }
    }

    public AudioFileStatus Status
    {
        get => _status;
        set
        {
            if (_status == value) return;
            DebugLog.Info($"[{FileName}] 狀態 {_status} → {value}");
            _status = value;
            Raise(nameof(Status));
            Raise(nameof(StatusText));
            Raise(nameof(CanChangeLanguage));
        }
    }

    /// <summary>清單顯示用的狀態文字。</summary>
    public string StatusText => Status switch
    {
        AudioFileStatus.Pending => "等待中",
        AudioFileStatus.Converting => "轉檔中",
        AudioFileStatus.Transcribing => "轉錄中",
        AudioFileStatus.Completed => "完成",
        AudioFileStatus.Failed => "失敗",
        AudioFileStatus.LanguageUnavailable => "不支援語系",
        _ => Status.ToString()
    };

    /// <summary>該檔的辨識語系（BCP-47 代碼）。轉檔／轉錄中與已完成時鎖定，需改語系請用 ResetForRetranscribe。</summary>
    public string Language
    {
        get => _language;
        set
        {
            if (string.IsNullOrWhiteSpace(value))
                throw new ArgumentException("語系代碼不可為空。", nameof(value));
            if (string.Equals(_language, value, StringComparison.OrdinalIgnoreCase))
                return;
            if (!CanChangeLanguage)
                throw new InvalidOperationException("此檔案目前狀態不允許直接更換語系；請使用 ResetForRetranscribe。");

            _language = value;
            Raise(nameof(Language));

            // 失敗或語系不支援的檔案，換語系後視為重新排入佇列。
            if (Status is AudioFileStatus.Failed or AudioFileStatus.LanguageUnavailable)
            {
                ErrorMessage = null;
                Status = AudioFileStatus.Pending;
            }
        }
    }

    /// <summary>供 AudioLibraryView 決定語系下拉選單是否可操作。</summary>
    public bool CanChangeLanguage =>
        Status is AudioFileStatus.Pending or AudioFileStatus.Failed or AudioFileStatus.LanguageUnavailable;

    /// <summary>已轉錄完成的檔案要換語系時：清空舊逐字稿、套用新語系並回到 Pending（保留已轉好的 wav 路徑）。</summary>
    public void ResetForRetranscribe(string language)
    {
        if (Status is AudioFileStatus.Converting or AudioFileStatus.Transcribing)
            throw new InvalidOperationException("處理中的檔案無法重新轉錄，請先取消。");
        if (string.IsNullOrWhiteSpace(language))
            throw new ArgumentException("語系代碼不可為空。", nameof(language));

        Segments.Clear();
        ErrorMessage = null;
        _language = language;
        Raise(nameof(Language));
        Status = AudioFileStatus.Pending;
    }

    private void Raise(string propertyName) =>
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
}

using System;

namespace DictationHelperWin.Modules.ImportTranscribe.Models;

/// <summary>
/// 對應企劃書 2.2：逐字稿檢視（含時間戳記）；2.3：依標點斷句加時間戳。
/// 匯出模式（TXT／SRT／DOCX／PDF）皆以此為基礎資料單位。
/// </summary>
public sealed class TranscriptSegment
{
    public required TimeSpan StartTime { get; init; }
    public required TimeSpan EndTime { get; init; }
    public required string Text { get; init; }

    /// <summary>此段辨識時使用的語系（BCP-47）。可選，供 DOCX／PDF 匯出標註各檔語系。</summary>
    public string? Language { get; init; }
}

using System;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using DictationHelperWin.Shared;

namespace DictationHelperWin.Modules.ImportTranscribe.Services;

/// <summary>
/// 對應企劃書 2.2／3.1：以 ffmpeg 把匯入的音檔統一轉成 16kHz／單聲道／16-bit wav。
/// Whisper 只吃這個格式，所以 mp3／m4a／wav／webm 全部都要轉（不再只有 webm）。
/// 轉檔結果放在暫存資料夾（%TEMP%\DictationHelperWin\converted），不會寫到來源檔旁邊。
/// ffmpeg 優先使用 Resources/ffmpeg.exe，找不到時退回系統 PATH 中的 ffmpeg。
/// </summary>
public sealed class AudioConverterService
{
    private static string FfmpegPath
    {
        get
        {
            var bundled = Path.Combine(AppContext.BaseDirectory, "Resources", "ffmpeg.exe");
            return File.Exists(bundled) ? bundled : "ffmpeg";
        }
    }

    /// <summary>Whisper 需要 16kHz 單聲道 wav，因此所有格式都需要轉檔。</summary>
    public bool NeedsConversion(string filePath) => true;

    /// <summary>轉成 16kHz 單聲道 wav，回傳轉檔後的檔案路徑（暫存資料夾內）。</summary>
    public async Task<string> ConvertToWavAsync(string sourceFilePath, CancellationToken cancellationToken = default)
    {
        var sw = Stopwatch.StartNew();
        var bundledPath = Path.Combine(AppContext.BaseDirectory, "Resources", "ffmpeg.exe");
        DebugLog.Info($"轉檔開始：來源={sourceFilePath}（存在={File.Exists(sourceFilePath)}）；" +
                      $"內建 ffmpeg={bundledPath}（存在={File.Exists(bundledPath)}）；實際使用={FfmpegPath}");
        if (!File.Exists(bundledPath))
            DebugLog.Warn("找不到內建 ffmpeg.exe，將改用系統 PATH 的 ffmpeg；請確認 Resources\\ffmpeg.exe 有複製到輸出目錄。");

        var outputDir = Path.Combine(Path.GetTempPath(), "DictationHelperWin", "converted");
        Directory.CreateDirectory(outputDir);
        var outputPath = Path.Combine(outputDir, $"{Guid.NewGuid():N}.wav");

        var startInfo = new ProcessStartInfo
        {
            FileName = FfmpegPath,
            RedirectStandardError = true,
            UseShellExecute = false,
            CreateNoWindow = true
        };
        // 用 ArgumentList 逐項加入，路徑含空白或中文時不需要自己處理引號。
        foreach (var arg in new[]
                 { "-y", "-i", sourceFilePath, "-vn", "-ar", "16000", "-ac", "1", "-c:a", "pcm_s16le", outputPath })
            startInfo.ArgumentList.Add(arg);
        var argText = string.Join(" ", startInfo.ArgumentList.Select(a => a.Contains(' ') ? "\"" + a + "\"" : a));
        DebugLog.Info($"ffmpeg 參數：{argText}");

        Process? started;
        try
        {
            started = Process.Start(startInfo);
        }
        catch (Win32Exception ex)
        {
            DebugLog.Error($"無法啟動 ffmpeg（NativeErrorCode={ex.NativeErrorCode}）：{startInfo.FileName}", ex);
            throw new InvalidOperationException("無法啟動 ffmpeg，請確認 Resources/ffmpeg.exe 是否存在。", ex);
        }

        if (started is null)
        {
            DebugLog.Error("Process.Start 回傳 null");
            throw new InvalidOperationException("無法啟動 ffmpeg，請確認 Resources/ffmpeg.exe 是否存在。");
        }

        using var process = started;
        using var cancelRegistration = cancellationToken.Register(() =>
        {
            try { if (!process.HasExited) process.Kill(entireProcessTree: true); } catch { /* 已結束 */ }
        });

        // 先開始讀 stderr 再等待結束，避免 ffmpeg 輸出太多訊息時卡住。
        var stderrTask = process.StandardError.ReadToEndAsync();
        await process.WaitForExitAsync(CancellationToken.None);
        var stderr = await stderrTask;

        DebugLog.Info($"ffmpeg 結束：ExitCode={process.ExitCode}，耗時 {sw.Elapsed.TotalSeconds:F1} 秒，stderr {stderr.Length} 字元");

        if (cancellationToken.IsCancellationRequested)
        {
            DebugLog.Warn("轉檔被取消");
            TryDelete(outputPath);
            cancellationToken.ThrowIfCancellationRequested();
        }

        if (process.ExitCode != 0)
        {
            DebugLog.Error($"ffmpeg 轉檔失敗（ExitCode={process.ExitCode}）。stderr 尾段：\n" +
                           (stderr.Length > 4000 ? stderr[^4000..] : stderr));
            TryDelete(outputPath);
            var tail = stderr.Length > 600 ? stderr[^600..] : stderr;
            throw new InvalidOperationException($"ffmpeg 轉檔失敗：{tail}");
        }

        DebugLog.Info($"轉檔完成：{outputPath}（存在={File.Exists(outputPath)}，" +
                      $"{(File.Exists(outputPath) ? new FileInfo(outputPath).Length : 0):N0} bytes）");
        return outputPath;
    }

    /// <summary>讀取 wav 檔的實際長度（四捨五入到秒）；讀取失敗回傳 TimeSpan.Zero。</summary>
    public static TimeSpan TryGetWavDuration(string wavPath)
    {
        try
        {
            using var reader = new NAudio.Wave.WaveFileReader(wavPath);
            return RoundToSeconds(reader.TotalTime);
        }
        catch (Exception ex)
        {
            DebugLog.Warn($"讀取 wav 長度失敗：{wavPath}：{ex.Message}");
            return TimeSpan.Zero;
        }
    }

    public static TimeSpan RoundToSeconds(TimeSpan value) =>
        TimeSpan.FromSeconds(Math.Round(value.TotalSeconds));

    private static void TryDelete(string path)
    {
        try { if (File.Exists(path)) File.Delete(path); } catch { /* 忽略 */ }
    }
}

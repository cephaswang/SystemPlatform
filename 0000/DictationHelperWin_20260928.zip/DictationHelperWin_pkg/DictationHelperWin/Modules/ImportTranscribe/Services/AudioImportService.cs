using System;
using System.Collections.Generic;
using System.IO;
using DictationHelperWin.Modules.ImportTranscribe.Models;
using DictationHelperWin.Shared;
using NAudio.Wave;

namespace DictationHelperWin.Modules.ImportTranscribe.Services;

/// <summary>
/// 對應企劃書 2.2：匯入：拖放或「選擇檔案」（Windows 開檔對話框 OpenFileDialog）。
/// 支援格式：mp3／m4a／wav／webm。每個匯入的檔案各自帶有語系設定。
/// </summary>
public sealed class AudioImportService
{
    private static readonly HashSet<string> SupportedExtensions = new(StringComparer.OrdinalIgnoreCase)
    {
        ".mp3", ".m4a", ".wav", ".webm"
    };

    public bool IsSupported(string filePath) =>
        SupportedExtensions.Contains(Path.GetExtension(filePath));

    /// <summary>
    /// 將使用者拖放或選擇的檔案路徑轉換為 AudioFile 清單項目。
    /// defaultLanguage 為新檔案的初始語系（BCP-47）；未指定時使用 LanguageDefaults.Tag。
    /// </summary>
    public IReadOnlyList<AudioFile> ImportFiles(IEnumerable<string> filePaths, string? defaultLanguage = null)
    {
        var language = string.IsNullOrWhiteSpace(defaultLanguage) ? LanguageDefaults.Tag : defaultLanguage;

        var result = new List<AudioFile>();
        foreach (var path in filePaths)
        {
            if (!IsSupported(path))
            {
                DebugLog.Warn($"略過不支援的格式：{path}");
                continue;
            }

            var duration = TryReadDuration(path);
            DebugLog.Info($"匯入：{path}（存在={File.Exists(path)}，{(File.Exists(path) ? new FileInfo(path).Length : 0):N0} bytes），語系={language}，長度={duration}");
            result.Add(new AudioFile
            {
                FilePath = path,
                Language = language,
                Duration = duration,
                Status = AudioFileStatus.Pending
            });
        }
        return result;
    }

    /// <summary>「套用到全部檔案」：只更動仍可更換語系的檔案，回傳實際更動的檔案數。</summary>
    public int ApplyLanguageToAll(IEnumerable<AudioFile> files, string language)
    {
        var count = 0;
        foreach (var file in files)
        {
            if (!file.CanChangeLanguage) continue;
            file.Language = language;
            count++;
        }
        return count;
    }

    /// <summary>
    /// 以 Media Foundation 讀取音檔長度（mp3／m4a／wav）。webm 通常讀不到，會回傳 Zero，
    /// 之後轉檔成 wav 時再補上實際長度。
    /// </summary>
    private static TimeSpan TryReadDuration(string path)
    {
        try
        {
            using var reader = new MediaFoundationReader(path);
            return AudioConverterService.RoundToSeconds(reader.TotalTime);
        }
        catch (Exception ex)
        {
            DebugLog.Warn($"讀取長度失敗（之後轉檔時會補上）：{path}：{ex.Message}");
            return TimeSpan.Zero;
        }
    }
}

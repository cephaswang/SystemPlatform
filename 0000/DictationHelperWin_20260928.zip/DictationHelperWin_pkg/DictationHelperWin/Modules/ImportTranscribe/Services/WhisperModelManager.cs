using System;
using System.IO;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using DictationHelperWin.Shared;

namespace DictationHelperWin.Modules.ImportTranscribe.Services;

/// <summary>
/// 管理匯入模式使用的 Whisper 語音辨識模型檔（ggml 格式）。
/// 模型不內嵌於安裝檔（體積大），首次轉錄時由使用者同意後下載，存放於
/// %LOCALAPPDATA%\DictationHelperWin\models，之後即可離線使用。
/// 要換模型大小（tiny／base／small／medium），改下面兩個常數即可；small 對中文的表現比 base 好很多。
/// </summary>
public sealed class WhisperModelManager
{
    public const string ModelName = "small";
    public const string ModelFileName = "ggml-small.bin";
    public const string ApproxSizeText = "約 470 MB";

    private const string ModelUrl =
        "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-small.bin";

    private static readonly HttpClient Http = new() { Timeout = Timeout.InfiniteTimeSpan };

    public string ModelDirectory => Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "DictationHelperWin", "models");

    public string ModelPath => Path.Combine(ModelDirectory, ModelFileName);

    /// <summary>只有下載完整、驗證過大小後才會產生正式檔名，所以檔案存在即視為可用。</summary>
    public bool IsModelInstalled => File.Exists(ModelPath);

    /// <summary>確保模型已下載；已存在則直接返回。progress 回報 0.0～1.0。</summary>
    public async Task EnsureModelAsync(IProgress<double>? progress = null, CancellationToken cancellationToken = default)
    {
        if (IsModelInstalled)
        {
            DebugLog.Info($"模型已存在，略過下載：{ModelPath}（{new FileInfo(ModelPath).Length:N0} bytes）");
            return;
        }

        Directory.CreateDirectory(ModelDirectory);
        var tempPath = ModelPath + ".download";
        DebugLog.Info($"開始下載模型 {ModelName}：{ModelUrl} → {ModelPath}");

        try
        {
            using var response = await Http.GetAsync(
                ModelUrl, HttpCompletionOption.ResponseHeadersRead, cancellationToken);
            DebugLog.Info($"HTTP {(int)response.StatusCode} {response.StatusCode}，Content-Length={response.Content.Headers.ContentLength?.ToString("N0") ?? "未提供"}");
            response.EnsureSuccessStatusCode();

            var total = response.Content.Headers.ContentLength;
            var nextLogPercent = 10;

            await using (var source = await response.Content.ReadAsStreamAsync(cancellationToken))
            await using (var target = new FileStream(
                tempPath, FileMode.Create, FileAccess.Write, FileShare.None, 81920, useAsync: true))
            {
                var buffer = new byte[81920];
                long readTotal = 0;
                int read;
                while ((read = await source.ReadAsync(buffer, cancellationToken)) > 0)
                {
                    await target.WriteAsync(buffer.AsMemory(0, read), cancellationToken);
                    readTotal += read;
                    if (total is > 0)
                    {
                        progress?.Report((double)readTotal / total.Value);

                        // 每 10% 記錄一次，避免記錄檔被進度訊息灌爆。
                        var percent = (int)(readTotal * 100 / total.Value);
                        if (percent >= nextLogPercent)
                        {
                            DebugLog.Info($"下載進度 {percent}%（{readTotal:N0} / {total.Value:N0} bytes）");
                            nextLogPercent = percent / 10 * 10 + 10;
                        }
                    }
                }
            }

            var actualSize = new FileInfo(tempPath).Length;
            DebugLog.Info($"下載結束，暫存檔大小 {actualSize:N0} bytes");

            if (total is > 0 && actualSize != total)
                throw new IOException($"模型檔下載不完整（預期 {total:N0}，實際 {actualSize:N0} bytes），請重新嘗試。");

            File.Move(tempPath, ModelPath, overwrite: true);
            progress?.Report(1.0);
            DebugLog.Info($"模型下載完成：{ModelPath}");
        }
        catch (OperationCanceledException)
        {
            DebugLog.Warn("模型下載已被取消。");
            try { File.Delete(tempPath); } catch { /* 忽略清理失敗 */ }
            throw;
        }
        catch (Exception ex)
        {
            DebugLog.Error("模型下載失敗。", ex);
            try { File.Delete(tempPath); } catch { /* 忽略清理失敗 */ }
            throw;
        }
    }
}

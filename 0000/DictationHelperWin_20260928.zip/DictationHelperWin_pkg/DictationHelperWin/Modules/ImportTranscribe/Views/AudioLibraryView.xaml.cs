using System;
using System.Collections.ObjectModel;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using DictationHelperWin.Modules.ImportTranscribe.Models;

namespace DictationHelperWin.Modules.ImportTranscribe.Views;

/// <summary>
/// 對應企劃書二、2.2：音檔清單（狀態＋長度＋語系，可新增刪除）。
/// </summary>
public partial class AudioLibraryView : UserControl
{
    public static readonly DependencyProperty AvailableLanguagesProperty =
        DependencyProperty.Register(
            nameof(AvailableLanguages),
            typeof(IReadOnlyList<LanguageOption>),
            typeof(AudioLibraryView),
            new PropertyMetadata(Array.Empty<LanguageOption>()));

    /// <summary>每列語系下拉選單的選項來源（由 ImportView 依已安裝語言包設定）。</summary>
    public IReadOnlyList<LanguageOption> AvailableLanguages
    {
        get => (IReadOnlyList<LanguageOption>)GetValue(AvailableLanguagesProperty);
        set => SetValue(AvailableLanguagesProperty, value);
    }

    public ObservableCollection<AudioFile> Files { get; } = new();

    public AudioFile? SelectedFile => FileListView.SelectedItem as AudioFile;

    /// <summary>當使用者於清單中選取不同音檔時觸發，供 ImportView 更新逐字稿檢視。</summary>
    public event EventHandler<AudioFile>? FileSelected;

    public AudioLibraryView()
    {
        InitializeComponent();
        FileListView.ItemsSource = Files;
    }

    public void AddFiles(IEnumerable<AudioFile> files)
    {
        foreach (var f in files) Files.Add(f);
    }

    private void FileListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (SelectedFile is not null)
            FileSelected?.Invoke(this, SelectedFile);
    }

    /// <summary>開啟右鍵選單時，依目前選取的檔案動態產生「以其他語系重新轉錄」的語系子選單。</summary>
    private void FileListView_ContextMenuOpening(object sender, ContextMenuEventArgs e)
    {
        RetranscribeMenuItem.Items.Clear();

        var file = SelectedFile;
        RetranscribeMenuItem.IsEnabled = file is not null &&
            file.Status is not (AudioFileStatus.Converting or AudioFileStatus.Transcribing);

        if (file is null) return;

        foreach (var language in AvailableLanguages)
        {
            var item = new MenuItem
            {
                Header = language.DisplayName,
                Tag = language,
                IsChecked = string.Equals(file.Language, language.Tag, StringComparison.OrdinalIgnoreCase)
            };
            item.Click += RetranscribeLanguageItem_Click;
            RetranscribeMenuItem.Items.Add(item);
        }
    }

    private void RetranscribeLanguageItem_Click(object sender, RoutedEventArgs e)
    {
        if (SelectedFile is not { } file || sender is not MenuItem { Tag: LanguageOption language })
            return;
        if (file.Status is AudioFileStatus.Converting or AudioFileStatus.Transcribing)
            return;

        if (file.Segments.Count > 0)
        {
            var result = MessageBox.Show(
                $"將清除「{file.FileName}」目前的逐字稿，並改以「{language.DisplayName}」重新排入轉錄。\n要繼續嗎？",
                "以其他語系重新轉錄", MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (result != MessageBoxResult.Yes) return;
        }

        file.ResetForRetranscribe(language.Tag);
        FileSelected?.Invoke(this, file); // 讓逐字稿檢視同步清空
    }

    private void RemoveMenuItem_Click(object sender, RoutedEventArgs e)
    {
        if (SelectedFile is not null)
            Files.Remove(SelectedFile);
    }
}

using System.Linq;
using System.Windows;
using System.Windows.Controls;
using DictationHelperWin.Modules.ImportTranscribe.Services;
using DictationHelperWin.Shared;
using DictationHelperWin.Shared.EnvironmentSetup;

namespace DictationHelperWin.Modules.ImportTranscribe.Views;

/// <summary>
/// 對應企劃書第四章（v0.3）：環境設置畫面（ffmpeg 檢查、語言包捷徑、
/// VB-Audio Virtual Cable 安裝與「監聽這個裝置」一次性設定引導）。
/// 另含「預設匯入語系」：新加入音檔的初始語系，每個音檔仍可在清單中個別調整。
/// </summary>
public partial class SettingsView : Window
{
    private readonly SpeechRecognitionService _recognitionService = new();

    public SettingsView()
    {
        InitializeComponent();

        RememberMicCheckBox.IsChecked = App.App.State.RememberLastMicrophone;
        RememberMicCheckBox.Checked += (_, _) => App.App.State.RememberLastMicrophone = true;
        RememberMicCheckBox.Unchecked += (_, _) => App.App.State.RememberLastMicrophone = false;

        DefaultLanguageComboBox.ItemsSource = _recognitionService.GetAvailableLanguages();
        DefaultLanguageComboBox.SelectedValue = App.App.State.DefaultImportLanguage;

        RefreshEnvironmentStatus();
    }

    private void DefaultLanguageComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (DefaultLanguageComboBox.SelectedValue is string tag)
            App.App.State.DefaultImportLanguage = tag;
    }

    private void RefreshEnvironmentStatus()
    {
        var status = App.App.State.EnvironmentCheck.LastStatus;
        FfmpegStatusText.Text = status is null
            ? "ffmpeg：尚未檢查"
            : $"ffmpeg：{(status.FfmpegOk ? "已就緒" : "找不到，webm 轉檔功能無法使用")}";

        if (status is null)
        {
            SpeechPackStatusText.Text = "語音辨識語言包（即時聽抄）：尚未檢查";
        }
        else if (status.MissingLanguageTags is { Count: > 0 } missing)
        {
            SpeechPackStatusText.Text =
                $"語音辨識語言包（即時聽抄）：音檔所選語系尚未安裝（{string.Join("、", missing)}）";
        }
        else
        {
            SpeechPackStatusText.Text =
                $"語音辨識語言包（即時聽抄）：{(status.SpeechLanguagePackMissing ? "尚未安裝" : "已安裝")}";
        }

        WhisperModelStatusText.Text = _recognitionService.ModelManager.IsModelInstalled
            ? $"匯入轉文字模型（Whisper {WhisperModelManager.ModelName}）：已下載"
            : $"匯入轉文字模型（Whisper {WhisperModelManager.ModelName}）：尚未下載" +
              $"（首次轉錄時會提示下載，{WhisperModelManager.ApproxSizeText}）";

        VbCableStatusText.Text = status is null
            ? "系統聲音（VB-Audio Virtual Cable）：尚未檢查"
            : status.VbCableInstalled
                ? "系統聲音（VB-Audio Virtual Cable）：已安裝，可使用系統聲音聽抄"
                : "系統聲音（VB-Audio Virtual Cable）：尚未安裝（選用功能，不影響麥克風聽抄與匯入轉文字稿）";
    }

    private void OpenSpeechSettingsButton_Click(object sender, RoutedEventArgs e)
    {
        ExplorerActions.OpenWindowsSpeechSettings();
    }

    /// <summary>
    /// 安裝內建的 VB-Audio Virtual Cable 驅動包（Resources\VBCABLE_Driver_Pack45.zip）。
    /// 流程：確認 → 解壓縮並以系統管理員權限執行安裝程式 → 結束後重新偵測裝置並更新狀態文字。
    /// </summary>
    private async void InstallVbCableButton_Click(object sender, RoutedEventArgs e)
    {
        var confirm = MessageBox.Show(
            "將安裝 VB-Audio Virtual Cable 虛擬音訊驅動（使用內建安裝包）。\n\n" +
            "• 需要系統管理員權限，Windows 會跳出「使用者帳戶控制」提示\n" +
            "• 安裝程式視窗開啟後，請按「Install Driver」\n" +
            "• 安裝完成後可能需要重新開機\n\n" +
            "要繼續嗎？",
            "安裝 VB-Audio Virtual Cable", MessageBoxButton.YesNo, MessageBoxImage.Question);
        if (confirm != MessageBoxResult.Yes) return;

        InstallVbCableButton.IsEnabled = false;
        try
        {
            var outcome = await EnvironmentCheckService.InstallBundledVbCableAsync();

            // 不論結果如何都重新偵測一次，狀態文字才會是最新的。
            await App.App.State.EnvironmentCheck.RefreshStatusAsync();
            RefreshEnvironmentStatus();

            switch (outcome.Status)
            {
                case VbCableInstallStatus.Completed:
                    if (App.App.State.EnvironmentCheck.LastStatus?.VbCableInstalled == true)
                    {
                        MessageBox.Show(
                            "已偵測到 VB-Audio Virtual Cable。\n" +
                            "接著請按下方「開啟『監聽這個裝置』設定」完成一次性設定，就能使用「系統聲音」聽抄了。",
                            "安裝完成", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                    else
                    {
                        MessageBox.Show(
                            "安裝程式已結束，但目前還沒偵測到 CABLE 裝置。\n" +
                            "可能需要重新開機，重新開機後再開啟本設定頁確認狀態。",
                            "尚未偵測到裝置", MessageBoxButton.OK, MessageBoxImage.Warning);
                    }
                    break;

                case VbCableInstallStatus.CancelledByUser:
                    MessageBox.Show("已取消安裝（未授予系統管理員權限）。", "安裝 VB-Audio Virtual Cable",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                    break;

                case VbCableInstallStatus.PackageMissing:
                case VbCableInstallStatus.SetupNotFound:
                    var reason = outcome.Status == VbCableInstallStatus.PackageMissing
                        ? "找不到內建的安裝包（Resources\\VBCABLE_Driver_Pack45.zip）。"
                        : "安裝包內找不到對應的安裝程式。";
                    var openPage = MessageBox.Show(
                        reason + "\n要改為開啟 VB-Audio 官方下載頁面，自行下載安裝嗎？",
                        "安裝 VB-Audio Virtual Cable", MessageBoxButton.YesNo, MessageBoxImage.Warning);
                    if (openPage == MessageBoxResult.Yes)
                        EnvironmentCheckService.OpenVbCableDownloadPage();
                    break;

                default:
                    MessageBox.Show($"安裝失敗：{outcome.Message}", "安裝 VB-Audio Virtual Cable",
                        MessageBoxButton.OK, MessageBoxImage.Error);
                    break;
            }
        }
        finally
        {
            InstallVbCableButton.IsEnabled = true;
        }
    }

    /// <summary>
    /// 對應企劃書 v0.3 第四章：開啟音效控制台「錄製」分頁，引導使用者完成一次性的
    /// 「CABLE Output → 內容 → 監聽 → 監聽這個裝置」設定（選好自己平常用的喇叭/耳機），
    /// 這樣系統聲音聽抄時才聽得到聲音。這是一次性設定，設定過後不需要每次聽抄都重做。
    /// </summary>
    private void OpenListenSettingButton_Click(object sender, RoutedEventArgs e)
    {
        EnvironmentCheckService.OpenSoundControlPanelRecordingTab();
        MessageBox.Show(
            "已為你開啟「音效」設定的「錄製」分頁：\n" +
            "1. 找到「CABLE Output (VB-Audio Virtual Cable)」，點兩下開啟內容\n" +
            "2. 切到「監聽」分頁，勾選「監聽這個裝置」\n" +
            "3. 在「透過此裝置撥放」選單選擇你平常使用的喇叭/耳機\n" +
            "完成後按確定即可，這是一次性設定，之後開始「系統聲音」聽抄就會自動生效。",
            "設定「監聽這個裝置」", MessageBoxButton.OK, MessageBoxImage.Information);
    }

    private void CloseButton_Click(object sender, RoutedEventArgs e)
    {
        Close();
    }
}

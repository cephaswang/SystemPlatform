using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;
using DictationHelperWin.Modules.ImportTranscribe.Models;
using DictationHelperWin.Modules.ImportTranscribe.Services;
using DictationHelperWin.Shared;

namespace DictationHelperWin.Modules.ImportTranscribe.Views;

/// <summary>
/// 對應企劃書二、2.2：模式一 匯入音檔轉文字稿的主畫面，整合音檔清單與逐字稿檢視。
/// 語系以「每個音檔」為單位；新加入檔案的初始語系取自 AppState（於設定頁修改）。
/// </summary>
public partial class ImportView : Window
{
    private readonly AudioImportService _importService = new();
    private readonly SpeechRecognitionService _recognitionService = new();
    private CancellationTokenSource? _cts;

    public ImportView()
    {
        InitializeComponent();
        DebugLog.Info($"匯入畫面開啟；記錄檔：{DebugLog.CurrentLogPath}");

        var languages = _recognitionService.GetAvailableLanguages();
        AudioLibrary.AvailableLanguages = languages;
    }

    protected override void OnClosed(EventArgs e)
    {
        _cts?.Cancel();
        _recognitionService.Dispose();
        base.OnClosed(e);
    }

    /// <summary>新加入音檔的初始語系；未設定時退回全域預設。</summary>
    private string DefaultLanguage =>
        App.App.State.DefaultImportLanguage is { Length: > 0 } tag ? tag : LanguageDefaults.Tag;

    /// <summary>對應企劃書 2.2：匯入（Windows 開檔對話框 OpenFileDialog）。</summary>
    private void SelectFilesButton_Click(object sender, RoutedEventArgs e)
    {
        var dialog = new OpenFileDialog
        {
            Multiselect = true,
            Filter = "音訊檔案 (*.mp3;*.m4a;*.wav;*.webm)|*.mp3;*.m4a;*.wav;*.webm"
        };

        if (dialog.ShowDialog() == true)
            AddFiles(dialog.FileNames);
    }

    /// <summary>對應企劃書 2.2：拖放匯入。</summary>
    private void ImportView_Drop(object sender, DragEventArgs e)
    {
        if (!e.Data.GetDataPresent(DataFormats.FileDrop)) return;

        var paths = ((string[])e.Data.GetData(DataFormats.FileDrop))
            .Where(_importService.IsSupported);
        AddFiles(paths);
    }

    private void AddFiles(IEnumerable<string> paths)
    {
        var pathList = paths.ToList();
        DebugLog.Info($"加入檔案 {pathList.Count} 個，初始語系={DefaultLanguage}");
        var files = _importService.ImportFiles(pathList, DefaultLanguage);
        AudioLibrary.AddFiles(files);
    }

    /// <summary>
    /// 開始轉錄：先確認 Whisper 模型（首次會詢問並下載），再批次處理所有等待中的檔案。
    /// 轉錄進行中，同一個按鈕變成「取消」。
    /// </summary>
    private async void StartButton_Click(object sender, RoutedEventArgs e)
    {
        // 進行中：這次點擊代表取消。
        if (_cts is not null)
        {
            DebugLog.Info("使用者按下取消");
            _cts.Cancel();
            StartButton.IsEnabled = false;
            StartButton.Content = "取消中…";
            return;
        }

        var pending = AudioLibrary.Files
            .Where(f => f.Status is AudioFileStatus.Pending or AudioFileStatus.LanguageUnavailable)
            .ToList();
        if (pending.Count == 0)
        {
            MessageBox.Show("清單中沒有等待轉錄的檔案。請先匯入音檔。", "開始轉錄",
                MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }

        var modelManager = _recognitionService.ModelManager;
        DebugLog.Info($"按下開始轉錄：待處理 {pending.Count} 個；模型已安裝={modelManager.IsModelInstalled}（{modelManager.ModelPath}）");
        if (!modelManager.IsModelInstalled)
        {
            var confirm = MessageBox.Show(
                $"首次轉錄需要下載 Whisper 語音辨識模型（{WhisperModelManager.ModelName}，{WhisperModelManager.ApproxSizeText}）。\n" +
                "下載後儲存在本機，之後即可離線使用。\n\n要現在下載嗎？",
                "下載語音辨識模型", MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (confirm != MessageBoxResult.Yes)
            {
                DebugLog.Info("使用者拒絕下載模型");
                return;
            }
        }

        _cts = new CancellationTokenSource();
        var token = _cts.Token;
        StartButton.Content = "取消";

        try
        {
            if (!modelManager.IsModelInstalled)
            {
                TaskProgressBar.Visibility = Visibility.Visible;
                TaskProgressBar.Value = 0;
                var downloadProgress = new Progress<double>(p =>
                {
                    TaskProgressBar.Value = p * 100;
                    StatusText.Text = $"下載語音辨識模型…{p:P0}";
                });
                await modelManager.EnsureModelAsync(downloadProgress, token);
            }

            TaskProgressBar.Visibility = Visibility.Visible;
            TaskProgressBar.IsIndeterminate = true;

            var fileProgress = new Progress<AudioFile>(f =>
                StatusText.Text = $"{f.FileName}：{f.StatusText}");
            await _recognitionService.TranscribeBatchAsync(pending, fileProgress, token);

            var done = pending.Count(f => f.Status == AudioFileStatus.Completed);
            var failed = pending.Count(f => f.Status == AudioFileStatus.Failed);
            var unsupported = pending.Count(f => f.Status == AudioFileStatus.LanguageUnavailable);
            DebugLog.Info($"批次結束：完成 {done}、失敗 {failed}、不支援語系 {unsupported}");
            StatusText.Text = $"完成 {done} 個" +
                              (failed > 0 ? $"；失敗 {failed} 個（游標移到狀態欄可看原因）" : "") +
                              (unsupported > 0 ? $"；不支援語系 {unsupported} 個" : "");
        }
        catch (OperationCanceledException)
        {
            DebugLog.Warn("批次已取消");
            StatusText.Text = "已取消。";
        }
        catch (Exception ex)
        {
            DebugLog.Error("批次轉錄發生例外", ex);
            StatusText.Text = "轉錄失敗。";
            MessageBox.Show($"轉錄失敗：{ex.Message}", "開始轉錄",
                MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally
        {
            _cts?.Dispose();
            _cts = null;
            StartButton.Content = "開始轉錄";
            StartButton.IsEnabled = true;
            TaskProgressBar.IsIndeterminate = false;
            TaskProgressBar.Visibility = Visibility.Collapsed;

            // 重新載入目前選取檔案的逐字稿，確保畫面與資料一致。
            if (AudioLibrary.SelectedFile is { } selected)
                TranscriptEditor.LoadSegments(selected.Segments);
        }
    }

    private void AudioLibrary_FileSelected(object? sender, AudioFile file)
    {
        TranscriptEditor.LoadSegments(file.Segments);
    }

    /// <summary>對應企劃書 2.2：匯出 TXT／SRT／DOCX／PDF，可勾選是否含時間戳記。</summary>
    private void ExportButton_Click(object sender, RoutedEventArgs e)
    {
        var selected = AudioLibrary.SelectedFile;
        if (selected is null)
        {
            MessageBox.Show("請先在音檔清單中選擇一個已完成辨識的檔案。", "提醒",
                MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        var exportSheet = new ExportSheetView(selected.Segments);
        exportSheet.Owner = this;
        exportSheet.ShowDialog();
    }

    private void SettingsButton_Click(object sender, RoutedEventArgs e)
    {
        var settings = new SettingsView { Owner = this };
        settings.ShowDialog();
    }
}

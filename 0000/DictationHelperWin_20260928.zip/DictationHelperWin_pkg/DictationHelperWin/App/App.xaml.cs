﻿using System;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;
using DictationHelperWin.Shared;

namespace DictationHelperWin.App;

/// <summary>
/// 對應企劃書二、2.1：App 進入點。
/// 啟動流程：初始化 AppState → 顯示模式選擇畫面（LauncherView）。
/// </summary>
public partial class App : Application
{
    /// <summary>
    /// 全域共用狀態（見 AppState.cs），供 Launcher／LiveDictation／ImportTranscribe 三個模組共用。
    /// </summary>
    public static AppState State { get; private set; } = new AppState();

    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);

        // 除錯記錄：環境資訊與全域未處理例外（只記錄，不改變原本的例外處理行為）。
        DebugLog.Info($"===== App 啟動 ===== OS={RuntimeInformation.OSDescription}；.NET={RuntimeInformation.FrameworkDescription}；" +
                      $"架構={RuntimeInformation.ProcessArchitecture}；程式目錄={AppContext.BaseDirectory}");
        DebugLog.Info($"ffmpeg 內建檔存在={System.IO.File.Exists(System.IO.Path.Combine(AppContext.BaseDirectory, "Resources", "ffmpeg.exe"))}；" +
                      $"runtimes 資料夾存在={System.IO.Directory.Exists(System.IO.Path.Combine(AppContext.BaseDirectory, "runtimes"))}");
        DispatcherUnhandledException += (_, args) =>
            DebugLog.Error("DispatcherUnhandledException", args.Exception);
        AppDomain.CurrentDomain.UnhandledException += (_, args) =>
            DebugLog.Error($"AppDomain.UnhandledException（IsTerminating={args.IsTerminating}）", args.ExceptionObject as Exception);
        TaskScheduler.UnobservedTaskException += (_, args) =>
            DebugLog.Error("TaskScheduler.UnobservedTaskException", args.Exception);

        // 對應企劃書第四章：環境設置大幅簡化。
        // 啟動時僅需非同步檢查 ffmpeg 是否存在、語音辨識語言包是否已安裝，
        // 不需要終端機指令、不需要管理員密碼、不需要重新開機。
        _ = State.EnvironmentCheck.RefreshStatusAsync();
    }

    protected override void OnExit(ExitEventArgs e)
    {
        // 對應企劃書 2.3：聽抄中若尚有未寫入的暫存內容，離開前應強制寫檔（容錯機制）。
        DebugLog.Info($"===== App 結束（ExitCode={e.ApplicationExitCode}）=====");
        State.Dispose();
        base.OnExit(e);
    }
}
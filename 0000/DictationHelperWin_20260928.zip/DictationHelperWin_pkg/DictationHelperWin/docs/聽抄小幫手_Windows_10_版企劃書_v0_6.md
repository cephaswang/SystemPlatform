# 聽抄小幫手 Windows 10 版（VoiceCapture for Windows）企劃書

**版本：v0.6（聽抄模式改用本機 Whisper；系統聲音改用 WasapiLoopbackCapture，不再需要 VB-Audio Virtual Cable 與切換系統裝置）**
**更新日期**：2026-09-28
**專案定位**：單一 Windows 桌面 App，內含「匯入音檔轉文字稿」與「聽抄（即時轉錄）」兩個模式，比照 macOS 版現況（VoxNote 兩模組已整併為單一 App，不再是三個各自獨立的 App）。

> **v0.6 修訂重點**（對應 2026-09-28 的實作、除錯與實測）：
> - **聽抄模式辨識引擎改為本機 Whisper**（與匯入模式相同的 `ggml-small` 模型，經 `WhisperRuntime` 共用同一個 `WhisperFactory`），不再使用 `Windows.Media.SpeechRecognition`。原因：(1) 該引擎只認「系統預設錄音裝置」，迫使 App 在聽抄期間切換系統裝置；(2) 需要 Windows 語言包——實測本機系統支援聽寫的語系只有 `en-US`，中文無法聽抄；(3) 需開啟「線上語音辨識」隱私設定。Whisper 直接吃音訊樣本，三個限制一次解除（見 3.2、3.7）。
> - **系統聲音改用 `WasapiLoopbackCapture`**：直接擷取「預設播放裝置」正在播放的聲音。**不再需要 VB-Audio Virtual Cable、不再切換系統預設播放／錄音裝置、不再需要「監聽這個裝置」設定**，v0.3 起「需要切換系統裝置」的架構與相關風險整組移除（見 3.3、第五章）。
> - **v0.3～v0.5 系統聲音路線失敗的根因（實測）**：VB-CABLE 路線下擷取到的不是原音，而是**回授（feedback）**——擷取音量在約 1～1.5 秒內衰減不了地升到飽和（RMS 約 0.33、峰值近 1.0，音高長時間固定），與原音（RMS 約 0.09、有起伏）完全對不上。最可能的原因是「CABLE Output → 監聽這個裝置」的輸出目標被設成預設播放裝置，而程式又把預設播放切到 CABLE Input，形成迴圈。Loopback 路線沒有這類設定，也就沒有這個風險。
> - **新增 3.7「聽抄辨識管線」**：擷取 → 16 kHz 單聲道 → `LiveSegmenter`（能量式 VAD 分段）→ 佇列 → 單一 Whisper 工作執行緒 → 過濾 → 寫檔。含參數、過濾規則、診斷工具與實測結果。
> - **新增辨識品質機制**：初始提示詞回吐移除（`StripPromptEcho`）、幻覺字幕與非語音標記過濾（`[Music]`、`(音樂)`、「字幕製作」等）、自訂詞彙檔 `vocabulary.txt`。
> - **新增診斷工具**：每 5 秒音訊統計、每段 wav 除錯輸出（`DumpSegments`）、辨識結果寫入記錄檔。
> - **環境檢查改為 ffmpeg ＋ Whisper 模型**；語音語言包與 VB-CABLE 不再列入必要項目（`EnvironmentCheckService` 已改）。
> - 已實作並實測：**系統聲音聽抄**（中文詩篇音源，11 句輸出，延遲約 3～5 秒）。**麥克風聽抄已實作但尚未實測。**
> - 受影響的程式：`SpeechTranscriber.cs`（重寫）、`DictationView.xaml.cs`、`AudioDeviceManager.cs`、`EnvironmentCheckService.cs`；新增 `LiveSegmenter.cs`、`Shared/WhisperRuntime.cs`。

---

## 歷史修訂紀錄（v0.3～v0.5，僅供追溯；其中 VB-CABLE、切換系統裝置與 `Windows.Media.SpeechRecognition` 的內容已被 v0.6 取代）

> **v0.5 修訂重點**（對應 2026-09-28 的實作與除錯狀況）：
> - **匯入模式辨識引擎定案為本機 Whisper（ggml 格式）**：程式實際以 `WhisperModelManager` 管理模型檔，首次轉錄時經使用者同意下載（預設 `ggml-small.bin`，約 470 MB），存放於 `%LOCALAPPDATA%\DictationHelperWin\models`，之後可離線使用。v0.4 待確認的「匯入模式辨識路線」據此結案（見 3.2、3.5、第七章）。
> - **移除匯入畫面上方的「預設語系」下拉選單與「套用到全部」按鈕**（實測無效、且與逐檔語系設定重複）。每個音檔仍在清單中各自設定語系；新加入音檔的初始語系改讀 `AppState.DefaultImportLanguage`（於設定頁修改，未設定時為 zh-TW）。
> - **新增除錯記錄（`Shared/DebugLog.cs`）**：轉錄流程各環節（ffmpeg 轉檔、模型下載、辨識、狀態變更、未處理例外）寫入 `%LOCALAPPDATA%\DictationHelperWin\logs\yyyyMMdd.log`，用來追查音檔顯示「失敗」的原因（見 3.6）。
> - 新增 3.5「Whisper 模型管理」、3.6「除錯記錄」；3.4 專案結構依實際目錄更新；環境設置、風險、開發階段、待確認事項同步更新。
> - 「系統聲音（VB-Audio Virtual Cable）」與「聽抄」模式的設計不變。（**v0.6 已變更**）
>
> **v0.4 修訂重點**：匯入模式的語系設定由「整批共用一個語系」改為「**每個音檔各自設定語系**」。
> - 音檔清單每列有自己的語系下拉選單；上方另設「預設語系」（只影響新加入的檔案）與「套用到全部」。（**v0.5 已移除這兩項，見上方 v0.5 說明**）
> - 語系以 BCP-47 代碼（如 zh-TW、en-US）記錄於每個音檔，轉檔／轉錄中與已完成的檔案鎖定語系；已完成的檔案要換語系須「以其他語系重新轉錄」（清空舊逐字稿）。
> - 某檔所選語系的語言包未安裝時，只標記該檔為「缺語言包」，不中斷整批，並提示開啟 Windows 語音設定。
> - 系統聲音（VB-Audio Virtual Cable）與聽抄模式的設計不變。
>
> **v0.3 修訂重點**：v0.2 因為確認 `Windows.Media.SpeechRecognition` 無法接受 `WasapiLoopbackCapture` 的自訂 PCM 串流，改走 Azure Speech 雲端服務。但需求已明確：**系統聲音模式要免費，不要付費雲端服務**。
>
> 解法：安裝免費的 **VB-Audio Virtual Cable**（Donationware，可設金額為 0 使用），它會在系統建立一組虛擬音訊裝置：
> - **CABLE Input**（虛擬「播放」裝置）
> - **CABLE Output**（虛擬「錄音」裝置，會原封不動收到送進 CABLE Input 的所有聲音）
>
> 因為 CABLE Output 對 Windows 而言就是一個**普通的錄音裝置**（不是自訂串流），只要把它設成系統的**預設錄音裝置**，`Windows.Media.SpeechRecognition`（以及所有只認「預設錄音裝置」的語音辨識 API）就能像讀麥克風一樣讀到系統聲音，完全不需要雲端服務、不需要額外費用、也不需要更換辨識引擎——**麥克風模式與系統聲音模式可以共用同一套 `Windows.Media.SpeechRecognition` 辨識邏輯**。
>
> 代價：因為要讓 CABLE Output 變成「預設錄音裝置」，系統的**預設播放裝置也必須先切到 CABLE Input**，聲音才會被送進虛擬線路；這樣使用者會暫時聽不到聲音，因此還需要在 CABLE Output 的內容內容啟用 Windows 內建的「**監聽這個裝置（Listen to this device）**」，指定輸出到使用者原本的喇叭/耳機，讓聲音同時送到真實喇叭。這代表 **Windows 版在系統聲音模式下，其實跟 macOS 版一樣需要「切換系統預設輸出/輸入裝置」**，第一章原本「Windows 版不需要切換系統裝置」的說法需要修正（僅麥克風模式仍然不需要切換）。

---


---

## 一、專案背景與目標

沿用 macOS 版動機：命令列聽抄流程圖形化、環境設置自動化、即時聽抄、匯入現成錄音批次轉逐字稿。Windows 版目標對齊 macOS 版第二節 1–11 項（圖形介面、多語系、即時顯示＋即時寫檔、依標點斷句加時間戳、輸入裝置選單、於檔案總管顯示逐字稿、容錯強制寫檔、環境一鍵設置、匯入批次轉錄與多格式匯出、內建教學）。

**v0.6 架構結論**：v0.1 曾指出「Windows 的 WASAPI 原生支援 Loopback 錄製模式，不需要虛擬裝置、不需要建立聚合裝置、也不需要切換系統輸出」；v0.2～v0.5 因為 `Windows.Media.SpeechRecognition` 無法接受自訂 PCM 串流，才被迫改走 VB-Audio Virtual Cable ＋ 切換系統預設裝置。**v0.6 改用直接吃樣本的本機 Whisper 後，這個前提消失，v0.1 的說法重新成立**：麥克風與系統聲音都由 NAudio 直接擷取，交給 Whisper 辨識，不需要任何虛擬裝置或系統設定變更。這使 Windows 版系統聲音聽抄的架構**比 macOS 版（BlackHole ＋ Multi-Output Device）更簡單**。

代價是辨識由雲端／系統引擎改為本機 CPU 運算：需下載約 470 MB 模型、辨識有 3～5 秒延遲、專有名詞需要靠詞彙檔補強（見 3.7、第五章）。

---

## 二、功能規格

### 2.1 App 整體流程

與 macOS 版相同：啟動後進入模式選擇畫面（「匯入音檔轉文字稿」／「聽抄」），下方環境狀態列，內建說明頁。

### 2.2 模式一：匯入音檔轉文字稿（v0.4 每檔語系；v0.5 簡化語系操作並定案 Whisper）

- 支援格式：mp3／m4a／wav／webm（webm 先用 ffmpeg 轉成可辨識格式）
- 匯入：拖放或「選擇檔案」（Windows 開檔對話框 `OpenFileDialog`）
- 音檔清單（檔名、長度、**語系**、狀態，可新增刪除）、逐字稿檢視（含時間戳記）
- **每檔語系（v0.4）**：
  - 每個音檔各自有語系設定，清單每列提供語系下拉選單（選項由 `SpeechRecognitionService.GetAvailableLanguages()` 提供，目前為 `zh-TW`、`zh-CN`、`en-US`、`ja-JP`、`ko-KR` 五種；與聽抄共用的清單見 `WhisperRuntime.Languages`）
  - **v0.5：已移除**畫面上方的「預設語系」下拉選單。新加入音檔的初始語系讀取 `AppState.DefaultImportLanguage`（於設定頁修改），未設定時為 zh-TW
  - **v0.5：已移除**「套用到全部」按鈕；要更換語系請在清單中逐檔調整（`AudioImportService.ApplyLanguageToAll` 已無呼叫者，可刪除）
  - 語系鎖定：轉檔中、轉錄中、已完成的檔案不可直接改語系；要改須從右鍵選單選「以其他語系重新轉錄」，確認後清空舊逐字稿並重新排入佇列
  - 不支援語系（程式狀態 `LanguageUnavailable`）：該檔標記為不支援語系，批次轉錄時略過該檔、不中斷其他檔案；更換為支援的語系後可再次轉錄（開始轉錄時會把「等待中」與「不支援語系」的檔案一併納入）
  - 批次轉錄時，同語系的檔案排在一起處理（辨識器綁定語系，減少切換次數）
- **辨識流程（v0.5，依實作）**：
  1. 按「開始轉錄」→ 若清單沒有等待中的檔案，提示先匯入音檔
  2. 檢查 Whisper 模型是否已安裝；未安裝則詢問是否下載（顯示模型名稱與約略大小），同意後顯示下載進度條與狀態列文字
  3. 批次轉錄清單中「等待中」與「不支援語系」的檔案，狀態列即時顯示「檔名：狀態」
  4. 轉錄進行中同一個按鈕變成「取消」，可中途取消
  5. 結束後狀態列摘要「完成 N 個；失敗 N 個（游標移到狀態欄可看原因）；不支援語系 N 個」，並重新載入目前選取檔案的逐字稿
- **失敗排查（v0.5）**：檔案狀態為「失敗」時，原因寫入除錯記錄檔（見 3.6），並可由狀態欄 tooltip 查看
- 匯出：TXT／SRT／DOCX／PDF，可勾選是否含時間戳記

（此模式為批次讀檔後送辨識引擎，不涉及即時裝置切換問題，不受 v0.3 修訂影響；語系設定方式由 v0.4 修訂如上。匯入模式使用本機 Whisper，模型管理見 3.5。）

### 2.3 模式二：聽抄（即時轉錄）（v0.6 改寫）

**聲音來源選單**：「系統聲音」＋ 系統目前所有啟用中的輸入裝置（麥克風）。選單排除 VB-Audio Virtual Cable 的 `CABLE Output`（若使用者電腦仍裝有它，避免被誤當麥克風選取）。系統聲音選項恆為可用，不再因 VB-CABLE 缺少而灰階。

| 項目 | macOS 版 | Windows 版（v0.6） |
| --- | --- | --- |
| 系統聲音來源 | BlackHole 2ch（偽裝成輸入裝置） | **`WasapiLoopbackCapture` 直接擷取預設播放裝置**，不需安裝任何第三方軟體 |
| 開始聽抄時的動作 | 自動切換系統輸出／輸入裝置 | **不切換任何系統裝置**；聲音照常從原本的喇叭／耳機播出 |
| 停止後裝置狀態 | 輸出停留在 Multi-Output Device（macOS 已知限制） | 無需還原（沒有被改動） |
| 麥克風來源 | AVAudioEngine 擷取指定輸入裝置 | NAudio `WasapiCapture` 依裝置 ID 直接開啟指定麥克風（**已實作，尚未實測**） |
| 辨識引擎 | `SFSpeechRecognizer` | **本機 Whisper（`ggml-small`）**，麥克風與系統聲音共用同一條管線 |
| 分段 | 引擎自行判斷 | `LiveSegmenter` 能量式 VAD：說話後停頓 700 ms 即切段，單段上限 20 秒 |

**辨識與輸出**：即時顯示可捲動可複製；每段語音辨識完成後依 Whisper 的句子輸出逐句寫檔並附時間戳記（時間為相對聽抄開始的時間）；停止前跳出確認；停止時把進行中的語音送出並**等佇列中所有段落辨識完成**才收尾（強制寫入未定案內容）；聽抄中鎖定語系與裝置選單；「於檔案總管顯示」快捷鍵（Ctrl+E）。

**畫面狀態（`StatusText`）**：下載模型中 xx%（首次）→ 載入模型中 → 聽抄中… → 辨識中… 第 N 段，佇列 M → 正在辨識最後的內容… → 已停止。

**開始聽抄的流程（`DictationView`）**：
1. 檢查來源與語系已選取
2. 模型未安裝 → 詢問下載（與匯入模式相同的模型與位置）
3. 載入模型並建立 Whisper processor（載入約 0.4 秒〔模型已在記憶體〕；首次載入數秒）
4. 建立逐字稿檔（`文件\聽抄小幫手\聽抄_yyyyMMdd_HHmmss.txt`）、開始擷取
5. 若預設播放裝置目前是 VB-CABLE（舊版異常結束的殘留），拒絕開始並提示改回喇叭／耳機

**雙語模式（隱藏功能）**：舊版「雙引擎比較信心分數」的設計隨 Windows 語音引擎一併不再適用，程式保留 `DualLanguageModeEnabled` 屬性但未實作。Whisper 是多語模型，之後可改為「自動語言偵測」取代（見第七章）。

---

## 三、系統架構

### 3.1 技術選型對照（macOS → Windows，v0.6）

| 項目 | macOS 版 | Windows 版 |
| --- | --- | --- |
| UI 框架 | SwiftUI | WPF（.NET 8，`net8.0-windows10.0.19041.0`） |
| 語音辨識（聽抄與匯入，v0.6 統一） | Speech Framework（`SFSpeechRecognizer`） | **本機 Whisper**：`Whisper.net` 1.9.1 ＋ `Whisper.net.Runtime`（CPU），`ggml-small` 模型；`WhisperRuntime.GetFactory` 共用同一份已載入模型 |
| 音訊擷取（麥克風） | AVFoundation（`AVAudioEngine`） | NAudio `WasapiCapture`，依裝置 ID 開啟 |
| 音訊擷取（系統聲音，v0.6） | BlackHole 虛擬裝置 | **NAudio `WasapiLoopbackCapture`**（預設播放裝置），不需虛擬裝置 |
| 格式轉換 | — | `BufferedWaveProvider` → `ToSampleProvider` → 多聲道平均為單聲道 → `WdlResamplingSampleProvider` 轉 16 kHz |
| 即時分段 | — | `LiveSegmenter`（能量式 VAD，見 3.7） |
| 虛擬音訊裝置 | 需要（BlackHole） | **不需要** |
| 音訊裝置列舉 | CoreAudio | NAudio `MMDeviceEnumerator`；**不再切換系統預設裝置**（`IPolicyConfig` 未公開介面不再使用） |
| 音檔轉檔 | ffmpeg（webm→m4a） | ffmpeg.exe（匯入模式用，轉成 16 kHz wav） |
| 環境檢查 | setup.sh／uninstall.sh | 檢查 ffmpeg、Whisper 模型（語言包與 VB-CABLE 已移出必要項目） |
| 檔案輸出 | FileManager／FileHandle | `System.IO`；DOCX 用 OpenXML SDK，PDF 用既有 PDF 產生套件 |

### 3.2 語音辨識選型說明（v0.6 改寫）

**決策紀錄：為何聽抄放棄 `Windows.Media.SpeechRecognition`**

| 問題 | 說明 |
| --- | --- |
| 只認系統預設錄音裝置 | 無法指定裝置 ID、無法餵自訂 PCM，導致必須切換系統預設裝置（v0.3 起的複雜度與風險來源） |
| 語言包依賴 | 實測本機 `SpeechRecognizer.SupportedTopicLanguages` 只有 `en-US`，中文無法聽抄；且語言包需使用者自行下載 |
| 隱私設定依賴 | 需開啟「線上語音辨識」 |
| 系統聲音路線不穩 | VB-CABLE ＋ 監聽設定實測出現回授，擷取到的不是原音（見上方 v0.6 說明） |

**現行方案**：聽抄與匯入都使用本機 Whisper。
- 麥克風、系統聲音與匯入音檔都轉成 **16 kHz 單聲道 float** 後送 Whisper，不受裝置限制。
- **語系**：固定五種（`zh-TW`、`zh-CN`、`en-US`、`ja-JP`、`ko-KR`），由 `WhisperRuntime.Languages` 提供；語系代碼經 `ToWhisperLanguage` 轉成 `zh`、`en` 等。清單與系統語言包無關。
- **初始提示詞**：繁體中文為「以下是繁體中文的逐字稿，請使用繁體中文與標點符號。」，簡體中文有對應版本；用來引導輸出繁／簡體與標點，僅為引導，不保證 100%。
- **自訂詞彙檔**（`%LOCALAPPDATA%\DictationHelperWin\vocabulary.txt`）：一行一詞（或以逗號、頓號分隔），`#` 為註解；開始聽抄時讀取，附加為「常見詞彙：……。」接在初始提示詞後，上限約 150 字。用來提高專有名詞的辨識率。
- `System.Speech.Recognition`（SAPI）與 Azure Speech 等雲端服務維持不採用。
- Whisper 模型只在首次使用時下載一次（見 3.5），辨識完全在本機執行，不產生費用。

**Whisper 用於即時聽抄的取捨**
- 延遲：說完一句話後要等 700 ms 停頓才切段，再加辨識時間；實測每段辨識約 3.5～4.2 秒（`small`、CPU），與音訊長度幾乎無關（Whisper 固定以 30 秒窗處理），整體延遲約 3～5 秒。
- 在持續有聲、沒有停頓的來源上，要等到 20 秒上限才會切段，可能切在句子中間。
- 對專有名詞、書面語、宗教／專業詞彙容易聽錯（實測「耶和華」→「一和華」、「糠秕」→「康比」）；靠詞彙檔與較大模型改善（見第七章）。

### 3.3 聽抄的音訊路徑（v0.6 改寫）

```
系統聲音模式：
  YouTube / 瀏覽器 / Media Player / Teams 等所有程式的聲音
       └→ Windows 預設播放裝置（使用者的喇叭／耳機，聲音照常播出）
              └→ WasapiLoopbackCapture（讀取該裝置的混音輸出）
                     └→ 16 kHz 單聲道 → LiveSegmenter → Whisper → 即時畫面 + 逐字稿檔案

麥克風模式：
  指定輸入裝置（依裝置 ID 直接開啟，不改系統預設）→ WasapiCapture
       └→ 16 kHz 單聲道 → LiveSegmenter → Whisper → 即時畫面 + 逐字稿檔案
```

系統聲音模式的行為與限制：
- Loopback 綁定「**按下開始當下**的預設播放裝置」；聽抄中切換喇叭／耳機，仍抓原裝置，需停止後重新開始。
- 擷取的是**整個系統的混音**，無法只抓單一程式；其他程式的通知音、背景音樂都會混入。
- 沒有任何聲音播放時，Loopback 不會送資料（統計顯示樣本數為 0 屬正常）；`LiveSegmenter.Tick()` 每 250 ms 呼叫以處理「說完最後一句後沒有新資料」的收尾。
- 若預設播放裝置是 VB-CABLE 的 `CABLE Input`，程式拒絕開始並提示改回真實喇叭。
- 部分以獨佔模式輸出或有 DRM 保護的播放內容可能擷取不到（WASAPI 一般已知限制，待實測）。

### 3.4 專案模組拆分（v0.6：依實際目錄更新）

```
DictationHelperWin/
├── App/ (App.xaml, App.xaml.cs, AppState.cs)
├── app.manifest, DictationHelperWin.csproj, DictationHelperWin.sln
├── Modules/
│   ├── Launcher/ (LauncherView：模式選擇＋環境狀態列)
│   ├── LiveDictation/
│   │   ├── DictationView.xaml / .cs     # 聽抄畫面（模型下載確認、狀態顯示、停止時等佇列）
│   │   ├── SpeechTranscriber.cs         # 聽抄核心（v0.6 重寫）：擷取、轉換、佇列、Whisper、過濾、寫檔
│   │   ├── LiveSegmenter.cs             # 能量式 VAD 分段器（v0.6 新增）
│   │   ├── AudioDeviceManager.cs        # 裝置列舉（系統聲音選項恆可用；排除 CABLE 虛擬裝置）
│   │   └── AudioLevelProbe.cs           # 舊除錯用音量探測，聽抄已不使用（可刪）
│   └── ImportTranscribe/
│       ├── Models/ (AudioFile〔含每檔 Language、Status〕, TranscriptSegment, LanguageOption)
│       ├── Services/
│       │   ├── AudioImportService.cs
│       │   ├── AudioConverterService.cs     # ffmpeg 轉檔
│       │   ├── SpeechRecognitionService.cs  # Whisper 批次轉錄（仍持有自己的 factory，待改用 WhisperRuntime）
│       │   ├── WhisperModelManager.cs       # Whisper 模型下載與管理（匯入／聽抄共用）
│       │   └── ExportService.cs
│       └── Views/ (ImportView, AudioLibraryView, TranscriptEditorView, ExportSheetView, SettingsView)
├── Shared/
│   ├── WhisperRuntime.cs                # v0.6 新增：共用 WhisperFactory、語系表、語言碼轉換、初始提示詞
│   ├── EnvironmentSetup/ (EnvironmentCheckService：檢查 ffmpeg、Whisper 模型)
│   ├── DebugLog.cs                      # 除錯記錄寫檔（見 3.6）
│   ├── ExplorerActions.cs
│   ├── PermissionManager.cs             # 隱私設定記錄（麥克風）
│   ├── AudioRouteSwitcher.cs            # 【聽抄已不使用，可移除】舊系統聲音路由切換
│   └── DefaultRecordingDeviceSwitcher.cs# 【聽抄已不使用，可移除】舊預設錄音裝置切換（IPolicyConfig）
├── docs/ (企劃書、readme.txt)
└── Resources/ (ffmpeg.exe；VBCABLE_Driver_Pack45.zip 已不需要，可移出專案)
```

> 註：`AudioSwitcher.AudioApi.CoreAudio` 套件只服務於舊的裝置切換；移除上述兩個切換類別後可一併移除該套件。記錄檔中反覆出現的 `UnobservedTaskException（Parameter 'source'）` 就來自這個套件內部的裝置變更廣播，Loopback 路線未再呼叫它後，該錯誤在實測中已不再出現。

### 3.5 Whisper 模型管理（v0.5 新增，v0.6 起匯入與聽抄共用，`WhisperModelManager.cs`）

匯入模式與聽抄模式都使用本機 Whisper 辨識。模型檔體積大，**不內嵌於安裝檔**，改為首次轉錄或聽抄時由使用者同意後下載。

| 項目 | 現況（依程式） |
| --- | --- |
| 模型 | `small`（`ggml-small.bin`），約 470 MB；程式註解指出對中文的表現比 `base` 好很多 |
| 來源 | Hugging Face `ggerganov/whisper.cpp` 的 `main` 分支（`resolve/main/ggml-small.bin`） |
| 存放位置 | `%LOCALAPPDATA%\DictationHelperWin\models\ggml-small.bin` |
| 換模型大小 | 改 `ModelName`、`ModelFileName`、`ApproxSizeText` 與下載網址（tiny／base／small／medium）；舊模型檔不會自動清除 |
| 可用判斷 | `IsModelInstalled = File.Exists(ModelPath)`；正式檔名只在下載完整並通過大小檢查後才會產生，因此檔案存在即視為可用 |

**下載流程（`EnsureModelAsync`）**
```
已安裝？ ── 是 ──► 直接返回
   │否
   ▼
建立 models 資料夾 → GET（ResponseHeadersRead）→ 檢查 HTTP 成功
   ▼
串流寫入暫存檔 ggml-small.bin.download（80 KB 緩衝），回報進度 0.0～1.0（需伺服器提供 Content-Length）
   ▼
若有 Content-Length：比對暫存檔大小，不符 → 丟出 IOException「模型檔下載不完整」
   ▼
File.Move(暫存檔 → ggml-small.bin, overwrite) → 回報 100%
（任何例外：刪除暫存檔後重新丟出；取消由 CancellationToken 控制）
```

**與畫面的互動**：
- 聽抄（`DictationView`，v0.6）：按「開始聽抄」時若模型未安裝，跳出相同的確認對話框；同意後於狀態列顯示「下載模型中… xx%」，完成後接著載入模型並開始擷取。
- 匯入（`ImportView`）：按「開始轉錄」時若模型未安裝，先跳出確認對話框（顯示模型名稱與約略大小，說明「下載後儲存在本機，之後即可離線使用」）；同意後顯示進度條與「下載語音辨識模型…xx%」，「開始轉錄」按鈕變成「取消」。

**已知限制與改善方向**
1. **無斷點續傳**：中斷後須從頭下載約 470 MB
2. **驗證強度有限**：僅在伺服器提供 `Content-Length` 時比對大小，沒有雜湊（SHA-256）驗證；伺服器未提供長度時完全不驗證
3. **無逾時**：`HttpClient.Timeout` 設為無限，網路卡住時只能由使用者手動取消
4. **未防併發**：`EnsureModelAsync` 沒有鎖，若同時呼叫兩次會爭用同一暫存檔（目前 UI 以 `_cts` 擋住重入，風險低）
5. **需連線至 huggingface.co**：離線、防火牆或公司網路環境下首次使用會失敗，應提供「手動放置模型檔」的說明與路徑
6. **未預檢磁碟空間**
7. **下載來源綁 `main` 分支**：上游檔案變動時無法重現同一版本，建議改為固定版本（commit）或自建鏡像
8. **失敗原因需可追查**：下載例外應寫入除錯記錄（見 3.6）

**模型載入與共用（v0.6）**：`WhisperRuntime.GetFactory(modelPath)` 以鎖保護、依路徑快取；模型載入約需數秒（首次），之後同一次執行內重複取用為毫秒級。**匯入模式的 `SpeechRecognitionService` 目前仍持有自己的 factory**，兩個模式在同一次執行都用到時會各載入一份模型（`small` 佔用數百 MB 記憶體），待改為共用（見第七章）。

### 3.6 除錯記錄（v0.5 新增，`Shared/DebugLog.cs`）

**目的**：追查匯入音檔顯示「失敗」卻看不到原因的問題（例外原先只進入狀態欄 tooltip）。

| 項目 | 說明 |
| --- | --- |
| 記錄位置 | `%LOCALAPPDATA%\DictationHelperWin\logs\yyyyMMdd.log`（依日期分檔，UTF-8） |
| 格式 | `時間 [等級] [執行緒] 類別.方法 - 訊息`，例外附完整 `ToString()`（含堆疊與 InnerException） |
| API | `DebugLog.Info(msg)`、`DebugLog.Warn(msg)`、`DebugLog.Error(msg, ex)`；同時輸出到 Visual Studio 輸出視窗 |
| 安全性 | 執行緒安全；寫檔失敗一律吞掉，不影響主流程 |
| 隱私原則 | 匯入模式：記錄檔名、語系、狀態、路徑與錯誤，**不寫入逐字稿內容**。**聽抄（v0.6 除錯階段例外）**：每句辨識結果會寫入記錄檔（`辨識結果 [時間] 文字`），便於對照；正式版應改為可關閉或預設關閉（見第七章） |

**規劃加入記錄的位置**

| 檔案 | 記錄內容 |
| --- | --- |
| `SpeechRecognitionService.cs` | 批次與逐檔的開始／結束、語系、辨識器建立、設為「失敗」的 catch 區塊（完整例外） |
| `AudioConverterService.cs` | ffmpeg 完整路徑與 `File.Exists`、命令列參數、退出碼、stderr、輸出檔是否存在與大小 |
| `WhisperModelManager.cs` | 模型路徑、是否已安裝、HTTP 狀態、Content-Length、下載進度（每 10%）、完成大小、例外 |
| `AudioFile.cs` | 狀態變更（檔名、舊→新狀態、錯誤訊息） |
| `AudioImportService.cs` | 匯入路徑、長度讀取結果、初始語系 |
| `ImportView.xaml.cs` | 開始轉錄的待處理檔數、模型是否已安裝、三個 catch 區塊 |
| `App.xaml.cs` | 啟動環境（OS、.NET、程式目錄）；掛上 `DispatcherUnhandledException`、`AppDomain.UnhandledException`、`TaskScheduler.UnobservedTaskException` |
| `SpeechTranscriber.cs`（v0.6） | 擷取裝置與格式、Whisper 提示詞與詞彙載入、每 5 秒音訊統計（樣本數、最大 RMS、有聲影格）、每段的分段原因與長度、辨識耗時、被過濾的文字、移除的提示詞回吐、辨識結果 |
| `SettingsView`（選用） | 「開啟記錄資料夾」按鈕 |

**目前調查中的問題**：`1_001.mp3`（長度 00:05:13）轉錄狀態為「失敗」。優先檢查項目：ffmpeg 是否有被複製到輸出目錄並能被找到、模型是否下載完整、轉出的 wav 是否有效。

---

### 3.7 聽抄辨識管線（v0.6 新增，`SpeechTranscriber.cs`、`LiveSegmenter.cs`）

**處理流程**

```
擷取執行緒（WASAPI DataAvailable）
  BufferedWaveProvider → 樣本 → 多聲道平均為單聲道 → WDL 重取樣 16 kHz
  → LiveSegmenter.AddSamples（每 30 ms 一個影格，算 RMS）
計時器（每 250 ms）→ LiveSegmenter.Tick（處理「沒有新資料」時的收尾）＋每 5 秒記錄統計
LiveSegmenter.SegmentReady（語音起點含 300 ms 前緩衝）
  → Channel 佇列（無上限，單一讀取者）
單一 Whisper 工作執行緒（整個聽抄期間重用同一個 processor）
  → 存除錯 wav（選用）→ Whisper ProcessAsync
  → 移除提示詞回吐 → 過濾非語音／幻覺 → 每句以「段落起點＋Whisper 偏移」為時間戳 → 寫檔＋SegmentTranscribed 事件
```

**`LiveSegmenter` 參數（皆可調）**

| 參數 | 預設 | 說明 |
| --- | --- | --- |
| `VoiceThreshold` | 0.01（RMS） | 影格 RMS ≥ 此值視為有聲；麥克風音量偏小時可能需調低（待實測） |
| `EndSilence` | 700 ms | 說話後連續靜音達此長度即結束該段 |
| `MaxSegment` | 20 秒 | 持續有聲的來源達此長度強制切段（可能切在句中） |
| `PreRoll` | 300 ms | 語音起點前保留的緩衝，避免吃掉字頭 |
| `MinVoice` | 300 ms | 有聲時間不足者視為雜訊丟棄，避免 Whisper 對雜音產生幻覺 |

**輸出過濾（`SpeechTranscriber`）**

| 機制 | 說明 |
| --- | --- |
| 移除提示詞回吐 | Whisper 有時把初始提示詞片段混進真實結果（實測：「按時和,請使用繁體中文與標點符號。」）。把提示詞中長度 ≥ 6 字的子句從結果移除，剩下的才是內容 |
| 非語音標記 | 空白、只有標點／符號、`[Music]`、`(音樂)`、`（…）`、以 ♪ 開頭者略過 |
| 已知幻覺字幕 | 「字幕製作」「字幕由」「感謝觀看」`Thanks for watching`、`Subtitles by`、`Amara.org` 等（Whisper 訓練資料中的片尾字幕）略過 |

**停止流程**：停止擷取 → 停止計時器 → `Flush()` 送出進行中的語音 → 關閉佇列寫入端 → **等工作執行緒把佇列處理完** → 關閉逐字稿檔。「不寫入未定案內容」的選項（`flushPending=false`）會直接取消未辨識的段落。

**診斷工具**

| 工具 | 說明 |
| --- | --- |
| 音訊統計 | 每 5 秒一行：樣本數（16 kHz 下約 8 萬）、最大 RMS、有聲影格數；樣本數 0 表示沒有資料（Loopback 靜音屬正常），最大 RMS 遠低於 0.01 表示音量太小 |
| 除錯 wav（`DumpSegments`，預設 `true`） | 每段送給 Whisper 的音訊存為 `%LOCALAPPDATA%\DictationHelperWin\logs\segments\seg_HHmmss_N.wav`，超過 2 天自動清除。可直接播放確認 Whisper 實際收到什麼。**穩定後改為 `false`** |
| 辨識結果記錄 | 每句寫入記錄檔（見 3.6 隱私說明） |

**實測紀錄（2026-09-28，系統聲音、`zh-TW`、`small`、CPU）**
- 音源為中文詩篇朗讀；11 句輸出，段落長 1.8～4.7 秒，都在說話停頓處切段。
- 每段辨識耗時 3.5～4.2 秒，佇列大致跟得上、沒有持續累積；最後按停止時佇列有 1 段，已等到辨識完成才收尾。
- 音量：最大 RMS 0.23～0.30，有起伏（對照回授時的 0.33 固定平線）。
- 錯誤集中在專有名詞與書面語：「耶和華」→「一和華」（兩次）、「糠秕」→「康比」、「站立」→「戰力」、「義人」→「一人」；另有一次提示詞回吐（已加移除機制）。
- 早期測試（VB-CABLE 路線）的音訊分析：擷取內容與原音檔逐時間點比對，頻譜形狀相關係數僅 0.10（幾乎隨機），音高固定；確認是回授而非辨識問題。

---

## 四、環境設置（v0.6 更新）

| 項目 | macOS 版四項檢查 | Windows 版（v0.6） |
| --- | --- | --- |
| 虛擬音訊裝置 | 需要（BlackHole，免費） | **不需要**（v0.6 起系統聲音用 Loopback；VB-Audio Virtual Cable 不再是前提） |
| 聚合/切換裝置邏輯 | 需要（Multi-Output Device） | **不需要**（不切換任何系統裝置） |
| ffmpeg | 需要 | 需要（匯入模式轉檔；`Resources\ffmpeg.exe`，已確認複製到輸出目錄） |
| 語音辨識語言包 | 系統內建 | **不需要**（Whisper 為多語模型，與 Windows 語言包無關） |
| Whisper 模型 | 不適用 | **需要**：首次轉錄或聽抄前下載 `ggml-small.bin`（約 470 MB）至 `%LOCALAPPDATA%\DictationHelperWin\models`，需連網與足夠磁碟空間；下載後可離線使用 |
| 「線上語音辨識」隱私設定 | 不適用 | **不需要**（v0.6 起不再使用 Windows 語音辨識） |
| 麥克風權限 | 需要 | 麥克風模式需要（「設定 → 隱私權與安全性 → 麥克風」）；系統聲音（Loopback）是否需要麥克風權限，待實測 |
| 雲端服務金鑰 | 不適用 | 不需要 |

環境檢查流程（v0.6）：
1. 檢查 ffmpeg 是否存在（內建 `Resources\ffmpeg.exe`，找不到再試系統 PATH）
2. 檢查 Whisper 模型是否已下載（`WhisperModelManager.IsModelInstalled`）；未下載時狀態列提示「首次轉錄或聽抄時會詢問是否下載」
3. 摘要文字只反映以上兩項；`EnvironmentStatus` 新增 `WhisperModelInstalled`，`SpeechLanguagePackMissing` 恆為 false，`VbCableInstalled` 僅為舊設定頁相容而保留

不需要終端機指令、不需要管理員密碼。VB-CABLE 的安裝／偵測方法（`InstallBundledVbCableAsync` 等）與設定頁相關區塊已無用途，可移除（見第七章）。

---

## 五、風險與已知限制（v0.6 更新）

**v0.6 移除的風險**（因不再切換系統裝置、不再使用 Windows 語音引擎與 VB-CABLE）：`Windows.Media.SpeechRecognition` 只認預設錄音裝置、系統預設裝置卡在 CABLE 的還原風險、`IPolicyConfig` 未公開介面與防毒軟體相容性、VB-CABLE 第三方軟體的散布授權與重開機、「監聽這個裝置」的延遲與回授、多組虛擬音訊裝置共存的相容性、辨識器語系切換成本、Windows 語言包缺少造成的「不支援語系」（Whisper 路線下語系固定為五種）。

| 項目 | 說明 |
| --- | --- |
| **聽抄延遲（v0.6 新增）** | 說完後需 700 ms 停頓＋約 3.5～4.2 秒辨識（`small`、CPU），實測整體延遲約 3～5 秒；不適合需要逐字即時字幕的用途。辨識耗時幾乎固定，段落密集時佇列可能累積（記錄檔於佇列超過 3 段時警告） |
| **CPU 用量與模型大小取捨（v0.6 新增）** | `medium` 中文更準，但在 CPU 上每段預期慢 2～3 倍，佇列會持續累積；需 GPU 加速（`Whisper.net.Runtime.Vulkan`／`.Cublas`，待評估）或維持 `small` |
| **專有名詞與書面語辨識錯誤（v0.6 新增）** | 實測宗教詞彙與書面語常聽錯；以自訂詞彙檔（`vocabulary.txt`）補強，效果待實測；詞彙過長會擠掉提示詞、增加回吐與幻覺風險 |
| **非語音與幻覺（v0.6 新增）** | 音樂、雜訊、靜音上 Whisper 會輸出 `[Music]`、`(音樂)`、提示詞或片尾字幕；已用 `MinVoice`、輸出過濾與幻覺字幕清單處理，但清單無法窮舉 |
| **持續有聲來源的分段（v0.6 新增）** | 沒有停頓的來源（背景音樂、連續朗讀）要等 20 秒上限才切段，可能切在句子中間 |
| **音量門檻（v0.6 新增）** | `VoiceThreshold = 0.01` 為固定值；麥克風音量偏小時可能整段被當雜訊丟棄，需實測是否改為自適應 |
| **系統聲音為整體混音（v0.6 新增）** | 無法只抓單一程式，其他程式的聲音會混入；聽抄前建議關閉不相關的聲音 |
| **Loopback 綁定開始時的預設播放裝置（v0.6 新增）** | 聽抄中更換喇叭／耳機不會跟著換，需停止後重新開始；是否要自動偵測並提示，見第七章 |
| **舊版殘留狀態（v0.6 新增）** | 使用者電腦上若殘留舊版留下的設定（預設播放／錄音裝置停在 CABLE、CABLE Output 開著「監聽這個裝置」），需人工改回；程式對「預設播放是 CABLE」會拒絕開始並提示 |
| **記錄檔含辨識文字、除錯 wav 佔空間（v0.6 新增）** | 除錯階段每句辨識結果寫入記錄檔、每段音訊存為 wav（自動清除 2 天前）；正式版須關閉或提供開關，避免隱私與磁碟問題 |
| **Whisper 模型首次下載** | 約 470 MB，需連線 huggingface.co；無續傳、無雜湊驗證、無逾時（見 3.5）；離線或受限網路首次使用會失敗，需提供手動放置說明 |
| **本機辨識的效能與資源** | `small` 對長音檔（如 5 分鐘以上）耗時與記憶體用量較高，需實測；匯入與聽抄各載入一份模型時記憶體加倍（見 3.5） |
| **轉檔／依賴檔缺漏** | `ffmpeg.exe` 位於 `Resources\`（啟動記錄確認已複製到輸出目錄）；Whisper 原生執行階段檔案（`runtimes` 資料夾）需隨程式一併輸出（啟動記錄確認存在） |
| **「失敗」缺乏可追查資訊** | 以 `DebugLog` 寫入記錄檔補足（見 3.6） |
| ffmpeg 依賴 | 與 macOS 版相同 |
| 麥克風模式混入環境音 | 與 macOS 版相同；麥克風路徑已實作但尚未實測 |
| 麥克風權限 | Windows 對應「設定 → 隱私權與安全性 → 麥克風」，麥克風模式需引導使用者開啟 |
| App 簽章 | 未簽章安裝檔會觸發 SmartScreen 警告，需程式碼簽章憑證 |

---

## 六、開發階段規劃（v0.6 更新）

| 階段 | 內容 |
| --- | --- |
| Phase 1 | 麥克風即時聽抄、斷句寫檔 — 原以 `Windows.Media.SpeechRecognition` 完成；**v0.6 改為 Whisper 管線，已實作、尚未實測** |
| Phase 2 | 系統聲音聽抄 — **v0.6 改為 `WasapiLoopbackCapture`，已完成並實測**（中文音源，11 句，延遲 3～5 秒）；VB-CABLE 整合方案取消 |
| Phase 3 | 匯入音檔轉文字稿模組（ffmpeg 轉檔、每檔語系、本機 Whisper 與模型管理、逐字稿檢視、除錯記錄）— **進行中**：主要畫面與服務已實作；`1_001.mp3` 轉錄失敗待查明 |
| Phase 3.5 | **聽抄辨識品質與效能（v0.6 新增）**：詞彙檔效果驗證、模型／GPU 加速評估、分段策略（持續有聲來源）、音量門檻、麥克風路徑實測 — **進行中** |
| Phase 4 | 匯出功能（TXT／SRT／DOCX／PDF） |
| Phase 5 | 環境設置畫面（ffmpeg 與 Whisper 模型檢查）、於檔案總管顯示、教學頁；**清理舊碼（VB-CABLE、裝置切換、AudioSwitcher 套件）** |
| Phase 6 | 打包簽章與發布（獨立安裝檔／Microsoft Store 兩路線評估；因已不呼叫 `IPolicyConfig`，MSIX 沙盒的主要疑慮降低，仍需驗證 Loopback、外部 ffmpeg.exe 與原生 Whisper 執行檔的相容性）；雙語／自動語言偵測評估 |

---

## 七、待確認事項（v0.6 更新）

**已結案**
- [x] ~~語音辨識路線~~ → **v0.6 定案：聽抄與匯入統一使用本機 Whisper**（取代 v0.3 的 `Windows.Media.SpeechRecognition`）
- [x] ~~系統聲音擷取方式~~ → **v0.6 定案：`WasapiLoopbackCapture`**，不使用 VB-Audio Virtual Cable
- [x] ~~VB-Audio Virtual Cable 的散布方式~~ → **不再需要**，此議題取消
- [x] ~~系統預設裝置切換是否自動化~~ → **不再切換**，議題取消
- [x] ~~`Resources\VBCABLE_Driver_Pack45.zip` 的授權與定位~~ → 不再需要，移出專案即可（見清理項）
- [x] ~~`ffmpeg.exe` 是否複製到輸出目錄~~ → 啟動記錄顯示內建檔存在、`runtimes` 資料夾存在，已確認
- [x] 匯入模式語系粒度：每個音檔各自設定語系（v0.4）；預設語系與「套用到全部」已移除（v0.5）
- [x] 初始語系規則：新加入檔案套用 `AppState.DefaultImportLanguage`，沒有紀錄時為 zh-TW
- [x] 不支援語系處理：標記 `LanguageUnavailable`、略過不中斷整批；已完成檔案換語系一律清空並重新轉錄
- [x] 匯入模式辨識路線：本機 Whisper（v0.5）

**聽抄（v0.6 新增）**
- [ ] **麥克風路徑實測**：已實作（`WasapiCapture` 依裝置 ID），尚未測試；含 `VoiceThreshold` 是否過高、裝置 ID 比對（目前以「ID 互相包含」，找不到退回預設錄音裝置）
- [ ] **延遲與模型**：`small` 約 3～5 秒延遲；是否評估 GPU 加速（`Whisper.net.Runtime.Vulkan`／`.Cublas`）搭配 `medium`，或提供設定頁切換 tiny／base／small／medium
- [ ] **自訂詞彙**：目前為手動編輯 `vocabulary.txt`；是否提供設定頁編輯介面、是否依語系分檔、詞彙長度上限與效果驗證
- [ ] **持續有聲來源的分段策略**：`MaxSegment` 20 秒是否過長、是否加入「句尾標點」之外的切段依據；`VoiceThreshold` 是否改自適應
- [ ] **聽抄中預設播放裝置改變**：是否偵測並提示（或自動重啟擷取）
- [ ] **記錄檔隱私與除錯輸出**：辨識結果寫入記錄檔是否僅限除錯；`DumpSegments` 預設改 `false`；記錄檔保留策略（例如最近 14 天、單檔上限）與設定頁「開啟記錄資料夾」
- [ ] **雙語模式去留**：改為 Whisper 自動語言偵測，或移除 `DualLanguageModeEnabled`
- [ ] **語系清單共用**：`SpeechRecognitionService.SupportedLanguages` 與 `WhisperRuntime.Languages` 各有一份，應統一
- [ ] **`SpeechRecognitionService` 改用 `WhisperRuntime.GetFactory`**：避免兩個模式各載入一份模型
- [ ] **Loopback 是否需要麥克風權限**、獨佔模式／DRM 內容是否擷取不到：待實測

**清理舊碼（v0.6 新增）**
- [ ] 移除 `Shared/AudioRouteSwitcher.cs`、`Shared/DefaultRecordingDeviceSwitcher.cs`，以及 `.csproj` 的 `AudioSwitcher.AudioApi.CoreAudio` 套件與相關註解
- [ ] 移除 `Modules/LiveDictation/AudioLevelProbe.cs`（聽抄已不使用）
- [ ] 移除 `SettingsView` 的 VB-CABLE 安裝／「監聽這個裝置」引導區塊，以及 `EnvironmentCheckService` 中 VB-CABLE 的偵測、安裝與開啟音效控制台方法、`EnvironmentStatus.VbCableInstalled` 欄位
- [ ] 移除 `Resources\VBCABLE_Driver_Pack45.zip` 與 `.csproj` 的複製設定
- [ ] `AppState.Dispose` 的記錄訊息仍寫「內含還原系統預設裝置」，已過時
- [ ] 使用者端：Windows 聲音設定中預設錄音裝置若停在 CABLE Output、CABLE Output 開著「監聽這個裝置」，需手動改回／關閉（測試機目前仍是）

**其他（沿用）**
- [ ] 是否需要自動語言偵測（匯入模式每檔自動判斷語系，取代手動選擇）
- [ ] 品牌名稱是否延用「聽抄小幫手」，或另立 Windows 版名稱
- [ ] 麥克風裝置選擇是否需要「記住上次選擇」邏輯（沿用 macOS 版設計；`AppState` 已有 `RememberLastMicrophone`）
- [ ] DOCX／PDF 匯出套件選型（OpenXML SDK 之外是否有現成方案）
- [ ] 發行路線：獨立安裝檔（需程式碼簽章）或 Microsoft Store（MSIX 沙盒下的 Loopback、外部 ffmpeg.exe、原生 Whisper 執行檔相容性需驗證）
- [ ] 是否需要系統匣常駐模式（比照 macOS 版「未來擴充建議」的選單列模式）
- [ ] **`1_001.mp3` 轉錄失敗的原因**：待以除錯記錄檔查明（ffmpeg 路徑／轉檔、模型檔完整性、辨識例外）
- [ ] **Whisper 模型選擇**：預設 `small`（470 MB）是否足夠／過重；是否提供設定頁選項切換 tiny／base／small／medium
- [ ] **模型下載強化**：續傳、SHA-256 驗證、逾時、固定版本或自建鏡像、磁碟空間預檢、手動放置模型的說明
- [ ] **記錄檔保留策略**：例如保留最近 14 天、單檔大小上限；是否提供設定頁「開啟記錄資料夾」

---

## 附錄：v0.6 實作異動檔案

| 檔案 | 異動 |
| --- | --- |
| `Modules/LiveDictation/SpeechTranscriber.cs` | 重寫：Loopback／麥克風擷取、16 kHz 轉換、`LiveSegmenter` 分段、佇列與單一 Whisper 工作執行緒、提示詞回吐移除、非語音與幻覺過濾、自訂詞彙檔、音訊統計與除錯 wav、停止時等佇列；不再切換系統裝置 |
| `Modules/LiveDictation/DictationView.xaml.cs` | 開始前確認並下載模型、狀態列訊息、停止時等辨識完成、事件改 `BeginInvoke`、系統聲音不再檢查 `IsAvailable` |
| `Modules/LiveDictation/AudioDeviceManager.cs` | 系統聲音選項恆可用、名稱改為「擷取電腦正在播放的聲音」；`TryGetVbCableDeviceIds` 僅保留 |
| `Shared/EnvironmentSetup/EnvironmentCheckService.cs` | 移除 `Windows.Media.SpeechRecognition` 引用；檢查改為 ffmpeg ＋ Whisper 模型；`EnvironmentStatus` 新增 `WhisperModelInstalled` |
| `Modules/LiveDictation/LiveSegmenter.cs`（新增） | 能量式 VAD 分段器 |
| `Shared/WhisperRuntime.cs`（新增） | 共用 `WhisperFactory`、語系表、語言碼轉換、初始提示詞 |

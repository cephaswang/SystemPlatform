rmdir /s /q obj
rmdir /s /q bin
dotnet build


dotnet add package Whisper.net
dotnet add package Whisper.net.Runtime


為什麼沒有聲音

程式會把系統預設播放裝置切到 CABLE Input，讓聲音進入虛擬線路，再由 CABLE Output 交給辨識器。所以聲音不再送到你的喇叭。要同時聽到聲音，需要對 CABLE Output 做一次性設定：

按 Win+R，輸入 mmsys.cpl，按 Enter。
切到「錄製」分頁，對 CABLE Output 按兩下打開內容。
切到「接聽」分頁，勾選「接聽此裝置」（Listen to this device）。
在「透過此裝置播放」選你平常用的喇叭或耳機，按套用。

設定完成後再開始聽抄，就能一邊聽、一邊辨識。這個設定是永久的，只需要做一次。

如果停止聽抄之後，喇叭還是沒有聲音，代表預設裝置沒有還原成功。可以在 mmsys.cpl 的「播放」分頁，對原本的喇叭按右鍵「設為預設裝置」，「錄製」分頁的麥克風也一樣處理。這種情況會在記錄檔裡留下「還原預設播放裝置失敗」。

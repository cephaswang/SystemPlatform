using System;
using System.Linq;
using AudioSwitcher.AudioApi;
using AudioSwitcher.AudioApi.CoreAudio;

namespace DictationHelperWin.Shared;

/// <summary>
/// 對應企劃書五、風險「無法變更系統預設輸出/輸入裝置」與企劃書 v0.3 系統聲音架構：
/// Windows 沒有官方公開 API 可以切換系統預設播放/錄音裝置，`Windows.Media.SpeechRecognition.SpeechRecognizer`
/// 只會聽「系統目前的預設錄音裝置」，不接受呼叫端指定裝置 ID。
///
/// 這支類別原本只切「預設錄音裝置」給麥克風模式用（類別原名 DefaultRecordingDeviceSwitcher）。
/// v0.3 改用 VB-Audio Virtual Cable 做系統聲音聽抄後，還需要在聽抄期間把「預設播放裝置」也切到
/// CABLE Input（聲音才會被送進虛擬線路、轉送到 CABLE Output），所以擴充成同時管理播放／錄音兩種
/// 預設裝置的切換與還原，並改名為 AudioRouteSwitcher。
///
/// 使用者需求是「自動切換、不能有使用者手動介入」，所以這裡沿用 IPolicyConfig 這個
/// 未公開（undocumented）COM 介面來做切換——這是 Windows 內建「音效」設定頁本身
/// 用來切換預設裝置的同一套機制，EarTrumpet、SoundSwitch 等知名工具也是這樣做的。
///
/// 但務必知道這裡的取捨：
///   1. 這是「未公開」API：不同 Windows 版本（Win7 / Win8 / Win10 舊版 / Win10 1803+ / Win11）
///      的介面版面（vtable）不完全相同，微軟不保證相容性，未來的 Windows 更新有可能讓它失效。
///   2. 有些防毒／端點防護軟體會把「程式呼叫未公開 COM 介面切換系統音效裝置」判定為可疑行為
///      （企劃書五、風險已經列出這一點）。
///   3. 這裡選擇透過 AudioSwitcher.AudioApi.CoreAudio 這個社群套件呼叫，而不是自己刻 vtable，
///      是因為它已經處理好「依 Windows 版本選擇正確介面版面」這件事，比手刻更不容易切壞。
///      即便如此，仍建議在正式發版前於目標的 Windows 10 / 11 版本上實測。
///
/// 「監聽這個裝置」（讓使用者在系統聲音模式下仍聽得到聲音）不是這支類別的責任：
/// 那是 CABLE Output 裝置內容裡的一個一次性手動設定，見
/// Shared/EnvironmentSetup/EnvironmentCheckService.cs 的安裝引導，不需要（也還沒找到穩定可靠的
/// 公開/半公開 API）每次聽抄開始/結束時自動切換。
///
/// 使用方式：
///   - 麥克風模式：SwitchCaptureTo(想要的麥克風 DeviceId)
///   - 系統聲音模式：SwitchPlaybackTo(CABLE Input 的 DeviceId) + SwitchCaptureTo(CABLE Output 的 DeviceId)
///   - 聽抄結束後一律呼叫 Restore()，把兩者都換回使用者原本的設定
///     （聽抄期間，系統上其他也在用麥克風/喇叭的程式，會暫時看到預設裝置變成上面切換的那些）。
/// </summary>
public sealed class AudioRouteSwitcher : IDisposable
{
    private readonly CoreAudioController _controller = new();

    private string? _originalDefaultCaptureDeviceId;
    private bool _hasSwitchedCapture;

    private string? _originalDefaultPlaybackDeviceId;
    private bool _hasSwitchedPlayback;

    /// <summary>診斷用：記錄目前四個預設裝置（播放／錄音 × 主要／通訊）。</summary>
    private void LogDefaults(string when)
    {
        try
        {
            DebugLog.Info($"[{when}] 預設播放={_controller.DefaultPlaybackDevice?.FullName ?? "無"}；" +
                          $"預設播放(通訊)={_controller.DefaultPlaybackCommunicationsDevice?.FullName ?? "無"}；" +
                          $"預設錄音={_controller.DefaultCaptureDevice?.FullName ?? "無"}；" +
                          $"預設錄音(通訊)={_controller.DefaultCaptureCommunicationsDevice?.FullName ?? "無"}");
        }
        catch (Exception ex)
        {
            DebugLog.Warn($"讀取預設裝置失敗：{ex.Message}");
        }
    }

    /// <summary>
    /// 把系統預設錄音裝置切換成指定裝置（麥克風，或系統聲音模式下的 CABLE Output）。
    /// deviceId 對應 AudioDeviceManager 列舉出來的 NAudio MMDevice.ID
    /// （兩者底層都是同一顆 Windows Core Audio API，裝置 ID 字串格式相容）。
    ///
    /// 注意：AudioSwitcher 對外的 GetDevice(Guid) 用的是它自己內部把裝置字串 ID
    /// 雜湊出來的 Guid，不是原始的 Core Audio 裝置 ID 字串，所以這裡改成列舉
    /// 目前所有錄音裝置、用 RealId（原始字串 ID）去比對，才能跟 NAudio 的 ID 對上。
    /// </summary>
    public void SwitchCaptureTo(string deviceId)
    {
        var target = _controller.GetCaptureDevices(DeviceState.Active)
            .FirstOrDefault(d => string.Equals(d.RealId, deviceId, StringComparison.OrdinalIgnoreCase));

        if (target is null)
        {
            DebugLog.Error($"找不到錄音裝置：{deviceId}");
            throw new InvalidOperationException($"找不到錄音裝置（可能已拔除、停用，或 VB-CABLE 未安裝）：{deviceId}");
        }

        DebugLog.Info($"切換預設錄音裝置 → {target.FullName}（{deviceId}）");
        LogDefaults("切換錄音前");

        // 只有第一次切換時記錄「使用者原本的預設裝置」，避免連續切換多次時
        // 把「切換後的裝置」誤記成原始值，導致 Restore() 換不回真正原本的裝置。
        if (!_hasSwitchedCapture)
        {
            _originalDefaultCaptureDeviceId = _controller.DefaultCaptureDevice?.RealId;
            _hasSwitchedCapture = true;
        }

        // 語音辨識實務上常吃「通訊（Communications）」角色的裝置，
        // 一般錄音／多媒體程式吃的則是「主要（Console/Multimedia）」角色。
        // 兩個角色都切成同一顆裝置，才能確保 SpeechRecognizer 不管認哪個角色都對得上。
        try
        {
            target.SetAsDefault();
            target.SetAsDefaultCommunications();
            LogDefaults("切換錄音後");
            var actual = _controller.DefaultCaptureDevice?.RealId;
            if (!string.Equals(actual, target.RealId, StringComparison.OrdinalIgnoreCase))
                DebugLog.Warn($"切換錄音裝置後驗證失敗：預期={target.RealId}，實際={actual ?? "無"}（呼叫沒有丟例外，但預設裝置沒變）");
        }
        catch (Exception ex)
        {
            DebugLog.Error("切換預設錄音裝置丟出例外", ex);
            throw new InvalidOperationException(
                "切換系統預設錄音裝置失敗。這是透過未公開的 Windows API 達成，" +
                "可能因 Windows 版本或防毒軟體攔截而失敗，請確認錯誤訊息後評估是否改回手動選擇。", ex);
        }
    }

    /// <summary>
    /// 把系統預設播放裝置切換成指定裝置（v0.3 系統聲音模式：切到 VB-CABLE 的 CABLE Input，
    /// 讓系統聲音被送進虛擬線路，才轉得到 CABLE Output）。麥克風模式不需要呼叫這個方法。
    /// </summary>
    public void SwitchPlaybackTo(string deviceId)
    {
        var target = _controller.GetPlaybackDevices(DeviceState.Active)
            .FirstOrDefault(d => string.Equals(d.RealId, deviceId, StringComparison.OrdinalIgnoreCase));

        if (target is null)
        {
            DebugLog.Error($"找不到播放裝置：{deviceId}");
            throw new InvalidOperationException($"找不到播放裝置（可能已拔除、停用，或 VB-CABLE 未安裝）：{deviceId}");
        }

        DebugLog.Info($"切換預設播放裝置 → {target.FullName}（{deviceId}）");
        LogDefaults("切換播放前");

        if (!_hasSwitchedPlayback)
        {
            _originalDefaultPlaybackDeviceId = _controller.DefaultPlaybackDevice?.RealId;
            _hasSwitchedPlayback = true;
        }

        try
        {
            target.SetAsDefault();
            target.SetAsDefaultCommunications();
            LogDefaults("切換播放後");
            var actual = _controller.DefaultPlaybackDevice?.RealId;
            if (!string.Equals(actual, target.RealId, StringComparison.OrdinalIgnoreCase))
                DebugLog.Warn($"切換播放裝置後驗證失敗：預期={target.RealId}，實際={actual ?? "無"}（呼叫沒有丟例外，但預設裝置沒變）");
        }
        catch (Exception ex)
        {
            DebugLog.Error("切換預設播放裝置丟出例外", ex);
            throw new InvalidOperationException(
                "切換系統預設播放裝置失敗。這是透過未公開的 Windows API 達成，" +
                "可能因 Windows 版本或防毒軟體攔截而失敗。", ex);
        }
    }

    /// <summary>
    /// 聽抄結束後呼叫，把預設播放/錄音裝置換回使用者原本的設定。
    /// 麥克風模式只切過錄音裝置、系統聲音模式播放+錄音都切過，這裡各自獨立判斷，
    /// 兩種情境呼叫同一個 Restore() 都能正確還原，呼叫端不需要區分是哪一種模式。
    /// </summary>
    public void Restore()
    {
        DebugLog.Info($"還原預設裝置：已切換錄音={_hasSwitchedCapture}，已切換播放={_hasSwitchedPlayback}");
        RestoreCapture();
        RestorePlayback();
        if (_hasSwitchedCapture || _hasSwitchedPlayback) return;
        LogDefaults("還原後");
    }

    private void RestoreCapture()
    {
        if (!_hasSwitchedCapture || string.IsNullOrEmpty(_originalDefaultCaptureDeviceId))
        {
            _hasSwitchedCapture = false;
            _originalDefaultCaptureDeviceId = null;
            return;
        }

        try
        {
            var original = _controller.GetCaptureDevices(DeviceState.Active)
                .FirstOrDefault(d => string.Equals(d.RealId, _originalDefaultCaptureDeviceId, StringComparison.OrdinalIgnoreCase));

            if (original is not null)
            {
                DebugLog.Info($"還原預設錄音裝置 → {original.FullName}");
                original.SetAsDefault();
                original.SetAsDefaultCommunications();
            }
            else
            {
                DebugLog.Warn($"還原失敗：找不到原本的錄音裝置 {_originalDefaultCaptureDeviceId}");
            }
        }
        catch (Exception ex)
        {
            DebugLog.Error("還原預設錄音裝置失敗（裝置可能卡在切換後的狀態）", ex);
            // 還原失敗不應該讓「停止聽抄」整個操作失敗——使用者仍然可以自行到
            // 「設定 → 系統 → 音效」手動改回來，這裡只記錄狀態、不拋例外中斷流程。
        }
        finally
        {
            _hasSwitchedCapture = false;
            _originalDefaultCaptureDeviceId = null;
        }
    }

    private void RestorePlayback()
    {
        if (!_hasSwitchedPlayback || string.IsNullOrEmpty(_originalDefaultPlaybackDeviceId))
        {
            _hasSwitchedPlayback = false;
            _originalDefaultPlaybackDeviceId = null;
            return;
        }

        try
        {
            var original = _controller.GetPlaybackDevices(DeviceState.Active)
                .FirstOrDefault(d => string.Equals(d.RealId, _originalDefaultPlaybackDeviceId, StringComparison.OrdinalIgnoreCase));

            if (original is not null)
            {
                DebugLog.Info($"還原預設播放裝置 → {original.FullName}");
                original.SetAsDefault();
                original.SetAsDefaultCommunications();
            }
            else
            {
                DebugLog.Warn($"還原失敗：找不到原本的播放裝置 {_originalDefaultPlaybackDeviceId}");
            }
        }
        catch (Exception ex)
        {
            DebugLog.Error("還原預設播放裝置失敗（裝置可能卡在切換後的狀態）", ex);
            // 同上：還原失敗不中斷流程，使用者仍可自行到「設定 → 系統 → 音效」手動改回來。
        }
        finally
        {
            _hasSwitchedPlayback = false;
            _originalDefaultPlaybackDeviceId = null;
        }
    }

    public void Dispose()
    {
        Restore();
        _controller.Dispose();
    }
}

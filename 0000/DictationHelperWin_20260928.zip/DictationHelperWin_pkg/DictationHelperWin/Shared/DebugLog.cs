using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.CompilerServices;
using System.Text;

namespace DictationHelperWin.Shared;

/// C:\Users\1000\AppData\Local\DictationHelperWin\logs\20260928.log
/// <summary>
/// 簡易除錯記錄：寫到 %LocalAppData%\DictationHelperWin\logs\yyyyMMdd.log。
/// 執行緒安全；寫檔失敗時不會丟例外（不能因為記錄而讓程式當掉）。
/// </summary>
public static class DebugLog
{
    private static readonly object Gate = new();

    /// <summary>記錄檔所在資料夾。</summary>
    public static string LogDirectory { get; } = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "DictationHelperWin", "logs");

    /// <summary>今天的記錄檔完整路徑。</summary>
    public static string CurrentLogPath =>
        Path.Combine(LogDirectory, $"{DateTime.Now:yyyyMMdd}.log");

    public static void Info(string message,
        [CallerMemberName] string member = "", [CallerFilePath] string file = "") =>
        Write("INFO ", message, null, member, file);

    public static void Warn(string message,
        [CallerMemberName] string member = "", [CallerFilePath] string file = "") =>
        Write("WARN ", message, null, member, file);

    public static void Error(string message, Exception? ex = null,
        [CallerMemberName] string member = "", [CallerFilePath] string file = "") =>
        Write("ERROR", message, ex, member, file);

    private static void Write(string level, string message, Exception? ex, string member, string file)
    {
        try
        {
            var sb = new StringBuilder();
            sb.Append(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff"))
              .Append(" [").Append(level).Append("] ")
              .Append("[T").Append(Environment.CurrentManagedThreadId).Append("] ")
              .Append(Path.GetFileNameWithoutExtension(file)).Append('.').Append(member)
              .Append(" - ").AppendLine(message);

            if (ex is not null)
                sb.AppendLine(ex.ToString()); // 含 InnerException 與完整堆疊

            var text = sb.ToString();
            Debug.Write(text);

            lock (Gate)
            {
                Directory.CreateDirectory(LogDirectory);
                File.AppendAllText(CurrentLogPath, text, Encoding.UTF8);
            }
        }
        catch
        {
            // 記錄本身失敗就放棄，避免影響主流程。
        }
    }
}

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using DictationHelperWin.Modules.ImportTranscribe.Models;
using Whisper.net;

namespace DictationHelperWin.Shared;

/// <summary>
/// Whisper 共用資源（聽抄模式使用）：
/// - 共用同一個 WhisperFactory（載入模型需要數秒且佔用大量記憶體，不要每次聽抄都重載）。
/// - 語系表與 BCP-47 → Whisper 語言碼、初始提示詞（與匯入模式 SpeechRecognitionService 的行為一致）。
/// 註：匯入模式的 SpeechRecognitionService 目前仍持有自己的 factory；若同一次執行兩個模式都使用，
/// 會各載入一份模型。之後可讓它也改用 GetFactory 以共用（見企劃書待辦）。
///
/// 語系表：列出 Whisper 多語模型（ggml-small 等）支援的全部 99 種語言。
/// 前五項（zh-TW、zh-CN、en-US、ja-JP、ko-KR）維持原本的代碼與顯示名稱，
/// 確保舊設定（AppState.DefaultImportLanguage、各音檔已存的語系）不會失效；
/// 其餘語言以 Whisper 語言碼作為代碼（fr、de、th…），依中文名稱排序接在後面。
/// 不含粵語（yue）：該語言只有 large-v3 之後的模型才支援，small 模型無法使用。
/// </summary>
public static class WhisperRuntime
{
    private static readonly object Gate = new();
    private static WhisperFactory? _factory;
    private static string? _loadedPath;

    // 其餘 94 種語言：代碼、原文名稱、繁體中文名稱。
    // 代碼用 Whisper 語言碼；jv（爪哇文）在 ToWhisperLanguage 轉成 Whisper 內部使用的 jw。
    private static readonly (string Code, string Native, string Chinese)[] OtherLanguages =
    {
        ("af", "Afrikaans", "南非荷蘭文"),
        ("am", "አማርኛ", "阿姆哈拉文"),
        ("ar", "العربية", "阿拉伯文"),
        ("as", "অসমীয়া", "阿薩姆文"),
        ("az", "Azərbaycanca", "亞塞拜然文"),
        ("ba", "Башҡортса", "巴什基爾文"),
        ("be", "Беларуская", "白俄羅斯文"),
        ("bg", "Български", "保加利亞文"),
        ("bn", "বাংলা", "孟加拉文"),
        ("bo", "བོད་སྐད་", "藏文"),
        ("br", "Brezhoneg", "布列塔尼文"),
        ("bs", "Bosanski", "波士尼亞文"),
        ("ca", "Català", "加泰隆尼亞文"),
        ("cs", "Čeština", "捷克文"),
        ("cy", "Cymraeg", "威爾斯文"),
        ("da", "Dansk", "丹麥文"),
        ("de", "Deutsch", "德文"),
        ("el", "Ελληνικά", "希臘文"),
        ("es", "Español", "西班牙文"),
        ("et", "Eesti", "愛沙尼亞文"),
        ("eu", "Euskara", "巴斯克文"),
        ("fa", "فارسی", "波斯文"),
        ("fi", "Suomi", "芬蘭文"),
        ("fo", "Føroyskt", "法羅文"),
        ("fr", "Français", "法文"),
        ("gl", "Galego", "加利西亞文"),
        ("gu", "ગુજરાતી", "古吉拉特文"),
        ("ha", "Hausa", "豪撒文"),
        ("haw", "ʻŌlelo Hawaiʻi", "夏威夷文"),
        ("he", "עברית", "希伯來文"),
        ("hi", "हिन्दी", "印地文"),
        ("hr", "Hrvatski", "克羅埃西亞文"),
        ("ht", "Kreyòl ayisyen", "海地克里奧文"),
        ("hu", "Magyar", "匈牙利文"),
        ("hy", "Հայերեն", "亞美尼亞文"),
        ("id", "Bahasa Indonesia", "印尼文"),
        ("is", "Íslenska", "冰島文"),
        ("it", "Italiano", "義大利文"),
        ("jv", "Basa Jawa", "爪哇文"),
        ("ka", "ქართული", "喬治亞文"),
        ("kk", "Қазақша", "哈薩克文"),
        ("km", "ខ្មែរ", "高棉文"),
        ("kn", "ಕನ್ನಡ", "卡納達文"),
        ("la", "Latina", "拉丁文"),
        ("lb", "Lëtzebuergesch", "盧森堡文"),
        ("ln", "Lingála", "林加拉文"),
        ("lo", "ລາວ", "寮文"),
        ("lt", "Lietuvių", "立陶宛文"),
        ("lv", "Latviešu", "拉脫維亞文"),
        ("mg", "Malagasy", "馬達加斯加文"),
        ("mi", "Māori", "毛利文"),
        ("mk", "Македонски", "馬其頓文"),
        ("ml", "മലയാളം", "馬拉雅拉姆文"),
        ("mn", "Монгол", "蒙古文"),
        ("mr", "मराठी", "馬拉地文"),
        ("ms", "Bahasa Melayu", "馬來文"),
        ("mt", "Malti", "馬爾他文"),
        ("my", "မြန်မာ", "緬甸文"),
        ("ne", "नेपाली", "尼泊爾文"),
        ("nl", "Nederlands", "荷蘭文"),
        ("nn", "Nynorsk", "新挪威文"),
        ("no", "Norsk", "挪威文"),
        ("oc", "Occitan", "奧克語"),
        ("pa", "ਪੰਜਾਬੀ", "旁遮普文"),
        ("pl", "Polski", "波蘭文"),
        ("ps", "پښتو", "普什圖文"),
        ("pt", "Português", "葡萄牙文"),
        ("ro", "Română", "羅馬尼亞文"),
        ("ru", "Русский", "俄文"),
        ("sa", "संस्कृतम्", "梵文"),
        ("sd", "سنڌي", "信德文"),
        ("si", "සිංහල", "僧伽羅文"),
        ("sk", "Slovenčina", "斯洛伐克文"),
        ("sl", "Slovenščina", "斯洛維尼亞文"),
        ("sn", "ChiShona", "修納文"),
        ("so", "Soomaali", "索馬利文"),
        ("sq", "Shqip", "阿爾巴尼亞文"),
        ("sr", "Српски", "塞爾維亞文"),
        ("su", "Basa Sunda", "巽他文"),
        ("sv", "Svenska", "瑞典文"),
        ("sw", "Kiswahili", "斯瓦希里文"),
        ("ta", "தமிழ்", "泰米爾文"),
        ("te", "తెలుగు", "泰盧固文"),
        ("tg", "Тоҷикӣ", "塔吉克文"),
        ("th", "ไทย", "泰文"),
        ("tk", "Türkmençe", "土庫曼文"),
        ("tl", "Tagalog", "他加祿文"),
        ("tr", "Türkçe", "土耳其文"),
        ("tt", "Татарча", "韃靼文"),
        ("uk", "Українська", "烏克蘭文"),
        ("ur", "اردو", "烏爾都文"),
        ("uz", "Oʻzbekcha", "烏茲別克文"),
        ("vi", "Tiếng Việt", "越南文"),
        ("yi", "ייִדיש", "意第緒文"),
        ("yo", "Yorùbá", "約魯巴文")
    };

    // 前五項維持原代碼與顯示名稱（舊設定相容），排在清單最前面方便常用。
    private static readonly string[] CommonCodes = { "zh-TW", "zh-CN", "en-US", "ja-JP", "ko-KR" };

    public static readonly IReadOnlyList<LanguageOption> Languages = BuildLanguages();

    private static readonly HashSet<string> SupportedCodes =
        new(CommonCodes.Concat(OtherLanguages.Select(l => l.Code)), StringComparer.OrdinalIgnoreCase);

    private static IReadOnlyList<LanguageOption> BuildLanguages()
    {
        var list = new List<LanguageOption>
        {
            new("zh-TW", "中文（繁體，台灣）"),
            new("zh-CN", "中文（簡體）"),
            new("en-US", "English (United States)"),
            new("ja-JP", "日本語"),
            new("ko-KR", "한국어")
        };

        // 其餘語言依繁體中文名稱排序（zh-TW 排序規則）；顯示為「原文（中文名）」，
        // 原文名稱與中文名稱都能讓使用者快速找到，且不會與前五項或彼此重複。
        var collator = StringComparer.Create(new CultureInfo("zh-TW"), ignoreCase: false);
        list.AddRange(
            OtherLanguages
                .OrderBy(l => l.Chinese, collator)
                .Select(l => new LanguageOption(l.Code, $"{l.Native}（{l.Chinese}）")));

        return list;
    }

    public static LanguageOption? FindByDisplayName(string displayName) =>
        Languages.FirstOrDefault(l => l.DisplayName == displayName);

    /// <summary>
    /// 語系代碼是否在目前的清單內。
    /// 供 AppState 讀取已存的 DefaultImportLanguage、或各音檔語系時驗證；
    /// 不在清單內就退回 zh-TW，避免舊設定或手動改壞的設定造成辨識失敗。
    /// </summary>
    public static bool IsSupported(string? languageTag) =>
        !string.IsNullOrWhiteSpace(languageTag) && SupportedCodes.Contains(languageTag);

    /// <summary>
    /// zh-TW → zh、en-US → en、fr → fr。
    /// 少數 BCP-47 代碼與 Whisper 內部語言碼不同：jv（爪哇文）→ jw、nb（書面挪威文）→ no、iw（舊式希伯來文）→ he。
    /// </summary>
    public static string ToWhisperLanguage(string languageTag)
    {
        var dash = languageTag.IndexOf('-');
        var code = (dash > 0 ? languageTag[..dash] : languageTag).ToLowerInvariant();
        return code switch
        {
            "jv" => "jw",
            "nb" => "no",
            "iw" => "he",
            _ => code
        };
    }

    /// <summary>以提示詞引導 Whisper 輸出繁體／簡體中文與標點（只是引導，不保證 100%）。其他語言不使用提示詞。</summary>
    public static string? GetInitialPrompt(string languageTag) => languageTag.ToLowerInvariant() switch
    {
        "zh-tw" or "zh-hk" => "以下是繁體中文的逐字稿，請使用繁體中文與標點符號。",
        "zh-cn" => "以下是简体中文的逐字稿，请使用简体中文和标点符号。",
        _ => null
    };

    public static WhisperFactory GetFactory(string modelPath)
    {
        lock (Gate)
        {
            if (_factory is not null && string.Equals(_loadedPath, modelPath, StringComparison.OrdinalIgnoreCase))
                return _factory;

            _factory?.Dispose();
            _factory = null;

            var sw = Stopwatch.StartNew();
            DebugLog.Info($"載入 Whisper 模型：{modelPath}；Whisper.net {typeof(WhisperFactory).Assembly.GetName().Version}");
            try
            {
                _factory = WhisperFactory.FromPath(modelPath);
                _loadedPath = modelPath;
                DebugLog.Info($"Whisper 模型載入完成，耗時 {sw.Elapsed.TotalSeconds:F1} 秒");
                return _factory;
            }
            catch (Exception ex)
            {
                DebugLog.Error("載入 Whisper 模型失敗", ex);
                throw;
            }
        }
    }

    /// <summary>App 結束時釋放模型。</summary>
    public static void Shutdown()
    {
        lock (Gate)
        {
            _factory?.Dispose();
            _factory = null;
            _loadedPath = null;
        }
    }
}

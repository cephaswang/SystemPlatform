using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Threading.Tasks;
using DictationHelperWin.Modules.ImportTranscribe.Services;
using NAudio.CoreAudioApi;

namespace DictationHelperWin.Shared.EnvironmentSetup;

/// <summary>
/// 環境檢查結果，供狀態列與其他畫面訂閱顯示。
/// MissingLanguageTags：呼叫端指定的語系中，語音辨識語言包尚未安裝者（BCP-47 代碼）；
/// 未指定要檢查的語系、或無法判斷時為空。
/// </summary>
public sealed record EnvironmentStatus(
    bool FfmpegOk,
    bool SpeechLanguagePackMissing,
    bool VbCableInstalled,
    string Summary,
    IReadOnlyList<string>? MissingLanguageTags = null,
    bool WhisperModelInstalled = true);

public enum VbCableInstallStatus
{
    /// <summary>安裝程式已執行完畢（是否成功仍需重新偵測裝置確認，可能需要重新開機）。</summary>
    Completed,
    /// <summary>找不到內建的 VBCABLE_Driver_Pack45.zip。</summary>
    PackageMissing,
    /// <summary>zip 內找不到對應的安裝程式（VBCABLE_Setup / VBCABLE_Setup_x64）。</summary>
    SetupNotFound,
    /// <summary>使用者在 Windows 使用者帳戶控制（UAC）提示按了「否」。</summary>
    CancelledByUser,
    Failed
}

public sealed record VbCableInstallOutcome(VbCableInstallStatus Status, string? Message = null);

/// <summary>
/// 環境檢查（v0.6）。
/// 匯入與聽抄都使用本機 Whisper：需要 ffmpeg（匯入轉檔）與 Whisper 模型檔（首次使用時經同意下載）。
/// 聽抄的系統聲音改用 WasapiLoopbackCapture，不再需要 VB-Audio Virtual Cable，也不需要 Windows 語音語言包；
/// VbCableInstalled 與相關安裝方法僅為舊設定頁相容而保留，不影響任何功能與摘要文字。
/// </summary>
public sealed class EnvironmentCheckService
{
    public event EventHandler<EnvironmentStatus>? StatusChanged;

    public EnvironmentStatus? LastStatus { get; private set; }

    /// <summary>
    /// 重新檢查環境。requiredLanguageTags 為選用參數：傳入音檔清單中各檔所選的語系代碼，
    /// 即會一併檢查這些語系的語音辨識語言包是否已安裝（匯入模式每檔可各自設定語系）。
    /// </summary>
    public async Task<EnvironmentStatus> RefreshStatusAsync(IEnumerable<string>? requiredLanguageTags = null)
    {
        var required = requiredLanguageTags?.ToList();
        DebugLog.Info($"環境檢查開始；指定檢查語系={(required is null ? "無" : string.Join(",", required))}");

        var ffmpegOk = await Task.Run(CheckFfmpegExists);
        var vbCableInstalled = await Task.Run(CheckVbCableInstalled);
        var modelInstalled = new WhisperModelManager().IsModelInstalled;
        var missingTags = required is null
            ? Array.Empty<string>()
            : await Task.Run(() => FindMissingSpeechLanguages(required));

        DebugLog.Info($"環境檢查結果：ffmpeg={ffmpegOk}，Whisper 模型已下載={modelInstalled}，VB-CABLE（舊，選用）={vbCableInstalled}");

        var summary = (ffmpegOk, modelInstalled) switch
        {
            (false, _) => "找不到 ffmpeg，匯入 webm 音檔時將無法轉檔。",
            (true, false) => $"尚未下載 Whisper 語音辨識模型（{WhisperModelManager.ApproxSizeText}），首次轉錄或聽抄時會詢問是否下載。",
            (true, true) => "環境檢查完成，一切就緒。",
        };

        var status = new EnvironmentStatus(
            ffmpegOk, false, vbCableInstalled, summary, missingTags, modelInstalled);
        LastStatus = status;
        StatusChanged?.Invoke(this, status);
        return status;
    }

    /// <summary>
    /// 從指定的語系代碼中，找出語音辨識語言包尚未安裝者。
    /// v0.6：Whisper 為多語模型，不依賴 Windows 語言包，恆回傳空清單（保留方法以相容呼叫端）。
    /// </summary>
    public IReadOnlyList<string> FindMissingSpeechLanguages(IEnumerable<string> requiredLanguageTags)
    {
        var installed = GetInstalledSpeechLanguageTags();
        if (installed is null) return Array.Empty<string>();

        return requiredLanguageTags
            .Where(tag => !string.IsNullOrWhiteSpace(tag))
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .Where(tag => !installed.Contains(tag, StringComparer.OrdinalIgnoreCase))
            .ToList();
    }

    /// <summary>v0.6：不再查詢 Windows 語言包；回傳 null 表示「不需要檢查」。</summary>
    private static IReadOnlyCollection<string>? GetInstalledSpeechLanguageTags() => null;

    /// <summary>檢查內嵌或系統 PATH 中是否有 ffmpeg.exe。</summary>
    private static bool CheckFfmpegExists()
    {
        var bundled = Path.Combine(AppContext.BaseDirectory, "Resources", "ffmpeg.exe");
        if (File.Exists(bundled)) return true;
        DebugLog.Warn($"找不到內建 ffmpeg：{bundled}，改試系統 PATH");

        try
        {
            using var process = Process.Start(new ProcessStartInfo
            {
                FileName = "ffmpeg",
                Arguments = "-version",
                RedirectStandardOutput = true,
                UseShellExecute = false,
                CreateNoWindow = true
            });
            process?.WaitForExit(2000);
            var ok = process is { ExitCode: 0 };
            DebugLog.Info($"系統 PATH 的 ffmpeg 檢查：{ok}");
            return ok;
        }
        catch (Exception ex)
        {
            DebugLog.Warn($"系統 PATH 找不到 ffmpeg：{ex.Message}");
            return false;
        }
    }

    /// <summary>
    /// 對應企劃書 v0.3 第四章：偵測 VB-Audio Virtual Cable 是否已安裝
    /// （尋找 CABLE Input 播放裝置與 CABLE Output 錄音裝置是否同時存在）。
    /// 與 AudioDeviceManager.TryGetVbCableDeviceIds 邏輯相同，但這裡不需要裝置 ID，
    /// 獨立寫一份輕量檢查，避免環境檢查服務去依賴 LiveDictation 模組。
    /// </summary>
    private static bool CheckVbCableInstalled()
    {
        try
        {
            using var enumerator = new MMDeviceEnumerator();

            var hasCableInput = enumerator
                .EnumerateAudioEndPoints(DataFlow.Render, DeviceState.Active)
                .Any(d => d.FriendlyName.Contains("CABLE Input", StringComparison.OrdinalIgnoreCase));

            var hasCableOutput = enumerator
                .EnumerateAudioEndPoints(DataFlow.Capture, DeviceState.Active)
                .Any(d => d.FriendlyName.Contains("CABLE Output", StringComparison.OrdinalIgnoreCase));

            DebugLog.Info($"VB-CABLE 偵測：CABLE Input（播放）={hasCableInput}，CABLE Output（錄音）={hasCableOutput}");
            return hasCableInput && hasCableOutput;
        }
        catch (Exception ex)
        {
            DebugLog.Warn($"VB-CABLE 偵測失敗：{ex.Message}");
            return false;
        }
    }

    /// <summary>
    /// 安裝內建的 VB-Audio Virtual Cable 驅動包（Resources\VBCABLE_Driver_Pack45.zip）：
    /// 解壓縮到暫存資料夾 → 依系統位元數選擇 VBCABLE_Setup_x64.exe / VBCABLE_Setup.exe →
    /// 以系統管理員權限執行（會跳出 UAC 提示）→ 等安裝程式結束。
    /// 安裝程式本身是圖形介面，使用者需在其視窗按「Install Driver」；完成後可能需要重新開機。
    /// 呼叫端應在結束後重新呼叫 RefreshStatusAsync 確認是否偵測到 CABLE 裝置。
    /// </summary>
    public static async Task<VbCableInstallOutcome> InstallBundledVbCableAsync()
    {
        var zipPath = Path.Combine(AppContext.BaseDirectory, "Resources", "VBCABLE_Driver_Pack45.zip");
        DebugLog.Info($"開始安裝內建 VB-CABLE：{zipPath}（存在={File.Exists(zipPath)}）");
        if (!File.Exists(zipPath))
            return new VbCableInstallOutcome(VbCableInstallStatus.PackageMissing);

        string? setupPath;
        try
        {
            setupPath = await Task.Run(() => ExtractVbCablePackage(zipPath));
        }
        catch (Exception ex)
        {
            DebugLog.Error("VB-CABLE 安裝包解壓縮失敗", ex);
            return new VbCableInstallOutcome(VbCableInstallStatus.Failed, $"解壓縮安裝包失敗：{ex.Message}");
        }

        if (setupPath is null)
            return new VbCableInstallOutcome(VbCableInstallStatus.SetupNotFound);

        try
        {
            using var process = Process.Start(new ProcessStartInfo
            {
                FileName = setupPath,
                WorkingDirectory = Path.GetDirectoryName(setupPath)!,
                UseShellExecute = true,
                Verb = "runas" // 驅動安裝需要系統管理員權限
            });

            if (process is null)
                return new VbCableInstallOutcome(VbCableInstallStatus.Failed, "無法啟動安裝程式。");

            await process.WaitForExitAsync();
            DebugLog.Info($"VB-CABLE 安裝程式結束：ExitCode={process.ExitCode}（安裝結果仍需重新偵測裝置確認，可能需重開機）");
            return new VbCableInstallOutcome(VbCableInstallStatus.Completed);
        }
        catch (Win32Exception ex) when (ex.NativeErrorCode == 1223) // ERROR_CANCELLED：UAC 被拒絕
        {
            DebugLog.Warn("使用者在 UAC 提示按了「否」，取消 VB-CABLE 安裝");
            return new VbCableInstallOutcome(VbCableInstallStatus.CancelledByUser);
        }
        catch (Exception ex)
        {
            DebugLog.Error("啟動 VB-CABLE 安裝程式失敗", ex);
            return new VbCableInstallOutcome(VbCableInstallStatus.Failed, ex.Message);
        }
    }

    /// <summary>解壓縮驅動包到暫存資料夾，回傳對應系統位元數的安裝程式路徑；找不到則回傳 null。</summary>
    private static string? ExtractVbCablePackage(string zipPath)
    {
        var targetDir = Path.Combine(Path.GetTempPath(), "DictationHelperWin", "VBCABLE_Driver_Pack45");

        if (Directory.Exists(targetDir))
            Directory.Delete(targetDir, recursive: true);
        Directory.CreateDirectory(targetDir);

        ZipFile.ExtractToDirectory(zipPath, targetDir);

        var setupName = Environment.Is64BitOperatingSystem ? "VBCABLE_Setup_x64.exe" : "VBCABLE_Setup.exe";
        return Directory
            .EnumerateFiles(targetDir, setupName, SearchOption.AllDirectories)
            .FirstOrDefault();
    }

    /// <summary>對應企劃書 v0.3 第四章：引導使用者前往官方網站下載安裝 VB-Audio Virtual Cable（內建安裝包不可用時的備援）。</summary>
    public static void OpenVbCableDownloadPage()
    {
        Process.Start(new ProcessStartInfo
        {
            FileName = "https://vb-audio.com/Cable/",
            UseShellExecute = true
        });
    }

    /// <summary>
    /// 對應企劃書 v0.3 第四章：開啟 Windows「音效」控制台的「錄製」分頁，
    /// 讓使用者自行完成一次性的「CABLE Output → 內容 → 監聽 → 監聽這個裝置」設定。
    /// mmsys.cpl 是 Windows 內建控制台工具，",,1" 指定開啟到「錄製」分頁；
    /// 若目標系統的 Windows 版本不支援此參數，會退回開啟一般的「音效」設定視窗。
    /// </summary>
    public static void OpenSoundControlPanelRecordingTab()
    {
        try
        {
            Process.Start(new ProcessStartInfo
            {
                FileName = "control.exe",
                Arguments = "mmsys.cpl,,1",
                UseShellExecute = true
            });
        }
        catch
        {
            Process.Start(new ProcessStartInfo
            {
                FileName = "mmsys.cpl",
                UseShellExecute = true
            });
        }
    }
}

using System;
using System.Linq;
using AudioSwitcher.AudioApi;
using AudioSwitcher.AudioApi.CoreAudio;

namespace DictationHelperWin.Shared;

/// <summary>
/// 對應企劃書五、風險「無法變更系統預設輸出/輸入裝置」：
/// Windows 沒有官方公開 API 可以切換系統預設錄音裝置，`Windows.Media.SpeechRecognition.SpeechRecognizer`
/// 只會聽「系統目前的預設錄音裝置」，不接受呼叫端指定裝置 ID。
///
/// 使用者需求是「自動切換、不能有使用者手動介入」，所以這裡改用 IPolicyConfig 這個
/// 未公開（undocumented）COM 介面來做切換——這是 Windows 內建「音效」設定頁本身
/// 用來切換預設裝置的同一套機制，EarTrumpet、SoundSwitch 等知名工具也是這樣做的。
///
/// 但務必知道這裡的取捨：
///   1. 這是「未公開」API：不同 Windows 版本（Win7 / Win8 / Win10 舊版 / Win10 1803+ / Win11）
///      的介面版面（vtable）不完全相同，微軟不保證相容性，未來的 Windows 更新有可能讓它失效。
///   2. 有些防毒／端點防護軟體會把「程式呼叫未公開 COM 介面切換系統音效裝置」判定為可疑行為
///      （企劃書五、風險已經列出這一點）。
///   3. 這裡選擇透過 AudioSwitcher.AudioApi.CoreAudio 這個社群套件呼叫，而不是自己刻 vtable，
///      是因為它已經處理好「依 Windows 版本選擇正確介面版面」這件事，比手刻更不容易切壞。
///      即便如此，仍建議在正式發版前於目標的 Windows 10 / 11 版本上實測。
///
/// 使用方式：聽抄開始前 SwitchToAsync(想要的麥克風 DeviceId)，聽抄結束後呼叫 Restore()
/// 把使用者原本的預設錄音裝置換回來，把「切換系統設定」造成的外部副作用降到最低
/// （聽抄期間，系統上其他也在用麥克風的程式，會暫時看到預設錄音裝置變成使用者選的那一支）。
/// </summary>
public sealed class DefaultRecordingDeviceSwitcher : IDisposable
{
    private readonly CoreAudioController _controller = new();
    private string? _originalDefaultDeviceId;
    private bool _hasSwitched;

    /// <summary>
    /// 把系統預設錄音裝置切換成指定的麥克風。
    /// deviceId 對應 AudioDeviceManager 列舉出來的 NAudio MMDevice.ID
    /// （兩者底層都是同一顆 Windows Core Audio API，裝置 ID 字串格式相容）。
    ///
    /// 注意：AudioSwitcher 對外的 GetDevice(Guid) 用的是它自己內部把裝置字串 ID
    /// 雜湊出來的 Guid，不是原始的 Core Audio 裝置 ID 字串，所以這裡改成列舉
    /// 目前所有錄音裝置、用 RealId（原始字串 ID）去比對，才能跟 NAudio 的 ID 對上。
    /// </summary>
    public void SwitchTo(string deviceId)
    {
        var target = _controller.GetCaptureDevices(DeviceState.Active)
            .FirstOrDefault(d => string.Equals(d.RealId, deviceId, StringComparison.OrdinalIgnoreCase));

        if (target is null)
        {
            DebugLog.Error($"[DefaultRecordingDeviceSwitcher] 找不到裝置：{deviceId}");
            throw new InvalidOperationException($"找不到裝置（可能已拔除或停用）：{deviceId}");
        }
        DebugLog.Info($"[DefaultRecordingDeviceSwitcher] 切換預設錄音裝置 → {target.FullName}（{deviceId}）");

        // 只有第一次切換時記錄「使用者原本的預設裝置」，避免連續切換多次麥克風時
        // 把「切換後的裝置」誤記成原始值，導致 Restore() 換不回真正原本的裝置。
        if (!_hasSwitched)
        {
            _originalDefaultDeviceId = _controller.DefaultCaptureDevice?.RealId;
            _hasSwitched = true;
        }

        // 語音辨識實務上常吃「通訊（Communications）」角色的裝置，
        // 一般錄音／多媒體程式吃的則是「主要（Console/Multimedia）」角色。
        // 兩個角色都切成同一顆裝置，才能確保 SpeechRecognizer 不管認哪個角色都對得上。
        try
        {
            target.SetAsDefault();
            target.SetAsDefaultCommunications();
            var actual = _controller.DefaultCaptureDevice?.RealId;
            if (!string.Equals(actual, target.RealId, StringComparison.OrdinalIgnoreCase))
                DebugLog.Warn($"[DefaultRecordingDeviceSwitcher] 切換後驗證失敗：預期={target.RealId}，實際={actual ?? "無"}");
        }
        catch (Exception ex)
        {
            DebugLog.Error("[DefaultRecordingDeviceSwitcher] 切換預設錄音裝置丟出例外", ex);
            throw new InvalidOperationException(
                "切換系統預設錄音裝置失敗。這是透過未公開的 Windows API 達成，" +
                "可能因 Windows 版本或防毒軟體攔截而失敗，請確認錯誤訊息後評估是否改回手動選擇。", ex);
        }
    }

    /// <summary>
    /// 聽抄結束後呼叫，把預設錄音裝置換回使用者原本的設定。
    /// </summary>
    public void Restore()
    {
        if (!_hasSwitched || string.IsNullOrEmpty(_originalDefaultDeviceId))
        {
            _hasSwitched = false;
            _originalDefaultDeviceId = null;
            return;
        }

        try
        {
            var original = _controller.GetCaptureDevices(DeviceState.Active)
                .FirstOrDefault(d => string.Equals(d.RealId, _originalDefaultDeviceId, StringComparison.OrdinalIgnoreCase));

            if (original is not null)
            {
                DebugLog.Info($"[DefaultRecordingDeviceSwitcher] 還原預設錄音裝置 → {original.FullName}");
                original.SetAsDefault();
                original.SetAsDefaultCommunications();
            }
        }
        catch (Exception ex)
        {
            DebugLog.Error("[DefaultRecordingDeviceSwitcher] 還原預設錄音裝置失敗", ex);
            // 還原失敗不應該讓「停止聽抄」整個操作失敗——使用者仍然可以自行到
            // 「設定 → 系統 → 音效」手動改回來，這裡只記錄狀態、不拋例外中斷流程。
        }
        finally
        {
            _hasSwitched = false;
            _originalDefaultDeviceId = null;
        }
    }

    public void Dispose()
    {
        Restore();
        _controller.Dispose();
    }
}

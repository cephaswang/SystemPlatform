using System;
using System.Threading.Tasks;
using Microsoft.Win32;

namespace DictationHelperWin.Shared;

/// <summary>
/// 對應企劃書第五章「麥克風/語音辨識權限」：
/// Windows 對應「設定 → 隱私權與安全性 → 麥克風」「語音辨識」，App 需引導使用者開啟。
/// </summary>
public static class PermissionManager
{
    /// <summary>
    /// 檢查是否已取得麥克風存取權限。
    /// TODO：改為實際呼叫 Windows.Media.Capture.MediaCapture 權限請求流程
    /// 或 Windows.Security.Authorization.AppCapabilityAccess API。
    /// </summary>
    public static Task<bool> EnsureMicrophonePermissionAsync()
    {
        DebugLog.Info("EnsureMicrophonePermissionAsync：目前是佔位實作，一律回傳 true");
        // 佔位實作：桌面（非封裝）應用程式在多數情況下可直接存取麥克風，
        // 但仍應處理使用者於隱私權設定中關閉存取的情境，並導引至設定頁（見 ExplorerActions）。
        return Task.FromResult(true);
    }

    /// <summary>
    /// 檢查是否已取得語音辨識（線上）使用授權。
    /// 對應企劃書 3.2：Phase 1 採 Windows.Media.SpeechRecognition，需連網。
    /// </summary>
    public static Task<bool> EnsureSpeechRecognitionPermissionAsync()
    {
        DebugLog.Info("EnsureSpeechRecognitionPermissionAsync：目前是佔位實作，一律回傳 true");
        return Task.FromResult(true);
    }

    /// <summary>
    /// 診斷用：把與聽抄相關的 Windows 隱私設定寫入除錯記錄（不改變任何行為）。
    /// - 「線上語音辨識」：HKCU\Software\Microsoft\Speech_OneCore\Settings\OnlineSpeechPrivacy\HasAccepted（1＝已開啟）。
    ///   Windows.Media.SpeechRecognition 的聽寫（Dictation）需要連網，此項為 0 時常會沒有結果或丟出 privacy 例外。
    /// - 麥克風存取：CapabilityAccessManager\ConsentStore\microphone（Allow／Deny）。
    /// </summary>
    public static void LogPrivacyState()
    {
        const string speechKey = @"Software\Microsoft\Speech_OneCore\Settings\OnlineSpeechPrivacy";
        const string micKey = @"Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\microphone";
        var speech = ReadRegistry(speechKey, "HasAccepted");
        var mic = ReadRegistry(micKey, "Value");
        var micDesktop = ReadRegistry(micKey + @"\NonPackaged", "Value");
        DebugLog.Info($"隱私設定：線上語音辨識 HasAccepted={speech}；麥克風(全域)={mic}；麥克風(桌面程式)={micDesktop}");
    }

    private static string ReadRegistry(string subKey, string name)
    {
        try
        {
            using var key = Registry.CurrentUser.OpenSubKey(subKey);
            var value = key?.GetValue(name);
            return value?.ToString() ?? "（未設定）";
        }
        catch (Exception ex)
        {
            return $"（讀取失敗：{ex.Message}）";
        }
    }
}

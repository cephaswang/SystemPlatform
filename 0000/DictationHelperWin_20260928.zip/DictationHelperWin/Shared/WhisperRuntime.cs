using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using DictationHelperWin.Modules.ImportTranscribe.Models;
using Whisper.net;

namespace DictationHelperWin.Shared;

/// <summary>
/// Whisper 共用資源（聽抄模式使用）：
/// - 共用同一個 WhisperFactory（載入模型需要數秒且佔用大量記憶體，不要每次聽抄都重載）。
/// - 語系表與 BCP-47 → Whisper 語言碼、初始提示詞（與匯入模式 SpeechRecognitionService 的行為一致）。
/// 註：匯入模式的 SpeechRecognitionService 目前仍持有自己的 factory；若同一次執行兩個模式都使用，
/// 會各載入一份模型。之後可讓它也改用 GetFactory 以共用（見企劃書待辦）。
/// </summary>
public static class WhisperRuntime
{
    private static readonly object Gate = new();
    private static WhisperFactory? _factory;
    private static string? _loadedPath;

    public static readonly IReadOnlyList<LanguageOption> Languages = new LanguageOption[]
    {
        new("zh-TW", "中文（繁體，台灣）"),
        new("zh-CN", "中文（簡體）"),
        new("en-US", "English (United States)"),
        new("ja-JP", "日本語"),
        new("ko-KR", "한국어")
    };

    public static LanguageOption? FindByDisplayName(string displayName) =>
        Languages.FirstOrDefault(l => l.DisplayName == displayName);

    /// <summary>zh-TW → zh、en-US → en。</summary>
    public static string ToWhisperLanguage(string languageTag)
    {
        var dash = languageTag.IndexOf('-');
        return (dash > 0 ? languageTag[..dash] : languageTag).ToLowerInvariant();
    }

    /// <summary>以提示詞引導 Whisper 輸出繁體／簡體中文與標點（只是引導，不保證 100%）。</summary>
    public static string? GetInitialPrompt(string languageTag) => languageTag.ToLowerInvariant() switch
    {
        "zh-tw" or "zh-hk" => "以下是繁體中文的逐字稿，請使用繁體中文與標點符號。",
        "zh-cn" => "以下是简体中文的逐字稿，请使用简体中文和标点符号。",
        _ => null
    };

    public static WhisperFactory GetFactory(string modelPath)
    {
        lock (Gate)
        {
            if (_factory is not null && string.Equals(_loadedPath, modelPath, StringComparison.OrdinalIgnoreCase))
                return _factory;

            _factory?.Dispose();
            _factory = null;

            var sw = Stopwatch.StartNew();
            DebugLog.Info($"載入 Whisper 模型：{modelPath}；Whisper.net {typeof(WhisperFactory).Assembly.GetName().Version}");
            try
            {
                _factory = WhisperFactory.FromPath(modelPath);
                _loadedPath = modelPath;
                DebugLog.Info($"Whisper 模型載入完成，耗時 {sw.Elapsed.TotalSeconds:F1} 秒");
                return _factory;
            }
            catch (Exception ex)
            {
                DebugLog.Error("載入 Whisper 模型失敗", ex);
                throw;
            }
        }
    }

    /// <summary>App 結束時釋放模型。</summary>
    public static void Shutdown()
    {
        lock (Gate)
        {
            _factory?.Dispose();
            _factory = null;
            _loadedPath = null;
        }
    }
}

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using DictationHelperWin.Modules.ImportTranscribe.Models;
using DictationHelperWin.Shared;
using Whisper.net;

namespace DictationHelperWin.Modules.ImportTranscribe.Services;

/// <summary>所選語系不在辨識引擎的支援清單內。</summary>
public sealed class LanguageNotSupportedException : Exception
{
    public string Language { get; }

    public LanguageNotSupportedException(string language)
        : base($"不支援的辨識語系：{language}")
    {
        Language = language;
    }
}

/// <summary>Whisper 模型檔尚未下載。</summary>
public sealed class SpeechModelNotInstalledException : Exception
{
    public SpeechModelNotInstalledException()
        : base("尚未下載 Whisper 語音辨識模型。")
    {
    }
}

/// <summary>
/// 對應企劃書 2.2／3.2：匯入音檔的批次辨識服務。
/// 匯入模式改用 Whisper（Whisper.net，離線、免費），因為 Windows.Media.SpeechRecognition 只能從系統預設錄音裝置收音，
/// 無法直接讀檔。聽抄模式（SpeechTranscriber）仍維持原本的 Windows.Media.SpeechRecognition。
/// 語系以「每個音檔」為單位（AudioFile.Language）；Whisper 是多語模型，所以不需要安裝語言包，
/// 只需要下載一次模型檔（見 WhisperModelManager）。
/// 流程：ffmpeg 轉 16kHz wav → Whisper 辨識 → 依 Whisper 自帶的分段與時間戳組成 TranscriptSegment。
/// </summary>
public sealed class SpeechRecognitionService : IDisposable
{
    private static readonly LanguageOption[] SupportedLanguages =
    {
        new("zh-TW", "中文（繁體，台灣）"),
        new("zh-CN", "中文（簡體）"),
        new("en-US", "English (United States)"),
        new("ja-JP", "日本語"),
        new("ko-KR", "한국어")
    };

    private readonly AudioConverterService _converter = new();
    private readonly object _factoryLock = new();
    private WhisperFactory? _factory;

    public WhisperModelManager ModelManager { get; } = new();

    /// <summary>列出可選的辨識語系（Whisper 為多語模型，清單與系統語言包無關）。</summary>
    public IReadOnlyList<LanguageOption> GetAvailableLanguages() => SupportedLanguages;

    public bool IsLanguageAvailable(string languageTag) =>
        SupportedLanguages.Any(l => string.Equals(l.Tag, languageTag, StringComparison.OrdinalIgnoreCase));

    /// <summary>BCP-47 代碼轉 Whisper 語言碼：zh-TW → zh、en-US → en。</summary>
    public static string ToWhisperLanguage(string languageTag)
    {
        var dash = languageTag.IndexOf('-');
        return (dash > 0 ? languageTag[..dash] : languageTag).ToLowerInvariant();
    }

    /// <summary>
    /// Whisper 的中文預設輸出偏向簡體；以提示詞引導輸出繁體／簡體與標點。
    /// 這只是引導，不保證 100% 不混用。
    /// </summary>
    private static string? GetInitialPrompt(string languageTag) => languageTag.ToLowerInvariant() switch
    {
        "zh-tw" or "zh-hk" => "以下是繁體中文的逐字稿，請使用繁體中文與標點符號。",
        "zh-cn" => "以下是简体中文的逐字稿，请使用简体中文和标点符号。",
        _ => null
    };

    /// <summary>
    /// 針對單一 16kHz 單聲道 wav 檔，以指定語系進行辨識，回傳含時間戳記的逐字稿片段清單。
    /// 辨識在背景執行緒進行；呼叫端在 UI 執行緒 await 後再更新集合即可。
    /// </summary>
    public Task<IReadOnlyList<TranscriptSegment>> TranscribeFileAsync(
        string wavFilePath, string languageTag, CancellationToken cancellationToken = default)
    {
        if (!IsLanguageAvailable(languageTag))
        {
            DebugLog.Warn($"語系不支援：{languageTag}");
            throw new LanguageNotSupportedException(languageTag);
        }
        if (!ModelManager.IsModelInstalled)
        {
            DebugLog.Error($"模型未安裝：{ModelManager.ModelPath}");
            throw new SpeechModelNotInstalledException();
        }

        return Task.Run<IReadOnlyList<TranscriptSegment>>(async () =>
        {
            var sw = Stopwatch.StartNew();
            DebugLog.Info($"Whisper 辨識開始：wav={wavFilePath}（{new FileInfo(wavFilePath).Length:N0} bytes），語系={languageTag}→{ToWhisperLanguage(languageTag)}");
            var factory = GetFactory();

            var builder = factory.CreateBuilder().WithLanguage(ToWhisperLanguage(languageTag));
            var prompt = GetInitialPrompt(languageTag);
            if (prompt is not null)
                builder = builder.WithPrompt(prompt);

            using var processor = builder.Build();
            using var stream = File.OpenRead(wavFilePath);
            DebugLog.Info($"Whisper processor 建立完成，已耗時 {sw.Elapsed.TotalSeconds:F1} 秒，開始 ProcessAsync");

            var segments = new List<TranscriptSegment>();
            await foreach (var result in processor.ProcessAsync(stream, cancellationToken))
            {
                var text = result.Text?.Trim();
                if (string.IsNullOrEmpty(text)) continue;

                segments.Add(new TranscriptSegment
                {
                    StartTime = result.Start,
                    EndTime = result.End,
                    Text = text,
                    Language = languageTag
                });
            }
            DebugLog.Info($"Whisper 辨識結束：{segments.Count} 個片段，耗時 {sw.Elapsed.TotalSeconds:F1} 秒");
            return segments;
        }, cancellationToken);
    }

    /// <summary>
    /// 批次辨識：每個檔案依自己的語系轉錄；同語系的檔案排在一起處理。
    /// 單一檔案失敗或語系不支援只標記該檔狀態，不中斷整批。
    /// 前置條件：模型已下載（ImportView 會先呼叫 ModelManager.EnsureModelAsync）。
    /// 請在 UI 執行緒呼叫並 await：檔案狀態與 Segments 集合都在呼叫端的執行緒上更新。
    /// </summary>
    public async Task TranscribeBatchAsync(
        IEnumerable<AudioFile> files,
        IProgress<AudioFile>? progress = null,
        CancellationToken cancellationToken = default)
    {
        if (!ModelManager.IsModelInstalled)
        {
            DebugLog.Error($"批次轉錄中止：模型未安裝（{ModelManager.ModelPath}）");
            throw new SpeechModelNotInstalledException();
        }

        var queue = files
            .Where(f => f.Status is AudioFileStatus.Pending or AudioFileStatus.LanguageUnavailable)
            .ToList();
        DebugLog.Info($"批次轉錄開始：{queue.Count} 個檔案；模型={ModelManager.ModelPath}（{new FileInfo(ModelManager.ModelPath).Length:N0} bytes）");

        foreach (var group in queue.GroupBy(f => f.Language, StringComparer.OrdinalIgnoreCase))
        {
            foreach (var file in group)
            {
                cancellationToken.ThrowIfCancellationRequested();
                file.ErrorMessage = null;
                var fileSw = Stopwatch.StartNew();
                DebugLog.Info($"開始處理：{file.FileName}，語系={file.Language}，來源={file.FilePath}");

                if (!IsLanguageAvailable(file.Language))
                {
                    DebugLog.Warn($"{file.FileName}：語系 {file.Language} 不在支援清單");
                    file.Status = AudioFileStatus.LanguageUnavailable;
                    progress?.Report(file);
                    continue;
                }

                try
                {
                    // 已轉過的 wav（例如換語系重新轉錄）直接沿用，不必重轉。
                    if (file.ConvertedFilePath is null || !File.Exists(file.ConvertedFilePath))
                    {
                        file.Status = AudioFileStatus.Converting;
                        progress?.Report(file);
                        file.ConvertedFilePath = await _converter.ConvertToWavAsync(file.FilePath, cancellationToken);
                    }
                    else
                    {
                        DebugLog.Info($"{file.FileName}：沿用已轉好的 wav：{file.ConvertedFilePath}");
                    }

                    if (file.Duration == TimeSpan.Zero)
                        file.Duration = AudioConverterService.TryGetWavDuration(file.ConvertedFilePath);

                    file.Status = AudioFileStatus.Transcribing;
                    progress?.Report(file);

                    var segments = await TranscribeFileAsync(file.ConvertedFilePath, file.Language, cancellationToken);

                    file.Segments.Clear();
                    foreach (var segment in segments)
                        file.Segments.Add(segment);

                    file.Status = AudioFileStatus.Completed;
                    DebugLog.Info($"完成：{file.FileName}，{segments.Count} 個片段，總耗時 {fileSw.Elapsed.TotalSeconds:F1} 秒");
                }
                catch (OperationCanceledException)
                {
                    DebugLog.Warn($"已取消：{file.FileName}");
                    file.Status = AudioFileStatus.Pending;
                    throw;
                }
                catch (Exception ex)
                {
                    DebugLog.Error($"失敗：{file.FileName}（狀態={file.Status}，語系={file.Language}，wav={file.ConvertedFilePath ?? "無"}）", ex);
                    file.ErrorMessage = ex.Message;
                    file.Status = AudioFileStatus.Failed;
                }

                progress?.Report(file);
            }
        }
    }

    /// <summary>模型載入需要數秒且佔用記憶體，因此整個 App 共用同一個 factory，用到時才載入。</summary>
    private WhisperFactory GetFactory()
    {
        lock (_factoryLock)
        {
            if (_factory is not null) return _factory;

            var sw = Stopwatch.StartNew();
            DebugLog.Info($"載入 Whisper 模型：{ModelManager.ModelPath}；Whisper.net {typeof(WhisperFactory).Assembly.GetName().Version}；" +
                          $"行程架構={System.Runtime.InteropServices.RuntimeInformation.ProcessArchitecture}");
            try
            {
                _factory = WhisperFactory.FromPath(ModelManager.ModelPath);
                DebugLog.Info($"Whisper 模型載入完成，耗時 {sw.Elapsed.TotalSeconds:F1} 秒");
                return _factory;
            }
            catch (Exception ex)
            {
                // 常見原因：缺少 Whisper.net.Runtime 原生檔（runtimes\win-x64）、模型檔損毀、記憶體不足。
                DebugLog.Error("載入 Whisper 模型失敗", ex);
                throw;
            }
        }
    }

    public void Dispose()
    {
        lock (_factoryLock)
        {
            _factory?.Dispose();
            _factory = null;
        }
    }
}

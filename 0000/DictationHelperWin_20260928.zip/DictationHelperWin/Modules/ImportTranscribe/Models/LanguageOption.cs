namespace DictationHelperWin.Modules.ImportTranscribe.Models;

/// <summary>
/// 語系選項：Tag 為 BCP-47 語系代碼（如 zh-TW，供 Windows.Globalization.Language 使用），
/// DisplayName 為下拉選單顯示名稱。
/// </summary>
public sealed record LanguageOption(string Tag, string DisplayName);

public static class LanguageDefaults
{
    /// <summary>App 全域預設匯入語系（之後可由 SettingsView 覆寫並記住上次選擇）。</summary>
    public const string Tag = "zh-TW";
}

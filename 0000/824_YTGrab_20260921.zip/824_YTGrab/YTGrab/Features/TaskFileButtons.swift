import SwiftUI

/// 下載完成的任務列上顯示的按鍵：開啟檔案、在 Finder 顯示。
/// 任務尚未完成時不顯示任何東西，可以直接放進每一列而不用自己判斷狀態。
struct TaskFileButtons: View {
    @ObservedObject var task: DownloadTask

    var body: some View {
        if task.status == .completed {
            HStack(spacing: 8) {
                Button {
                    FinderActions.open(file: task.outputFileURL)
                } label: {
                    Image(systemName: "play.circle")
                }
                .help("用預設程式開啟")
                .disabled(task.outputFileURL == nil)

                Button {
                    FinderActions.reveal(
                        file: task.outputFileURL,
                        fallbackDirectory: task.outputDirectory
                    )
                } label: {
                    Image(systemName: "folder")
                }
                .help("在 Finder 顯示")
            }
            .buttonStyle(.borderless)
        }
    }
}

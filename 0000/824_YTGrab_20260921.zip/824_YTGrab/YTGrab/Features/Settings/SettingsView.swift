import SwiftUI
import AppKit

struct SettingsView: View {
    @EnvironmentObject private var appState: AppState
    @EnvironmentObject private var queueManager: DownloadQueueManager
    @State private var ytdlpVersion: String = "讀取中…"

    var body: some View {
        Form {
            Section("下載") {
                HStack {
                    Text("下載路徑")
                    Spacer()
                    Text(appState.downloadDirectory.path)
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                    Button("選擇…") { chooseDownloadDirectory() }
                }

                Stepper(
                    "同時下載數量：\(queueManager.maxConcurrentDownloads)",
                    value: $queueManager.maxConcurrentDownloads,
                    in: 1...5
                )
            }

            Section("yt-dlp") {
                HStack {
                    Text("執行檔路徑")
                    Spacer()
                    TextField("", text: $appState.ytdlpBinaryPath)
                        .textFieldStyle(.roundedBorder)
                        .multilineTextAlignment(.trailing)
                        .frame(maxWidth: 260)
                    Button("選擇…") { chooseYTDLPBinary() }
                }

                HStack {
                    Text("版本")
                    Spacer()
                    Text(ytdlpVersion).foregroundStyle(.secondary)
                }
                Button("檢查更新") { Task { await checkVersion() } }

                Text("找不到執行檔時，可在終端機執行「which yt-dlp」確認安裝路徑，再貼到上方欄位或用「選擇…」指定。")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Section("Cookies") {
                Text("支援從瀏覽器匯入 Cookies（--cookies-from-browser），用於需要登入才能存取的內容。")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                // TODO: 瀏覽器選擇下拉選單（Safari / Chrome / Firefox）
            }
        }
        .padding()
        .frame(width: 480)
        .task { await checkVersion() }
        .onChange(of: appState.ytdlpBinaryPath) { _ in
            Task { await checkVersion() }
        }
    }

    private func checkVersion() async {
        do {
            ytdlpVersion = try await appState.client.fetchVersion()
        } catch {
            ytdlpVersion = "無法取得（\(error.localizedDescription)）"
        }
    }

    private func chooseDownloadDirectory() {
        let panel = NSOpenPanel()
        panel.canChooseDirectories = true
        panel.canChooseFiles = false
        panel.allowsMultipleSelection = false
        if panel.runModal() == .OK, let url = panel.url {
            appState.downloadDirectory = url
        }
    }

    private func chooseYTDLPBinary() {
        let panel = NSOpenPanel()
        panel.canChooseDirectories = false
        panel.canChooseFiles = true
        panel.allowsMultipleSelection = false
        panel.directoryURL = URL(fileURLWithPath: "/usr/local/bin")
        panel.prompt = "選擇 yt-dlp"
        if panel.runModal() == .OK, let url = panel.url {
            appState.ytdlpBinaryPath = url.path
        }
    }
}

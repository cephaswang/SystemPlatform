import SwiftUI

struct DownloadQueueView: View {
    @EnvironmentObject private var queueManager: DownloadQueueManager

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            Text("下載佇列").font(.headline).padding([.horizontal, .top])

            if queueManager.tasks.isEmpty {
                Text("目前沒有下載任務").foregroundStyle(.secondary).padding()
            } else {
                List(queueManager.tasks) { task in
                    DownloadTaskRow(task: task, queueManager: queueManager)
                }
            }
        }
    }
}

private struct DownloadTaskRow: View {
    @ObservedObject var task: DownloadTask
    let queueManager: DownloadQueueManager

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack {
                Text(task.title).lineLimit(1)
                Spacer()
                statusLabel
            }

            ProgressView(value: task.progress)

            HStack {
                if !task.speedText.isEmpty {
                    Text(task.speedText).font(.caption).foregroundStyle(.secondary)
                }
                if !task.etaText.isEmpty {
                    Text("剩餘 \(task.etaText)").font(.caption).foregroundStyle(.secondary)
                }
                Spacer()
                actionButtons
            }
        }
        .padding(.vertical, 4)
    }

    @ViewBuilder
    private var statusLabel: some View {
        switch task.status {
        case .queued: Text("等待中").font(.caption).foregroundStyle(.secondary)
        case .running: Text("下載中").font(.caption).foregroundStyle(.blue)
        case .paused: Text("已暫停").font(.caption).foregroundStyle(.orange)
        case .completed: Text("已完成").font(.caption).foregroundStyle(.green)
        case .failed: Text("失敗").font(.caption).foregroundStyle(.red)
        case .cancelled: Text("已取消").font(.caption).foregroundStyle(.secondary)
        }
    }

    @ViewBuilder
    private var actionButtons: some View {
        switch task.status {
        case .running:
            Button("暫停") { queueManager.pause(task) }
            Button("取消") { queueManager.cancel(task) }
        case .paused:
            Button("繼續") { queueManager.resume(task) }
            Button("取消") { queueManager.cancel(task) }
        case .queued:
            Button("取消") { queueManager.cancel(task) }
        case .failed:
            Button("重試") { queueManager.retry(task) }
        case .completed, .cancelled:
            EmptyView()
        }
    }
}

import Foundation

/// 通用的外部程序執行器，負責啟動 Process、串流讀取 stdout（逐行），
/// 並回傳最終結束狀態。所有跟 yt-dlp / ffmpeg 的溝通都經過這裡，
/// 上層（YTDLPClient / DownloadQueueManager）不直接碰 Process。
enum ProcessRunnerError: Error, LocalizedError {
    case executableNotFound(String)
    case nonZeroExit(Int32, stderr: String)
    case launchFailed(Error)

    var errorDescription: String? {
        switch self {
        case .executableNotFound(let path):
            return "找不到執行檔：\(path)"
        case .nonZeroExit(let code, let stderr):
            return "程序結束碼 \(code)：\(stderr)"
        case .launchFailed(let error):
            return "啟動失敗：\(error.localizedDescription)"
        }
    }
}

/// 背景執行緒讀取 pipe、其他執行緒取用結果，用鎖保護。
private final class OutputBuffer: @unchecked Sendable {
    private let lock = NSLock()
    private var storage = Data()

    var data: Data {
        lock.lock(); defer { lock.unlock() }
        return storage
    }

    func set(_ newValue: Data) {
        lock.lock(); defer { lock.unlock() }
        storage = newValue
    }
}

final class ProcessRunner {

    /// GUI App 被 launchd/Finder 啟動時，子程序繼承的預設 PATH 通常只有
    /// /usr/bin:/bin:/usr/sbin:/sbin，不包含 Homebrew 或使用者自行安裝的路徑。
    /// yt-dlp 本體常是帶 `#!/usr/bin/env python3` shebang 的 Python script，
    /// 若 PATH 裡沒有使用者實際安裝新版 Python 的路徑，env 會誤用系統內建、
    /// 版本過舊（隨 Command Line Tools 附的 3.9）的 python3，導致執行失敗。
    /// 這裡把常見的 Homebrew / 手動安裝路徑補到 PATH 最前面。
    private static func buildEnvironment() -> [String: String] {
        var environment = ProcessInfo.processInfo.environment

        let extraPaths = [
            "/opt/homebrew/bin",
            "/opt/homebrew/sbin",
            "/usr/local/bin",
            "/usr/local/sbin"
        ]
        let existingPath = environment["PATH"] ?? "/usr/bin:/bin:/usr/sbin:/sbin"
        let existingComponents = existingPath.split(separator: ":").map(String.init)
        // 補在最前面，且避免重複
        let mergedComponents = extraPaths.filter { !existingComponents.contains($0) } + existingComponents
        environment["PATH"] = mergedComponents.joined(separator: ":")

        return environment
    }

    /// 執行一次性指令，等待結束並回傳完整 stdout（適合 --dump-json 這種一次性輸出）。
    static func run(executablePath: String, arguments: [String]) async throws -> String {
        guard FileManager.default.isExecutableFile(atPath: executablePath) else {
            throw ProcessRunnerError.executableNotFound(executablePath)
        }

        return try await withCheckedThrowingContinuation { continuation in
            let process = Process()
            process.executableURL = URL(fileURLWithPath: executablePath)
            process.arguments = arguments
            process.environment = buildEnvironment()

            let stdoutPipe = Pipe()
            let stderrPipe = Pipe()
            process.standardOutput = stdoutPipe
            process.standardError = stderrPipe

            let stdoutBuffer = OutputBuffer()
            let stderrBuffer = OutputBuffer()

            // 兩條 pipe 各自在背景執行緒讀到 EOF，等「兩條都讀完」且「程序已結束」才 resume。
            // 舊寫法靠 readabilityHandler，程序結束時 pipe 裡可能還有資料沒被讀走，
            // 輸出量大（例如播放列表的 JSON）時內容會被截斷，導致 JSON 解析失敗。
            let readGroup = DispatchGroup()
            readGroup.enter()
            readGroup.enter()

            process.terminationHandler = { proc in
                readGroup.notify(queue: .global()) {
                    if proc.terminationStatus == 0 {
                        let output = String(data: stdoutBuffer.data, encoding: .utf8) ?? ""
                        continuation.resume(returning: output)
                    } else {
                        let errOutput = String(data: stderrBuffer.data, encoding: .utf8) ?? "未知錯誤"
                        continuation.resume(throwing: ProcessRunnerError.nonZeroExit(proc.terminationStatus, stderr: errOutput))
                    }
                }
            }

            do {
                try process.run()
            } catch {
                readGroup.leave()
                readGroup.leave()
                continuation.resume(throwing: ProcessRunnerError.launchFailed(error))
                return
            }

            DispatchQueue.global().async {
                stdoutBuffer.set((try? stdoutPipe.fileHandleForReading.readToEnd()) ?? Data())
                readGroup.leave()
            }
            DispatchQueue.global().async {
                stderrBuffer.set((try? stderrPipe.fileHandleForReading.readToEnd()) ?? Data())
                readGroup.leave()
            }
        }
    }

    /// 執行長時間任務（下載），逐行回呼 stdout，供呼叫端解析進度。
    /// 回傳已啟動的 Process，讓呼叫端可保存起來做暫停/取消。
    @discardableResult
    static func runStreaming(
        executablePath: String,
        arguments: [String],
        onLine: @escaping (String) -> Void,
        onCompletion: @escaping (Result<Void, ProcessRunnerError>) -> Void
    ) -> Process? {
        guard FileManager.default.isExecutableFile(atPath: executablePath) else {
            onCompletion(.failure(.executableNotFound(executablePath)))
            return nil
        }

        let process = Process()
        process.executableURL = URL(fileURLWithPath: executablePath)
        process.arguments = arguments
        process.environment = buildEnvironment()

        let stdoutPipe = Pipe()
        let stderrPipe = Pipe()
        process.standardOutput = stdoutPipe
        process.standardError = stderrPipe

        var lineBuffer = ""
        var stderrData = Data()

        stdoutPipe.fileHandleForReading.readabilityHandler = { handle in
            let data = handle.availableData
            guard !data.isEmpty, let chunk = String(data: data, encoding: .utf8) else { return }
            lineBuffer += chunk
            while let range = lineBuffer.range(of: "\n") {
                let line = String(lineBuffer[..<range.lowerBound])
                lineBuffer.removeSubrange(..<range.upperBound)
                if !line.isEmpty {
                    DispatchQueue.main.async { onLine(line) }
                }
            }
        }

        stderrPipe.fileHandleForReading.readabilityHandler = { handle in
            stderrData.append(handle.availableData)
        }

        process.terminationHandler = { proc in
            stdoutPipe.fileHandleForReading.readabilityHandler = nil
            stderrPipe.fileHandleForReading.readabilityHandler = nil
            DispatchQueue.main.async {
                if proc.terminationStatus == 0 {
                    onCompletion(.success(()))
                } else {
                    let errText = String(data: stderrData, encoding: .utf8) ?? "未知錯誤"
                    onCompletion(.failure(.nonZeroExit(proc.terminationStatus, stderr: errText)))
                }
            }
        }

        do {
            try process.run()
            return process
        } catch {
            onCompletion(.failure(.launchFailed(error)))
            return nil
        }
    }
}

import Foundation
import Combine

@MainActor
final class AppState: ObservableObject {
    @Published var ytdlpBinaryPath: String {
        didSet {
            UserDefaults.standard.set(ytdlpBinaryPath, forKey: Self.customPathKey)
            client.updateBinaryPath(ytdlpBinaryPath)
        }
    }
    @Published var downloadDirectory: URL
    @Published var currentVideoInfo: VideoInfo?
    @Published var currentPlaylist: PlaylistInfo?
    /// 網址同時帶有影片與 list= 時，暫存起來等使用者選「單支影片 / 整個播放列表」。
    @Published var pendingChoiceURL: String?
    @Published var isFetchingInfo = false
    @Published var fetchErrorMessage: String?

    let client: YTDLPClient
    let queueManager: DownloadQueueManager

    private static let customPathKey = "ytdlpBinaryPath"

    /// 依序嘗試常見安裝位置：
    /// 1. App Bundle 內建（正式打包後）
    /// 2. 使用者在設定頁手動指定過的路徑（存在 UserDefaults）
    /// 3. Homebrew Apple Silicon 預設路徑
    /// 4. Homebrew Intel / 傳統 macOS 常見路徑
    /// 5. 系統路徑
    private static func resolveYTDLPPath() -> String {
        let fileManager = FileManager.default

        if let bundledPath = Bundle.main.path(forResource: "yt-dlp", ofType: nil),
           fileManager.isExecutableFile(atPath: bundledPath) {
            return bundledPath
        }

        if let savedPath = UserDefaults.standard.string(forKey: customPathKey),
           fileManager.isExecutableFile(atPath: savedPath) {
            return savedPath
        }

        let candidates = [
            "/opt/homebrew/bin/yt-dlp",   // Apple Silicon Homebrew
            "/usr/local/bin/yt-dlp",      // Intel Homebrew / 常見手動安裝路徑
            "/usr/bin/yt-dlp",
            "/opt/local/bin/yt-dlp"       // MacPorts
        ]
        for path in candidates where fileManager.isExecutableFile(atPath: path) {
            return path
        }

        // 都找不到時，仍回傳最常見的路徑當預設值，讓使用者在設定頁看到並可以修正
        return candidates.first!
    }

    init() {
        let resolvedPath = Self.resolveYTDLPPath()

        self.ytdlpBinaryPath = resolvedPath
        self.downloadDirectory = FileManager.default.urls(for: .downloadsDirectory, in: .userDomainMask).first
            ?? FileManager.default.homeDirectoryForCurrentUser

        let client = YTDLPClient(binaryPath: resolvedPath)
        self.client = client
        self.queueManager = DownloadQueueManager(client: client)
    }

    private enum URLKind {
        case video              // 一般單支影片
        case videoInPlaylist    // watch?v=...&list=...：要問使用者想抓哪一個
        case playlist           // /playlist?list=...：一定是整個列表
    }

    private func classify(_ urlString: String) -> URLKind {
        guard client.urlContainsPlaylistReference(urlString) else { return .video }
        let path = URLComponents(string: urlString)?.path ?? ""
        return path.hasPrefix("/playlist") ? .playlist : .videoInPlaylist
    }

    private func resetResults() {
        currentVideoInfo = nil
        currentPlaylist = nil
        pendingChoiceURL = nil
        fetchErrorMessage = nil
    }

    /// URLInputView 的入口：依網址類型分流。
    func fetchInfo(for urlString: String) async {
        switch classify(urlString) {
        case .video:
            await fetchVideo(url: urlString)
        case .playlist:
            await fetchPlaylist(url: urlString)
        case .videoInPlaylist:
            resetResults()
            pendingChoiceURL = urlString
        }
    }

    /// 只解析單支影片（YTDLPClient 會加 --no-playlist）。
    func fetchVideo(url: String) async {
        resetResults()
        isFetchingInfo = true
        defer { isFetchingInfo = false }

        do {
            currentVideoInfo = try await client.fetchVideoInfo(url: url)
        } catch {
            fetchErrorMessage = error.localizedDescription
        }
    }

    /// 解析整個播放列表（flat-playlist，只取項目清單）。
    func fetchPlaylist(url: String) async {
        resetResults()
        isFetchingInfo = true
        defer { isFetchingInfo = false }

        do {
            currentPlaylist = try await client.fetchPlaylist(url: url)
        } catch {
            fetchErrorMessage = error.localizedDescription
        }
    }
}

import SwiftUI

@main
struct YTGrabApp: App {
    @StateObject private var appState = AppState()

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(appState)
        }
        .commands {
            HelpCommands()
        }

        Window("YTGrab 使用說明", id: "help") {
            HelpView()
                .frame(minWidth: 680, minHeight: 520)
        }
        .defaultSize(width: 960, height: 760)
    }
}

struct HelpCommands: Commands {
    @Environment(\.openWindow) private var openWindow

    var body: some Commands {
        CommandGroup(replacing: .help) {
            Button("YTGrab 使用說明") {
                openWindow(id: "help")
            }
            .keyboardShortcut("?", modifiers: .command)
        }
    }
}

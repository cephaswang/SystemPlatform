import SwiftUI

@main
struct YTGrabApp: App {
    @StateObject private var appState = AppState()

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(appState)
                .environmentObject(appState.queueManager)
                .frame(minWidth: 720, minHeight: 560)
        }
        .windowResizability(.contentSize)

        Settings {
            SettingsView()
                .environmentObject(appState)
                .environmentObject(appState.queueManager)
        }
    }
}

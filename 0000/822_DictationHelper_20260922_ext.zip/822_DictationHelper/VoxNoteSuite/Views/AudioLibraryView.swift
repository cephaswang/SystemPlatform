import SwiftUI

struct AudioLibraryView: View {

    @EnvironmentObject private var library: AudioLibraryStore
    @State private var showingImportSheet = false
    @State private var showingExportSheet = false

    var body: some View {
        let _ = print("🖼️ AudioLibraryView body 重新評估，selectedAudioFile.status=\(library.selectedAudioFile?.status.self ?? .pending)")
        NavigationSplitView {
            List(selection: $library.selectedAudioFileID) {
                ForEach(library.audioFiles) { file in
                    HStack {
                        Image(systemName: statusIcon(for: file.status))
                            .foregroundColor(statusColor(for: file.status))

                        VStack(alignment: .leading, spacing: 2) {
                            Text(file.displayName)
                                .font(.body)
                            Text(file.durationDescription)
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                    }
                    .tag(file.id)
                }
            }
            .frame(minWidth: 220)
            .toolbar {
                ToolbarItem {
                    Button {
                        showingImportSheet = true
                    } label: {
                        Label("匯入音檔", systemImage: "plus")
                    }
                }
            }
        } detail: {
            if let selected = library.selectedAudioFile {
                TranscriptEditorView(audioFile: selected)
                    .id("\(selected.id)-\(selected.status)")   // 新增這行
                    .toolbar {
                        ToolbarItem {
                            Button {
                                showingExportSheet = true
                            } label: {
                                Label("匯出", systemImage: "square.and.arrow.up")
                            }
                            .disabled(selected.status != .completed)
                        }
                    }
            } else {
                ContentUnavailableView(
                    "尚未選擇音檔",
                    systemImage: "waveform",
                    description: Text("從左側清單選擇一個音檔，或點擊「匯入音檔」開始")
                )
            }
        }
        .sheet(isPresented: $showingImportSheet) {
            // 改用 appendImportedFiles(_:)：內部已包進 Task { @MainActor in }，
            // 避免這個 closure 剛好在 sheet dismiss 的 view-update 週期裡
            // 同步修改 @Published 的 audioFiles，觸發
            // 「Publishing changes from within view updates」警告。
            ImportView { importedFiles in
                library.appendImportedFiles(importedFiles)
            }
        }
        .sheet(isPresented: $showingExportSheet) {
            if let selected = library.selectedAudioFile {
                ExportSheetView(audioFile: selected)
            }
        }
    }

    private func statusIcon(for status: AudioFile.TranscriptionStatus) -> String {
        switch status {
        case .pending: return "clock"
        case .processing: return "waveform.circle"
        case .completed: return "checkmark.circle.fill"
        case .failed: return "exclamationmark.triangle.fill"
        }
    }

    private func statusColor(for status: AudioFile.TranscriptionStatus) -> Color {
        switch status {
        case .pending: return .secondary
        case .processing: return .blue
        case .completed: return .green
        case .failed: return .red
        }
    }
}

#Preview {
    AudioLibraryView()
        .environmentObject(AudioLibraryStore())
}

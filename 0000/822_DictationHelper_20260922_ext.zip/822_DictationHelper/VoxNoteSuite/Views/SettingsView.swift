import SwiftUI

struct SettingsView: View {

    enum RecognitionEngine: String, CaseIterable, Identifiable {
        case appleSpeech = "Apple Speech Framework"
        case whisperLocal = "Whisper（本地端）"
        case whisperCloud = "Whisper（雲端 API）"

        var id: String { rawValue }
    }

    @EnvironmentObject private var library: AudioLibraryStore

    @AppStorage("selectedLocale") private var selectedLocale: String = "zh-TW"
    @AppStorage("recognitionEngine") private var recognitionEngine: RecognitionEngine = .appleSpeech
    @AppStorage("shortcutStartImport") private var shortcutStartImport: String = "⌘I"
    @AppStorage("shortcutExport") private var shortcutExport: String = "⌘E"

    private let availableLocales = ["zh-TW", "zh-CN", "en-US", "en-GB", "ja-JP"]

    var body: some View {
        TabView {
            generalTab
                .tabItem { Label("一般", systemImage: "gearshape") }

            shortcutsTab
                .tabItem { Label("快捷鍵", systemImage: "keyboard") }
        }
        .padding(20)
        .frame(width: 420, height: 260)
    }

    private var generalTab: some View {
        Form {
            Picker("辨識語系", selection: $selectedLocale) {
                ForEach(availableLocales, id: \.self) { locale in
                    Text(locale).tag(locale)
                }
            }

            Picker("辨識引擎", selection: $recognitionEngine) {
                ForEach(RecognitionEngine.allCases) { engine in
                    Text(engine.rawValue).tag(engine)
                }
            }

            if recognitionEngine == .whisperCloud {
                Text("使用雲端 API 將傳送音檔至第三方伺服器，請留意隱私考量。")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
        }
        .padding(.top, 12)
    }

    private var shortcutsTab: some View {
        Form {
            TextField("開始匯入", text: $shortcutStartImport)
            TextField("匯出目前逐字稿", text: $shortcutExport)

            Text("快捷鍵修改後，需重新啟動 App 才會生效。")
                .font(.caption)
                .foregroundColor(.secondary)
        }
        .padding(.top, 12)
    }
}

#Preview {
    SettingsView()
        .environmentObject(AudioLibraryStore())
}

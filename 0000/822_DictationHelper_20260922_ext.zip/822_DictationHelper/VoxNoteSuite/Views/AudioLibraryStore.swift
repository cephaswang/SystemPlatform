import Foundation
import Combine

/// 管理已匯入音檔與其轉錄狀態的共用資料來源
final class AudioLibraryStore: ObservableObject {
    @Published var audioFiles: [AudioFile] = []
    @Published var selectedAudioFileID: AudioFile.ID?

    var selectedAudioFile: AudioFile? {
        audioFiles.first { $0.id == selectedAudioFileID }
    }

    private let recognitionService = SpeechRecognitionService()

    /// 對單一音檔啟動語音辨識：locale 讀取「該檔案自己」在匯入時選定的語系
    /// （見 AudioFile.locale），不再讀全域 UserDefaults，讓每個檔案的語系互相獨立。
    /// 辨識引擎（Apple Speech / Whisper）維持全域設定，因為那牽涉到隱私與功能選擇，
    /// 通常是使用者對整個 App 的一次性選擇。
    ///
    /// 整段包進 Task { @MainActor in } ——包含開頭同步的 .status = .processing——
    /// 是為了避免這個函式剛好在 sheet dismiss 的 view-update transaction 裡被呼叫，
    /// 同步修改 @Published 屬性觸發「Publishing changes from within view updates」。
    func startTranscription(for fileID: AudioFile.ID) {
        DispatchQueue.main.async {
            guard let index = self.audioFiles.firstIndex(where: { $0.id == fileID }),
                  self.audioFiles[index].status == .pending else { return }

            self.audioFiles[index].status = .processing
            let audioURL = self.audioFiles[index].sourceURL
            let locale = self.audioFiles[index].locale

            let engine = SettingsView.RecognitionEngine(
                rawValue: UserDefaults.standard.string(forKey: "recognitionEngine") ?? ""
            ) ?? .appleSpeech

            Task { @MainActor in
                do {
                    let segments = try await self.recognitionService.recognize(
                        audioURL: audioURL,
                        locale: locale,
                        engine: engine
                    )
                    guard let idx = self.audioFiles.firstIndex(where: { $0.id == fileID }) else { return }
                    self.audioFiles[idx].transcriptSegments = segments
                    self.audioFiles[idx].status = .completed
                } catch {
                    guard let idx = self.audioFiles.firstIndex(where: { $0.id == fileID }) else { return }
                    self.audioFiles[idx].status = .failed
                }
            }
        }
    }

    func appendImportedFiles(_ files: [AudioFile]) {
        DispatchQueue.main.async {
            self.audioFiles.append(contentsOf: files)
            files.forEach { self.startTranscription(for: $0.id) }
        }
    }
    
    
}

# VoxNote 語音工作站 — macOS 語音轉文字整合企劃

> **本版更新說明**：本版依 2025/09/22 實際專案目錄（`dir.txt`）校對，反映目前真實的檔案配置，
> 與原始企劃（三個獨立 `.xcodeproj` + Workspace 的理想架構）已有落差，落差處以 ⚠️ 標註，
> 需要你確認是刻意調整過的架構，還是遺漏／待補的檔案。

## 專案定位

**VoxNote 語音工作站** 是一個整合品牌，底下收納兩個**功能互補**的 macOS 語音轉文字情境：

| 模組 | 專案代號 | 核心情境 |
|---|---|---|
| **VoxNote 匯入轉錄** | VoxNoteImport | 使用者「已有音檔」（教學影片、會議錄音、Podcast），匯入後離線／批次轉成文字稿 |
| **聽抄小幫手** | VoiceCapture | 使用者「正在聽」系統喇叭播放的聲音（教學影片、會議錄影即時播放），即時擷取並邊聽邊轉成文字稿 |

兩者互為情境互補（事後匯入 vs. 即時聽抄），因此整合為同一品牌對外發佈。

> ⚠️ **架構落差 1**：原企劃設定兩個 App「原始碼、Model、Service 完全不共用，各自獨立編譯」，
> 並以獨立 `.xcodeproj` 隔開。但實際目錄只看到**單一** `Dictation Helper.xcodeproj`，
> `VoxNoteSuite/` 與 `Dictation Helper/` 兩個原始碼資料夾很可能是**同一個 Xcode 專案底下的兩個 Group／Target**，
> 而非各自獨立的 Xcode 專案。若這是刻意改成單一專案管理，建議在此明確記錄；
> 若不是刻意的，就代表原本「零共用、獨立簽署」的整合原則可能已經跑掉，需要重新確認邊界。

---

## 一、專案文件（企劃階段）

| 檔案 | 功能 | 現況 |
|---|---|---|
| `01_企劃書.md` | 產品定位、目標使用者、競品分析（如 Otter.ai、飛書妙記）、商業模式 | 目錄中未見獨立檔案，內容併入本文件 |
| `02_功能規格書.md` | 詳列 MVP 與後續版本功能：匯入音檔、轉文字、逐字稿編輯、匯出格式 | 未見 |
| `03_使用者流程圖.md` | 從「匯入音檔」到「取得文字稿」的操作路徑 | 未見 |
| `04_UI線框圖/` | 主畫面、錄音清單、轉錄結果頁的示意圖 | 未見；`docs/` 下有 `b01–b05.jpg`、`c01–c04.jpg` 等圖片，可能是這類素材 |
| `05_技術選型評估.md` | 比較 Apple Speech Framework vs Whisper（本地/雲端）vs 第三方 API | 未見 |
| `06_整合架構說明.md` | 說明專案結構、Launcher 啟動邏輯、兩者邊界原則 | 未見；本文件第六節暫代 |
| `喇叭聽抄小幫手_macOS_App_企劃書.txt` | VoiceCapture 舊版單獨企劃書（v1.0） | 存在於 `Dictation Helper/docs/` |
| `App_Review_回覆_VoiceCapture.md` | App Store 審查回覆紀錄 | 存在於 `Dictation Helper/docs/` |
| `聽抄小幫手_使用說明.docx` / `.pdf` | 使用者說明文件 | 存在於 `Dictation Helper/docs/` |
| `VoxNote_專案企劃_001.md` | 本企劃書舊版快照 | 存在於 `Dictation Helper/docs/VoxNote/` |

---

## 二、專案總覽結構（依實際目錄校對）

```
822_DictationHelper/                       專案根目錄
├── Dictation Helper.xcodeproj/             唯一的 Xcode 專案設定檔 ⚠️（非原企劃的 Workspace + 3 專案）
├── Dictation Helper/                       VoiceCapture（聽抄小幫手）原始碼所在資料夾
├── VoxNoteSuite/                           VoxNoteImport（匯入轉錄）原始碼所在資料夾
├── CertificateSigningRequest.*             簽署憑證相關檔案
└── generate_csr.sh                         產生 CSR 的腳本
```

> ⚠️ **架構落差 2**：原企劃結構為
> `VoxNoteSuite/{VoxNoteSuite.xcworkspace, VoxNoteLauncher/, VoxNoteImport/, VoiceCapture/}`，
> 三者並列於 `VoxNoteSuite/` 之下。實際上 `VoxNoteSuite/` 只裝了 VoxNoteImport 的原始碼，
> VoiceCapture 的原始碼在專案根目錄另一個資料夾 `Dictation Helper/` 裡，兩者是**平行的兩個資料夾**，
> 不是原企劃設想的巢狀包含關係。

---

## 三、VoxNoteLauncher（啟動入口）

| 檔案／資料夾 | 功能 | 現況 |
|---|---|---|
| `VoxNoteLauncher.xcodeproj` | 獨立 Xcode 專案設定檔 | ⚠️ 未見獨立專案，推測併入主專案 |
| `LauncherApp.swift` | App 進入點，開啟單一啟動視窗 | 🔴 **遺失**：目錄中完全找不到此檔（含 `.txt` 備份也已被移除） |
| `LauncherView.swift` | 顯示「匯入音檔轉錄」「即時聽抄」兩個入口按鈕 | 存在，但位置改在 `VoxNoteSuite/` 根目錄，非獨立 Launcher 資料夾 |
| `AppLauncherService.swift` | 以 `NSWorkspace.shared.open(_:)` 開啟對方 App Bundle | 存在，同樣位於 `VoxNoteSuite/` 根目錄 |
| `Resources/Assets.xcassets` | 啟動畫面圖示與品牌識別圖片 | 未見獨立 Launcher 用的 Assets |
| `Info.plist` | App 基本設定 | 未見獨立檔案 |

> 🔴 **需要你確認**：`LauncherApp.swift` 整支不見了，且 `Dictation Helper/` 資料夾裡多出了
> `RootApp.swift`、`RootView.swift` 兩支原企劃沒有的檔案（見下節），命名方式很像是
> 「App 進入點 + 主畫面」的角色。是否 Launcher 的職責已經被合併進 `Dictation Helper` target，
> 由 `RootApp.swift` / `RootView.swift` 取代？若是，建議把這節內容整併過去並更新檔名對照；
> 若不是，`LauncherApp.swift` 需要盡快補回，否則 Launcher 完全沒有進入點可以編譯。

---

## 四、VoxNoteImport（匯入轉錄，位於 `VoxNoteSuite/`）

| 檔案／資料夾 | 功能 | 現況 |
|---|---|---|
| `VoxNoteImport.xcodeproj` | 獨立 Xcode 專案設定檔 | ⚠️ 未見，推測併入 `Dictation Helper.xcodeproj` |
| `App/VoxNoteImportApp.swift` | App 進入點，初始化主視窗與環境設定 | 🔴 **遺失**：`VoxNoteSuite/App/` 資料夾目前是**空的**，原本的 `.swift` 與備份 `.swift.txt`／`.swift_01.txt` 都已不在 |
| `Views/AudioLibraryView.swift` | 主畫面，顯示已匯入音檔清單與轉錄狀態 | ✅ 存在（`VoxNoteSuite/Views/`） |
| `Views/AudioLibraryStore.swift` | 音檔清單與轉錄狀態的共用資料來源（`ObservableObject`） | ✅ 存在；⚠️ 原企劃未單獨列出此檔，目前歸在 `Views/` 底下，語意上其實屬於狀態管理層，可考慮之後移至獨立的 `Stores/` 或 `ViewModels/` 資料夾 |
| `Views/ImportView.swift` | 拖放或選取音檔匯入介面（支援 mp3 / m4a / wav / webm） | ✅ 存在 |
| `Views/TranscriptEditorView.swift` | 顯示與編輯轉錄後文字稿（含時間戳對照） | ✅ 存在 |
| `Views/ExportSheetView.swift` | 匯出格式選擇（txt / srt / docx / pdf） | ✅ 存在 |
| `Views/SettingsView.swift` | 語言選擇、辨識引擎切換、快捷鍵設定 | ✅ 存在 |
| `Models/AudioFile.swift` | 定義音檔物件（路徑、時長、格式、狀態） | ✅ 存在 |
| `Models/TranscriptSegment.swift` | 定義單句轉錄結果（文字、起訖時間、信心度） | ✅ 存在 |
| `Services/AudioImportService.swift` | 處理音檔讀取與格式相容性檢查 | ✅ 存在 |
| `Services/SpeechRecognitionService.swift` | 呼叫語音辨識引擎，回傳文字結果 | ✅ 存在 |
| `Services/AudioConverterService.swift` | 音檔格式轉換（webm→m4a、辨識前轉 .caf） | ✅ 存在 |
| `Services/ExportService.swift` | 將逐字稿輸出為指定檔案格式 | ✅ 存在 |
| `Utilities/PermissionManager.swift` | 管理語音辨識／麥克風權限請求 | ✅ 存在 |
| `Resources/Assets.xcassets` | App 圖示、介面圖片資源 | ⚠️ 未見於 `VoxNoteSuite/` 下，需確認資源是否共用了 `Dictation Helper/Assets.xcassets` |
| `Resources/Localizable.strings` | 多語系文字（繁中／英文） | 未見 |
| `Info.plist` | App 權限宣告 | 未見獨立檔案 |
| `Tests/VoxNoteImportTests.swift` | 單元測試 | 未見 |

> 🔴 **最優先待辦**：`App/` 資料夾是空的，代表 VoxNoteImport 目前**沒有 App 進入點**，
> 這支檔案若真的遺失，專案應無法正確啟動這個 target（先前排查 build 錯誤時，
> 是移除了掛在 target 裡但編不過的 `.txt` 備份檔，正常檔案應仍保留；建議立即在 Xcode
> 的 Project Navigator 裡確認 `VoxNoteImportApp.swift` 是否還存在於某處、只是未被列在
> 這次的 `dir.txt` 掃描路徑內，或是否已被誤刪，需要從版本控制／備份還原）。

> 📌 **文件維護附註**：`webm` 支援前提維持原企劃所述——AVFoundation 無法原生解析 webm 容器，
> 由 `AudioImportService` 呼叫 `AudioConverterService` 以 ffmpeg 抽出音軌轉成 `.m4a`，
> 原始 webm 保留於 `AudioFile.originalSourceURL`。發行版須將已簽署的 ffmpeg 執行檔打包進
> App Bundle（例如 `Contents/Resources/ffmpeg`）；開發階段退而尋找
> `/opt/homebrew/bin/ffmpeg`、`/usr/local/bin/ffmpeg`。

---

## 五、VoiceCapture（聽抄小幫手，位於 `Dictation Helper/`）

| 檔案／資料夾 | 功能 | 現況 |
|---|---|---|
| `VoiceCapture.xcodeproj` | 獨立 Xcode 專案設定檔 | ⚠️ 未見，推測併入 `Dictation Helper.xcodeproj` |
| `VoiceCaptureApp.swift` | App 進入點，建立主視窗 | ⚠️ 未見此檔名；請對照下方 `RootApp.swift` 是否為改名後的同一角色 |
| `ContentView.swift` | 主畫面 UI：語系選單、輸入裝置選單、開始/停止按鈕、即時辨識文字框、已存檔列表 | ✅ 存在 |
| `SpeechTranscriber.swift` | 語音辨識核心邏輯 | ✅ 存在 |
| `AudioDeviceManager.swift` | 音訊輸入裝置列舉與切換（CoreAudio，對應 BlackHole） | ✅ 存在 |
| `Info.plist` | 權限使用說明 | 未見獨立檔案 |
| `VoiceCapture.entitlements` | App Sandbox 權限 | 未見獨立檔案 |
| `Assets.xcassets` | App 圖示與影像資源 | ✅ 存在 |
| `RootApp.swift` 🆕 | 原企劃未列出；私有檔案，命名推測為目前實際的 App 進入點 | ✅ 存在，⚠️ 需確認是否取代了 `VoiceCaptureApp.swift`／`LauncherApp.swift` 的角色 |
| `RootView.swift` 🆕 | 原企劃未列出；私有檔案，命名推測為進入點對應的根畫面 | ✅ 存在，⚠️ 同上，需確認是否也承擔了 Launcher 選單的職責 |
| `HelpView.swift` 🆕 | 原企劃未列出 | ✅ 存在，用途待補充 |
| `PrerequisiteChecker.swift` 🆕 | 原企劃未列出；命名推測為檢查 BlackHole 等事前準備是否就緒 | ✅ 存在，用途待補充 |
| `SetupScript.swift` 🆕 | 原企劃未列出；命名推測為引導使用者完成 BlackHole／Multi-Output Device 設定的流程 | ✅ 存在，用途待補充 |

輸出檔案（執行期產生，非隨專案原始碼提供）：
`~/Documents/transcript_YYYY-MM-DD_HHmmss.txt`

> 事前準備（沿用原企劃）：需安裝 BlackHole 虛擬音訊裝置，並於「Audio MIDI 設定」手動建立一次
> Multi-Output Device，才能讓喇叭聲音同時送到虛擬裝置與實體喇叭。`PrerequisiteChecker.swift` /
> `SetupScript.swift` 兩支新檔案很可能就是把這段手動流程程式化、加上偵測與引導，
> 屬於功能上的自然擴充，建議請實際作者補充一段說明納入本節，而非只在此標記為未知。

> ⚠️ **架構落差 3**：`RootApp.swift`、`RootView.swift` 兩個檔名的「Root」語意，
> 讓人聯想到「整個 App 的根入口」，而不只是 VoiceCapture 單一功能畫面。
> 若這兩支檔案實際上承擔的是「品牌 Launcher（選擇匯入轉錄 or 即時聽抄）」的角色，
> 表示 Launcher 目前是**依附在 VoiceCapture target 裡**，而不是原企劃設想的第三個獨立 App。
> 這會讓「三個各自獨立編譯」的整合原則名存實亡，建議盡快確認並更新第六節的整合原則備忘。

---

## 六、整合原則備忘（現況校正）

1. **品牌整合、程式碼是否整合待確認**：原企劃要求三個專案各自擁有獨立的 `.xcodeproj`、
   Model、Service、Assets；實際只觀察到單一 `Dictation Helper.xcodeproj`，
   `VoxNoteSuite/` 與 `Dictation Helper/` 是否仍維持「零共用」原則，需要以 Xcode 內的
   Target 設定（而非只看資料夾）逐一確認 Compile Sources 是否互相引用。
2. **唯一的連接點應是 Launcher**：原設計是 Launcher 僅以「開啟外部 App Bundle」串接，
   不 import 對方模組。目前 `LauncherApp.swift` 遺失、Launcher 相關檔案疑似併入
   VoiceCapture target，這個邊界目前**無法從檔案結構確認是否還成立**，需要對照
   `Dictation Helper.xcodeproj` 的 target 設定實際檢查。
3. **各自獨立發佈**：若最終確認是單一 Xcode 專案、多個 Target 的架構，仍可維持「各自
   簽署、公證、更新版本號」的目標，但需要在 `project.pbxproj` 裡各自設定獨立的
   Bundle Identifier 與版本號，而非放在同一個 Target 下用 flag 切換。
4. **未來若要共用邏輯**：維持原企劃原則，需另外抽成獨立的 Swift Package 並經雙方明確
   評估後才導入。
5. **命名規範**：維持原企劃原則（例如 `AudioLibraryView.swift` 而非通用的
   `ContentView.swift`），但目前 `Dictation Helper/ContentView.swift` 仍用通用命名，
   VoiceCapture 這側尚未套用此規範，可視情況統一。

---

## 七、待辦清單（本次校對新增）

- [ ] 🔴 確認 `VoxNoteSuite/App/VoxNoteImportApp.swift` 是否真的遺失，需要從版本控制還原或重寫
- [ ] 🔴 確認 `LauncherApp.swift` 的去向：是遺失、還是已被 `RootApp.swift` 取代
- [ ] 確認 `RootApp.swift`／`RootView.swift`／`HelpView.swift`／`PrerequisiteChecker.swift`／
      `SetupScript.swift` 五支新檔案各自的實際職責，並補進本文件對應章節
- [ ] 確認目前是單一 Xcode 專案（多 Target）還是仍有多個 `.xcodeproj`，更新第二節結構圖
- [ ] 確認 `Info.plist`、`Assets.xcassets`、`Localizable.strings` 等資源檔案在單一專案下
      是否為每個 Target 各自一份，避免誤用共用資源

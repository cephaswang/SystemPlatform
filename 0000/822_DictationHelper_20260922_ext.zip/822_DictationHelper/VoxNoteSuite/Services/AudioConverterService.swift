import Foundation
import AVFoundation

enum AudioConversionError: LocalizedError {
    case exportSessionUnavailable
    case conversionFailed(String)
    case ffmpegNotFound
    case ffmpegExecutionFailed(String)

    var errorDescription: String? {
        switch self {
        case .exportSessionUnavailable:
            return "無法建立音訊轉檔工作階段"
        case .conversionFailed(let reason):
            return "音檔轉換失敗：\(reason)"
        case .ffmpegNotFound:
            return "找不到內建的 ffmpeg 轉檔工具，無法處理此格式"
        case .ffmpegExecutionFailed(let reason):
            return "轉檔工具執行失敗：\(reason)"
        }
    }
}

/// 音檔轉換服務，涵蓋兩種情境：
/// 1. 匯入階段：把 AVFoundation 無法原生解析的容器格式（例如 .webm）
///    先轉成可讀取的格式，這樣後續時長讀取、逐字稿處理才能正常運作
/// 2. 辨識前處理：把已可讀取的音檔統一轉成辨識引擎偏好的格式（.caf）
struct AudioConverterService {

    /// AVFoundation 在 macOS 上可原生讀取時長／音軌的容器格式
    private let nativelyReadableExtensions: Set<String> = ["mp3", "m4a", "wav"]

    /// 匯入階段需要先轉檔才能繼續處理的格式
    private let extensionsRequiringPreConversion: Set<String> = ["webm"]

    func requiresPreConversion(_ url: URL) -> Bool {
        extensionsRequiringPreConversion.contains(url.pathExtension.lowercased())
    }

    // MARK: - 匯入階段：webm 等格式的預先轉檔

    /// 若檔案是 AVFoundation 無法原生讀取的格式，先轉成 .m4a 並回傳暫存檔 URL；
    /// 若本來就是可原生讀取的格式，直接回傳原始 URL（不做任何轉換）。
    func convertToPlayableFormatIfNeeded(sourceURL: URL) async throws -> URL {
        let ext = sourceURL.pathExtension.lowercased()

        guard extensionsRequiringPreConversion.contains(ext) else {
            return sourceURL
        }

        let ffmpegURL = try locateFFmpegBinary()

        let outputURL = FileManager.default.temporaryDirectory
            .appendingPathComponent(UUID().uuidString)
            .appendingPathExtension("m4a")

        try await runFFmpeg(
            executableURL: ffmpegURL,
            arguments: [
                "-i", sourceURL.path,
                "-vn",                 // 只取音軌，捨棄畫面
                "-acodec", "aac",
                "-y",                  // 覆寫輸出檔（暫存檔理論上不存在，保險用）
                outputURL.path
            ]
        )

        return outputURL
    }

    /// 尋找可用的 ffmpeg 執行檔。
    /// 正式發行版本應將 ffmpeg 以簽署過的執行檔一併打包進 App Bundle（例如
    /// `Contents/Resources/ffmpeg`）；沙盒環境下 App 可以啟動自己 Bundle 內的
    /// 執行檔，不需要額外的沙盒例外設定。開發階段則退而求其次，嘗試常見的
    /// Homebrew 安裝路徑，方便本機測試。
    private func locateFFmpegBinary() throws -> URL {
        if let bundled = Bundle.main.url(forResource: "ffmpeg", withExtension: nil) {
            return bundled
        }

        let developmentFallbackPaths = [
            "/opt/homebrew/bin/ffmpeg",
            "/usr/local/bin/ffmpeg"
        ]

        for path in developmentFallbackPaths where FileManager.default.isExecutableFile(atPath: path) {
            return URL(fileURLWithPath: path)
        }

        throw AudioConversionError.ffmpegNotFound
    }

    private func runFFmpeg(executableURL: URL, arguments: [String]) async throws {
        try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
            let process = Process()
            process.executableURL = executableURL
            process.arguments = arguments

            let errorPipe = Pipe()
            process.standardError = errorPipe
            process.standardOutput = Pipe() // 丟棄一般輸出，避免緩衝區塞滿

            process.terminationHandler = { finishedProcess in
                if finishedProcess.terminationStatus == 0 {
                    continuation.resume(returning: ())
                } else {
                    let errorData = errorPipe.fileHandleForReading.readDataToEndOfFile()
                    let message = String(data: errorData, encoding: .utf8) ?? "未知錯誤（結束碼 \(finishedProcess.terminationStatus)）"
                    continuation.resume(throwing: AudioConversionError.ffmpegExecutionFailed(message))
                }
            }

            do {
                try process.run()
            } catch {
                continuation.resume(throwing: AudioConversionError.ffmpegExecutionFailed(error.localizedDescription))
            }
        }
    }

    // MARK: - 辨識前處理：統一轉為辨識引擎偏好格式

    /// 將來源音檔轉換為 .caf（Core Audio Format），輸出至暫存目錄，回傳暫存檔 URL
    func convertToRecognitionFormat(sourceURL: URL) async throws -> URL {
        let asset = AVURLAsset(url: sourceURL)

        guard let exportSession = AVAssetExportSession(
            asset: asset,
            presetName: AVAssetExportPresetAppleM4A
        ) else {
            throw AudioConversionError.exportSessionUnavailable
        }

        let outputURL = FileManager.default.temporaryDirectory
            .appendingPathComponent(UUID().uuidString)
            .appendingPathExtension("caf")

        exportSession.outputURL = outputURL
        exportSession.outputFileType = .caf

        await exportSession.export()

        switch exportSession.status {
        case .completed:
            return outputURL
        case .failed, .cancelled:
            throw AudioConversionError.conversionFailed(
                exportSession.error?.localizedDescription ?? "未知錯誤"
            )
        default:
            throw AudioConversionError.conversionFailed("匯出工作階段狀態異常")
        }
    }

    /// 轉檔完成後清除暫存檔案
    func cleanupTemporaryFile(at url: URL) {
        try? FileManager.default.removeItem(at: url)
    }
}

import Foundation
import CoreAudio
import AppKit
import Combine

/// VoxNote 聽抄環境所需的四個設置項目
enum SetupStep: String, CaseIterable, Identifiable {
    case blackHole        = "BlackHole 2ch 虛擬音訊裝置"
    case aggregateDevice  = "Multi-Output Device"
    case defaultOutput    = "系統輸出裝置切換"
    case ffmpeg           = "ffmpeg（webm 轉檔用）"

    var id: String { rawValue }

    var detail: String {
        switch self {
        case .blackHole:
            return "讓系統聲音可以同時被錄音程式擷取"
        case .aggregateDevice:
            return "把喇叭與 BlackHole 合併成一個輸出裝置"
        case .defaultOutput:
            return "把系統輸出切到剛建立的 Multi-Output Device"
        case .ffmpeg:
            return "用於將 webm 音檔轉成可辨識的 m4a"
        }
    }
}

enum SetupStatus: Equatable {
    case notInstalled
    case installed
    case checking
    case error(String)

    var isReady: Bool { self == .installed }
}

@MainActor
final class AudioSetupManager: ObservableObject {

    static let shared = AudioSetupManager()

    @Published var statuses: [SetupStep: SetupStatus] = [
        .blackHole: .notInstalled,
        .aggregateDevice: .notInstalled,
        .defaultOutput: .notInstalled,
        .ffmpeg: .notInstalled
    ]

    @Published var isBusy = false
    @Published var log: [String] = []

    // MARK: - 常數

    private let aggregateDeviceUID  = "com.voxnote.multioutput"
    private let aggregateDeviceName = "VoxNote Multi-Output"
    private let blackHoleInstallPath = "/Library/Audio/Plug-Ins/HAL/BlackHole2ch.driver"
    /// 內嵌在 App Bundle 裡的安裝檔，需自行放到 Resources/BlackHole2ch.pkg
    private let bundledPkgResourceName = "BlackHole2ch"
    private let bundledPkgExtension = "pkg"

    private var previousDefaultOutputUID: String?

    private init() {}

    // MARK: - 對外：整體檢查

    func checkAll() {
        statuses[.blackHole] = checkBlackHoleInstalled() ? .installed : .notInstalled
        statuses[.aggregateDevice] = checkAggregateDeviceExists() ? .installed : .notInstalled
        statuses[.defaultOutput] = checkDefaultOutputIsAggregate() ? .installed : .notInstalled
        statuses[.ffmpeg] = checkFFmpegAvailable() ? .installed : .notInstalled
    }

    var allReady: Bool {
        statuses.values.allSatisfy { $0.isReady }
    }

    // MARK: - 對外：一鍵設置

    func runOneClickSetup() async {
        guard !isBusy else { return }
        isBusy = true
        log.removeAll()
        defer { isBusy = false }

        // 1. BlackHole
        if checkBlackHoleInstalled() {
            appendLog("✅ BlackHole 已安裝，略過")
        } else {
            appendLog("⏳ 安裝 BlackHole（需要輸入密碼）…")
            do {
                try await installBlackHole()
                appendLog("✅ BlackHole 安裝完成")
            } catch {
                appendLog("❌ BlackHole 安裝失敗：\(error.localizedDescription)")
                statuses[.blackHole] = .error(error.localizedDescription)
                checkAll()
                return
            }
        }
        statuses[.blackHole] = .installed

        // 2. 重新整理 CoreAudio 裝置清單（新驅動需要一點時間被系統載入）
        appendLog("⏳ 等待系統載入新的音訊裝置…")
        let blackHoleID = await waitForDevice(nameContains: "BlackHole", timeout: 8)
        guard let blackHoleID else {
            appendLog("❌ 找不到 BlackHole 裝置，可能需要登出重新登入後再試一次")
            checkAll()
            return
        }

        // 3. 建立 / 尋找內建喇叭
        guard let builtInID = findBuiltInOutputDeviceID() else {
            appendLog("❌ 找不到內建輸出裝置")
            checkAll()
            return
        }

        // 4. 建立 Multi-Output Device
        if let existingAgg = findAggregateDeviceID() {
            appendLog("✅ Multi-Output Device 已存在，略過建立")
            statuses[.aggregateDevice] = .installed
            _ = existingAgg
        } else {
            appendLog("⏳ 建立 Multi-Output Device…")
            do {
                _ = try createAggregateDevice(builtInDeviceID: builtInID, blackHoleDeviceID: blackHoleID)
                appendLog("✅ Multi-Output Device 建立完成")
                statuses[.aggregateDevice] = .installed
            } catch {
                appendLog("❌ 建立失敗：\(error.localizedDescription)")
                statuses[.aggregateDevice] = .error(error.localizedDescription)
                checkAll()
                return
            }
        }

        // 5. 切換系統輸出
        appendLog("⏳ 切換系統輸出至 Multi-Output Device…")
        if let aggID = findAggregateDeviceID() {
            previousDefaultOutputUID = getDeviceUID(getDefaultOutputDeviceID())
            setDefaultOutputDevice(aggID)
            appendLog("✅ 已切換系統輸出")
            statuses[.defaultOutput] = .installed
        }

        // 6. 檢查 ffmpeg
        if checkFFmpegAvailable() {
            appendLog("✅ ffmpeg 可用")
            statuses[.ffmpeg] = .installed
        } else {
            appendLog("⚠️ 找不到 ffmpeg（App 內未內嵌，也未安裝於系統路徑），webm 轉檔功能將無法使用")
            statuses[.ffmpeg] = .notInstalled
        }

        appendLog("🎉 設置流程結束")
        checkAll()
    }

    // MARK: - 對外：一鍵移除

    func runOneClickRemoval() async {
        guard !isBusy else { return }
        isBusy = true
        log.removeAll()
        defer { isBusy = false }

        // 1. 還原系統輸出裝置
        if let aggID = findAggregateDeviceID() {
            appendLog("⏳ 還原系統輸出裝置…")
            if let prevUID = previousDefaultOutputUID,
               let prevID = findDeviceID(byUID: prevUID) {
                setDefaultOutputDevice(prevID)
            } else if let builtIn = findBuiltInOutputDeviceID() {
                setDefaultOutputDevice(builtIn)
            }
            appendLog("✅ 已還原系統輸出")

            // 2. 移除 Multi-Output Device
            appendLog("⏳ 移除 Multi-Output Device…")
            let status = AudioHardwareDestroyAggregateDevice(aggID)
            if status == noErr {
                appendLog("✅ Multi-Output Device 已移除")
            } else {
                appendLog("⚠️ 移除 Multi-Output Device 失敗（狀態碼 \(status)）")
            }
        } else {
            appendLog("ℹ️ 沒有找到 Multi-Output Device，略過")
        }

        // 3. 移除 BlackHole
        if checkBlackHoleInstalled() {
            appendLog("⏳ 移除 BlackHole（需要輸入密碼）…")
            do {
                try await uninstallBlackHole()
                appendLog("✅ BlackHole 已移除")
            } catch {
                appendLog("❌ 移除 BlackHole 失敗：\(error.localizedDescription)")
            }
        } else {
            appendLog("ℹ️ 沒有偵測到 BlackHole，略過")
        }

        appendLog("🧹 移除流程結束")
        checkAll()
    }

    private func appendLog(_ s: String) {
        log.append(s)
    }

    // MARK: - BlackHole 安裝 / 解除安裝

    private func installBlackHole() async throws {
        guard let pkgPath = Bundle.main.path(forResource: bundledPkgResourceName, ofType: bundledPkgExtension) else {
            throw SetupError.message("App 內找不到內嵌的 BlackHole2ch.pkg，請確認已加入 Resources")
        }
        let script = """
        do shell script "installer -pkg " & quoted form of "\(pkgPath)" & " -target /" with administrator privileges
        """
        try runAppleScript(script)
        // 重啟 coreaudiod 讓新驅動被載入
        try? runShell("/usr/bin/killall", args: ["coreaudiod"])
    }

    private func uninstallBlackHole() async throws {
        let script = """
        do shell script "rm -rf " & quoted form of "\(blackHoleInstallPath)" with administrator privileges
        """
        try runAppleScript(script)
        try? runShell("/usr/bin/killall", args: ["coreaudiod"])
    }

    // MARK: - 狀態檢查

    func checkBlackHoleInstalled() -> Bool {
        FileManager.default.fileExists(atPath: blackHoleInstallPath)
    }

    func checkAggregateDeviceExists() -> Bool {
        findAggregateDeviceID() != nil
    }

    func checkDefaultOutputIsAggregate() -> Bool {
        guard let aggID = findAggregateDeviceID() else { return false }
        return getDefaultOutputDeviceID() == aggID
    }

    func checkFFmpegAvailable() -> Bool {
        if let bundled = Bundle.main.path(forResource: "ffmpeg", ofType: nil),
           FileManager.default.isExecutableFile(atPath: bundled) {
            return true
        }
        let candidates = ["/opt/homebrew/bin/ffmpeg", "/usr/local/bin/ffmpeg"]
        return candidates.contains { FileManager.default.fileExists(atPath: $0) }
    }

    private func waitForDevice(nameContains substring: String, timeout: TimeInterval) async -> AudioDeviceID? {
        let deadline = Date().addingTimeInterval(timeout)
        while Date() < deadline {
            if let id = findDeviceID(nameContains: substring) { return id }
            try? await Task.sleep(nanoseconds: 500_000_000)
        }
        return findDeviceID(nameContains: substring)
    }

    // MARK: - CoreAudio 輔助函式

    private func allDeviceIDs() -> [AudioDeviceID] {
        var address = AudioObjectPropertyAddress(
            mSelector: kAudioHardwarePropertyDevices,
            mScope: kAudioObjectPropertyScopeGlobal,
            mElement: kAudioObjectPropertyElementMain)
        var dataSize: UInt32 = 0
        guard AudioObjectGetPropertyDataSize(AudioObjectID(kAudioObjectSystemObject), &address, 0, nil, &dataSize) == noErr else {
            return []
        }
        let count = Int(dataSize) / MemoryLayout<AudioDeviceID>.size
        var ids = [AudioDeviceID](repeating: 0, count: count)
        guard AudioObjectGetPropertyData(AudioObjectID(kAudioObjectSystemObject), &address, 0, nil, &dataSize, &ids) == noErr else {
            return []
        }
        return ids
    }

    private func getDeviceName(_ id: AudioDeviceID) -> String? {
        var address = AudioObjectPropertyAddress(
            mSelector: kAudioObjectPropertyName,
            mScope: kAudioObjectPropertyScopeGlobal,
            mElement: kAudioObjectPropertyElementMain)
        var name: CFString = "" as CFString
        var size = UInt32(MemoryLayout<CFString>.size)
        let status = withUnsafeMutablePointer(to: &name) { ptr -> OSStatus in
            AudioObjectGetPropertyData(id, &address, 0, nil, &size, ptr)
        }
        return status == noErr ? (name as String) : nil
    }

    private func getDeviceUID(_ id: AudioDeviceID) -> String? {
        var address = AudioObjectPropertyAddress(
            mSelector: kAudioDevicePropertyDeviceUID,
            mScope: kAudioObjectPropertyScopeGlobal,
            mElement: kAudioObjectPropertyElementMain)
        var uid: CFString = "" as CFString
        var size = UInt32(MemoryLayout<CFString>.size)
        let status = withUnsafeMutablePointer(to: &uid) { ptr -> OSStatus in
            AudioObjectGetPropertyData(id, &address, 0, nil, &size, ptr)
        }
        return status == noErr ? (uid as String) : nil
    }

    private func deviceHasOutputChannels(_ id: AudioDeviceID) -> Bool {
        var address = AudioObjectPropertyAddress(
            mSelector: kAudioDevicePropertyStreamConfiguration,
            mScope: kAudioDevicePropertyScopeOutput,
            mElement: kAudioObjectPropertyElementMain)
        var dataSize: UInt32 = 0
        guard AudioObjectGetPropertyDataSize(id, &address, 0, nil, &dataSize) == noErr, dataSize > 0 else {
            return false
        }
        let bufferList = UnsafeMutablePointer<AudioBufferList>.allocate(capacity: Int(dataSize))
        defer { bufferList.deallocate() }
        guard AudioObjectGetPropertyData(id, &address, 0, nil, &dataSize, bufferList) == noErr else {
            return false
        }
        let buffers = UnsafeMutableAudioBufferListPointer(bufferList)
        return buffers.contains { $0.mNumberChannels > 0 }
    }

    private func transportType(_ id: AudioDeviceID) -> UInt32? {
        var address = AudioObjectPropertyAddress(
            mSelector: kAudioDevicePropertyTransportType,
            mScope: kAudioObjectPropertyScopeGlobal,
            mElement: kAudioObjectPropertyElementMain)
        var transport: UInt32 = 0
        var size = UInt32(MemoryLayout<UInt32>.size)
        let status = AudioObjectGetPropertyData(id, &address, 0, nil, &size, &transport)
        return status == noErr ? transport : nil
    }

    private func findDeviceID(nameContains substring: String) -> AudioDeviceID? {
        allDeviceIDs().first { id in
            guard let name = getDeviceName(id) else { return false }
            return name.localizedCaseInsensitiveContains(substring)
        }
    }

    private func findDeviceID(byUID uid: String) -> AudioDeviceID? {
        allDeviceIDs().first { getDeviceUID($0) == uid }
    }

    private func findAggregateDeviceID() -> AudioDeviceID? {
        findDeviceID(byUID: aggregateDeviceUID)
    }

    private func findBuiltInOutputDeviceID() -> AudioDeviceID? {
        allDeviceIDs().first { id in
            transportType(id) == kAudioDeviceTransportTypeBuiltIn && deviceHasOutputChannels(id)
        }
    }

    private func getDefaultOutputDeviceID() -> AudioDeviceID {
        var address = AudioObjectPropertyAddress(
            mSelector: kAudioHardwarePropertyDefaultOutputDevice,
            mScope: kAudioObjectPropertyScopeGlobal,
            mElement: kAudioObjectPropertyElementMain)
        var deviceID = AudioDeviceID(0)
        var size = UInt32(MemoryLayout<AudioDeviceID>.size)
        _ = AudioObjectGetPropertyData(AudioObjectID(kAudioObjectSystemObject), &address, 0, nil, &size, &deviceID)
        return deviceID
    }

    @discardableResult
    private func setDefaultOutputDevice(_ id: AudioDeviceID) -> Bool {
        var address = AudioObjectPropertyAddress(
            mSelector: kAudioHardwarePropertyDefaultOutputDevice,
            mScope: kAudioObjectPropertyScopeGlobal,
            mElement: kAudioObjectPropertyElementMain)
        var deviceID = id
        let status = AudioObjectSetPropertyData(AudioObjectID(kAudioObjectSystemObject), &address, 0, nil, UInt32(MemoryLayout<AudioDeviceID>.size), &deviceID)
        return status == noErr
    }

    private func createAggregateDevice(builtInDeviceID: AudioDeviceID, blackHoleDeviceID: AudioDeviceID) throws -> AudioDeviceID {
        guard let builtInUID = getDeviceUID(builtInDeviceID),
              let blackHoleUID = getDeviceUID(blackHoleDeviceID) else {
            throw SetupError.message("無法取得裝置 UID")
        }

        let subDeviceList: [[String: Any]] = [
            [kAudioSubDeviceUIDKey as String: builtInUID],
            [kAudioSubDeviceUIDKey as String: blackHoleUID]
        ]
        let description: [String: Any] = [
            kAudioAggregateDeviceNameKey as String: aggregateDeviceName,
            kAudioAggregateDeviceUIDKey as String: aggregateDeviceUID,
            kAudioAggregateDeviceSubDeviceListKey as String: subDeviceList,
            kAudioAggregateDeviceMasterSubDeviceKey as String: builtInUID,
            kAudioAggregateDeviceIsStackedKey as String: 1
        ]

        var deviceID = AudioDeviceID(0)
        let status = AudioHardwareCreateAggregateDevice(description as CFDictionary, &deviceID)
        guard status == noErr else {
            throw SetupError.message("AudioHardwareCreateAggregateDevice 失敗（狀態碼 \(status)）")
        }
        return deviceID
    }

    // MARK: - Shell / AppleScript 輔助

    private func runAppleScript(_ source: String) throws {
        var error: NSDictionary?
        guard let script = NSAppleScript(source: source) else {
            throw SetupError.message("無法建立 AppleScript")
        }
        script.executeAndReturnError(&error)
        if let error {
            let message = (error[NSAppleScript.errorMessage] as? String) ?? "未知錯誤"
            // -128 是使用者取消密碼輸入
            if let number = error[NSAppleScript.errorNumber] as? Int, number == -128 {
                throw SetupError.message("使用者取消了授權")
            }
            throw SetupError.message(message)
        }
    }

    private func runShell(_ path: String, args: [String]) throws {
        let process = Process()
        process.executableURL = URL(fileURLWithPath: path)
        process.arguments = args
        try process.run()
        process.waitUntilExit()
    }

    enum SetupError: LocalizedError {
        case message(String)
        var errorDescription: String? {
            switch self {
            case .message(let m): return m
            }
        }
    }
}

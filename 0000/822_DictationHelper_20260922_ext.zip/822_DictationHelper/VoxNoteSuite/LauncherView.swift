import SwiftUI

struct LauncherView: View {

    let onSelectImport: () -> Void
    let onSelectVoiceCapture: () -> Void

    var body: some View {
        VStack(spacing: 24) {

            Text("VoxNote 語音工作站")
                .font(.title)
                .bold()

            Text("請選擇要開啟的模式")
                .font(.subheadline)
                .foregroundColor(.secondary)

            HStack(spacing: 20) {

                LauncherButton(
                    title: "匯入音檔轉錄",
                    subtitle: "已有音檔，事後轉成文字稿",
                    systemImage: "waveform.badge.plus",
                    action: onSelectImport
                )

                LauncherButton(
                    title: "即時聽抄",
                    subtitle: "邊聽系統喇叭聲音，邊即時轉文字",
                    systemImage: "speaker.wave.2.circle",
                    action: onSelectVoiceCapture
                )
            }
        }
        .padding(32)
        .frame(width: 480)
    }
}

/// 單一入口按鈕（純 UI 元件）
private struct LauncherButton: View {
    let title: String
    let subtitle: String
    let systemImage: String
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            VStack(spacing: 10) {
                Image(systemName: systemImage)
                    .font(.system(size: 36))
                Text(title)
                    .font(.headline)
                Text(subtitle)
                    .font(.caption)
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
            }
            .padding()
            .frame(width: 190, height: 160)
            .background(Color(nsColor: .controlBackgroundColor))
            .cornerRadius(12)
        }
        .buttonStyle(.plain)
    }
}

#Preview {
    LauncherView(onSelectImport: {}, onSelectVoiceCapture: {})
}

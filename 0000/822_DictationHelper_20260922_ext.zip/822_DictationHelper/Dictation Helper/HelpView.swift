import SwiftUI
import AppKit

/// 共用的「開啟使用說明 PDF」邏輯。
/// 抽成獨立的 enum,是為了讓選單列（RootApp.swift）可以直接呼叫，
/// 不需要透過 NotificationCenter 或是把 HelpView 塞進畫面階層才能觸發。
///
/// 在 App Bundle 裡尋找並開啟使用說明 PDF，
/// 交給系統預設的 PDF 檢視器（通常是「預覽程式」）開啟。
/// 找不到時會跳出系統警示視窗，提醒需要把 PDF 加入 Xcode 專案。
enum HelpPDFOpener {
    static func open() {
        if let url = Bundle.main.url(forResource: "聽抄小幫手_使用說明", withExtension: "pdf") {
            NSWorkspace.shared.open(url)
        } else {
            let alert = NSAlert()
            alert.messageText = "找不到使用說明 PDF"
            alert.informativeText = "請確認「聽抄小幫手_使用說明.pdf」已加入 Xcode 專案，並勾選 Target Membership。"
            alert.alertStyle = .warning
            alert.runModal()
        }
    }
}

/// 保留這個 View 是為了相容舊的呼叫方式
/// （例如 .sheet(isPresented:) { HelpView() } 或其他仍直接建立 HelpView() 的地方）。
/// 這個 View 本身不會顯示任何畫面：一出現就開啟 PDF，然後立刻關閉自己。
///
/// 注意：選單列「Dictation Helper > Help」現在已經改成直接呼叫
/// HelpPDFOpener.open()（見 RootApp.swift），不會再經過這個 View。
struct HelpView: View {
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        let _ = print("🖼️ [\(Self.self)] body (\(#fileID))")
        Color.clear
            .onAppear {
                HelpPDFOpener.open()
                dismiss()
            }
    }
}

#Preview {
    HelpView()
}

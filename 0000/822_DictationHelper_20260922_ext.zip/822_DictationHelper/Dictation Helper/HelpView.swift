import SwiftUI

/// 原本這裡是顯示一個內建的使用說明面板，
/// 現在改為直接開啟隨 App 附帶的「聽抄小幫手_使用說明.pdf」，
/// 交給系統預設的 PDF 檢視器（通常是「預覽程式」）開啟。
///
/// 呼叫方式維持不變（例如 .sheet(isPresented:) { HelpView() } 或
/// 選單列「Dictation Helper > Help」的指令仍可照舊呼叫 HelpView()），
/// 這個 View 本身不會顯示任何畫面：一出現就開啟 PDF，然後立刻關閉自己。
struct HelpView: View {
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        let _ = print("🖼️ [\(Self.self)] body (\(#fileID))")
        Color.clear
            .onAppear {
                openHelpPDF()
                dismiss()
            }
    }

    /// 在 App Bundle 裡尋找並開啟使用說明 PDF。
    /// 找不到時會跳出系統警示視窗，提醒需要把 PDF 加入 Xcode 專案。
    private func openHelpPDF() {
        if let url = Bundle.main.url(forResource: "聽抄小幫手_使用說明", withExtension: "pdf") {
            NSWorkspace.shared.open(url)
        } else {
            let alert = NSAlert()
            alert.messageText = "找不到使用說明 PDF"
            alert.informativeText = "請確認「聽抄小幫手_使用說明.pdf」已加入 Xcode 專案，並勾選 Target Membership。"
            alert.alertStyle = .warning
            alert.runModal()
        }
    }
}

#Preview {
    HelpView()
}

import SwiftUI
import AppKit
import Speech

struct ContentView: View {
    @StateObject private var transcriber = SpeechTranscriber()
    @StateObject private var deviceManager = AudioDeviceManager()

    @AppStorage("selectedLocale") private var selectedLocale: String = Locale.current.identifier
    @State private var availableLocales: [String] = []

    // 雙語模式（記住使用者上次的選擇）
    @AppStorage("bilingualMode") private var bilingualMode: Bool = false
    @AppStorage("localeA") private var localeA: String = "zh-TW"
    @AppStorage("localeB") private var localeB: String = "en-US"

    // 前置軟體檢查（BlackHole）相關狀態
    @State private var showSetupAlert = false
    @State private var setupScriptURL: URL?

    // 停止聽抄確認對話框
    @State private var showStopConfirmation = false

    // 尚無逐字稿內容時的提示
    @State private var showNoTranscriptAlert = false

    // Help 選單「使用說明」視窗
    @State private var showHelpSheet = false

    var body: some View {
        let _ = print("🖼️ [\(Self.self)] body (\(#fileID))")
        
        VStack(alignment: .leading, spacing: 16) {

            Text("聽抄小幫手")
                .font(.title2)
                .bold()

            // 雙語模式開關
            /*
            Toggle(isOn: $bilingualMode) {
                Text("雙語模式（同時辨識兩種語言，自動選信心較高者）")
            }
            .disabled(transcriber.isRunning)
            */

            if bilingualMode {
                // 雙語模式：兩個語言各自選單
                HStack {
                    Text("語言 A：")
                    Picker("", selection: $localeA) {
                        ForEach(availableLocales, id: \.self) { code in
                            Text("\(displayName(for: code))（\(code)）").tag(code)
                        }
                    }
                    .frame(width: 280)
                    .disabled(transcriber.isRunning)
                }
                HStack {
                    Text("語言 B：")
                    Picker("", selection: $localeB) {
                        ForEach(availableLocales, id: \.self) { code in
                            Text("\(displayName(for: code))（\(code)）").tag(code)
                        }
                    }
                    .frame(width: 280)
                    .disabled(transcriber.isRunning)
                }
                Text("💡 雙語模式會同時跑兩個辨識引擎，CPU 用量較高；每句話說完後系統會自動比較兩邊的信心分數，選較高者存檔。無法辨識「同一句話裡中英夾雜」的情況，適合「整段話都用同一種語言、但不同段落切換語言」的場景。")
                    .font(.caption)
                    .foregroundColor(.secondary)
            } else {
                // 單語模式：動態列出「這台 Mac 目前」支援語音辨識的所有語系
                HStack {
                    Text("語系：")
                    Picker("", selection: $selectedLocale) {
                        ForEach(availableLocales, id: \.self) { code in
                            Text("\(displayName(for: code))（\(code)）").tag(code)
                        }
                    }
                    .frame(width: 300)
                    .disabled(transcriber.isRunning)

                    Text("（共 \(availableLocales.count) 種）")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }

            // 輸入裝置選單
            HStack {
                Text("輸入裝置：")
                Picker("", selection: Binding(
                    get: { deviceManager.currentInputDeviceID ?? 0 },
                    set: { newID in deviceManager.setDefaultInputDevice(newID) }
                )) {
                    ForEach(deviceManager.inputDevices) { device in
                        Text(device.name).tag(device.id)
                    }
                }
                .frame(width: 260)
                .disabled(transcriber.isRunning)

                Button("重新整理") {
                    deviceManager.refreshDevices()
                }
                .disabled(transcriber.isRunning)
            }

            Text("⚠️ 輸出裝置請至「系統設定 > 聲音」選擇 Multi-Output Device，才聽得到聲音又能被辨識\n輸入裝置請在下方選單選擇 BlackHole 2ch")
               // .font(.title3)
               // .bold()
                .foregroundColor(.black)
                .padding(10)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(Color.green)
                .cornerRadius(8)

            // 開始 / 停止
            HStack {
                Button(transcriber.isRunning ? "停止聽抄" : "開始聽抄") {
                    if transcriber.isRunning {
                        showStopConfirmation = true
                    } else {
                        let outputDir = FileManager.default
                            .urls(for: .documentDirectory, in: .userDomainMask)
                            .first!
                        if bilingualMode {
                            transcriber.startBilingual(localeA: localeA, localeB: localeB, outputDirectory: outputDir)
                        } else {
                            transcriber.start(localeIdentifier: selectedLocale, outputDirectory: outputDir)
                        }
                    }
                }
                .buttonStyle(.borderedProminent)
                .confirmationDialog(
                    "確定要停止聽抄嗎？",
                    isPresented: $showStopConfirmation,
                    titleVisibility: .visible
                ) {
                    Button("停止聽抄", role: .destructive) {
                        transcriber.stop()
                    }
                    Button("取消", role: .cancel) { }
                } message: {
                    Text("停止後，目前尚未定案的內容會強制寫入檔案，不會遺失。")
                }

                Button("在 Finder 中顯示逐字稿") {
                    if let url = transcriber.outputFileURL,
                       FileManager.default.fileExists(atPath: url.path) {
                        NSWorkspace.shared.activateFileViewerSelecting([url])
                    } else {
                        showNoTranscriptAlert = true
                    }
                }
            }

            if !transcriber.statusMessage.isEmpty {
                Text(transcriber.statusMessage)
                    .foregroundColor(.red)
            }

            Divider()

            if bilingualMode {
                // 雙語模式：兩個引擎各自的即時假設分開顯示
                Text("即時辨識（語言 A：\(displayName(for: localeA))）：")
                    .font(.headline)
                ScrollView {
                    Text(transcriber.liveTextA)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .textSelection(.enabled)
                }
                .padding(8)
                .frame(maxWidth: .infinity, minHeight: 36, maxHeight: 80, alignment: .leading)
                .background(Color.gray.opacity(0.1))
                .cornerRadius(6)

                Text("即時辨識（語言 B：\(displayName(for: localeB))）：")
                    .font(.headline)
                ScrollView {
                    Text(transcriber.liveTextB)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .textSelection(.enabled)
                }
                .padding(8)
                .frame(maxWidth: .infinity, minHeight: 36, maxHeight: 80, alignment: .leading)
                .background(Color.gray.opacity(0.1))
                .cornerRadius(6)
            } else {
                Text("即時辨識：")
                    .font(.headline)
                ScrollView {
                    Text(transcriber.liveText)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .textSelection(.enabled)
                }
                .padding(8)
                .frame(maxWidth: .infinity, minHeight: 40, maxHeight: 120, alignment: .leading)
                .background(Color.gray.opacity(0.1))
                .cornerRadius(6)
            }

            HStack {
                Text("已存檔內容：")
                    .font(.headline)
                if let url = transcriber.outputFileURL {
                    Text("(\(url.lastPathComponent))")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
            ScrollView {
                VStack(alignment: .leading, spacing: 4) {
                    ForEach(Array(transcriber.savedSentences.enumerated()), id: \.offset) { _, sentence in
                        Text(sentence)
                    }
                }
                .frame(maxWidth: .infinity, alignment: .leading)
            }
            .frame(minHeight: 200)
            .background(Color.gray.opacity(0.05))
            .cornerRadius(6)


        }
        .padding(20)
        .frame(minWidth: 560, minHeight: 640)
        .onAppear {
            loadAvailableLocales()
            checkPrerequisites()
        }
        .onReceive(NotificationCenter.default.publisher(for: .showHelpWindow)) { _ in
            showHelpSheet = true
        }
        .sheet(isPresented: $showHelpSheet) {
            HelpView()
        }
        .alert("尚未有逐字稿內容", isPresented: $showNoTranscriptAlert) {
            Button("好，我知道了", role: .cancel) { }
        } message: {
            Text("請先按下「開始聽抄」並播放/說話，系統辨識出第一句話後，才會建立逐字稿檔案。")
        }
        .sheet(isPresented: $showSetupAlert) {
            SetupInstructionsView(
                locationDescription: setupScriptLocationDescription,
                command: setupScriptCommand,
                onCopy: copyInstallCommandToClipboard,
                onDismiss: { showSetupAlert = false }
            )
        }
    }

    // MARK: - 前置軟體檢查

    private func checkPrerequisites() {
        guard !PrerequisiteChecker.isBlackHoleInstalled() else { return }

        if let url = PrerequisiteChecker.copySetupScriptToDesktop() {
            setupScriptURL = url
            showSetupAlert = true
        }
    }

    private func copyInstallCommandToClipboard() {
        let pasteboard = NSPasteboard.general
        pasteboard.clearContents()
        pasteboard.setString(setupScriptCommand, forType: .string)
    }

    // 依實際寫入的資料夾路徑，動態組出人看得懂的位置說明
    private var setupScriptLocationDescription: String {
        guard let url = setupScriptURL else { return SetupScript.fileName }
        let folderName = url.deletingLastPathComponent().lastPathComponent
        return "「\(folderName)」資料夾：\(SetupScript.fileName)"
    }

    // 依實際寫入的資料夾路徑，動態組出對應的終端機指令
    private var setupScriptCommand: String {
        guard let url = setupScriptURL else {
            return "cd ~/Desktop && ./\(SetupScript.fileName)"
        }
        let folderPath = url.deletingLastPathComponent().path
        return "cd \"\(folderPath)\" && bash ./\(SetupScript.fileName)"
    }

    // MARK: - 動態載入這台 Mac 目前支援語音辨識的所有語系

    private func loadAvailableLocales() {
        let supported = SFSpeechRecognizer.supportedLocales()
            .map { $0.identifier }
            .sorted { lhs, rhs in
                displayName(for: lhs).localizedStandardCompare(displayName(for: rhs)) == .orderedAscending
            }

        availableLocales = supported

        // 正規化比對（zh-TW / zh_TW 視為相同，大小寫也忽略），避免因格式差異比對失敗
        func normalize(_ s: String) -> String {
            s.replacingOccurrences(of: "_", with: "-").lowercased()
        }

        func firstMatch(_ target: String) -> String? {
            supported.first { normalize($0) == normalize(target) }
        }

        // 單語模式：如果上次存的選擇這台系統目前仍支援，就沿用；否則才套用預設邏輯
        let preferredCandidates = ["zh-TW", "zh-Hant-TW", "zh-Hant_TW", "zh_TW"]

        if let keep = firstMatch(selectedLocale) {
            selectedLocale = keep // 統一成系統實際回傳的字串格式，避免底線/大小寫差異
        } else if let match = preferredCandidates.compactMap({ firstMatch($0) }).first {
            selectedLocale = match
        } else if let match = firstMatch(Locale.current.identifier) {
            selectedLocale = match
        } else if let first = supported.first {
            selectedLocale = first
        }

        // 雙語模式：同樣優先沿用上次存下來的選擇
        if let keepA = firstMatch(localeA) {
            localeA = keepA
        } else if let matchA = firstMatch("zh-TW") ?? preferredCandidates.compactMap({ firstMatch($0) }).first {
            localeA = matchA
        } else if let first = supported.first {
            localeA = first
        }

        if let keepB = firstMatch(localeB) {
            localeB = keepB
        } else if let matchB = firstMatch("en-US") {
            localeB = matchB
        } else if let second = supported.first(where: { $0 != localeA }) {
            localeB = second
        }
    }

    // 把語系代碼（如 "zh-TW"）轉成人類看得懂的名稱（如 "中文（台灣）"）
    private func displayName(for code: String) -> String {
        Locale.current.localizedString(forIdentifier: code) ?? code
    }
}

// 需要先安裝 BlackHole 時顯示的自訂視窗（取代原本的 .alert，
// 因為系統原生 alert 的內文無法自訂顏色／底色）
struct SetupInstructionsView: View {
    let locationDescription: String
    let command: String
    let onCopy: () -> Void
    let onDismiss: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("需要先安裝 BlackHole")
                .font(.title2)
                .bold()

            Text("偵測不到 BlackHole 虛擬音訊裝置，這是把喇叭聲音送進辨識引擎必要的元件。")

            VStack(alignment: .leading, spacing: 6) {
                Text("已經把安裝腳本複製到：")
                Text(locationDescription)
                    .font(.system(.body, design: .monospaced))
            }

            VStack(alignment: .leading, spacing: 6) {
                Text("請打開「終端機」App，執行以下指令完成安裝：")
                Text(command)
                    .font(.system(.body, design: .monospaced))
                    .textSelection(.enabled)
                    .padding(8)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.gray.opacity(0.1))
                    .cornerRadius(6)
            }

            Text("⚠️ 安裝完成後，請務必「重新開機」，BlackHole 才會正式生效！")
                .bold()
                .foregroundColor(.black)
                .padding(10)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(Color.green)
                .cornerRadius(8)

            HStack {
                Spacer()
                Button("複製指令", action: onCopy)
                Button("知道了", role: .cancel, action: onDismiss)
                    .buttonStyle(.borderedProminent)
            }
        }
        .padding(24)
        .frame(width: 480)
    }
}

#Preview {
    ContentView()
}

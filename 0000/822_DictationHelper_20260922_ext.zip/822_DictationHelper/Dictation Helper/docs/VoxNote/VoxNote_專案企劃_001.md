# VoxNote 語音手記 — macOS 語音轉文字 App 企劃

## 專案名稱候選

| 名稱 | 說明 |
|---|---|
| VoxNote 語音手記 | Vox（聲音）+ Note（筆記），簡潔好記，App Store 上架也順口 |
| 聽譯坊 TranScribe | 強調「聽了幫你譯成文字」的核心功能 |
| 音轉文 EchoText | 直白說明功能，適合訴求「快速、準確」的定位 |

以下以 **VoxNote** 為採用名稱，規劃 macOS App 的檔案結構與各檔案功能。

---

## 一、專案文件（企劃階段）

| 檔案 | 功能 |
|---|---|
| `01_企劃書.md` | 產品定位、目標使用者、競品分析（如 Otter.ai、飛書妙記）、商業模式 |
| `02_功能規格書.md` | 詳列 MVP 與後續版本功能：匯入音檔、轉文字、逐字稿編輯、匯出格式 |
| `03_使用者流程圖.md` | 從「匯入音檔」到「取得文字稿」的操作路徑 |
| `04_UI線框圖/` | 主畫面、錄音清單、轉錄結果頁的示意圖 |
| `05_技術選型評估.md` | 比較 Apple Speech Framework vs Whisper（本地/雲端）vs 第三方 API 的準確度、成本、隱私考量 |

---

## 二、App 專案檔案結構（Xcode / SwiftUI 專案）

| 檔案／資料夾 | 功能 |
|---|---|
| `VoxNote.xcodeproj` | Xcode 專案設定檔 |
| `App/VoxNoteApp.swift` | App 進入點，初始化主視窗與環境設定 |
| `Views/ContentView.swift` | 主畫面，顯示已匯入音檔清單與轉錄狀態 |
| `Views/ImportView.swift` | 拖放或選取音檔匯入介面 |
| `Views/TranscriptEditorView.swift` | 顯示與編輯轉錄後文字稿（含時間戳對照） |
| `Views/ExportSheetView.swift` | 匯出格式選擇（txt / srt / docx / pdf） |
| `Views/SettingsView.swift` | 語言選擇、辨識引擎切換、快捷鍵設定 |
| `Models/AudioFile.swift` | 定義音檔物件（路徑、時長、格式、狀態） |
| `Models/TranscriptSegment.swift` | 定義單句轉錄結果（文字、起訖時間、信心度） |
| `Services/AudioImportService.swift` | 處理音檔讀取與格式相容性檢查（mp3/m4a/wav） |
| `Services/SpeechRecognitionService.swift` | 呼叫語音辨識引擎（Apple Speech 或 Whisper），回傳文字結果 |
| `Services/AudioConverterService.swift` | 音檔格式轉換（統一轉為辨識引擎支援格式） |
| `Services/ExportService.swift` | 將逐字稿輸出為指定檔案格式 |
| `Utilities/PermissionManager.swift` | 管理麥克風／檔案存取權限請求 |
| `Resources/Assets.xcassets` | App 圖示、介面圖片資源 |
| `Resources/Localizable.strings` | 多語系文字（繁中／英文） |
| `Info.plist` | App 權限宣告（麥克風、檔案存取說明） |
| `Tests/VoxNoteTests.swift` | 單元測試（轉檔正確性、辨識結果解析） |

import Foundation
import AVFoundation
import Speech
import Combine

final class SpeechTranscriber: ObservableObject {

    @Published var liveText: String = ""
    @Published var savedSentences: [String] = []
    @Published var isRunning: Bool = false
    @Published var statusMessage: String = ""
    @Published var outputFileURL: URL?

    private let audioEngine = AVAudioEngine()
    private var recognizer: SFSpeechRecognizer?
    private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?
    private var recognitionTask: SFSpeechRecognitionTask?
    private var outputFileHandle: FileHandle?
    private var latestText: String = ""
    private var pendingOutputDirectory: URL?

    // 用來過濾「上一次」工作結束時姍姍來遲的殘留回報（例如按停止後又立刻按開始）
    private var currentSessionID = UUID()

    // MARK: - 開始聽寫

    func start(localeIdentifier: String, outputDirectory: URL) {
        guard !isRunning else { return }
        statusMessage = ""

        // 清空畫面顯示，確保接下來顯示的內容只對應「這次」要建立的新檔案，
        // 避免跟上一個檔案的內容混在一起、對不起來
        liveText = ""
        savedSentences = []

        // 注意：這裡不建立檔案。改成等第一句話真正要寫入時（appendToFile 裡）
        // 才用「當下時間」建檔命名，讓檔名時間跟畫面上第一行文字的時間戳記完全一致
        pendingOutputDirectory = outputDirectory
        outputFileURL = nil
        outputFileHandle = nil

        guard let recognizer = SFSpeechRecognizer(locale: Locale(identifier: localeIdentifier)),
              recognizer.isAvailable else {
            statusMessage = "❌ 無法使用語系「\(localeIdentifier)」的語音辨識"
            return
        }
        self.recognizer = recognizer

        let sessionID = UUID()
        currentSessionID = sessionID

        requestPermissions { [weak self] granted in
            guard let self = self else { return }
            DispatchQueue.main.async {
                // 如果權限回呼回來時，使用者已經又切換到別的工作（sessionID 不同），就不要再啟動了
                guard self.currentSessionID == sessionID else { return }
                if granted {
                    self.beginRecognition(sessionID: sessionID)
                } else {
                    self.statusMessage = "❌ 麥克風或語音辨識權限被拒絕，請至「系統設定 > 隱私權與安全性」開啟"
                }
            }
        }
    }

    private func requestPermissions(completion: @escaping (Bool) -> Void) {
        SFSpeechRecognizer.requestAuthorization { status in
            guard status == .authorized else {
                completion(false)
                return
            }
            AVCaptureDevice.requestAccess(for: .audio) { granted in
                completion(granted)
            }
        }
    }

    private func beginRecognition(sessionID: UUID) {
        let request = SFSpeechAudioBufferRecognitionRequest()
        request.shouldReportPartialResults = true
        recognitionRequest = request

        let inputNode = audioEngine.inputNode
        let format = inputNode.outputFormat(forBus: 0)

        inputNode.installTap(onBus: 0, bufferSize: 1024, format: format) { [weak self] buffer, _ in
            self?.recognitionRequest?.append(buffer)
        }

        audioEngine.prepare()
        do {
            try audioEngine.start()
            isRunning = true
        } catch {
            statusMessage = "❌ 音訊引擎啟動失敗：\(error.localizedDescription)"
            return
        }

        recognitionTask = recognizer?.recognitionTask(with: request) { [weak self] result, error in
            guard let self = self else { return }
            // 過濾掉不屬於目前這次工作的殘留回報（例如上一輪按停止後的取消通知）
            guard self.currentSessionID == sessionID else { return }

            if let result = result {
                let text = result.bestTranscription.formattedString
                self.latestText = text
                DispatchQueue.main.async {
                    guard self.currentSessionID == sessionID else { return }
                    self.liveText = text
                }

                if result.isFinal {
                    self.appendToFile(text)
                    self.latestText = ""
                }
            }

            if let error = error {
                let nsError = error as NSError
                // 1110 = 沒有語音輸入的逾時；使用者主動停止造成的取消也不當作錯誤顯示
                let isBenign = nsError.code == 1110 || !self.isRunning
                if !isBenign {
                    DispatchQueue.main.async {
                        guard self.currentSessionID == sessionID else { return }
                        self.statusMessage = "⚠️ 辨識問題：\(error.localizedDescription)"
                    }
                }
            }
        }
    }

    // MARK: - 停止聽寫

    func stop() {
        guard isRunning else { return }

        // 讓任何稍後才送達的回呼都被視為「舊工作」而被忽略
        currentSessionID = UUID()

        audioEngine.stop()
        audioEngine.inputNode.removeTap(onBus: 0)
        recognitionRequest?.endAudio()
        recognitionTask?.cancel()
        recognitionRequest = nil
        recognitionTask = nil

        // 不管有沒有等到官方判定的 isFinal，只要還有內容就強制寫入，避免遺失
        if !latestText.isEmpty {
            appendToFile(latestText)
            latestText = ""
        }

        outputFileHandle?.closeFile()
        isRunning = false
    }

    // MARK: - 自動斷句寫檔

    private func appendToFile(_ text: String) {
        guard !text.isEmpty else { return }

        let now = Date() // 用同一個 Date 產生檔名與時間戳記，確保兩者完全一致

        // 延遲建檔：第一句話真正要寫入時才建立檔案，檔名時間 = 這句話的時間
        if outputFileHandle == nil {
            guard let directory = pendingOutputDirectory else { return }
            let fileNameFormatter = DateFormatter()
            fileNameFormatter.dateFormat = "yyyy-MM-dd_HHmmss"
            let fileName = "transcript_\(fileNameFormatter.string(from: now)).txt"
            let fileURL = directory.appendingPathComponent(fileName)
            FileManager.default.createFile(atPath: fileURL.path, contents: nil)
            outputFileHandle = try? FileHandle(forWritingTo: fileURL)
            DispatchQueue.main.async {
                self.outputFileURL = fileURL
            }
        }

        let timeFormatter = DateFormatter()
        timeFormatter.dateFormat = "HH:mm:ss"
        let timePrefix = timeFormatter.string(from: now)

        func isSentenceEnder(_ ch: Character) -> Bool {
            return "。！？.!?".contains(ch)
        }

        var sentences: [String] = []
        var current = ""
        for ch in text {
            current.append(ch)
            if isSentenceEnder(ch) {
                let trimmed = current.trimmingCharacters(in: .whitespacesAndNewlines)
                if !trimmed.isEmpty { sentences.append(trimmed) }
                current = ""
            }
        }
        let remaining = current.trimmingCharacters(in: .whitespacesAndNewlines)
        if !remaining.isEmpty { sentences.append(remaining) }
        if sentences.isEmpty {
            sentences = [text.trimmingCharacters(in: .whitespacesAndNewlines)]
        }

        var fileOutput = ""
        for sentence in sentences where !sentence.isEmpty {
            let line = "[\(timePrefix)] \(sentence)"
            fileOutput += line + "\n"
            DispatchQueue.main.async {
                self.savedSentences.append(line)
            }
        }
        fileOutput += "\n" // 每次寫入之間加空行區隔

        if let data = fileOutput.data(using: .utf8) {
            outputFileHandle?.seekToEndOfFile()
            outputFileHandle?.write(data)
        }
    }
}

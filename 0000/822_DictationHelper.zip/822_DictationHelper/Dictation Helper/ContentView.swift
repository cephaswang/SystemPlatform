import SwiftUI
import AppKit
import Speech

struct ContentView: View {
    @StateObject private var transcriber = SpeechTranscriber()
    @StateObject private var deviceManager = AudioDeviceManager()

    @State private var selectedLocale: String = Locale.current.identifier
    @State private var availableLocales: [String] = []

    // 前置軟體檢查（BlackHole）相關狀態
    @State private var showSetupAlert = false
    @State private var setupScriptURL: URL?

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {

            Text("聽寫小幫手")
                .font(.title2)
                .bold()

            // 語系選單：動態列出「這台 Mac 目前」支援語音辨識的所有語系
            HStack {
                Text("語系：")
                Picker("", selection: $selectedLocale) {
                    ForEach(availableLocales, id: \.self) { code in
                        Text(displayName(for: code)).tag(code)
                    }
                }
                .frame(width: 240)
                .disabled(transcriber.isRunning)

                Text("（共 \(availableLocales.count) 種）")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }

            // 輸入裝置選單
            HStack {
                Text("輸入裝置：")
                Picker("", selection: Binding(
                    get: { deviceManager.currentInputDeviceID ?? 0 },
                    set: { newID in deviceManager.setDefaultInputDevice(newID) }
                )) {
                    ForEach(deviceManager.inputDevices) { device in
                        Text(device.name).tag(device.id)
                    }
                }
                .frame(width: 260)
                .disabled(transcriber.isRunning)

                Button("重新整理") {
                    deviceManager.refreshDevices()
                }
                .disabled(transcriber.isRunning)
            }

            Text("👉 請先在「輸入裝置」選擇 BlackHole 等虛擬麥克風\n👉 並先在「Audio MIDI 設定」建立好 Multi-Output Device，\n    讓喇叭聲音同時送到該裝置，才聽得到聲音又能被辨識")
                .font(.caption)
                .foregroundColor(.secondary)

            // 開始 / 停止
            HStack {
                Button(transcriber.isRunning ? "停止聽寫" : "開始聽寫") {
                    if transcriber.isRunning {
                        transcriber.stop()
                    } else {
                        let outputDir = FileManager.default
                            .urls(for: .documentDirectory, in: .userDomainMask)
                            .first!
                        transcriber.start(localeIdentifier: selectedLocale, outputDirectory: outputDir)
                    }
                }
                .buttonStyle(.borderedProminent)

                if let url = transcriber.outputFileURL {
                    Button("在 Finder 中顯示逐字稿") {
                        NSWorkspace.shared.activateFileViewerSelecting([url])
                    }
                }
            }

            if !transcriber.statusMessage.isEmpty {
                Text(transcriber.statusMessage)
                    .foregroundColor(.red)
            }

            Divider()

            Text("即時辨識：")
                .font(.headline)
            Text(transcriber.liveText)
                .padding(8)
                .frame(maxWidth: .infinity, minHeight: 40, alignment: .leading)
                .background(Color.gray.opacity(0.1))
                .cornerRadius(6)

            HStack {
                Text("已存檔內容：")
                    .font(.headline)
                if let url = transcriber.outputFileURL {
                    Text("(\(url.lastPathComponent))")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
            ScrollView {
                VStack(alignment: .leading, spacing: 4) {
                    ForEach(Array(transcriber.savedSentences.enumerated()), id: \.offset) { _, sentence in
                        Text(sentence)
                    }
                }
                .frame(maxWidth: .infinity, alignment: .leading)
            }
            .frame(minHeight: 200)
            .background(Color.gray.opacity(0.05))
            .cornerRadius(6)
        }
        .padding(20)
        .frame(minWidth: 520, minHeight: 580)
        .onAppear {
            loadAvailableLocales()
            checkPrerequisites()
        }
        .alert("需要先安裝 BlackHole", isPresented: $showSetupAlert) {
            Button("複製指令") {
                copyInstallCommandToClipboard()
            }
            Button("知道了", role: .cancel) { }
        } message: {
            Text("""
            偵測不到 BlackHole 虛擬音訊裝置，這是把喇叭聲音送進辨識引擎必要的元件。

            已經把安裝腳本複製到你的「桌面」：
            \(SetupScript.fileName)

            請打開「終端機」App，執行以下指令完成安裝：

            cd ~/Desktop && ./\(SetupScript.fileName)

            （按下方「複製指令」可直接複製這行指令）
            """)
        }
    }

    // MARK: - 前置軟體檢查

    private func checkPrerequisites() {
        guard !PrerequisiteChecker.isBlackHoleInstalled() else { return }

        if let url = PrerequisiteChecker.copySetupScriptToDesktop() {
            setupScriptURL = url
            showSetupAlert = true
        }
    }

    private func copyInstallCommandToClipboard() {
        let command = "cd ~/Desktop && ./\(SetupScript.fileName)"
        let pasteboard = NSPasteboard.general
        pasteboard.clearContents()
        pasteboard.setString(command, forType: .string)
    }

    // MARK: - 動態載入這台 Mac 目前支援語音辨識的所有語系

    private func loadAvailableLocales() {
        let supported = SFSpeechRecognizer.supportedLocales()
            .map { $0.identifier }
            .sorted { lhs, rhs in
                displayName(for: lhs).localizedStandardCompare(displayName(for: rhs)) == .orderedAscending
            }

        availableLocales = supported

        // 正規化比對（zh-TW / zh_TW 視為相同，大小寫也忽略），避免因格式差異比對失敗
        func normalize(_ s: String) -> String {
            s.replacingOccurrences(of: "_", with: "-").lowercased()
        }

        func firstMatch(_ target: String) -> String? {
            supported.first { normalize($0) == normalize(target) }
        }

        // 直接鎖定繁體中文候選清單（依優先順序），不依賴 Locale.current，
        // 避免系統語言格式（zh_TW@rg=... 等）比對失敗導致選錯語系
        let preferredCandidates = ["zh-TW", "zh-Hant-TW", "zh-Hant_TW", "zh_TW"]

        if let match = preferredCandidates.compactMap({ firstMatch($0) }).first {
            selectedLocale = match
        } else if let match = firstMatch(Locale.current.identifier) {
            selectedLocale = match
        } else if let first = supported.first {
            selectedLocale = first
        }
    }

    // 把語系代碼（如 "zh-TW"）轉成人類看得懂的名稱（如 "中文（台灣）"）
    private func displayName(for code: String) -> String {
        Locale.current.localizedString(forIdentifier: code) ?? code
    }
}

#Preview {
    ContentView()
}

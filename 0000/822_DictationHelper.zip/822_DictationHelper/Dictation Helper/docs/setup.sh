#!/bin/bash
#
# setup.sh - 「喇叭聽寫小幫手」App 前置軟體安裝腳本
#
# 這支腳本會自動安裝：
#   1. Homebrew（若尚未安裝）
#   2. BlackHole 2ch（虛擬音訊裝置，用來把喇叭聲音導入語音辨識）
#
# 無法自動化、需要你手動做的部分（腳本結束時會再提醒一次）：
#   - 在「Audio MIDI 設定」建立 Multi-Output Device
#     （這一步涉及圖形介面操作，且沒有官方公開指令可自動建立，需手動點）
#   - 在 Xcode 裡開啟 App Sandbox、勾選麥克風/檔案讀寫權限
#   - 設定 > 鍵盤 > 聽寫，開啟系統聽寫功能（Speech Framework 依賴此開關）
#
# 使用方式：
#   chmod +x setup.sh
#   ./setup.sh
#

set -e

echo "===================================================="
echo " 喇叭聽寫小幫手 - 前置軟體安裝"
echo "===================================================="
echo ""

# ---------- 1. 檢查 / 安裝 Homebrew ----------
if command -v brew >/dev/null 2>&1; then
    echo "✅ 已安裝 Homebrew：$(brew --version | head -n 1)"
else
    echo "⚙️  尚未安裝 Homebrew，開始安裝..."
    /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

    # Apple Silicon 機器的 Homebrew 預設裝在 /opt/homebrew，需要手動加入 PATH
    if [ -f "/opt/homebrew/bin/brew" ]; then
        echo 'eval "$(/opt/homebrew/bin/brew shellenv)"' >> "$HOME/.zprofile"
        eval "$(/opt/homebrew/bin/brew shellenv)"
    fi

    echo "✅ Homebrew 安裝完成"
fi
echo ""

# ---------- 2. 檢查 / 安裝 BlackHole 2ch ----------
echo "🔍 檢查 BlackHole 2ch 是否已安裝..."
if system_profiler SPAudioDataType 2>/dev/null | grep -q "BlackHole 2ch"; then
    echo "✅ 系統已偵測到 BlackHole 2ch 裝置"
elif brew list --cask blackhole-2ch >/dev/null 2>&1; then
    echo "✅ Homebrew 顯示 blackhole-2ch 已安裝（可能需要重新開機或重新登入才會出現在音訊裝置清單）"
else
    echo "⚙️  尚未安裝 BlackHole 2ch，開始安裝..."
    brew install blackhole-2ch
    echo "✅ BlackHole 2ch 安裝完成"
    echo "⚠️  安裝驅動程式後，建議「登出再登入」或「重新開機」，虛擬音訊裝置才會正確出現"
fi
echo ""

# ---------- 3. 檢查 Xcode 指令列工具（編譯 Swift 專案需要） ----------
echo "🔍 檢查 Xcode 指令列工具..."
if xcode-select -p >/dev/null 2>&1; then
    echo "✅ 已安裝 Xcode 指令列工具：$(xcode-select -p)"
else
    echo "⚙️  尚未安裝 Xcode 指令列工具，開始安裝（會跳出系統安裝視窗）..."
    xcode-select --install
    echo "👉 請依照跳出的視窗完成安裝後，再重新執行本腳本一次"
    exit 0
fi
echo ""

# ---------- 4. 檢查是否已安裝完整版 Xcode（開發 App 需要，非僅指令列工具） ----------
if [ -d "/Applications/Xcode.app" ]; then
    echo "✅ 已偵測到 /Applications/Xcode.app"
else
    echo "⚠️  未偵測到完整版 Xcode.app（開發、編譯 SwiftUI App 需要用到）"
    echo "    請至 App Store 搜尋「Xcode」安裝（免費，安裝檔較大，需要一些時間）"
fi
echo ""

echo "===================================================="
echo " 自動安裝部分已完成，以下步驟需要手動操作："
echo "===================================================="
cat << 'EOF'

[1] 建立 Multi-Output Device（讓你聽得到聲音，同時能被辨識）
    - 開啟「Audio MIDI 設定」（Spotlight 搜尋 Audio MIDI Setup）
    - 左下角「+」→「建立多重輸出裝置」
    - 勾選：你的實體喇叭/耳機 ＋ BlackHole 2ch
    - 在 BlackHole 2ch 那一列勾選「Drift Correction」

[2] 開啟系統聽寫功能（Speech Framework 依賴此開關）
    - 系統設定 → 鍵盤 → 聽寫 → 開啟
    - 確認語言清單有你要用的語言，必要時下載語音套件

[3] 在 Xcode 專案中設定權限
    - Target → Info：加入
        Privacy - Microphone Usage Description
        Privacy - Speech Recognition Usage Description
    - Target → Signing & Capabilities → + Capability → 搜尋「Sandbox」
      → 加入 App Sandbox → 勾選：
        Hardware > Audio Input
        File Access > User Selected File (Read/Write)

[4] 執行 App 後，在介面中：
    - 「輸入裝置」選單選擇 BlackHole 2ch
    - 「語系」選單選擇要用的語言
    - 按「開始聽寫」

EOF

echo "===================================================="
echo " 安裝腳本執行完畢"
echo "===================================================="

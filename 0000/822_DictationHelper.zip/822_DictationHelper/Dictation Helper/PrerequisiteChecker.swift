import Foundation

enum PrerequisiteChecker {

    // 檢查系統目前的音訊輸入裝置清單中，是否有 BlackHole
    static func isBlackHoleInstalled() -> Bool {
        AudioDeviceManager.fetchInputDevices().contains { device in
            device.name.localizedCaseInsensitiveContains("BlackHole")
        }
    }

    // 把內嵌的安裝腳本寫到桌面，並設定為可執行檔
    // 回傳寫入後的檔案路徑；失敗則回傳 nil
    @discardableResult
    static func copySetupScriptToDesktop() -> URL? {
        guard let desktopURL = FileManager.default.urls(for: .desktopDirectory, in: .userDomainMask).first else {
            return nil
        }

        let destinationURL = desktopURL.appendingPathComponent(SetupScript.fileName)

        do {
            // 如果桌面已經有同名檔案，先移除再重寫，確保內容是最新版本
            if FileManager.default.fileExists(atPath: destinationURL.path) {
                try FileManager.default.removeItem(at: destinationURL)
            }

            try SetupScript.content.write(to: destinationURL, atomically: true, encoding: .utf8)

            // 設定為可執行檔（等同 chmod +x）
            try FileManager.default.setAttributes(
                [.posixPermissions: 0o755],
                ofItemAtPath: destinationURL.path
            )

            return destinationURL
        } catch {
            print("❌ 複製安裝腳本到桌面失敗：\(error.localizedDescription)")
            return nil
        }
    }
}

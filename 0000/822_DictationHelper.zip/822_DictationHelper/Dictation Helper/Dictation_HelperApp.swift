import SwiftUI

@main
struct Dictation_HelperApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

import SwiftUI

struct HelpView: View {
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack {
                Text("聽寫小幫手 使用說明")
                    .font(.title2)
                    .bold()
                Spacer()
                Button("關閉") { dismiss() }
            }
            .padding()

            Divider()

            ScrollView {
                VStack(alignment: .leading, spacing: 18) {

                    helpSection(
                        title: "這個 App 在做什麼？",
                        content: "把喇叭正在播放的聲音（例如影片、Podcast）即時轉成文字，並自動存成逐字稿檔案。"
                    )

                    helpSection(
                        title: "第一次使用前的設定",
                        content: """
                        1. 安裝 BlackHole 虛擬音訊裝置
                           （App 偵測不到時會自動把安裝腳本複製到桌面，並提示指令）

                        2. 到「Audio MIDI 設定」建立 Multi-Output Device
                           勾選：你的實體喇叭/耳機 ＋ BlackHole 2ch
                           並在 BlackHole 2ch 那一列勾選「Drift Correction」

                        3. 系統設定 > 鍵盤 > 聽寫，開啟「聽寫」功能
                           （語音辨識引擎需要這個開關）
                        """
                    )

                    helpSection(
                        title: "每次使用的步驟",
                        content: """
                        1. 系統設定 > 聲音 > 輸出，選擇 Multi-Output Device
                        2. 在本 App「輸入裝置」選單，選擇 BlackHole 2ch
                        3. 選擇語系（或開啟雙語模式，同時支援兩種語言）
                        4. 按「開始聽寫」，播放聲音
                        5. 講完/播完後按「停止聽寫」
                        6. 按「在 Finder 中顯示逐字稿」查看存檔內容
                        """
                    )

                    helpSection(
                        title: "雙語模式是什麼？",
                        content: "同時啟動兩個語言的辨識引擎，每句話結束後自動比較信心分數，選較準確的語言寫入逐字稿。適合「不同段落切換語言」的情況，無法辨識「同一句話中英夾雜」。"
                    )

                    helpSection(
                        title: "常見問題",
                        content: """
                        • 聽不到聲音：輸出裝置有沒有選成 Multi-Output Device？
                        • 辨識不出文字：輸入裝置有沒有選成 BlackHole 2ch？
                        • 特定語言辨識失敗：該語系的語音套件可能還沒下載，
                          到「設定 > 時間與語言 > 語言與地區」該語言的選項裡確認
                        """
                    )

                    helpSection(
                        title: "需要進一步協助？",
                        content: "歡迎來信 share35app@gmail.com，或使用選單列「Dictation Helper > Help」裡的聯絡支援。"
                    )
                }
                .padding()
            }
        }
        .frame(width: 480, height: 520)
    }

    @ViewBuilder
    private func helpSection(title: String, content: String) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(title)
                .font(.headline)
            Text(content)
                .font(.callout)
                .foregroundColor(.secondary)
                .fixedSize(horizontal: false, vertical: true)
        }
    }
}

#Preview {
    HelpView()
}

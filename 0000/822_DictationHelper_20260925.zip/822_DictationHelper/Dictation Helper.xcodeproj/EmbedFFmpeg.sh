#!/bin/bash
#
# EmbedFFmpeg.sh
#
# 用途：作為 Xcode 的 Run Script Build Phase，在每次 build 時：
#   1. 找到本機安裝的 ffmpeg（Homebrew 路徑）
#   2. 複製進 App Bundle 的 Contents/Resources/ffmpeg
#   3. 用跟主 App 相同的簽署身份重新簽署這支執行檔
#      （若有開 Hardened Runtime，未簽署或簽署身份不一致的內嵌執行檔
#        在執行期會被系統直接擋下，複製了也沒用）
#
# 對應的 Swift 端：AudioConverterService.locateFFmpegBinary() 裡
#   Bundle.main.url(forResource: "ffmpeg", withExtension: nil)
# 找的就是這裡放的檔案，不用改 Swift 程式碼。
#
# 安裝方式（只需做一次）：
#   1. Xcode 打開 Dictation Helper.xcodeproj
#   2. 選到 VoxNoteImport 這個 target → Build Phases 分頁
#   3. 左上角「+」→ New Run Script Phase
#   4. 把這支腳本存到專案裡，例如 Scripts/EmbedFFmpeg.sh，
#      在 Run Script 欄位填：
#        chmod +x "${SRCROOT}/Scripts/EmbedFFmpeg.sh"
#        "${SRCROOT}/Scripts/EmbedFFmpeg.sh"
#   5. 建議把這個 Run Script Phase 拖到 Build Phases 清單的最後一個
#      （在 Copy Bundle Resources 之後即可，這支腳本自己處理複製，
#      不需要額外把 ffmpeg 加進 Copy Bundle Resources）
#

set -e

echo "🔧 [EmbedFFmpeg] 開始處理 ffmpeg 內嵌..."

# ---------- 只在真正建置 App（不是建置 for testing 的中介產物）時執行 ----------
if [ -z "${BUILT_PRODUCTS_DIR:-}" ] || [ -z "${CONTENTS_FOLDER_PATH:-}" ]; then
    echo "⚠️  [EmbedFFmpeg] 找不到 Xcode build 環境變數，略過（這支腳本應該作為 Run Script Build Phase 執行）"
    exit 0
fi

RESOURCES_DIR="${BUILT_PRODUCTS_DIR}/${CONTENTS_FOLDER_PATH}/Resources"
DEST_PATH="${RESOURCES_DIR}/ffmpeg"

# ---------- 尋找本機 ffmpeg ----------
# 優先順序：PATH 裡的 ffmpeg → 常見 Homebrew 路徑
CANDIDATE_PATHS=()
if command -v ffmpeg >/dev/null 2>&1; then
    CANDIDATE_PATHS+=("$(command -v ffmpeg)")
fi
CANDIDATE_PATHS+=("/opt/homebrew/bin/ffmpeg" "/usr/local/bin/ffmpeg")

FFMPEG_SOURCE=""
for path in "${CANDIDATE_PATHS[@]}"; do
    if [ -x "$path" ]; then
        FFMPEG_SOURCE="$path"
        break
    fi
done

if [ -z "$FFMPEG_SOURCE" ]; then
    echo "❌ [EmbedFFmpeg] 在建置這台機器上找不到可執行的 ffmpeg。"
    echo "   請先用 Homebrew 安裝：brew install ffmpeg"
    exit 1
fi

echo "🔍 [EmbedFFmpeg] 使用來源 ffmpeg：${FFMPEG_SOURCE}"
echo "🔍 [EmbedFFmpeg] 目的地：${DEST_PATH}"

# ---------- 複製 ----------
mkdir -p "${RESOURCES_DIR}"
cp -f "${FFMPEG_SOURCE}" "${DEST_PATH}"
chmod +x "${DEST_PATH}"
echo "✅ [EmbedFFmpeg] 已複製並設定執行權限"

# ---------- 重新簽署 ----------
# CODE_SIGNING_ALLOWED=NO 通常發生在某些中介建置步驟；沒有簽署身份時（例如
# ad-hoc/開發階段的 "-"）也要能正常處理，避免整個 build 失敗。
if [ "${CODE_SIGNING_ALLOWED:-YES}" = "NO" ]; then
    echo "ℹ️  [EmbedFFmpeg] 此次建置未啟用程式碼簽署（CODE_SIGNING_ALLOWED=NO），略過簽署步驟"
    exit 0
fi

SIGN_IDENTITY="${EXPANDED_CODE_SIGN_IDENTITY:-${CODE_SIGN_IDENTITY:--}}"
echo "🔏 [EmbedFFmpeg] 使用簽署身份：${SIGN_IDENTITY}"

CODESIGN_ARGS=(--force --timestamp=none --sign "${SIGN_IDENTITY}")

# 若主 App 有開 Hardened Runtime，內嵌的執行檔也要一併加上 runtime 選項，
# 否則系統在執行期仍可能拒絕啟動這支被複製進來的 ffmpeg。
if [ "${ENABLE_HARDENED_RUNTIME:-NO}" = "YES" ]; then
    CODESIGN_ARGS+=(--options runtime)
    echo "🔏 [EmbedFFmpeg] 偵測到 Hardened Runtime 已啟用，簽署時加上 --options runtime"
fi

codesign "${CODESIGN_ARGS[@]}" "${DEST_PATH}"

echo "✅ [EmbedFFmpeg] ffmpeg 簽署完成"

# ---------- 驗證 ----------
if codesign --verify --verbose "${DEST_PATH}" 2>&1 | grep -q "valid on disk"; then
    echo "✅ [EmbedFFmpeg] 簽署驗證通過"
else
    echo "⚠️  [EmbedFFmpeg] 簽署驗證訊息如下，若顯示 ad-hoc 簽署（身份為 \"-\"）在本機測試通常仍可執行，" \
         "但正式發行／公證前務必確認使用真正的 Developer ID"
    codesign --verify --verbose "${DEST_PATH}" 2>&1 || true
fi

echo "🎉 [EmbedFFmpeg] 完成"

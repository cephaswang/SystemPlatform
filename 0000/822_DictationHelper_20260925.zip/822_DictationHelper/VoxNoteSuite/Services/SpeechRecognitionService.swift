import Foundation
import Speech

enum SpeechRecognitionError: LocalizedError {
    case permissionDenied
    case recognizerUnavailable
    case recognitionFailed(String)
    case engineNotImplemented(String)

    var errorDescription: String? {
        switch self {
        case .permissionDenied:
            return "尚未取得語音辨識權限"
        case .recognizerUnavailable:
            return "目前語系的語音辨識功能無法使用"
        case .recognitionFailed(let reason):
            return "辨識失敗：\(reason)"
        case .engineNotImplemented(let name):
            return "「\(name)」尚未串接，請於設定中改選 Apple Speech Framework"
        }
    }
}

/// 序列化佇列：確保同一時間只有一個 SFSpeechRecognizer 辨識任務在執行。
/// Apple Speech Framework 底層限制單一進程只允許一個辨識任務同時進行，
/// 若同時對多個檔案發起辨識，後發起的請求會把先前的任務 cancel 掉，
/// 進而導致該任務的 completion callback 被系統多呼叫一次（見 SpeechRecognitionService
/// 內的 resumeOnce 保護），並可能造成 continuation 重複 resume 而 crash。
/// 因此所有辨識請求一律先透過本佇列排隊，逐一執行。
actor RecognitionQueue {
    static let shared = RecognitionQueue()

    private var isBusy = false
    private var waiters: [CheckedContinuation<Void, Never>] = []

    /// 取得執行權；若目前有其他辨識任務正在跑，會在此暫停直到輪到自己
    func acquire() async {
        if !isBusy {
            isBusy = true
            return
        }
        await withCheckedContinuation { waiters.append($0) }
    }

    /// 釋放執行權，讓下一個排隊中的請求開始執行
    func release() {
        if waiters.isEmpty {
            isBusy = false
        } else {
            let next = waiters.removeFirst()
            next.resume()
        }
    }
}

/// 呼叫語音辨識引擎，將音檔轉為逐句文字結果。
/// 依 SettingsView 中選擇的引擎（Apple Speech / Whisper 本地 / Whisper 雲端）分派處理，
/// 對外統一回傳 [TranscriptSegment]。
struct SpeechRecognitionService {

    /// 詞與詞之間的靜音間隔超過此門檻（秒），即使沒有偵測到句尾標點，
    /// 也視為一個斷句點。用來避免整段音檔因為 recognizer 沒加標點
    /// 而被合併成單一超長句子（例如 log 中出現的 segments=1）。
    private let pauseBreakThreshold: TimeInterval = 0.6

    /// 對外主要入口：傳入已轉檔完成的音檔 URL 與語系，回傳逐句辨識結果
    func recognize(
        audioURL: URL,
        locale: String,
        engine: SettingsView.RecognitionEngine
    ) async throws -> [TranscriptSegment] {
        switch engine {
        case .appleSpeech:
            return try await recognizeWithAppleSpeech(audioURL: audioURL, locale: locale)
        case .whisperLocal:
            throw SpeechRecognitionError.engineNotImplemented("Whisper（本地端）")
        case .whisperCloud:
            throw SpeechRecognitionError.engineNotImplemented("Whisper（雲端 API）")
        }
    }

    // MARK: - Apple Speech Framework

    private func recognizeWithAppleSpeech(audioURL: URL, locale: String) async throws -> [TranscriptSegment] {
        // 排隊等待，確保同一時間只有一個辨識任務在執行（Apple Speech 不支援多進程並發）
        await RecognitionQueue.shared.acquire()
        defer {
            Task { await RecognitionQueue.shared.release() }
        }

        print("🎙️ [SpeechRecognitionService] 開始辨識 file=\(audioURL.lastPathComponent) locale=\(locale)")

        guard await requestAuthorizationIfNeeded() else {
            print("⚠️ [SpeechRecognitionService] 尚未取得語音辨識權限 file=\(audioURL.lastPathComponent)")
            throw SpeechRecognitionError.permissionDenied
        }

        guard let recognizer = SFSpeechRecognizer(locale: Locale(identifier: locale)),
              recognizer.isAvailable else {
            print("⚠️ [SpeechRecognitionService] recognizer 不可用 file=\(audioURL.lastPathComponent) locale=\(locale)")
            throw SpeechRecognitionError.recognizerUnavailable
        }

        let request = SFSpeechURLRecognitionRequest(url: audioURL)
        request.shouldReportPartialResults = false

        // 請 recognizer 自動加上標點符號（句號、問號等），作為斷句依據。
        // 未加此設定時，多數語系的辨識結果完全不含標點，導致 groupIntoSentences
        // 永遠找不到句尾字元，整段音檔會被當成「一句」（對應 log 中的 segments=1）。
        if #available(macOS 13.0, *) {
            request.addsPunctuation = true
        }

        // 防止底層 delegate/callback 在極端情況下（例如任務被系統取消）
        // 對同一個 continuation 呼叫超過一次 resume 而觸發 Fatal error。
        let resumeLock = NSLock()
        var didResume = false

        func resumeOnce(_ body: () -> Void) {
            resumeLock.lock()
            defer { resumeLock.unlock() }
            guard !didResume else {
                print("⚠️ [SpeechRecognitionService] 偵測到重複的 resume 呼叫，已略過 file=\(audioURL.lastPathComponent)")
                return
            }
            didResume = true
            body()
        }

        return try await withCheckedThrowingContinuation { continuation in
            recognizer.recognitionTask(with: request) { result, error in
                if let error {
                    resumeOnce {
                        print("❌ [SpeechRecognitionService] 辨識失敗 file=\(audioURL.lastPathComponent) locale=\(locale) error=\(error.localizedDescription)")
                        continuation.resume(throwing: SpeechRecognitionError.recognitionFailed(error.localizedDescription))
                    }
                    return
                }

                guard let result, result.isFinal else { return }

                let segments = result.bestTranscription.segments.map { segment in
                    TranscriptSegment(
                        text: segment.substring,
                        startTime: segment.timestamp,
                        endTime: segment.timestamp + segment.duration,
                        confidence: Double(segment.confidence)
                    )
                }

                resumeOnce {
                    let sentences = groupIntoSentences(segments)
                    print("✅ [SpeechRecognitionService] 辨識完成 file=\(audioURL.lastPathComponent) locale=\(locale) segments=\(sentences.count)")
                    continuation.resume(returning: sentences)
                }
            }
        }
    }

    /// 將逐字（word-level）辨識片段合併為逐句（sentence-level）片段。
    /// 斷句依據有二，任一成立即斷句：
    /// 1. 該詞以句尾標點結尾（。！？.!?）— 主要依據，前提是 recognizer 有加標點
    /// 2. 與下一個詞之間的靜音間隔超過 pauseBreakThreshold —
    ///    fallback，避免 recognizer 沒加標點時整段音檔變成單一句子
    private func groupIntoSentences(_ wordSegments: [TranscriptSegment]) -> [TranscriptSegment] {
        let sentenceEnders: Set<Character> = ["。", "！", "？", ".", "!", "?"]
        var sentences: [TranscriptSegment] = []
        var buffer: [TranscriptSegment] = []

        for (index, word) in wordSegments.enumerated() {
            buffer.append(word)

            let endsWithPunctuation: Bool
            if let lastChar = word.text.last {
                endsWithPunctuation = sentenceEnders.contains(lastChar)
            } else {
                endsWithPunctuation = false
            }

            let hasLongPauseAfter: Bool
            if index + 1 < wordSegments.count {
                let nextWord = wordSegments[index + 1]
                hasLongPauseAfter = (nextWord.startTime - word.endTime) >= pauseBreakThreshold
            } else {
                hasLongPauseAfter = false
            }

            if endsWithPunctuation || hasLongPauseAfter {
                sentences.append(merge(buffer))
                buffer.removeAll()
            }
        }

        if !buffer.isEmpty {
            sentences.append(merge(buffer))
        }

        return sentences
    }

    private func merge(_ words: [TranscriptSegment]) -> TranscriptSegment {
        TranscriptSegment(
            text: joinWords(words.map(\.text)),
            startTime: words.first?.startTime ?? 0,
            endTime: words.last?.endTime ?? 0,
            confidence: words.map(\.confidence).reduce(0, +) / Double(max(words.count, 1))
        )
    }

    /// 依語言特性智慧合併詞語文字：
    /// - 中日韓（CJK）字元前後緊鄰時不加空格（該語言本身不使用空格斷詞）
    /// - 其餘情況（例如英文單字接英文單字）之間補一個空格
    /// 修正原本 `words.map(\.text).joined()` 直接無空格拼接、
    /// 造成英文等語言辨識結果變成 "Helloeveryoneinthissession..." 的問題。
    private func joinWords(_ words: [String]) -> String {
        var result = ""
        for word in words {
            guard !word.isEmpty else { continue }
            if result.isEmpty {
                result = word
                continue
            }
            if needsSpace(before: result, after: word) {
                result += " "
            }
            result += word
        }
        return result
    }

    private func needsSpace(before: String, after: String) -> Bool {
        guard let lastChar = before.last, let firstChar = after.first else { return false }

        // 標點符號前不加空格（例如 "hello" + "." -> "hello."）
        if firstChar.isPunctuation && !isCJK(firstChar) {
            return false
        }

        // 任一側是 CJK 字元時不加空格（中日韓文字彼此相鄰或與標點相鄰皆不需空格）
        if isCJK(lastChar) || isCJK(firstChar) {
            return false
        }

        return true
    }

    private func isCJK(_ character: Character) -> Bool {
        for scalar in character.unicodeScalars {
            switch scalar.value {
            case 0x4E00...0x9FFF,   // CJK 統一表意文字
                 0x3400...0x4DBF,   // CJK 擴展 A
                 0x3040...0x309F,   // 平假名
                 0x30A0...0x30FF,   // 片假名
                 0xAC00...0xD7A3:   // 韓文音節
                return true
            default:
                continue
            }
        }
        return false
    }

    private func requestAuthorizationIfNeeded() async -> Bool {
        await withCheckedContinuation { continuation in
            SFSpeechRecognizer.requestAuthorization { status in
                continuation.resume(returning: status == .authorized)
            }
        }
    }
}

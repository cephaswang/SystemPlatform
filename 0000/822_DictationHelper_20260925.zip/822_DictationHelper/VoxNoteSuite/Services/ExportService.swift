import Foundation

enum ExportError: LocalizedError {
    case noSegments
    case writeFailed(String)
    case formatNotImplemented(String)

    var errorDescription: String? {
        switch self {
        case .noSegments:
            return "此音檔尚無可匯出的逐字稿內容"
        case .writeFailed(let reason):
            return "寫入檔案失敗：\(reason)"
        case .formatNotImplemented(let format):
            return "「\(format)」格式尚未支援，請改選 TXT 或 SRT"
        }
    }
}

/// 將 AudioFile 的逐字稿依指定格式寫入使用者選擇的路徑
struct ExportService {

    func export(
        audioFile: AudioFile,
        format: ExportSheetView.ExportFormat,
        includeTimestamps: Bool,
        to destinationURL: URL,
        completion: @escaping (Result<Void, Error>) -> Void
    ) {
        guard !audioFile.transcriptSegments.isEmpty else {
            completion(.failure(ExportError.noSegments))
            return
        }

        DispatchQueue.global(qos: .userInitiated).async {
            do {
                let content: String
                switch format {
                case .txt:
                    content = makeTXT(segments: audioFile.transcriptSegments, includeTimestamps: includeTimestamps)
                case .srt:
                    content = makeSRT(segments: audioFile.transcriptSegments)
                case .docx, .pdf:
                    throw ExportError.formatNotImplemented(format.rawValue)
                }

                try content.write(to: destinationURL, atomically: true, encoding: .utf8)

                DispatchQueue.main.async { completion(.success(())) }
            } catch {
                DispatchQueue.main.async { completion(.failure(error)) }
            }
        }
    }

    // MARK: - TXT

    private func makeTXT(segments: [TranscriptSegment], includeTimestamps: Bool) -> String {
        segments.map { segment in
            includeTimestamps ? "[\(segment.timestampDescription)] \(segment.text)" : segment.text
        }.joined(separator: "\n")
    }

    // MARK: - SRT

    private func makeSRT(segments: [TranscriptSegment]) -> String {
        segments.enumerated().map { index, segment in
            """
            \(index + 1)
            \(srtTimestamp(segment.startTime)) --> \(srtTimestamp(segment.endTime))
            \(segment.text)
            """
        }.joined(separator: "\n\n")
    }

    private func srtTimestamp(_ seconds: TimeInterval) -> String {
        let totalMilliseconds = Int((seconds * 1000).rounded())
        let hours = totalMilliseconds / 3_600_000
        let minutes = (totalMilliseconds % 3_600_000) / 60_000
        let secs = (totalMilliseconds % 60_000) / 1_000
        let millis = totalMilliseconds % 1_000
        return String(format: "%02d:%02d:%02d,%03d", hours, minutes, secs, millis)
    }
}

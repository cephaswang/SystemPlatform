import Foundation
import AVFoundation

enum AudioImportError: LocalizedError {
    case unsupportedFormat(String)
    case unreadableFile(URL)

    var errorDescription: String? {
        switch self {
        case .unsupportedFormat(let ext):
            return "不支援的音檔格式：.\(ext)（支援 mp3 / m4a / wav / webm）"
        case .unreadableFile(let url):
            return "無法讀取檔案：\(url.lastPathComponent)"
        }
    }
}

/// 負責匯入階段的檔案有效性檢查、必要時的預先轉檔，與基本資訊擷取（時長等）。
/// 不負責辨識前的格式轉換（見 AudioConverterService.convertToRecognitionFormat）。
struct AudioImportService {

    /// mp3 / m4a / wav 可被 AVFoundation 直接讀取；webm 需先經 AudioConverterService 轉檔
    private let supportedExtensions: Set<String> = ["mp3", "m4a", "wav", "webm"]

    private let converter = AudioConverterService()

    /// 檢查副檔名是否支援
    func isSupported(_ url: URL) -> Bool {
        supportedExtensions.contains(url.pathExtension.lowercased())
    }

    /// 讀取單一音檔並組成 AudioFile 物件（含實際時長）。
    /// 若為 webm 等 AVFoundation 無法原生讀取的格式，會先自動轉成 .m4a 再繼續處理，
    /// 原始檔案位置保留在 AudioFile.originalSourceURL。
    /// locale：使用者於匯入畫面針對這一個檔案選定的辨識語系。
    func makeAudioFile(from url: URL, locale: String) async throws -> AudioFile {
        guard isSupported(url) else {
            throw AudioImportError.unsupportedFormat(url.pathExtension)
        }

        let playableURL: URL
        do {
            playableURL = try await converter.convertToPlayableFormatIfNeeded(sourceURL: url)
        } catch {
            throw error
        }

        let asset = AVURLAsset(url: playableURL)
        let duration: TimeInterval
        do {
            let cmDuration = try await asset.load(.duration)
            duration = CMTimeGetSeconds(cmDuration)
        } catch {
            throw AudioImportError.unreadableFile(url)
        }

        return AudioFile(
            id: UUID(),
            sourceURL: playableURL,
            originalSourceURL: url,
            displayName: url.deletingPathExtension().lastPathComponent,
            durationSeconds: duration.isFinite ? duration : 0,
            status: .pending,
            locale: locale
        )
    }

    /// 批次匯入多個檔案；每個檔案各自帶著自己選定的 locale。
    /// 個別檔案失敗不影響其餘檔案，於 failures 回報。
    ///
    /// onItemStart：即將開始處理某個 URL 前呼叫一次（可用來在畫面上顯示「轉換中…」）。
    /// onItemFinish：該 URL 處理完成（成功或失敗）後立刻呼叫一次，
    /// 讓呼叫端（例如 ImportView）能逐檔即時更新畫面，不必等整批跑完。
    /// 兩個 callback 都會在呼叫端所在的 executor 上執行；若用來更新 @State，
    /// 呼叫端須自行確保在主執行緒上處理（例如整個呼叫都在 @MainActor 的 View 內）。
    func makeAudioFiles(
        from items: [(url: URL, locale: String)],
        onItemStart: @escaping (URL) -> Void = { _ in },
        onItemFinish: @escaping (URL, Result<AudioFile, Error>) -> Void = { _, _ in }
    ) async -> (imported: [AudioFile], failures: [(URL, Error)]) {
        var imported: [AudioFile] = []
        var failures: [(URL, Error)] = []

        for item in items {
            onItemStart(item.url)
            do {
                let audioFile = try await makeAudioFile(from: item.url, locale: item.locale)
                imported.append(audioFile)
                onItemFinish(item.url, .success(audioFile))
            } catch {
                failures.append((item.url, error))
                onItemFinish(item.url, .failure(error))
            }
        }

        return (imported, failures)
    }
}

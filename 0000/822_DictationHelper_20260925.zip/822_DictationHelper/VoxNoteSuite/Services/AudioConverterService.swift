import Foundation
import AVFoundation
import Darwin

enum AudioConversionError: LocalizedError {
    case exportSessionUnavailable
    case conversionFailed(String)
    case ffmpegNotFound
    case ffmpegExecutionFailed(String)

    var errorDescription: String? {
        switch self {
        case .exportSessionUnavailable:
            return "無法建立音訊轉檔工作階段"
        case .conversionFailed(let reason):
            return "音檔轉換失敗：\(reason)"
        case .ffmpegNotFound:
            return "找不到內建的 ffmpeg 轉檔工具，無法處理此格式"
        case .ffmpegExecutionFailed(let reason):
            return "轉檔工具執行失敗：\(reason)"
        }
    }
}

/// 音檔轉換服務，涵蓋兩種情境：
/// 1. 匯入階段：把 AVFoundation 無法原生解析的容器格式（例如 .webm）
///    先轉成可讀取的格式，這樣後續時長讀取、逐字稿處理才能正常運作
/// 2. 辨識前處理：把已可讀取的音檔統一轉成辨識引擎偏好的格式（.caf）
struct AudioConverterService {

    /// AVFoundation 在 macOS 上可原生讀取時長／音軌的容器格式
    private let nativelyReadableExtensions: Set<String> = ["mp3", "m4a", "wav"]

    /// 匯入階段需要先轉檔才能繼續處理的格式
    private let extensionsRequiringPreConversion: Set<String> = ["webm"]

    func requiresPreConversion(_ url: URL) -> Bool {
        extensionsRequiringPreConversion.contains(url.pathExtension.lowercased())
    }

    // MARK: - 匯入階段：webm 等格式的預先轉檔

    /// 若檔案是 AVFoundation 無法原生讀取的格式，先轉成 .m4a 並回傳暫存檔 URL；
    /// 若本來就是可原生讀取的格式，直接回傳原始 URL（不做任何轉換）。
    func convertToPlayableFormatIfNeeded(sourceURL: URL) async throws -> URL {
        let ext = sourceURL.pathExtension.lowercased()

        guard extensionsRequiringPreConversion.contains(ext) else {
            return sourceURL
        }

        let ffmpegURL = try locateFFmpegBinary()

        let outputURL = FileManager.default.temporaryDirectory
            .appendingPathComponent(UUID().uuidString)
            .appendingPathExtension("m4a")

        try await runFFmpeg(
            executableURL: ffmpegURL,
            arguments: [
                "-i", sourceURL.path,
                "-vn",                 // 只取音軌，捨棄畫面
                "-acodec", "aac",
                "-y",                  // 覆寫輸出檔（暫存檔理論上不存在，保險用）
                outputURL.path
            ]
        )

        return outputURL
    }

    /// 尋找可用的 ffmpeg 執行檔。
    /// 目前策略：優先使用電腦上（Homebrew）已安裝的版本，方便開發與個人使用時
    /// 隨時跟著 `brew upgrade ffmpeg` 更新，不需要每次改版都重新打包 App。
    /// 若之後要發行給不一定有裝 Homebrew 的使用者，才需要切回「打包進 App Bundle」
    /// 的做法（對應 EmbedFFmpeg.sh，目前先停用）。
    ///
    /// 檢查方式改用 POSIX 的 access()，失敗時能直接讀出 errno（系統回報的確切原因，
    /// 例如 EACCES=沒有權限、ENOENT=路徑不存在），比 FileManager.isExecutableFile
    /// 只回傳 true/false、看不出原因更好診斷。
    private func locateFFmpegBinary() throws -> URL {
        if let bundled = Bundle.main.url(forResource: "ffmpeg", withExtension: nil) {
            print("🔧 [AudioConverterService] 使用 App Bundle 內建的 ffmpeg：\(bundled.path)")
            print("⚠️ [AudioConverterService] 若你原本打算改用電腦上安裝的版本，" +
                  "代表 App Bundle 裡還留有先前打包的 ffmpeg——" +
                  "請 Clean Build Folder（⇧⌘K）後重新 build，確保用的是這裡才是最新的。")
            return bundled
        }
        print("🔧 [AudioConverterService] App Bundle 內找不到 ffmpeg，改用電腦上（Homebrew）安裝的版本…")

        let developmentFallbackPaths = [
            "/opt/homebrew/bin/ffmpeg",
            "/usr/local/bin/ffmpeg"
        ]

        for path in developmentFallbackPaths {
            let exists = FileManager.default.fileExists(atPath: path)

            if access(path, X_OK) == 0 {
                print("✅ [AudioConverterService] 找到可執行的 ffmpeg：\(path)")
                return URL(fileURLWithPath: path)
            }

            // 立刻讀 errno，避免中間任何函式呼叫把它覆蓋掉
            let code = errno
            let reason = String(cString: strerror(code))
            print("🔧 [AudioConverterService] 檢查 \(path) → fileExists=\(exists)，" +
                  "access(X_OK) 失敗：errno=\(code)（\(reason)）")
        }

        throw AudioConversionError.ffmpegNotFound
    }

    private func runFFmpeg(executableURL: URL, arguments: [String]) async throws {
        try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
            let process = Process()
            process.executableURL = executableURL
            process.arguments = arguments

            let errorPipe = Pipe()
            process.standardError = errorPipe
            process.standardOutput = Pipe() // 丟棄一般輸出，避免緩衝區塞滿

            process.terminationHandler = { finishedProcess in
                if finishedProcess.terminationStatus == 0 {
                    continuation.resume(returning: ())
                } else {
                    let errorData = errorPipe.fileHandleForReading.readDataToEndOfFile()
                    let message = String(data: errorData, encoding: .utf8) ?? "未知錯誤（結束碼 \(finishedProcess.terminationStatus)）"
                    continuation.resume(throwing: AudioConversionError.ffmpegExecutionFailed(message))
                }
            }

            do {
                try process.run()
            } catch {
                continuation.resume(throwing: AudioConversionError.ffmpegExecutionFailed(error.localizedDescription))
            }
        }
    }

    // MARK: - 辨識前處理：統一轉為辨識引擎偏好格式

    /// 將來源音檔轉換為 .caf（Core Audio Format），輸出至暫存目錄，回傳暫存檔 URL
    func convertToRecognitionFormat(sourceURL: URL) async throws -> URL {
        let asset = AVURLAsset(url: sourceURL)

        guard let exportSession = AVAssetExportSession(
            asset: asset,
            presetName: AVAssetExportPresetAppleM4A
        ) else {
            throw AudioConversionError.exportSessionUnavailable
        }

        let outputURL = FileManager.default.temporaryDirectory
            .appendingPathComponent(UUID().uuidString)
            .appendingPathExtension("caf")

        exportSession.outputURL = outputURL
        exportSession.outputFileType = .caf

        await exportSession.export()

        switch exportSession.status {
        case .completed:
            return outputURL
        case .failed, .cancelled:
            throw AudioConversionError.conversionFailed(
                exportSession.error?.localizedDescription ?? "未知錯誤"
            )
        default:
            throw AudioConversionError.conversionFailed("匯出工作階段狀態異常")
        }
    }

    /// 轉檔完成後清除暫存檔案
    func cleanupTemporaryFile(at url: URL) {
        try? FileManager.default.removeItem(at: url)
    }
}

import SwiftUI

struct TranscriptEditorView: View {

    let audioFile: AudioFile

    @State private var segments: [TranscriptSegment] = []
    @State private var selectedSegmentID: TranscriptSegment.ID?
    @State private var isLoading = false

    var body: some View {
        VStack(spacing: 0) {
            header

            Divider()

            switch audioFile.status {
            case .pending, .processing:
                processingPlaceholder
            case .failed:
                ContentUnavailableView(
                    "轉錄失敗",
                    systemImage: "exclamationmark.triangle",
                    description: Text("請嘗試重新匯入此音檔")
                )
            case .completed:
                transcriptList
            }
        }
        // 原本只用 audioFile.id 當作 task id，導致「同一個檔案從 processing 變成
        // completed」時（id 沒變）不會重新觸發，逐字稿因此一直顯示空白。
        // 改成把 status 一併納入 task id，只要 status 改變（例如轉錄完成）
        // 就會重新執行 loadSegmentsIfNeeded()，確保畫面能即時反映最新結果。
        .task(id: taskKey) {
            loadSegmentsIfNeeded()
        }
    }

    /// 結合 id 與 status 的複合 key，用於驅動 .task(id:) 在狀態改變時重新執行
    private var taskKey: String {
        "\(audioFile.id)-\(audioFile.status)"
    }

    private var header: some View {
        HStack {
            VStack(alignment: .leading) {
                Text(audioFile.displayName)
                    .font(.headline)
                Text(audioFile.durationDescription)
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            Spacer()
        }
        .padding()
    }

    private var processingPlaceholder: some View {
        VStack(spacing: 12) {
            ProgressView()
            Text(audioFile.status == .pending ? "等待開始轉錄…" : "辨識中，請稍候…")
                .foregroundColor(.secondary)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }

    private var transcriptList: some View {
        List(selection: $selectedSegmentID) {
            ForEach($segments) { $segment in
                HStack(alignment: .top, spacing: 12) {
                    Text(segment.timestampDescription)
                        .font(.caption.monospacedDigit())
                        .foregroundColor(.secondary)
                        .frame(width: 70, alignment: .leading)

                    // 可直接編輯逐字稿內容，修正辨識誤差
                    TextField("逐字稿內容", text: $segment.text, axis: .vertical)
                        .textFieldStyle(.plain)
                }
                .padding(.vertical, 4)
                .tag(segment.id)
            }
        }
        .listStyle(.inset)
    }

    private func loadSegmentsIfNeeded() {
        // 原本這裡多了 `segments.isEmpty` 的條件，導致第一次（processing 階段）
        // 載入過一次空陣列後，即使之後 status 變成 completed 也不會再重新賦值。
        // 拿掉該條件，只要目前是 completed 就同步一次 audioFile.transcriptSegments，
        // 這樣「轉錄完成」與「重新轉錄同一檔案覆蓋舊結果」都能正確反映到畫面上。
        guard audioFile.status == .completed else { return }
        print("📝 loadSegmentsIfNeeded 執行，taskKey=\(taskKey)，來源 segments 數=\(audioFile.transcriptSegments.count)")
        segments = audioFile.transcriptSegments
    }
}

#Preview {
    TranscriptEditorView(
        audioFile: AudioFile(
            id: UUID(),
            sourceURL: URL(fileURLWithPath: "/tmp/demo.m4a"),
            displayName: "會議錄音 0922",
            durationSeconds: 125,
            status: .completed
        )
    )
}

import SwiftUI
import UniformTypeIdentifiers

struct ImportView: View {

    /// 匯入完成後回傳新建立的 AudioFile 清單，交由呼叫端（AudioLibraryView）併入資料來源
    var onImport: ([AudioFile]) -> Void

    @Environment(\.dismiss) private var dismiss
    @State private var isDropTargeted = false
    @State private var pendingURLs: [URL] = []
    /// 每個待匯入檔案各自選定的語系，key 為該檔案的 URL
    @State private var localeSelections: [URL: String] = [:]
    /// 每個檔案目前的處理狀態，用於在清單上即時顯示「等待中／轉換中／已完成／失敗」
    @State private var itemStatuses: [URL: ImportItemStatus] = [:]
    @State private var errorMessage: String?
    @State private var isImporting = false

    private let importService = AudioImportService()

    /// mp3 / m4a / wav 可直接讀取；webm 會在匯入時自動轉檔（僅取音軌）
    private let supportedExtensions = ["mp3", "m4a", "wav", "webm"]

    /// 新加入的檔案預設用哪個語系；沿用 Settings 裡的全域偏好值當預設，
    /// 使用者仍可針對個別檔案單獨覆蓋，不受此值之後變動影響
    @AppStorage("selectedLocale") private var defaultLocale: String = "zh-TW"

    private var supportedTypes: [UTType] {
        [.mp3, .wav, .mpeg4Audio, UTType(filenameExtension: "webm")].compactMap { $0 }
    }

    /// 單一待匯入檔案目前的處理階段
    private enum ImportItemStatus: Equatable {
        case waiting
        case converting
        case done
        case failed(String)

        var label: String {
            switch self {
            case .waiting: return "等待中"
            case .converting: return "轉換中…"
            case .done: return "已完成"
            case .failed(let reason): return "失敗：\(reason)"
            }
        }

        var color: Color {
            switch self {
            case .waiting: return .secondary
            case .converting: return .blue
            case .done: return .green
            case .failed: return .red
            }
        }
    }

    // MARK: - 語系清單（對應 Apple Speech Framework / SFSpeechRecognizer 支援的地區語系）
    // 實際可用語系會因系統版本與裝置已安裝的聽寫語言而略有差異；
    // 這裡列出目前 Apple 平台常見支援的語系，供匯入時逐檔選擇。
    private static let availableLocales: [(code: String, label: String)] = [
        ("ar-SA", "Arabic (Saudi Arabia)"),
        ("yue-CN", "Cantonese (China mainland)"),
        ("ca-ES", "Catalan (Spain)"),
        ("zh-CN", "Chinese (China mainland)"),
        ("zh-HK", "Chinese (Hong Kong)"),
        ("zh-TW", "Chinese (Taiwan)"),
        ("hr-HR", "Croatian (Croatia)"),
        ("cs-CZ", "Czech (Czechia)"),
        ("da-DK", "Danish (Denmark)"),
        ("nl-BE", "Dutch (Belgium)"),
        ("nl-NL", "Dutch (Netherlands)"),
        ("en-AU", "English (Australia)"),
        ("en-CA", "English (Canada)"),
        ("en-IN", "English (India)"),
        ("en-ID", "English (Indonesia)"),
        ("en-IE", "English (Ireland)"),
        ("en-NZ", "English (New Zealand)"),
        ("en-PH", "English (Philippines)"),
        ("en-SA", "English (Saudi Arabia)"),
        ("en-SG", "English (Singapore)"),
        ("en-ZA", "English (South Africa)"),
        ("en-AE", "English (United Arab Emirates)"),
        ("en-GB", "English (United Kingdom)"),
        ("en-US", "English (United States)"),
        ("fi-FI", "Finnish (Finland)"),
        ("fr-BE", "French (Belgium)"),
        ("fr-CA", "French (Canada)"),
        ("fr-FR", "French (France)"),
        ("fr-CH", "French (Switzerland)"),
        ("de-AT", "German (Austria)"),
        ("de-DE", "German (Germany)"),
        ("de-CH", "German (Switzerland)"),
        ("el-GR", "Greek (Greece)"),
        ("he-IL", "Hebrew (Israel)"),
        ("hi-IN-translit", "Hindi (India, transliterated)"),
        ("hi-IN", "Hindi (India)"),
        ("hi-Latn", "Hindi (Latin)"),
        ("hu-HU", "Hungarian (Hungary)"),
        ("id-ID", "Indonesian (Indonesia)"),
        ("it-IT", "Italian (Italy)"),
        ("it-CH", "Italian (Switzerland)"),
        ("ja-JP", "Japanese (Japan)"),
        ("ko-KR", "Korean (South Korea)"),
        ("ms-MY", "Malay (Malaysia)"),
        ("nb-NO", "Norwegian Bokmål (Norway)"),
        ("pl-PL", "Polish (Poland)"),
        ("pt-BR", "Portuguese (Brazil)"),
        ("pt-PT", "Portuguese (Portugal)"),
        ("ro-RO", "Romanian (Romania)"),
        ("ru-RU", "Russian (Russia)"),
        ("sk-SK", "Slovak (Slovakia)"),
        ("es-AR", "Spanish (Argentina)"),
        ("es-CL", "Spanish (Chile)"),
        ("es-CO", "Spanish (Colombia)"),
        ("es-ES", "Spanish (Spain)"),
        ("es-MX", "Spanish (Mexico)"),
        ("es-US", "Spanish (United States)"),
        ("sv-SE", "Swedish (Sweden)"),
        ("th-TH", "Thai (Thailand)"),
        ("tr-TR", "Turkish (Turkey)"),
        ("uk-UA", "Ukrainian (Ukraine)"),
        ("vi-VN", "Vietnamese (Vietnam)"),
        ("wuu-CN", "Wu Chinese / Shanghainese (China mainland)")
    ]

    var body: some View {
        VStack(spacing: 20) {

            Text("匯入音檔")
                .font(.title2)
                .bold()

            dropZone

            // 固定顯示這個區塊（而非用 if 讓它憑空出現/消失），
            // 避免拖放結束瞬間窗口高度改變，與尚未收尾的 AppKit 拖放事務相撞
            pendingFilesList
                .frame(height: 200)

            Text(errorMessage ?? " ")
                .font(.caption)
                .foregroundColor(.red)
                .textSelection(.enabled)
                .fixedSize(horizontal: false, vertical: true)
                .frame(minHeight: 14, alignment: .leading)

            HStack {
                Button("選擇檔案…") {
                    presentFilePicker()
                }
                .disabled(isImporting)

                Spacer()

                Button("取消") { dismiss() }
                    .disabled(isImporting)

                Button {
                    Task { await confirmImport() }
                } label: {
                    if isImporting {
                        HStack(spacing: 6) {
                            ProgressView().controlSize(.small)
                            Text("轉檔並匯入中…")
                        }
                    } else {
                        Text("開始匯入")
                    }
                }
                .keyboardShortcut(.defaultAction)
                .disabled(pendingURLs.isEmpty || isImporting)
            }
        }
        .padding(24)
        .frame(width: 560)
    }

    @ViewBuilder
    private var pendingFilesList: some View {
        if pendingURLs.isEmpty {
            RoundedRectangle(cornerRadius: 8)
                .fill(Color.clear)
                .overlay(
                    Text("尚未選擇任何檔案")
                        .font(.caption)
                        .foregroundColor(.secondary)
                )
        } else {
            List(pendingURLs, id: \.self) { url in
                HStack {
                    VStack(alignment: .leading, spacing: 2) {
                        Label(url.lastPathComponent, systemImage: "waveform")
                            .lineLimit(1)
                            .truncationMode(.middle)

                        // 逐檔即時狀態：等待中／轉換中…／已完成／失敗：原因
                        // 匯入尚未開始時預設顯示「等待中」，webm 檔額外提示會自動轉檔
                        HStack(spacing: 6) {
                            let status = itemStatuses[url] ?? .waiting

                            if status == .converting {
                                ProgressView()
                                    .controlSize(.mini)
                            }

                            Text(status.label)
                                .font(.caption2)
                                .foregroundColor(status.color)

                            if url.pathExtension.lowercased() == "webm", status == .waiting {
                                Text("· 匯入時將自動轉檔")
                                    .font(.caption2)
                                    .foregroundColor(.secondary)
                            }
                        }
                    }

                    Spacer()

                    // 每個檔案各自的辨識語系選單；預設帶入 Settings 全域偏好，
                    // 使用者可針對這一個檔案單獨覆蓋，不影響清單裡其他檔案
                    Picker("", selection: localeBinding(for: url)) {
                        ForEach(Self.availableLocales, id: \.code) { item in
                            Text("\(item.label) (\(item.code))").tag(item.code)
                        }
                    }
                    .labelsHidden()
                    .frame(width: 210)
                    .disabled(isImporting)
                }
                .padding(.vertical, 4)
            }
        }
    }

    /// 提供給每個檔案獨立的語系綁定；若尚未有紀錄，第一次讀取時用 defaultLocale 補上
    private func localeBinding(for url: URL) -> Binding<String> {
        Binding(
            get: { localeSelections[url] ?? defaultLocale },
            set: { localeSelections[url] = $0 }
        )
    }

    private var dropZone: some View {
        RoundedRectangle(cornerRadius: 12)
            .strokeBorder(style: StrokeStyle(lineWidth: 2, dash: [6]))
            .foregroundColor(isDropTargeted ? .accentColor : .secondary)
            .background(
                RoundedRectangle(cornerRadius: 12)
                    .fill(isDropTargeted ? Color.accentColor.opacity(0.08) : Color.clear)
            )
            .frame(height: 90)
            .overlay(
                VStack(spacing: 8) {
                    Image(systemName: "square.and.arrow.down")
                        .font(.system(size: 28))
                    Text("拖放音檔到這裡（支援 mp3 / m4a / wav / webm）")
                        .font(.callout)
                        .foregroundColor(.secondary)
                }
            )
            .onDrop(of: [.fileURL], isTargeted: $isDropTargeted) { providers in
                handleDrop(providers: providers)
                return true
            }
    }

    private func handleDrop(providers: [NSItemProvider]) {
        for provider in providers {
            provider.loadItem(forTypeIdentifier: UTType.fileURL.identifier, options: nil) { item, _ in
                guard let data = item as? Data,
                      let url = URL(dataRepresentation: data, relativeTo: nil) else { return }

                // 刻意延後一點點時間再變更狀態：onDrop 的 completion handler
                // 仍在 AppKit 的拖放事務（drag session）收尾過程中被呼叫，
                // 這時如果立刻同步改動會觸發畫面結構變化的 @State，
                // 容易撞上尚未結束的 kDragIPCWithinWindow，
                // 產生 layout recursion 與「Publishing changes from within view updates」的警告。
                // 等到下一輪 runloop（拖放事務已完全收尾）再更新，可以避開這個衝突。
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.05) {
                    var transaction = Transaction()
                    transaction.disablesAnimations = true
                    withTransaction(transaction) {
                        addURLIfSupported(url)
                    }
                }
            }
        }
    }

    private func presentFilePicker() {
        let panel = NSOpenPanel()
        panel.allowsMultipleSelection = true
        panel.canChooseDirectories = false
        panel.allowedContentTypes = supportedTypes

        if panel.runModal() == .OK {
            panel.urls.forEach { addURLIfSupported($0) }
        }
    }

    private func addURLIfSupported(_ url: URL) {
        let fileExtension = url.pathExtension.lowercased()
        guard supportedExtensions.contains(fileExtension) else {
            errorMessage = "不支援的格式：\(url.lastPathComponent)"
            return
        }
        errorMessage = nil
        if !pendingURLs.contains(url) {
            pendingURLs.append(url)
            localeSelections[url] = defaultLocale
            itemStatuses[url] = .waiting
        }
    }

    /// 實際呼叫 AudioImportService：webm 會先在此步驟轉檔，再讀取時長並組成 AudioFile；
    /// 每個檔案帶著自己選定的 locale 一起送進去，並透過 onItemStart / onItemFinish
    /// 即時更新畫面上每一列的狀態文字，讓使用者看得到目前處理到哪個檔案。
    private func confirmImport() async {
        isImporting = true
        errorMessage = nil

        let items = pendingURLs.map { url in
            (url: url, locale: localeSelections[url] ?? defaultLocale)
        }

        let result = await importService.makeAudioFiles(
            from: items,
            onItemStart: { url in
                Task { @MainActor in
                    itemStatuses[url] = .converting
                }
            },
            onItemFinish: { url, outcome in
                Task { @MainActor in
                    switch outcome {
                    case .success:
                        itemStatuses[url] = .done
                    case .failure(let error):
                        itemStatuses[url] = .failed(error.localizedDescription)
                    }
                }
            }
        )
        isImporting = false

        if !result.failures.isEmpty {
            let names = result.failures.map { $0.0.lastPathComponent }.joined(separator: "、")
            let reasons = result.failures
                .map { "\($0.0.lastPathComponent)：\($0.1.localizedDescription)" }
                .joined(separator: "\n")
            errorMessage = result.imported.isEmpty
                ? "匯入失敗：\n\(reasons)"
                : "以下檔案匯入失敗（\(names)），其餘已成功匯入：\n\(reasons)"
        }

        guard !result.imported.isEmpty else { return }

        onImport(result.imported)

        if result.failures.isEmpty {
            dismiss()
        } else {
            // 有部分失敗時保留視窗，讓使用者看清楚錯誤訊息，並移除已成功的檔案避免重複匯入
            let importedURLs = Set(result.imported.map(\.originalSourceURL))
            pendingURLs.removeAll { importedURLs.contains($0) }
        }
    }
}

#Preview {
    ImportView(onImport: { _ in })
}

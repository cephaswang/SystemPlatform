import Foundation
import Combine

/// 管理已匯入音檔與其轉錄狀態的共用資料來源
final class AudioLibraryStore: ObservableObject {
    @Published var audioFiles: [AudioFile] = [] {
        didSet {
            // 從磁碟載入時也會經過這個 setter，但那個動作本身不該再觸發一次寫檔，
            // 所以載入期間用 isRestoringFromDisk 擋掉。
            guard !isRestoringFromDisk else { return }
            persist()
        }
    }
    @Published var selectedAudioFileID: AudioFile.ID?

    var selectedAudioFile: AudioFile? {
        audioFiles.first { $0.id == selectedAudioFileID }
    }

    private let recognitionService = SpeechRecognitionService()

    // MARK: - 持久化（App 重啟後還原音檔清單與轉錄結果）

    private var isRestoringFromDisk = false

    private var persistenceDirectoryURL: URL {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first!
        return base.appendingPathComponent("VoxNoteImport", isDirectory: true)
    }

    private var persistenceFileURL: URL {
        persistenceDirectoryURL.appendingPathComponent("library.json")
    }

    init() {
        loadFromDisk()
    }

    /// App 啟動時載入上次保存的音檔清單（含逐字稿）。
    /// 第一次啟動、檔案不存在，或格式對不上時，安靜地從空清單開始，不視為錯誤，
    /// 避免因為存檔格式升級或損毀就整個開不起來。
    private func loadFromDisk() {
        guard let data = try? Data(contentsOf: persistenceFileURL) else { return }
        guard let decoded = try? JSONDecoder().decode([AudioFile].self, from: data) else {
            print("⚠️ AudioLibraryStore：無法解析已存檔的音檔清單，忽略並從空清單開始")
            return
        }
        isRestoringFromDisk = true
        audioFiles = decoded
        isRestoringFromDisk = false
    }

    /// 將目前的音檔清單（含逐字稿）寫回磁碟。
    /// 在背景執行緒編碼與寫檔，避免逐字稿內容較大時卡住主執行緒／UI。
    private func persist() {
        let snapshot = audioFiles
        let directory = persistenceDirectoryURL
        let fileURL = persistenceFileURL

        DispatchQueue.global(qos: .utility).async {
            do {
                try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
                let data = try JSONEncoder().encode(snapshot)
                try data.write(to: fileURL, options: .atomic)
            } catch {
                print("⚠️ AudioLibraryStore：儲存音檔清單失敗：\(error.localizedDescription)")
            }
        }
    }

    // MARK: - 刪除

    /// 刪除單一音檔（連同其轉錄稿）。
    /// 是否要跳確認提示由呼叫端（AudioLibraryView）負責，這裡只做實際刪除。
    func deleteAudioFile(_ file: AudioFile) {
        DispatchQueue.main.async {
            self.audioFiles.removeAll { $0.id == file.id }
            if self.selectedAudioFileID == file.id {
                self.selectedAudioFileID = nil
            }
        }
    }

    /// 清空整個音檔清單（連同所有轉錄稿）。
    /// 是否要跳確認提示由呼叫端（AudioLibraryView）負責，這裡只做實際刪除。
    func deleteAllAudioFiles() {
        DispatchQueue.main.async {
            self.audioFiles.removeAll()
            self.selectedAudioFileID = nil
        }
    }

    // MARK: - 匯入與轉錄（原有邏輯，未變動）

    /// 對單一音檔啟動語音辨識：locale 讀取「該檔案自己」在匯入時選定的語系
    /// （見 AudioFile.locale），不再讀全域 UserDefaults，讓每個檔案的語系互相獨立。
    /// 辨識引擎（Apple Speech / Whisper）維持全域設定，因為那牽涉到隱私與功能選擇，
    /// 通常是使用者對整個 App 的一次性選擇。
    ///
    /// 整段包進 Task { @MainActor in } ——包含開頭同步的 .status = .processing——
    /// 是為了避免這個函式剛好在 sheet dismiss 的 view-update transaction 裡被呼叫，
    /// 同步修改 @Published 屬性觸發「Publishing changes from within view updates」。
    func startTranscription(for fileID: AudioFile.ID) {
        DispatchQueue.main.async {
            guard let index = self.audioFiles.firstIndex(where: { $0.id == fileID }),
                  self.audioFiles[index].status == .pending else { return }

            self.audioFiles[index].status = .processing
            let audioURL = self.audioFiles[index].sourceURL
            let locale = self.audioFiles[index].locale

            let engine = SettingsView.RecognitionEngine(
                rawValue: UserDefaults.standard.string(forKey: "recognitionEngine") ?? ""
            ) ?? .appleSpeech

            Task { @MainActor in
                do {
                    let segments = try await self.recognitionService.recognize(
                        audioURL: audioURL,
                        locale: locale,
                        engine: engine
                    )
                    guard let idx = self.audioFiles.firstIndex(where: { $0.id == fileID }) else { return }
                    self.audioFiles[idx].transcriptSegments = segments
                    self.audioFiles[idx].status = .completed
                } catch {
                    guard let idx = self.audioFiles.firstIndex(where: { $0.id == fileID }) else { return }
                    self.audioFiles[idx].status = .failed
                }
            }
        }
    }

    func appendImportedFiles(_ files: [AudioFile]) {
        DispatchQueue.main.async {
            self.audioFiles.append(contentsOf: files)
            files.forEach { self.startTranscription(for: $0.id) }
        }
    }
}

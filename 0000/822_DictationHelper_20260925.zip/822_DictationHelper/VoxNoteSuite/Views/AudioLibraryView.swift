import SwiftUI

struct AudioLibraryView: View {

    @EnvironmentObject private var library: AudioLibraryStore
    @State private var showingImportSheet = false
    @State private var showingExportSheet = false

    // 個別刪除：先記下「使用者想刪的那一筆」，跳出確認後才真的執行，
    // 避免手滑誤刪、且能在提示文字裡帶出檔名。
    @State private var fileAwaitingDeleteConfirmation: AudioFile?

    // 全部刪除：用 confirmationDialog 二次確認，措辭要比單筆刪除更明確警示。
    @State private var showingDeleteAllConfirmation = false

    var body: some View {
        let debugStatus: AudioFile.TranscriptionStatus = library.selectedAudioFile?.status ?? .pending
        let _ = print("🖼️ AudioLibraryView body 重新評估，selectedAudioFile.status=\(debugStatus)")
        NavigationSplitView {
            List(selection: $library.selectedAudioFileID) {
                ForEach(library.audioFiles) { file in
                    rowView(for: file)
                }
            }
           // .frame(minWidth: 220)
            .toolbar {
                ToolbarItem {
                    Button {
                        showingImportSheet = true
                    } label: {
                        Label("匯入音檔", systemImage: "plus")
                    }
                }
                ToolbarItem {
                    Button(role: .destructive) {
                        showingDeleteAllConfirmation = true
                    } label: {
                        Label("全部刪除", systemImage: "trash.fill")
                    }
                    .disabled(library.audioFiles.isEmpty)
                }
            }
        } detail: {
            if let selected = library.selectedAudioFile {
                TranscriptEditorView(audioFile: selected)
                    .id("\(selected.id)-\(selected.status)")   // 新增這行
                    .toolbar {
                        ToolbarItem {
                            Button {
                                showingExportSheet = true
                            } label: {
                                Label("匯出", systemImage: "square.and.arrow.up")
                            }
                            .disabled(selected.status != .completed)
                        }
                    }
            } else {
                ContentUnavailableView(
                    "尚未選擇音檔",
                    systemImage: "waveform",
                    description: Text("從左側清單選擇一個音檔，或點擊「匯入音檔」開始")
                )
            }
        }
        .frame(minWidth: 560, minHeight: 640)   // ← 加在這裡，緊接在 NavigationSplitView 之後
        .sheet(isPresented: $showingImportSheet) {
            // 改用 appendImportedFiles(_:)：內部已包進 Task { @MainActor in }，
            // 避免這個 closure 剛好在 sheet dismiss 的 view-update 週期裡
            // 同步修改 @Published 的 audioFiles，觸發
            // 「Publishing changes from within view updates」警告。
            ImportView { importedFiles in
                library.appendImportedFiles(importedFiles)
            }
        }
        .sheet(isPresented: $showingExportSheet) {
            if let selected = library.selectedAudioFile {
                ExportSheetView(audioFile: selected)
            }
        }
        // 個別刪除確認
        .alert(
            "刪除「\(fileAwaitingDeleteConfirmation?.displayName ?? "")」？",
            isPresented: Binding(
                get: { fileAwaitingDeleteConfirmation != nil },
                set: { if !$0 { fileAwaitingDeleteConfirmation = nil } }
            ),
            presenting: fileAwaitingDeleteConfirmation
        ) { file in
            Button("刪除", role: .destructive) {
                library.deleteAudioFile(file)
            }
            Button("取消", role: .cancel) {}
        } message: { _ in
            Text("這個音檔的轉錄文字稿將一併刪除，且無法復原。")
        }
        // 全部刪除確認
        .confirmationDialog(
            "確定要刪除全部 \(library.audioFiles.count) 個音檔？",
            isPresented: $showingDeleteAllConfirmation,
            titleVisibility: .visible
        ) {
            Button("刪除全部音檔與轉錄稿", role: .destructive) {
                library.deleteAllAudioFiles()
            }
            Button("取消", role: .cancel) {}
        } message: {
            Text("所有音檔清單與已完成的逐字稿都會被永久刪除，此動作無法復原。")
        }
    }

    private func statusIcon(for status: AudioFile.TranscriptionStatus) -> String {
        switch status {
        case .pending: return "clock"
        case .processing: return "waveform.circle"
        case .completed: return "checkmark.circle.fill"
        case .failed: return "exclamationmark.triangle.fill"
        }
    }

    private func statusColor(for status: AudioFile.TranscriptionStatus) -> Color {
        switch status {
        case .pending: return .secondary
        case .processing: return .blue
        case .completed: return .green
        case .failed: return .red
        }
    }

    @ViewBuilder
    private func rowView(for file: AudioFile) -> some View {
        AudioFileRow(file: file, statusIcon: statusIcon, statusColor: statusColor)
            .tag(file.id)
            .swipeActions(edge: .trailing, allowsFullSwipe: false) {
                deleteButton(for: file)
            }
            .contextMenu {
                deleteButton(for: file)
            }
    }

    @ViewBuilder
    private func deleteButton(for file: AudioFile) -> some View {
        Button(role: .destructive) {
            fileAwaitingDeleteConfirmation = file
        } label: {
            Label("刪除", systemImage: "trash")
        }
    }
}

/// 抽成獨立的列 view，避免整條 modifier chain（tag / swipeActions / contextMenu）
/// 和內部的 HStack 疊在同一個表達式裡，導致 type-checker 逾時。
private struct AudioFileRow: View {
    let file: AudioFile
    let statusIcon: (AudioFile.TranscriptionStatus) -> String
    let statusColor: (AudioFile.TranscriptionStatus) -> Color

    var body: some View {
        HStack {
            Image(systemName: statusIcon(file.status))
                .foregroundColor(statusColor(file.status))

            VStack(alignment: .leading, spacing: 2) {
                Text(file.displayName)
                    .font(.body)
                Text(file.durationDescription)
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
        }
    }
}

#Preview {
    AudioLibraryView()
        .environmentObject(AudioLibraryStore())
}

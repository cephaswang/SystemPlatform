import Foundation

/// 代表逐字稿中的一個句子片段
struct TranscriptSegment: Identifiable, Equatable, Codable {

    let id: UUID
    var text: String
    var startTime: TimeInterval
    var endTime: TimeInterval

    /// 語音辨識引擎回傳的信心度（0.0 ~ 1.0），供未來標示「可能辨識錯誤」使用
    var confidence: Double

    init(
        id: UUID = UUID(),
        text: String,
        startTime: TimeInterval,
        endTime: TimeInterval,
        confidence: Double = 1.0
    ) {
        self.id = id
        self.text = text
        self.startTime = startTime
        self.endTime = endTime
        self.confidence = confidence
    }

    /// UI 顯示用的時間戳字串，例如 "00:12"
    var timestampDescription: String {
        let totalSeconds = Int(startTime.rounded())
        let minutes = totalSeconds / 60
        let seconds = totalSeconds % 60
        return String(format: "%02d:%02d", minutes, seconds)
    }
}

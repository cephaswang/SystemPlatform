import Foundation
import AppKit
import AVFoundation
import Speech

/// 統一管理 App 所需的系統權限請求與現況查詢
/// （VoxNoteImport 主要用於：語音辨識授權、使用者選取檔案的讀寫授權）
struct PermissionManager {

    enum PermissionStatus {
        case authorized
        case denied
        case notDetermined
    }

    /// 語音辨識權限現況
    var speechRecognitionStatus: PermissionStatus {
        switch SFSpeechRecognizer.authorizationStatus() {
        case .authorized:
            return .authorized
        case .denied, .restricted:
            return .denied
        case .notDetermined:
            return .notDetermined
        @unknown default:
            return .notDetermined
        }
    }

    /// 請求語音辨識權限，回傳是否取得授權
    func requestSpeechRecognitionPermission() async -> Bool {
        await withCheckedContinuation { continuation in
            SFSpeechRecognizer.requestAuthorization { status in
                continuation.resume(returning: status == .authorized)
            }
        }
    }

    /// 麥克風權限現況（VoxNoteImport 目前不主動錄音，僅在未來支援「同時錄音並匯入」時使用）
    var microphoneStatus: PermissionStatus {
        switch AVCaptureDevice.authorizationStatus(for: .audio) {
        case .authorized:
            return .authorized
        case .denied, .restricted:
            return .denied
        case .notDetermined:
            return .notDetermined
        @unknown default:
            return .notDetermined
        }
    }

    /// 請求麥克風權限，回傳是否取得授權
    func requestMicrophonePermission() async -> Bool {
        await AVCaptureDevice.requestAccess(for: .audio)
    }

    /// 提示使用者前往系統設定開啟權限（適用於使用者曾拒絕、需手動開啟的情況）
    func openSystemPrivacySettings() {
        guard let url = URL(string: "x-apple.systempreferences:com.apple.preference.security?Privacy") else { return }
        NSWorkspace.shared.open(url)
    }
}


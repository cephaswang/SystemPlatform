import Foundation
import AppKit
import Combine

/// Launcher 可開啟的兩個獨立 App。
/// 注意：此列舉僅記錄「Bundle Identifier」與「顯示名稱」，
/// 不 import、不引用 VoxNoteImport 或 VoiceCapture 專案中的任何原始碼檔案，
/// 兩個 App 之間唯一的關聯僅止於此處的識別字串。
enum LauncherTarget {
    case voxNoteImport
    case voiceCapture

    /// 對應各自專案 Info.plist 中設定的 Bundle Identifier
    var bundleIdentifier: String {
        switch self {
        case .voxNoteImport:
            return "com.voxnote.import"
        case .voiceCapture:
            return "com.voxnote.voicecapture"
        }
    }

    var displayName: String {
        switch self {
        case .voxNoteImport:
            return "VoxNote 匯入轉錄"
        case .voiceCapture:
            return "聽抄小幫手"
        }
    }
}

enum AppLauncherError: LocalizedError {
    case appNotFound(String)
    case launchFailed(String)

    var errorDescription: String? {
        switch self {
        case .appNotFound(let name):
            return "找不到「\(name)」，請確認已安裝於 Applications 資料夾。"
        case .launchFailed(let name):
            return "「\(name)」啟動失敗。"
        }
    }
}

/// 負責以系統層級（NSWorkspace）開啟另外兩個獨立 App，
/// 不與對方共用任何 Model / Service / Assets 檔案。
final class AppLauncherService: ObservableObject {

    /// 依 Bundle Identifier 尋找並開啟對應的 App。
    func open(_ target: LauncherTarget) throws {
        guard let appURL = NSWorkspace.shared.urlForApplication(
            withBundleIdentifier: target.bundleIdentifier
        ) else {
            throw AppLauncherError.appNotFound(target.displayName)
        }

        let configuration = NSWorkspace.OpenConfiguration()
        configuration.activates = true

        NSWorkspace.shared.openApplication(
            at: appURL,
            configuration: configuration
        ) { _, error in
            if error != nil {
                // 開啟失敗時僅記錄，不中斷 Launcher 本身
                NSLog("VoxNoteLauncher: 開啟 \(target.displayName) 失敗：\(String(describing: error))")
            }
        }
    }
}

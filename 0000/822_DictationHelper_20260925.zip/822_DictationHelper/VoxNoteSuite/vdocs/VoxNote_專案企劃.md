# VoxNote 語音工作站 — macOS 語音轉文字整合企劃

> **本版更新說明（v3，2026/09/25）**：本版依 2026/09/25 最新的專案目錄（`dir.txt`）與 App 實際畫面校對，
> 並承接 2026/09/22 那一版所列的「三項架構落差」與「兩個遺失檔案」。這幾項在本版已有結論，
> 結論寫在「架構現況」一節；仍無法確認的項目，統一留在第七節待辦。
>
> **標記說明**：✅ 已確認存在　🆕 前版未列出　🟡 依畫面或檔名推論，尚未對照原始碼　
> ⚠️ 待確認　🔴 需處理

## 版本紀錄

| 版本 | 日期 | 內容 |
|---|---|---|
| v1 | — | 原始企劃：三個獨立 `.xcodeproj` + Workspace（Launcher、VoxNoteImport、VoiceCapture），三者原始碼零共用 |
| v2 | 2026/09/22 | 依當時 `dir.txt` 校對，列出三項架構落差與兩個疑似遺失的 App 進入點檔案（前版年份寫作 2025，依檔案時間戳判斷應為 2026，本版已更正） |
| v3 | 2026/09/25 | 依最新目錄與畫面校對：三項落差改為結論；新增「環境設置」「麥克風聽抄」「使用教學」；更新文件清單與待辦 |

## 專案定位

**VoxNote 語音工作站** 是一個整合品牌，底下收納兩個**功能互補**的 macOS 語音轉文字情境：

| 模組 | 專案代號 | 核心情境 |
|---|---|---|
| **VoxNote 匯入轉錄** | VoxNoteImport | 使用者「已有音檔」（教學影片、會議錄音、Podcast），匯入後離線／批次轉成文字稿，並匯出 TXT／SRT／DOCX／PDF |
| **聽抄小幫手** | VoiceCapture | 使用者「正在聽」或「正在說」，即時轉成文字稿。聲音來源可選：**系統喇叭聲音**（透過 BlackHole，例如教學影片、會議錄影）或**麥克風**（🆕 現場說話、演講、開會） |

兩者互為情境互補（事後匯入 vs. 即時聽抄）。

**目前對外的樣貌**：兩個模組已整合成**同一個 App**，視窗標題為「Dictation Helper」，
啟動畫面標題為「聽抄小幫手」，畫面上有「匯入音檔轉文字稿」「聽抄」兩個入口，
下方是環境狀態列。「VoxNote」目前只出現在原始碼資料夾名稱（`VoxNoteSuite/`）與本文件，
UI 上並未使用。

> ⚠️ **品牌名稱待決定**：對外要沿用「聽抄小幫手／Dictation Helper」，還是改用「VoxNote」？
> 這會影響 App 名稱、Bundle Identifier、圖示與上架說明文字，建議在下一次發佈前定案。

---

## 架構現況（前版三項落差的結論）

| 前版落差 | 前版判斷 | 本版結論 | 依據 |
|---|---|---|---|
| 落差 1：單一 `.xcodeproj` | 不確定是刻意合併，還是「零共用、獨立簽署」原則跑掉 | **判定為刻意的單一 App 架構**：兩個模組在同一個視窗內切換，不再是兩個各自獨立編譯的 App | 目錄只有一個 `Dictation Helper.xcodeproj`；教學截圖中，模式選擇、聽抄、匯入三個畫面都在「Dictation Helper」同一個視窗，聽抄與匯入畫面左上角有返回鍵 🟡 |
| 落差 2：`VoxNoteSuite/` 與 `Dictation Helper/` 平行而非巢狀 | 與原企劃的巢狀結構不同 | 兩個資料夾是**同一個 App 內的兩組原始碼**，平行擺放即可，不需要改回巢狀 | 同上 🟡 |
| 落差 3：`RootApp.swift`／`RootView.swift` 是否取代 Launcher | Launcher 依附在 VoiceCapture 的可能性 | **是**：`RootApp`／`RootView` 應為整個 App 的進入點與根畫面，模式選擇由 `LauncherView` 呈現 🟡 | 只有一個可見的視窗與導覽流程；`LauncherApp.swift` 與 `VoxNoteImportApp.swift` 都不再需要（見下） |
| 🔴 `LauncherApp.swift` 遺失 | 找不到此檔 | **不是遺失，是併入單一 App 後不再需要**：一個 Target 只能有一個 App 進入點，兩支獨立進入點檔案與備份 `.txt` 已被移除 🟡 | 同上，並與前版所述「移除編不過的 `.txt` 備份檔」的排查紀錄相符 |
| 🔴 `VoxNoteImportApp.swift` 遺失 | `VoxNoteSuite/App/` 是空的 | 同上；`VoxNoteSuite/App/` 是**空資料夾**，可以刪除 | 目錄仍顯示 `App/` 大小為 0 |

> 🟡 上表結論是依畫面行為與目錄結構推論。要完全確認，需在 Xcode 檢查 Target 的 Compile Sources：
> 只應有**一個**含 `@main` 的檔案，且沒有殘留的舊進入點。這項已列入第七節待辦。

**因此，原企劃的整合原則「三個 App 零共用、各自獨立簽署」不再成立**，改為
「單一 App、單一簽署與版本號，內部依功能分資料夾」，詳見第六節。

---

## 一、專案文件（企劃階段）

| 檔案 | 功能 | 現況 |
|---|---|---|
| `01_企劃書.md` | 產品定位、目標使用者、競品分析（如 Otter.ai、飛書妙記）、商業模式 | 目錄中未見獨立檔案，內容併入本文件 |
| `02_功能規格書.md` | 詳列 MVP 與後續版本功能 | 未見；功能規格目前散見於本文件與聽抄企劃書 v2.0 |
| `03_使用者流程圖.md` | 從「匯入音檔」到「取得文字稿」的操作路徑 | 未見；操作流程已寫在使用教學頁（見下） |
| `04_UI線框圖/` | 主畫面、錄音清單、轉錄結果頁的示意圖 | 未見。**更正前版推測**：`docs/helpdocs/images/` 的 `c00`～`c10`、`c01_import`、`c01_live` 是使用教學的畫面截圖，不是線框圖；`docs/` 下的 `b04.jpg`、`b05.jpg` 用途待確認 |
| `05_技術選型評估.md` | 比較 Apple Speech Framework、Whisper、第三方 API | 未見 |
| `06_整合架構說明.md` | 專案結構、Launcher 啟動邏輯、模組邊界 | 未見；本文件「架構現況」與第六節暫代 |
| `喇叭聽抄小幫手_macOS_App_企劃書.txt` | VoiceCapture 的獨立企劃書 | ✅ 已更新為 **v2.0（2026/09/25）**，位於 `Dictation Helper/docs/`；改為純文字規格，不含程式碼 |
| `App_Review_回覆_VoiceCapture.md` | App Store 審查回覆紀錄 | ✅ 存在於 `Dictation Helper/docs/` |
| `聽抄小幫手_使用說明.docx` / `.pdf` | 使用者說明文件 | 🔴 最新目錄**已不在** `docs/` 下，改由網頁版教學取代；⚠️ 是刻意移除，還是搬到別處，待確認 |
| `docs/helpdocs/index.html` 🆕 | 使用教學網頁：事前環境設置、匯入音檔轉文字稿、聽抄（含系統聲音與麥克風兩種來源）、常見狀況 | ✅ 存在，圖片在 `docs/helpdocs/images/`；另有打包檔 `docs/helpdocs.zip`；並有 YouTube 與網站兩個教學影片連結 |
| `docs/setup.sh`、`docs/uninstall.sh` 🆕 | 環境安裝與移除腳本 | ✅ 存在 |
| `VoxNote_專案企劃_001.md` | 本企劃書舊版快照 | ⚠️ 最新目錄的 `docs/` 下已看不到 `VoxNote/` 子資料夾；本文件目前放在 `VoxNoteSuite/vdocs/` |
| `docs/ScreenRecorderPro_proposal.txt` 🆕 | 另一個專案（ScreenRecorderPro）的企劃書 | ✅ 存在，但**不屬於本產品**，建議移到該專案的資料夾 |
| `docs/c001.txt`、`docs/readme.txt` 🆕 | 用途待確認 | ⚠️ 檔案很小（320、78 位元組） |
| `VoxNoteSuite/vdir.txt` 🆕 | 前次目錄快照 | ✅ 存在，供校對用 |

---

## 二、專案總覽結構（依 2026/09/25 目錄校對）

```
822_DictationHelper/                       專案根目錄（資料夾名稱依前版，以實際為準）
├── Dictation Helper.xcodeproj/             唯一的 Xcode 專案設定檔（內含 EmbedFFmpeg.sh）
├── Dictation Helper/                       App 進入點、聽抄模組、環境前置檢查、說明、文件
├── VoxNoteSuite/                           匯入轉錄模組、模式選擇畫面、環境設置
├── Scripts/                                建置腳本（EmbedFFmpeg.sh）
├── CertificateSigningRequest.*             簽署憑證相關檔案
└── generate_csr.sh                         產生 CSR 的腳本
```

> 🔴 **安全提醒**：`CertificateSigningRequest.key` 是私鑰，不應放進版本控管、壓縮分享或隨專案散布。

---

## 三、Launcher（模式選擇與導覽）

原設計是獨立的 VoxNoteLauncher App，以「開啟另一個 App Bundle」的方式串接兩個模組。
現況已改為 **App 內導覽**：

| 檔案／資料夾 | 功能 | 現況 |
|---|---|---|
| `Dictation Helper/RootApp.swift` | App 進入點 | ✅ 存在 🟡 推論為整個 App 唯一的進入點，取代 `LauncherApp.swift`、`VoxNoteImportApp.swift`、`VoiceCaptureApp.swift` |
| `Dictation Helper/RootView.swift` | 根畫面，負責在各畫面之間切換 | ✅ 存在 🟡 推論 |
| `VoxNoteSuite/LauncherView.swift` | 模式選擇畫面：「匯入音檔轉文字稿」「聽抄」兩個入口，下方有環境狀態列（例如「聽抄小幫手環境已設置完成」，點一下開啟環境設置視窗） | ✅ 存在 🟡 環境狀態列是否由此檔繪製，待確認 |
| `VoxNoteSuite/AppLauncherService.swift` | 以 `NSWorkspace` 開啟另一個 App Bundle | ✅ 存在；⚠️ 改成單一 App 後是否還被使用，待確認，若已無用可移除 |
| `LauncherApp.swift`、`VoxNoteLauncher.xcodeproj`、獨立 Launcher 的 `Assets`、`Info.plist` | 原設計的獨立 Launcher | 不再需要（見「架構現況」） |
| `Dictation Helper/Assets.xcassets` | App 圖示與色彩 | ✅ 存在，整個 App 共用一份 |

---

## 四、VoxNoteImport（匯入轉錄，位於 `VoxNoteSuite/`）

| 檔案／資料夾 | 功能 | 現況 |
|---|---|---|
| `App/` | 原本放 `VoxNoteImportApp.swift` | 空資料夾，不再需要，可刪除 |
| `Views/AudioLibraryView.swift` | 已匯入音檔清單與轉錄狀態（畫面左側清單，顯示轉錄狀態與長度，可新增、刪除項目） | ✅ 存在 |
| `Views/AudioLibraryStore.swift` | 音檔清單與轉錄狀態的共用資料來源 | ✅ 存在；語意上屬於狀態管理層，之後可考慮移至獨立的 `Stores/` 資料夾 |
| `Views/ImportView.swift` | 拖放或「選擇檔案」匯入介面（支援 mp3／m4a／wav／webm），並可選擇辨識語系 | ✅ 存在 |
| `Views/TranscriptEditorView.swift` | 顯示逐字稿（分段、含時間戳記） | ✅ 存在；「編輯」功能的範圍待確認 |
| `Views/ExportSheetView.swift` | 匯出視窗：選 TXT 純文字／SRT 字幕檔／DOCX 文件／PDF 文件，可勾選「包含時間戳記」 | ✅ 存在 |
| `Views/SettingsView.swift` | 設定畫面 | ✅ 存在；前版企劃描述為「語言選擇、辨識引擎切換、快捷鍵設定」，⚠️ 實際內容待確認 |
| `Models/AudioFile.swift` | 音檔物件（路徑、時長、格式、狀態） | ✅ 存在 |
| `Models/TranscriptSegment.swift` | 單句轉錄結果（文字、起訖時間、信心度） | ✅ 存在 |
| `Services/AudioImportService.swift` | 音檔讀取與格式相容性檢查 | ✅ 存在 |
| `Services/SpeechRecognitionService.swift` | 呼叫語音辨識引擎，回傳文字結果 | ✅ 存在 |
| `Services/AudioConverterService.swift` | 音檔格式轉換（webm 轉 m4a、辨識前轉 .caf） | ✅ 存在 |
| `Services/ExportService.swift` | 將逐字稿輸出為指定檔案格式 | ✅ 存在 |
| `Utilities/PermissionManager.swift` | 管理語音辨識／麥克風權限請求 | ✅ 存在 |
| `Resources/Localizable.strings` | 多語系文字（繁中／英文） | 未見 |
| `Tests/VoxNoteImportTests.swift` | 單元測試 | 未見 |
| `vdocs/VoxNote_專案企劃.md` | 本文件 | ✅ 存在 |

> 📌 **webm 與 ffmpeg**：AVFoundation 無法原生解析 webm 容器，因此由 `AudioImportService` 呼叫
> `AudioConverterService`，以 ffmpeg 抽出音軌轉成 `.m4a`，原始 webm 保留於
> `AudioFile.originalSourceURL`。ffmpeg 現在有三個相關環節：
> 1. 環境設置視窗有「ffmpeg (webm 轉檔用)」檢查項目，缺少時可按「重新安裝外掛」，
>    由使用者在終端機執行 `setup.sh` 安裝
> 2. 專案內有 `EmbedFFmpeg.sh` 建置腳本（`Scripts/` 與 `Dictation Helper.xcodeproj/` 各一份）
> 3. 原企劃的規劃：發行版將已簽署的 ffmpeg 打包進 App Bundle；開發階段退而尋找
>    `/opt/homebrew/bin/ffmpeg`、`/usr/local/bin/ffmpeg`
>
> ⚠️ 三者實際的取得順序與優先權待確認，確定後請補進本節。

---

## 五、VoiceCapture（聽抄小幫手，位於 `Dictation Helper/`）

| 檔案／資料夾 | 功能 | 現況 |
|---|---|---|
| `ContentView.swift` | 聽抄畫面：語系選單、輸入裝置選單、開始／停止、即時辨識、已存檔內容 | ✅ 存在，功能見下方「聽抄功能現況」 |
| `SpeechTranscriber.swift` | 語音辨識核心邏輯（含雙語模式） | ✅ 存在 |
| `AudioDeviceManager.swift` | 列舉輸入裝置、讀寫系統預設輸入裝置 | ✅ 存在；🆕 排除內部臨時聚合裝置 `CADefaultDeviceAggregate-*` |
| `PrerequisiteChecker.swift` 🆕 | 偵測 BlackHole 是否已安裝；未安裝時把 `setup.sh` 複製到桌面 | ✅ 存在，用途已確認 |
| `SetupScript.swift` 🆕 | 安裝腳本的檔名與資訊，供前置檢查與安裝說明視窗使用 | ✅ 存在，用途已確認 |
| `HelpView.swift` 🆕 | App 內說明頁 | ✅ 存在 🟡 依檔名推論，內容待補充 |
| `RootApp.swift`、`RootView.swift` 🆕 | 見「三、Launcher」 | ✅ 存在 🟡 |
| `Assets.xcassets` | App 圖示與影像資源 | ✅ 存在 |
| `docs/` | 文件、腳本與使用教學 | ✅ 存在，見第一節 |
| `Info.plist`、`.entitlements` | 權限宣告與沙盒設定 | 未見獨立檔案，⚠️ 需確認麥克風與語音辨識使用說明是否已設定在 Target 的 Info 設定中 |

輸出檔案（執行期產生，非隨專案原始碼提供）：
`~/Documents/transcript_YYYY-MM-DD_HHmmss.txt`

### 聽抄功能現況

- **兩種聲音來源** 🆕
  - **系統聲音（BlackHole 2ch）**：按下「開始聽抄」時，自動把系統輸出切到 Multi-Output Device、輸入切到 BlackHole 2ch，使用者不必再進「系統設定 › 聲音」
  - **麥克風**：直接收錄使用者說話與周圍環境的聲音；不更動系統輸出、不需要設定 Multi-Output Device
- 輸入裝置選單在名稱後加註「（系統聲音）」或「（麥克風）」；選單只記錄使用者的選擇，按下「開始聽抄」時才套用到系統
- 畫面依所選來源顯示不同提示：系統聲音為綠色提示、麥克風為藍色提示；若自動切換輸出失敗，顯示黃色警告
- 語系清單動態讀取這台 Mac 目前支援的所有語系（實測共 63 種），並記住上次選擇
- 停止聽抄前跳出確認對話框；停止時尚未定案的內容仍會強制寫入檔案
- **雙語模式**：程式已實作（同時跑兩個辨識引擎，取信心分數較高者），但介面開關目前為隱藏 🟡
- 需要的權限：麥克風、語音辨識；兩種來源都需要（BlackHole 也屬於音訊輸入）

### 環境設置（🆕 取代原企劃的「手動設定」）

原企劃寫「需於 Audio MIDI 設定手動建立一次 Multi-Output Device」，這段已經**程式化**：

| 項目 | 說明 |
|---|---|
| 檢查四項 | BlackHole 2ch 虛擬音訊裝置、Multi-Output Device、系統輸出裝置切換、ffmpeg |
| 一鍵設置 | 自動處理缺項；四項全部完成時按鈕變灰 |
| 重新安裝外掛 | 把 `setup.sh` 複製到桌面，並提供終端機指令供複製；可能要求輸入管理員密碼；安裝完成後需**重新開機**才生效 |
| 一鍵移除 | 依序還原系統輸出裝置、移除 Multi-Output Device、解除安裝 BlackHole |
| 實作位置 | `VoxNoteSuite/AudioSetupManager.swift`（邏輯，含建立聚合裝置）、`VoxNoteSuite/AudioSetupView.swift`（畫面） |

> 只用麥克風聽抄時，不需要 Multi-Output Device 與系統輸出切換。

---

## 六、整合原則備忘（現況校正）

1. **單一 App、兩個模式**：匯入轉錄與聽抄在同一個 App 內以畫面導覽切換，
   不再以「開啟另一個 App Bundle」串接。原「三個 App 零共用」原則取消。
2. **共用的部分要有意識地管理**：目前實際共用的有環境設置（`AudioSetupManager`）、
   App 圖示與色彩（`Assets.xcassets`）、權限處理（`PermissionManager` 與 `SpeechTranscriber`
   各有一份權限請求邏輯 🟡）。之後若共用邏輯增加，再評估抽成獨立 Swift Package，
   避免兩個資料夾互相直接引用而糾纏。
3. **單一發佈**：一個 Bundle Identifier、一個版本號、一次簽署與公證。
   ⚠️ 需確認 `project.pbxproj` 裡是單一 Target，或多個 Target 共同組成 App。
4. **資料夾邊界**：`VoxNoteSuite/` 放匯入轉錄、模式選擇與環境設置；
   `Dictation Helper/` 放進入點、聽抄與說明。建議「環境設置」與「模式選擇」
   這兩組屬於整個 App 的檔案，日後移到中立的資料夾（例如 `Shared/` 或 `App/`），
   避免看起來像只屬於匯入模組。
5. **命名規範**：匯入側維持具體命名（例如 `AudioLibraryView.swift`）；
   聽抄側的 `ContentView.swift` 仍是通用命名，可視情況改為更具體的名稱。

---

## 七、待辦清單

**前版待辦的處理結果**

- [x] `VoxNoteImportApp.swift`、`LauncherApp.swift` 是否遺失 → 判定為併入單一 App 後不再需要（🟡 仍需在 Xcode 確認）
- [x] 目前是單一 Xcode 專案還是多個 `.xcodeproj` → 確認只有一個 `Dictation Helper.xcodeproj`
- [x] `PrerequisiteChecker.swift`、`SetupScript.swift` 的職責 → 已確認並寫入第五節
- [ ] `RootApp.swift`、`RootView.swift`、`HelpView.swift` 的實際職責 → 目前為推論，需對照原始碼補上
- [ ] `Info.plist`、`Assets.xcassets`、`Localizable.strings` 是否每個 Target 各一份 → 至少 `Assets.xcassets` 確認為共用一份

**本版新增**

- [ ] 🔴 在 Xcode 檢查 Compile Sources：只有一個 `@main`，無殘留的舊進入點或 `.txt` 備份
- [ ] 刪除空的 `VoxNoteSuite/App/` 資料夾
- [ ] 確認 `AppLauncherService.swift` 是否仍被使用，無用則移除
- [ ] 決定對外品牌名稱（聽抄小幫手／Dictation Helper／VoxNote）
- [ ] 確認 `聽抄小幫手_使用說明.docx`／`.pdf` 是刻意移除還是搬移
- [ ] 把 `docs/ScreenRecorderPro_proposal.txt` 移到 ScreenRecorderPro 專案資料夾
- [ ] 確認 `docs/b04.jpg`、`b05.jpg`、`c001.txt`、`readme.txt` 的用途，無用則清理
- [ ] 私鑰 `CertificateSigningRequest.key` 移出專案資料夾，另行妥善保管
- [ ] 補齊 ffmpeg 的取得順序說明（`setup.sh`、`EmbedFFmpeg.sh`、開發階段備援路徑）
- [ ] 使用教學頁補上麥克風模式的專屬截圖
- [ ] 停止聽抄後，還原原本的系統輸出裝置（目前只有「一鍵移除」會還原）
- [ ] 評估重新開啟雙語模式的介面開關

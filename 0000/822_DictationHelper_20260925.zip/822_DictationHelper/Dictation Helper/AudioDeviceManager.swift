import Foundation
import CoreAudio
import Combine

struct AudioDeviceInfo: Identifiable, Hashable {
    let id: AudioDeviceID
    let name: String
}

final class AudioDeviceManager: ObservableObject {

    @Published var inputDevices: [AudioDeviceInfo] = []
    @Published var currentInputDeviceID: AudioDeviceID?

    init() {
        refreshDevices()
    }

    func refreshDevices() {
        inputDevices = Self.fetchInputDevices()
        currentInputDeviceID = Self.getDefaultInputDevice()
    }

    // 列舉系統中所有具備輸入聲道的音訊裝置
    static func fetchInputDevices() -> [AudioDeviceInfo] {
        var propertySize: UInt32 = 0
        var address = AudioObjectPropertyAddress(
            mSelector: kAudioHardwarePropertyDevices,
            mScope: kAudioObjectPropertyScopeGlobal,
            mElement: kAudioObjectPropertyElementMain)

        AudioObjectGetPropertyDataSize(AudioObjectID(kAudioObjectSystemObject), &address, 0, nil, &propertySize)
        let deviceCount = Int(propertySize) / MemoryLayout<AudioDeviceID>.size
        guard deviceCount > 0 else { return [] }

        var deviceIDs = [AudioDeviceID](repeating: 0, count: deviceCount)
        AudioObjectGetPropertyData(AudioObjectID(kAudioObjectSystemObject), &address, 0, nil, &propertySize, &deviceIDs)

        var result: [AudioDeviceInfo] = []

        for deviceID in deviceIDs {
            var inputAddress = AudioObjectPropertyAddress(
                mSelector: kAudioDevicePropertyStreamConfiguration,
                mScope: kAudioObjectPropertyScopeInput,
                mElement: kAudioObjectPropertyElementMain)

            var streamSize: UInt32 = 0
            AudioObjectGetPropertyDataSize(deviceID, &inputAddress, 0, nil, &streamSize)
            guard streamSize > 0 else { continue }

            let bufferListPointer = UnsafeMutablePointer<AudioBufferList>.allocate(
                capacity: Int(streamSize))
            defer { bufferListPointer.deallocate() }

            AudioObjectGetPropertyData(deviceID, &inputAddress, 0, nil, &streamSize, bufferListPointer)
            let bufferList = UnsafeMutableAudioBufferListPointer(bufferListPointer)
            let channelCount = bufferList.reduce(0) { $0 + Int($1.mNumberChannels) }
            guard channelCount > 0 else { continue } // 沒有輸入聲道，跳過（純輸出裝置）

            var nameAddress = AudioObjectPropertyAddress(
                mSelector: kAudioObjectPropertyName,
                mScope: kAudioObjectPropertyScopeGlobal,
                mElement: kAudioObjectPropertyElementMain)

            var name: Unmanaged<CFString>?
            var nameSize = UInt32(MemoryLayout<Unmanaged<CFString>?>.size)
            let status = withUnsafeMutablePointer(to: &name) { ptr -> OSStatus in
                AudioObjectGetPropertyData(deviceID, &nameAddress, 0, nil, &nameSize, ptr)
            }

            let deviceName: String
            if status == noErr, let cfName = name?.takeRetainedValue() {
                deviceName = cfName as String
            } else {
                deviceName = "裝置 #\(deviceID)"
            }

            // 排除 CoreAudio 臨時建立的內部私有聚合裝置「CADefaultDeviceAggregate-<PID>-<編號>」：
            // 它不是真實的麥克風，名稱含行程 PID、每次啟動都不同，選它會收不到聲音。
            if deviceName.hasPrefix("CADefaultDeviceAggregate") {
                print("[Audio] 略過內部聚合裝置：\(deviceName)（id=\(deviceID)）")
                continue
            }

            result.append(AudioDeviceInfo(id: deviceID, name: deviceName))
        }

        return result
    }

    // 等待系統「實際」把預設輸入裝置切成 deviceID 之後才回傳，
    // 取代原本固定睡 300ms 的做法（那是經驗值，遇到握手較慢的裝置會不夠，
    // 導致辨識引擎在系統真的切換完成前就搶著用舊格式讀取，丟出 -10877）。
    //
    // 做法：註冊 kAudioHardwarePropertyDefaultInputDevice 的屬性監聽，
    // 系統確定切換完成（HAL 發出通知）時才 resume；同時設一個 timeout 保底，
    // 避免監聽一直沒觸發（例如某些邊緣情況下 HAL 沒發通知）就卡死使用者。
    func waitForDefaultInputDeviceChange(
        expected deviceID: AudioDeviceID,
        timeout: TimeInterval = 2.0
    ) async -> Bool {
        // 切換前如果已經是目標裝置（例如切換其實沒改變），不需要等通知，直接回傳成功
        if Self.getDefaultInputDevice() == deviceID {
            return true
        }

        return await withCheckedContinuation { continuation in
            var address = AudioObjectPropertyAddress(
                mSelector: kAudioHardwarePropertyDefaultInputDevice,
                mScope: kAudioObjectPropertyScopeGlobal,
                mElement: kAudioObjectPropertyElementMain)

            var resumed = false
            let lock = NSLock()

            // listenerBlock 和 timeout 都可能觸發 resume，用 lock + resumed 旗標
            // 確保 continuation 只會被 resume 一次（重複 resume 會直接 crash）。
            var removeListener: (() -> Void)?

            let finish: (Bool) -> Void = { success in
                lock.lock()
                let shouldResume = !resumed
                resumed = true
                lock.unlock()
                guard shouldResume else { return }
                removeListener?()
                continuation.resume(returning: success)
            }

            let listenerBlock: AudioObjectPropertyListenerBlock = { _, _ in
                if Self.getDefaultInputDevice() == deviceID {
                    finish(true)
                }
            }

            let addStatus = AudioObjectAddPropertyListenerBlock(
                AudioObjectID(kAudioObjectSystemObject),
                &address,
                DispatchQueue.main,
                listenerBlock)

            removeListener = {
                var addr = address
                AudioObjectRemovePropertyListenerBlock(
                    AudioObjectID(kAudioObjectSystemObject),
                    &addr,
                    DispatchQueue.main,
                    listenerBlock)
            }

            if addStatus != noErr {
                // 監聽註冊失敗（理論上很少見），退回舊行為：等一段固定時間再放行，
                // 至少不會直接卡死使用者。
                print("[Audio] 註冊輸入裝置變更監聽失敗：status=\(addStatus)，退回固定等待")
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                    finish(Self.getDefaultInputDevice() == deviceID)
                }
                return
            }

            // 註冊監聽後，裝置可能在通知送達前就已經切好了，這裡再檢查一次保險
            if Self.getDefaultInputDevice() == deviceID {
                finish(true)
                return
            }

            DispatchQueue.main.asyncAfter(deadline: .now() + timeout) {
                print("[Audio] 等待輸入裝置切換逾時（\(timeout)s），放行但可能尚未真正切換完成")
                finish(false)
            }
        }
    }

    // 取得目前系統預設輸入裝置
    static func getDefaultInputDevice() -> AudioDeviceID? {
        var deviceID = AudioDeviceID(0)
        var size = UInt32(MemoryLayout<AudioDeviceID>.size)
        var address = AudioObjectPropertyAddress(
            mSelector: kAudioHardwarePropertyDefaultInputDevice,
            mScope: kAudioObjectPropertyScopeGlobal,
            mElement: kAudioObjectPropertyElementMain)

        let status = AudioObjectGetPropertyData(
            AudioObjectID(kAudioObjectSystemObject), &address, 0, nil, &size, &deviceID)

        return status == noErr ? deviceID : nil
    }

    // 設定系統預設輸入裝置（等同命令列版本的 SwitchAudioSource -t input）
    // 回傳 true 代表 CoreAudio 接受了這次切換（status == noErr）。
    @discardableResult
    func setDefaultInputDevice(_ deviceID: AudioDeviceID) -> Bool {
        var mutableID = deviceID
        var address = AudioObjectPropertyAddress(
            mSelector: kAudioHardwarePropertyDefaultInputDevice,
            mScope: kAudioObjectPropertyScopeGlobal,
            mElement: kAudioObjectPropertyElementMain)

        let status = AudioObjectSetPropertyData(
            AudioObjectID(kAudioObjectSystemObject),
            &address, 0, nil,
            UInt32(MemoryLayout<AudioDeviceID>.size),
            &mutableID)

        print("[Audio] 設定預設輸入裝置 id=\(deviceID)：status=\(status)（0 = 成功）")
        if status == noErr {
            currentInputDeviceID = deviceID
        }
        return status == noErr
    }
}

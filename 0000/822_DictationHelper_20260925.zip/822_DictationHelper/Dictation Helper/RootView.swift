import SwiftUI

/// App 目前顯示的畫面。
/// 原本靠 AppLauncherService 開啟另一個獨立 App 進程來切換功能，
/// 現在改成單一 target、單一視窗，用這個列舉在同一個 RootView 裡切換要顯示的內容。
enum AppScreen {
    case launcher
    case voxNoteImport
    case voiceCapture
}

struct RootView: View {

    @State private var screen: AppScreen = .launcher

    var body: some View {
        let _ = print("🖼️ [\(Self.self)] body (\(#fileID))")
        Group {
            switch screen {
            case .launcher:
                LauncherView(
                    onSelectImport: { screen = .voxNoteImport },
                    onSelectVoiceCapture: { screen = .voiceCapture }
                )

            case .voxNoteImport:
                AudioLibraryView()
                    .toolbar {
                        ToolbarItem(placement: .navigation) {
                            Button {
                                screen = .launcher
                            } label: {
                                Label("返回", systemImage: "chevron.left")
                            }
                        }
                    }

            case .voiceCapture:
                ContentView()
                    .toolbar {
                        ToolbarItem(placement: .navigation) {
                            Button {
                                screen = .launcher
                            } label: {
                                Label("返回", systemImage: "chevron.left")
                            }
                        }
                    }
            }
        }
    }
}

#Preview {
    RootView()
        .environmentObject(AudioLibraryStore())
}

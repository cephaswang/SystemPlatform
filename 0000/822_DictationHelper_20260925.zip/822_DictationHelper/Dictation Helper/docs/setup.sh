#!/bin/bash
#
# setup.sh -「聽抄小幫手」使用者安裝腳本
#
# 適用對象：一般使用者（已經拿到編譯好的 App，只需要準備好周邊環境）
#
# 這支腳本會自動：
#   1. 透過 Homebrew 安裝 BlackHole 2ch（虛擬音訊裝置，用來把喇叭聲音導入語音辨識）
#      → 需要事先安裝好 Homebrew（https://brew.sh）
#      （BlackHole 新版 GitHub Release 通常不再附上編譯好的 .pkg，
#        故不採用直接下載 .pkg 的方式，改用官方推薦的 Homebrew 安裝）
#   2. 透過 Homebrew 強制移除並重新安裝 ffmpeg（外掛，App 用來做音訊格式轉換/處理）
#
# 無法自動化、需要你手動做的部分（腳本結束時會再提醒一次）：
#   - 在「Audio MIDI 設定」建立 Multi-Output Device
#     （這一步涉及圖形介面操作，沒有官方公開指令可自動建立，需手動點）
#   - 設定 > 鍵盤 > 聽抄，開啟系統聽抄功能
#
# 使用方式：
#   chmod +x setup.sh
#   ./setup.sh
#

set -e

echo "===================================================="
echo " 聽抄小幫手 - 使用前準備"
echo "===================================================="
echo ""

# ---------- 檢查作業系統 ----------
if [[ "$(uname)" != "Darwin" ]]; then
    echo "❌ 這支腳本只能在 macOS 上執行"
    exit 1
fi


# ---------- 強制移除並重新安裝 BlackHole 2ch ----------
echo "⚙️  強制移除並重新安裝 BlackHole 2ch..."

if command -v brew >/dev/null 2>&1; then
    echo "🗑️  移除現有的 BlackHole 2ch（若存在）..."
    # --force：即使目前系統偵測不到已安裝紀錄，也強制嘗試移除殘留檔案
    # --zap：連同設定檔、偏好設定一併清除，確保是真正乾淨的移除
    brew uninstall --cask --force --zap blackhole-2ch 2>/dev/null || true

    echo "🍺 透過 brew 安裝 BlackHole 2ch..."
    brew install blackhole-2ch

    # Homebrew cask 安裝 pkg 時可能需要輸入密碼（sudo），屬正常現象
    echo "✅ BlackHole 2ch 安裝指令執行完成"
else
    echo "❌ 找不到 Homebrew（brew 指令）。"
    echo "   請先安裝 Homebrew（https://brew.sh），或改為手動下載安裝："
    echo "   1. 前往 https://existential.audio/downloads/ 或"
    echo "      https://github.com/ExistentialAudio/BlackHole/releases"
    echo "      手動下載 BlackHole 2ch 的安裝檔（.pkg）"
    echo "   2. 雙擊執行安裝"
    exit 1
fi
echo ""

# ---------- 驗證安裝結果 ----------
echo "🔍 驗證安裝結果..."

if [ -d "/Library/Audio/Plug-Ins/HAL" ] && ls "/Library/Audio/Plug-Ins/HAL" 2>/dev/null | grep -qi blackhole; then
    echo "✅ 驅動檔案確認：/Library/Audio/Plug-Ins/HAL 內已有 BlackHole 相關檔案"
else
    echo "⚠️  尚未看到驅動檔案，可能需要重新開機才會生效"
fi

if system_profiler SPAudioDataType 2>/dev/null | grep -q "BlackHole 2ch"; then
    echo "✅ 系統已偵測到 BlackHole 2ch 裝置"
else
    echo "⚠️  系統音訊清單尚未偵測到裝置，請「登出再登入」或「重新開機」後再檢查一次"
fi
echo ""

# ---------- 強制移除並重新安裝 外掛 ffmpeg ----------
echo "⚙️  強制移除並重新安裝 外掛 ffmpeg..."

echo "🗑️  移除現有的 ffmpeg（若存在）..."
brew uninstall --force ffmpeg 2>/dev/null || true

echo "🍺 透過 brew 安裝 ffmpeg..."
brew install ffmpeg

echo "✅ ffmpeg 安裝指令執行完成"
echo ""

# ---------- 驗證 ffmpeg 安裝結果 ----------
echo "🔍 驗證 ffmpeg 安裝結果..."

if command -v ffmpeg >/dev/null 2>&1; then
    echo "✅ ffmpeg 已安裝：$(ffmpeg -version | awk 'NR==1')"
else
    echo "⚠️  尚未偵測到 ffmpeg 指令，請確認 Homebrew 的安裝路徑是否已加入 PATH"
fi
echo ""

echo "===================================================="
echo " 自動安裝部分已完成，以下步驟需要手動操作："
echo "===================================================="
cat << 'EOF'

[1] 建立 Multi-Output Device（讓你聽得到聲音，同時能被辨識）
    - 開啟「Audio MIDI 設定」（Spotlight 搜尋 Audio MIDI Setup）
    - 左下角「+」→「建立多重輸出裝置」
    - 勾選：你的實體喇叭/耳機 ＋ BlackHole 2ch
    - 在 BlackHole 2ch 那一列勾選「Drift Correction」

[2] 開啟系統聽抄功能（App 依賴此開關）
    - 系統設定 → 鍵盤 → 聽抄 → 開啟
    - 確認語言清單有你要用的語言，必要時下載語音套件

[3] 開啟「聽抄小幫手」App，在介面中：
    - 「輸入裝置」選單選擇 BlackHole 2ch
    - 「語系」選單選擇要用的語言
    - 按「開始聽抄」

若步驟 [1] 完成後，App 的「輸入裝置」選單仍看不到 BlackHole 2ch，
請先重新開機一次，再重新開啟 App。

EOF

echo "===================================================="
echo " 安裝腳本執行完畢"
echo "===================================================="

import Foundation
import AVFoundation
import Speech
import Combine
import AppKit
import CoreAudio
import AudioToolbox

final class SpeechTranscriber: ObservableObject {

    // 單語模式使用的即時顯示；雙語模式請看 liveTextA / liveTextB
    @Published var liveText: String = ""
    @Published var liveTextA: String = ""
    @Published var liveTextB: String = ""

    @Published var savedSentences: [String] = []
    @Published var isRunning: Bool = false
    @Published var statusMessage: String = ""
    @Published var outputFileURL: URL?
    @Published var isBilingualMode: Bool = false

    private var audioEngine = AVAudioEngine()

    // 使用者在 ContentView 選單上選的輸入裝置 id，由 start()/startBilingual() 傳入。
    // 不再只靠「系統預設輸入裝置」這個間接管道，而是直接把這個 id 綁定到
    // AVAudioEngine.inputNode 底層的 AudioUnit（見 bindInputDeviceIfNeeded()），
    // 理由見該函式上方註解。
    private var pendingInputDeviceID: AudioDeviceID?

    // 單語模式
    private var recognizer: SFSpeechRecognizer?
    private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?
    private var recognitionTask: SFSpeechRecognitionTask?
    private var latestText: String = ""

    // 雙語模式：A、B 兩個引擎同時處理同一份音訊
    private var recognizerA: SFSpeechRecognizer?
    private var recognizerB: SFSpeechRecognizer?
    private var requestA: SFSpeechAudioBufferRecognitionRequest?
    private var requestB: SFSpeechAudioBufferRecognitionRequest?
    private var taskA: SFSpeechRecognitionTask?
    private var taskB: SFSpeechRecognitionTask?
    private var latestTextA: String = ""
    private var latestTextB: String = ""

    // 雙語模式：等待另一邊也 final，再比較信心值擇優寫入
    private struct PendingCandidate {
        let text: String
        let confidence: Float
        let isTrackA: Bool // 記錄這個候選來自哪一路，避免同一路的兩句話被誤判成互相競爭
    }
    private var pendingCandidate: PendingCandidate?
    private var pendingTimer: Timer?
    private let pendingWindow: TimeInterval = 1.2 // 等待另一邊 final 的最長時間（秒）

    private var outputFileHandle: FileHandle?
    private var pendingOutputDirectory: URL?

    // 用來過濾「上一次」工作結束時姍姍來遲的殘留回報（例如按停止後又立刻按開始）
    private var currentSessionID = UUID()

    // MARK: - 除錯用：讀取「系統實際」預設輸入裝置與硬體格式
    //
    // 這裡不依賴 AudioDeviceManager，直接用 CoreAudio 查，目的是拿來跟
    // AVAudioEngine.inputNode 回報的 format 互相比對——如果兩者對不上，
    // 通常就是 -10877 的直接原因：AVAudioEngine 用了一個跟硬體當下實際
    // 格式不一致的 format 去掛 tap / 啟動。

    private func currentDefaultInputDeviceID() -> AudioDeviceID? {
        var deviceID = AudioDeviceID(0)
        var size = UInt32(MemoryLayout<AudioDeviceID>.size)
        var address = AudioObjectPropertyAddress(
            mSelector: kAudioHardwarePropertyDefaultInputDevice,
            mScope: kAudioObjectPropertyScopeGlobal,
            mElement: kAudioObjectPropertyElementMain)
        let status = AudioObjectGetPropertyData(
            AudioObjectID(kAudioObjectSystemObject), &address, 0, nil, &size, &deviceID)
        return status == noErr ? deviceID : nil
    }

    private func deviceDisplayName(_ deviceID: AudioDeviceID) -> String {
        var address = AudioObjectPropertyAddress(
            mSelector: kAudioObjectPropertyName,
            mScope: kAudioObjectPropertyScopeGlobal,
            mElement: kAudioObjectPropertyElementMain)
        var name: CFString = "" as CFString
        var size = UInt32(MemoryLayout<CFString>.size)
        let status = withUnsafeMutablePointer(to: &name) { ptr -> OSStatus in
            AudioObjectGetPropertyData(deviceID, &address, 0, nil, &size, ptr)
        }
        return status == noErr ? (name as String) : "（讀不到名稱，status=\(status)）"
    }

    /// 讀「硬體」目前實際的輸入串流格式（不是 AVAudioEngine 快取的那份）
    private func hardwareInputStreamFormatDescription(for deviceID: AudioDeviceID) -> String {
        var format = AudioStreamBasicDescription()
        var size = UInt32(MemoryLayout<AudioStreamBasicDescription>.size)
        var address = AudioObjectPropertyAddress(
            mSelector: kAudioDevicePropertyStreamFormat,
            mScope: kAudioObjectPropertyScopeInput,
            mElement: kAudioObjectPropertyElementMain)
        let status = AudioObjectGetPropertyData(deviceID, &address, 0, nil, &size, &format)
        guard status == noErr else { return "讀取硬體格式失敗（status=\(status)）" }
        return "sampleRate=\(format.mSampleRate), channels=\(format.mChannelsPerFrame), formatID=\(format.mFormatID), bitsPerChannel=\(format.mBitsPerChannel)"
    }

    /// 印出目前「AVAudioEngine 端」跟「CoreAudio 硬體端」各自認知的輸入格式，
    /// 兩者對不上時通常就是 -10877 的根源。`context` 用來標記是在哪個時間點印的。
    private func logAudioEngineDiagnostics(context: String) {
        let inputNode = audioEngine.inputNode
        let nodeFormat = inputNode.outputFormat(forBus: 0)
        var line = "[Audio][診斷] \(context)｜AVAudioEngine.inputNode format: sampleRate=\(nodeFormat.sampleRate), channels=\(nodeFormat.channelCount), commonFormat=\(nodeFormat.commonFormat.rawValue), isStandard=\(nodeFormat.isStandard)"

        if let deviceID = currentDefaultInputDeviceID() {
            line += "\n[Audio][診斷] \(context)｜系統預設輸入裝置：id=\(deviceID) name=\(deviceDisplayName(deviceID))，硬體格式：\(hardwareInputStreamFormatDescription(for: deviceID))"
        } else {
            line += "\n[Audio][診斷] \(context)｜讀不到系統預設輸入裝置 id"
        }
        print(line)
    }

    /// 把 AVAudioEngine.inputNode 底層的 AudioUnit 明確綁定到 `pendingInputDeviceID`
    /// 指定的裝置，而不是讓它自己去猜/查「系統預設輸入裝置」。
    ///
    /// 背景：實測發現即使每次都建立全新的 AVAudioEngine 實例，
    /// `inputNode.outputFormat(forBus: 0)` 查到的聲道數還是可能跟硬體實際的
    /// 聲道數對不上（log 顯示 engine 說 3 聲道、硬體其實是 1 聲道的 External
    /// Microphone）。這代表問題不是「舊狀態沒清乾淨」，而是 AVAudioEngine 在
    /// macOS、尤其是 Sandbox 環境下，不指定裝置時對「目前系統預設輸入裝置」
    /// 的查詢本身就不可靠／有時機問題。
    ///
    /// 解法：用 `kAudioOutputUnitProperty_CurrentDevice` 直接告訴底層 AudioUnit
    /// 要用哪個 AudioDeviceID，跳過「猜系統預設值」這一步，格式協商就會根據
    /// 這個明確指定的裝置來，不會再受「系統預設值是否已經傳播完成」影響。
    /// 必須在 installTap()（會去讀 outputFormat）之前呼叫。

    private func bindInputDeviceIfNeeded() {
        guard let deviceID = pendingInputDeviceID, deviceID != 0 else {
            print("[Audio] 沒有指定的輸入裝置 id，inputNode 繼續用系統預設輸入")
            return
        }

        guard let audioUnit = audioEngine.inputNode.audioUnit else {
            print("[Audio] 拿不到 inputNode 底層的 AudioUnit，無法明確綁定裝置，退回系統預設輸入")
            return
        }

        // 關閉這顆共用 I/O AudioUnit 的「輸出」element（element 0）。
        // 這支 App 只做輸入擷取，完全沒有接訊號到 outputNode，
        // 但 macOS 上 inputNode/outputNode 是同一顆 AUHAL，引擎預設仍會啟用
        // 輸出 element 並嘗試 render；下面這段又把輸出 element 綁去跟輸入
        // 相同的裝置（BlackHole），跟系統實際輸出裝置（Multi-Output Device）
        // 的格式兜不起來，就是狂刷「render err: -50 / ASBD::NumberChannelStreams」的原因。
        var disableOutput: UInt32 = 0
        let disableStatus = AudioUnitSetProperty(
            audioUnit,
            kAudioOutputUnitProperty_EnableIO,
            kAudioUnitScope_Output, 0,
            &disableOutput,
            UInt32(MemoryLayout<UInt32>.size))
        print("[Audio] 關閉 I/O unit 輸出 element：status=\(disableStatus)（0 = 成功）")

        var mutableDeviceID = deviceID
        let status = AudioUnitSetProperty(
            audioUnit,
            kAudioOutputUnitProperty_CurrentDevice,
            kAudioUnitScope_Global, 0,
            &mutableDeviceID,
            UInt32(MemoryLayout<AudioDeviceID>.size))

        print("[Audio] 明確綁定 inputNode 到裝置 id=\(deviceID)：status=\(status)（0 = 成功）")
    }
    

    /// 直接用 CoreAudio 查到的「硬體真實」串流格式組一個 AVAudioFormat，
    /// 不透過 AVAudioEngine.inputNode.outputFormat(forBus:) 這層。
    ///
    /// 背景：實測發現即使 bindInputDeviceIfNeeded() 的 AudioUnitSetProperty
    /// 回傳成功（status=0，代表裝置確實綁定成功），緊接著查
    /// inputNode.outputFormat(forBus: 0) 得到的聲道數還是跟硬體實際的聲道數
    /// 對不上（log：硬體 1 聲道，AVAudioEngine 卻回報 3 聲道）。這代表綁定本身
    /// 沒問題，是 AVAudioEngine 內部快取的 format 描述沒有跟著刷新——換句話說，
    /// inputNode.outputFormat(forBus:) 在這個情境下完全不可信。
    /// 解法：不要問 AVAudioEngine「你覺得格式是什麼」，直接把 CoreAudio 查到的
    /// 硬體 AudioStreamBasicDescription 轉成 AVAudioFormat 給 installTap 用。
    private func hardwareAVAudioFormat(for deviceID: AudioDeviceID) -> AVAudioFormat? {
        var asbd = AudioStreamBasicDescription()
        var size = UInt32(MemoryLayout<AudioStreamBasicDescription>.size)
        var address = AudioObjectPropertyAddress(
            mSelector: kAudioDevicePropertyStreamFormat,
            mScope: kAudioObjectPropertyScopeInput,
            mElement: kAudioObjectPropertyElementMain)

        let status = AudioObjectGetPropertyData(deviceID, &address, 0, nil, &size, &asbd)
        guard status == noErr else {
            print("[Audio] 讀取硬體 stream format 失敗（status=\(status)），無法組出 AVAudioFormat")
            return nil
        }

        guard let format = AVAudioFormat(streamDescription: &asbd) else {
            print("[Audio] AudioStreamBasicDescription 轉換成 AVAudioFormat 失敗：\(asbd)")
            return nil
        }
        return format
    }

    /// installTap 用的 format：優先用「硬體真實的 sampleRate / channel 數」，
    /// 但一律組成 AVAudioEngine 要求的 standard 格式（deinterleaved Float32），
    /// 而不是直接拿硬體原始 ASBD 轉出來的格式。
    ///
    /// 背景：像 BlackHole 這類虛擬裝置回報的硬體 ASBD 常常不是 standard 格式
    /// （isStandard=false，可能是 interleaved 或非 Float32）。直接拿這種格式
    /// 給 installTap 用，AVAudioEngine 內部對 buffer 數量的假設（non-interleaved
    /// 需要 channel 數個 buffer）會跟 AUHAL 實際協商出的 stream 型態對不上，
    /// 這正是「ioData.mNumberBuffers=2 / NumberChannelStreams(...)=1」這個
    /// render err -50 狂刷的根源——單聲道時因為 1 buffer 剛好兩邊一致而僥倖沒事，
    /// 一到多聲道（BlackHole 2ch）就會整個爆掉。
    private func preferredTapFormat(inputNode: AVAudioInputNode) -> AVAudioFormat {
        if let deviceID = pendingInputDeviceID,
           let hwFormat = hardwareAVAudioFormat(for: deviceID),
           let standardFormat = AVAudioFormat(
               commonFormat: .pcmFormatFloat32,
               sampleRate: hwFormat.sampleRate,
               channels: hwFormat.channelCount,
               interleaved: false) {
            print("[Audio] installTap 使用硬體 sampleRate/channels 轉出的 standard 格式：sampleRate=\(standardFormat.sampleRate), channels=\(standardFormat.channelCount), isStandard=\(standardFormat.isStandard)")
            return standardFormat
        }
        let fallback = inputNode.outputFormat(forBus: 0)
        print("[Audio] 拿不到硬體格式，退回 inputNode.outputFormat：sampleRate=\(fallback.sampleRate), channels=\(fallback.channelCount)")
        return fallback
    }

    // MARK: - 啟動音訊引擎（含失敗重試）

    /// 掛上 tap 並啟動 audioEngine；剛切換系統預設輸入裝置後，CoreAudio 把新裝置的
    /// 格式完全就緒需要一點時間，太早呼叫 `audioEngine.start()` 會丟出 -10877
    /// （kAudioUnitErr_InvalidElement）。
    ///
    /// 原本只重試一次、且是「立刻」重試，遇到裝置握手比較慢的情況（例如外接麥克風）
    /// 常常連重試那一次也還沒就緒，兩次都失敗、聽抄整個啟動不起來。
    /// 後來加上診斷 log 才抓到真正原因：同一個 AVAudioEngine 實例重複使用時，
    /// `reset()` 不保證會重新查詢「目前」預設輸入裝置的實際聲道數/格式——
    /// 裝置從多聲道切到少聲道（或反過來）時特別容易讓 inputNode 回報的格式
    /// 跟硬體實際格式對不上，這才是 -10877 的根源。
    /// 現在改成：每次嘗試都直接丟掉舊的 AVAudioEngine、建立全新實例（見下方），
    /// `installTap` 用「當下」全新的 inputNode/format 重新掛 tap；失敗就用遞增的
    /// 延遲（不會卡住主執行緒/UI）再試，最多試 `maxAttempts` 次才真正判定失敗。
    private func startAudioEngineWithRetry(
        maxAttempts: Int = 4,
        installTap: @escaping () -> Void,
        completion: @escaping (Bool) -> Void
    ) {
        func attempt(_ attemptNumber: Int) {
            logAudioEngineDiagnostics(context: "第 \(attemptNumber) 次嘗試開始前")

            audioEngine.stop()
            audioEngine.inputNode.removeTap(onBus: 0)
            // 不用 audioEngine.reset()：實測發現裝置從多聲道（例如先前用過的
            // BlackHole/聚合裝置）切到少聲道（例如這裡的單聲道麥克風）時，
            // reset() 並不會強制 AVAudioEngine 重新查詢目前預設輸入裝置「實際」
            // 的聲道數／格式，導致 inputNode.outputFormat(forBus: 0) 回報的聲道數
            // 跟硬體真正的聲道數對不上（診斷 log 就是這樣抓到的：engine 說 3 聲道，
            // 硬體其實只有 1 聲道），這正是 -10877 的根源。
            // 改成每次嘗試都直接丟掉舊的 AVAudioEngine、建立全新實例，
            // 逼它從零重新跟「目前」的預設輸入裝置協商格式，不會殘留舊裝置的快取。
            audioEngine = AVAudioEngine()
            bindInputDeviceIfNeeded()

            installTap()
            logAudioEngineDiagnostics(context: "第 \(attemptNumber) 次嘗試｜installTap() 之後、prepare() 之前")

            audioEngine.prepare()
            do {
                try audioEngine.start()
                if attemptNumber > 1 {
                    print("[Audio] 音訊引擎在第 \(attemptNumber) 次嘗試後啟動成功")
                }
                completion(true)
            } catch {
                // 把完整的 NSError（domain / code / userInfo）印出來，
                // 而不是只看 localizedDescription——後者常常只有一句籠統的
                // 「操作無法完成」，看不出真正是哪個 element / property 出問題。
                let nsError = error as NSError
                print("[Audio] audioEngine.start() 第 \(attemptNumber) 次嘗試失敗｜domain=\(nsError.domain) code=\(nsError.code) userInfo=\(nsError.userInfo)")
                print("[Audio] 完整 error 物件：\(error)")
                logAudioEngineDiagnostics(context: "第 \(attemptNumber) 次失敗當下")

                guard attemptNumber < maxAttempts else {
                    DispatchQueue.main.async {
                        self.statusMessage = "❌ 音訊引擎啟動失敗（已重試 \(maxAttempts) 次）：\(error.localizedDescription)"
                    }
                    completion(false)
                    return
                }
                // 遞增延遲：150ms、300ms、450ms……讓 CoreAudio 有更多時間把新裝置的
                // 格式穩定下來，同時用 asyncAfter 而非 Thread.sleep，不會卡住 UI。
                let delay = 0.15 * Double(attemptNumber)
                DispatchQueue.main.asyncAfter(deadline: .now() + delay) {
                    attempt(attemptNumber + 1)
                }
            }
        }
        attempt(1)
    }

    // MARK: - 開始聽抄（單語模式）

    func start(localeIdentifier: String, outputDirectory: URL, inputDeviceID: AudioDeviceID?) {
        guard !isRunning else { return }
        pendingInputDeviceID = inputDeviceID
        let sessionID = prepareNewSession(outputDirectory: outputDirectory)
        isBilingualMode = false

        guard let recognizer = SFSpeechRecognizer(locale: Locale(identifier: localeIdentifier)),
              recognizer.isAvailable else {
            statusMessage = "❌ 無法使用語系「\(localeIdentifier)」的語音辨識"
            return
        }
        self.recognizer = recognizer

        requestPermissions { [weak self] granted, reason in
            guard let self = self else { return }
            DispatchQueue.main.async {
                guard self.currentSessionID == sessionID else { return }
                if granted {
                    self.beginSingleRecognition(sessionID: sessionID)
                } else {
                    self.statusMessage = "❌ 麥克風或語音辨識權限被拒絕，請至「系統設定 > 隱私權與安全性」開啟"
                    if let reason = reason {
                        self.openPrivacySettings(for: reason)
                    }
                }
            }
        }
    }

    // MARK: - 開始聽抄（雙語模式：同時辨識兩種語言，自動選信心較高者）

    func startBilingual(localeA: String, localeB: String, outputDirectory: URL, inputDeviceID: AudioDeviceID?) {
        guard !isRunning else { return }
        pendingInputDeviceID = inputDeviceID
        let sessionID = prepareNewSession(outputDirectory: outputDirectory)
        isBilingualMode = true

        guard let recA = SFSpeechRecognizer(locale: Locale(identifier: localeA)), recA.isAvailable,
              let recB = SFSpeechRecognizer(locale: Locale(identifier: localeB)), recB.isAvailable else {
            statusMessage = "❌ 無法使用語系「\(localeA)」或「\(localeB)」的語音辨識"
            return
        }
        self.recognizerA = recA
        self.recognizerB = recB

        requestPermissions { [weak self] granted, reason in
            guard let self = self else { return }
            DispatchQueue.main.async {
                guard self.currentSessionID == sessionID else { return }
                if granted {
                    self.beginBilingualRecognition(sessionID: sessionID)
                } else {
                    self.statusMessage = "❌ 麥克風或語音辨識權限被拒絕，請至「系統設定 > 隱私權與安全性」開啟"
                    if let reason = reason {
                        self.openPrivacySettings(for: reason)
                    }
                }
            }
        }
    }

    // MARK: - 共用：準備新的一輪聽抄

    @discardableResult
    private func prepareNewSession(outputDirectory: URL) -> UUID {
        statusMessage = ""
        liveText = ""
        liveTextA = ""
        liveTextB = ""
        savedSentences = []

        pendingOutputDirectory = outputDirectory
        outputFileURL = nil
        outputFileHandle = nil

        pendingCandidate = nil
        pendingTimer?.invalidate()
        pendingTimer = nil

        latestText = ""
        latestTextA = ""
        latestTextB = ""

        let sessionID = UUID()
        currentSessionID = sessionID
        return sessionID
    }

    // 權限被拒時，用來標記究竟是「語音辨識」還是「麥克風」被拒絕，
    // 以便打開對應的系統設定分頁。
    enum PermissionDenialReason {
        case speechRecognition
        case microphone
    }

    private func requestPermissions(completion: @escaping (Bool, PermissionDenialReason?) -> Void) {
        SFSpeechRecognizer.requestAuthorization { status in
            guard status == .authorized else {
                completion(false, .speechRecognition)
                return
            }
            AVCaptureDevice.requestAccess(for: .audio) { granted in
                completion(granted, granted ? nil : .microphone)
            }
        }
    }

    // 打開「系統設定 > 隱私權與安全性」對應的分頁，讓使用者直接開啟權限
    private func openPrivacySettings(for reason: PermissionDenialReason) {
        let urlString: String
        switch reason {
        case .speechRecognition:
            urlString = "x-apple.systempreferences:com.apple.preference.security?Privacy_SpeechRecognition"
        case .microphone:
            urlString = "x-apple.systempreferences:com.apple.preference.security?Privacy_Microphone"
        }
        if let url = URL(string: urlString) {
            NSWorkspace.shared.open(url)
        }
    }

    // MARK: - 單語模式實作

    private func beginSingleRecognition(sessionID: UUID) {
        let request = SFSpeechAudioBufferRecognitionRequest()
        request.shouldReportPartialResults = true
        // 明確關閉裝置端辨識，強制走伺服端辨識。
        // 裝置端辨識會嘗試連線到系統私有服務 com.apple.audioanalyticsd，
        // 第三方 App 在有開 App Sandbox 的情況下拿不到對應的例外授權，
        // 會被 sandbox 擋下，在主控台印出「PRECONDITION FAILURE ... audioanalyticsd」。
        request.requiresOnDeviceRecognition = false
        recognitionRequest = request

        startAudioEngineWithRetry(installTap: { [weak self] in
            guard let self = self else { return }
            let inputNode = self.audioEngine.inputNode
            let format = self.preferredTapFormat(inputNode: inputNode)
            inputNode.installTap(onBus: 0, bufferSize: 1024, format: format) { [weak self] buffer, _ in
                self?.recognitionRequest?.append(buffer)
            }
        }) { [weak self] started in
            guard let self = self, self.currentSessionID == sessionID else { return }
            guard started else { return }
            self.isRunning = true

            self.recognitionTask = self.recognizer?.recognitionTask(with: request) { [weak self] result, error in
                guard let self = self else { return }
                guard self.currentSessionID == sessionID else { return }

                if let result = result {
                    let text = result.bestTranscription.formattedString
                    self.latestText = text
                    DispatchQueue.main.async {
                        guard self.currentSessionID == sessionID else { return }
                        self.liveText = text
                    }

                    if result.isFinal {
                        self.appendToFile(text)
                        self.latestText = ""
                    }
                }

                if let error = error {
                    let nsError = error as NSError
                    let isBenign = nsError.code == 1110 || !self.isRunning
                    if !isBenign {
                        DispatchQueue.main.async {
                            guard self.currentSessionID == sessionID else { return }
                            self.statusMessage = "⚠️ 辨識問題：\(error.localizedDescription)"
                        }
                    }
                }
            }
        }
    }

    // MARK: - 雙語模式實作

    private func beginBilingualRecognition(sessionID: UUID) {
        let reqA = SFSpeechAudioBufferRecognitionRequest()
        reqA.shouldReportPartialResults = true
        reqA.requiresOnDeviceRecognition = false // 理由同單語模式，見 beginSingleRecognition 註解
        let reqB = SFSpeechAudioBufferRecognitionRequest()
        reqB.shouldReportPartialResults = true
        reqB.requiresOnDeviceRecognition = false
        requestA = reqA
        requestB = reqB

        // 同一份音訊同時餵給兩個辨識引擎：兩個 request 是各自獨立、非同步處理音訊的，
        // 直接把「同一個」AVAudioPCMBuffer 參考丟給兩邊，容易在其中一路還沒讀完時
        // 就被另一路或下一次 tap 回呼覆寫／釋放，導致其中一路（甚至兩路）拿到損毀的音訊，
        // 這正是先前雙語辨識結果會出現大量語意不連貫亂碼的主因之一。
        // 修法：其中一路用原始 buffer，另一路用「複製」出來的獨立 buffer。
        startAudioEngineWithRetry(installTap: { [weak self] in
            guard let self = self else { return }
            let inputNode = self.audioEngine.inputNode
            let format = self.preferredTapFormat(inputNode: inputNode)
            inputNode.installTap(onBus: 0, bufferSize: 1024, format: format) { [weak self] buffer, _ in
                guard let self = self else { return }
                self.requestA?.append(buffer)
                if let bufferCopy = self.duplicate(buffer) {
                    self.requestB?.append(bufferCopy)
                } else {
                    // 極少數情況複製失敗時，寧可讓 B 這次少聽一段，也不要冒著共用 buffer 的風險
                    self.requestB?.append(buffer)
                }
            }
        }) { [weak self] started in
            guard let self = self, self.currentSessionID == sessionID else { return }
            guard started else { return }
            self.isRunning = true

            self.taskA = self.recognizerA?.recognitionTask(with: reqA) { [weak self] result, error in
                self?.handleBilingualResult(result: result, error: error, isTrackA: true, sessionID: sessionID)
            }
            self.taskB = self.recognizerB?.recognitionTask(with: reqB) { [weak self] result, error in
                self?.handleBilingualResult(result: result, error: error, isTrackA: false, sessionID: sessionID)
            }
        }
    }

    // 深層複製一份 AVAudioPCMBuffer，讓兩個獨立的辨識 request 各自擁有互不干擾的音訊資料
    private func duplicate(_ buffer: AVAudioPCMBuffer) -> AVAudioPCMBuffer? {
        guard let copy = AVAudioPCMBuffer(pcmFormat: buffer.format, frameCapacity: buffer.frameCapacity) else {
            return nil
        }
        copy.frameLength = buffer.frameLength
        let channelCount = Int(buffer.format.channelCount)
        let frameLength = Int(buffer.frameLength)
        guard frameLength > 0 else { return copy }

        if let src = buffer.floatChannelData, let dst = copy.floatChannelData {
            for ch in 0..<channelCount {
                dst[ch].update(from: src[ch], count: frameLength)
            }
        } else if let src = buffer.int16ChannelData, let dst = copy.int16ChannelData {
            for ch in 0..<channelCount {
                dst[ch].update(from: src[ch], count: frameLength)
            }
        } else if let src = buffer.int32ChannelData, let dst = copy.int32ChannelData {
            for ch in 0..<channelCount {
                dst[ch].update(from: src[ch], count: frameLength)
            }
        } else {
            return nil // 未知的取樣格式，交由呼叫端決定退回原本的做法
        }
        return copy
    }

    private func handleBilingualResult(result: SFSpeechRecognitionResult?, error: Error?, isTrackA: Bool, sessionID: UUID) {
        guard currentSessionID == sessionID else { return }

        if let result = result {
            let text = result.bestTranscription.formattedString

            if isTrackA { latestTextA = text } else { latestTextB = text }

            DispatchQueue.main.async {
                guard self.currentSessionID == sessionID else { return }
                if isTrackA {
                    self.liveTextA = text
                } else {
                    self.liveTextB = text
                }
            }

            if result.isFinal {
                let segments = result.bestTranscription.segments
                let confidence: Float = segments.isEmpty
                    ? 0
                    : segments.map { $0.confidence }.reduce(0, +) / Float(segments.count)

                if isTrackA { latestTextA = "" } else { latestTextB = "" }
                DispatchQueue.main.async {
                    guard self.currentSessionID == sessionID else { return }
                    if isTrackA { self.liveTextA = "" } else { self.liveTextB = "" }
                }

                handleFinalCandidate(text: text, confidence: confidence, isTrackA: isTrackA, sessionID: sessionID)
            }
        }

        if let error = error {
            let nsError = error as NSError
            let isBenign = nsError.code == 1110 || !self.isRunning
            if !isBenign {
                DispatchQueue.main.async {
                    guard self.currentSessionID == sessionID else { return }
                    self.statusMessage = "⚠️ 辨識問題（\(isTrackA ? "語言 A" : "語言 B")）：\(error.localizedDescription)"
                }
            }
        }
    }

    // 判斷某個語系「應該」以中日韓文字為主（用來在信心值不可靠時，當作次要判斷依據）
    private func expectsCJKScript(localeIdentifier: String) -> Bool {
        let lower = localeIdentifier.lowercased()
        return lower.hasPrefix("zh") || lower.hasPrefix("ja") || lower.hasPrefix("ko")
    }

    // 計算一段文字裡「符合預期文字系統」的比例（0~1）。用來輔助判斷：
    // 中文引擎聽到英文語音時，常會硬湊出一串看起來「有信心」但語意不通的文字，
    // 這種輔助分數可以在 confidence 打平（例如裝置端辨識常固定回傳 0）時提供額外依據。
    private func scriptConsistencyScore(_ text: String, expectCJK: Bool) -> Double {
        let scalars = text.unicodeScalars.filter { !CharacterSet.whitespacesAndNewlines.contains($0) && !CharacterSet.punctuationCharacters.contains($0) }
        guard !scalars.isEmpty else { return 0 }
        let cjkCount = scalars.filter { (0x4E00...0x9FFF).contains($0.value) || (0x3400...0x4DBF).contains($0.value) }.count
        let ratio = Double(cjkCount) / Double(scalars.count)
        return expectCJK ? ratio : (1 - ratio)
    }

    // 在兩個候選之間擇優：優先看信心值（差距明顯時直接採信）；
    // 差距不明顯或雙方都是 0（常見於裝置端辨識）時，改用文字系統一致性分數輔助判斷。
    private func pickWinner(_ a: PendingCandidate, _ b: PendingCandidate) -> String {
        let confidenceGap = abs(a.confidence - b.confidence)
        if confidenceGap > 0.05 {
            return a.confidence >= b.confidence ? a.text : b.text
        }

        let aLocale = a.isTrackA ? recognizerA?.locale.identifier : recognizerB?.locale.identifier
        let bLocale = b.isTrackA ? recognizerA?.locale.identifier : recognizerB?.locale.identifier
        let aScore = scriptConsistencyScore(a.text, expectCJK: expectsCJKScript(localeIdentifier: aLocale ?? ""))
        let bScore = scriptConsistencyScore(b.text, expectCJK: expectsCJKScript(localeIdentifier: bLocale ?? ""))

        if aScore == bScore {
            // 真的分不出高下時，維持原本「信心值較高者優先」的行為
            return a.confidence >= b.confidence ? a.text : b.text
        }
        return aScore > bScore ? a.text : b.text
    }

    // 收到任一語言的 final 結果時呼叫：限時等待「另一邊」也 final，比較後擇優寫入。
    // 注意：只會拿 A 的候選跟 B 的候選配對比較，同一路連續兩句話絕不會被拿來互相競爭。
    private func handleFinalCandidate(text: String, confidence: Float, isTrackA: Bool, sessionID: UUID) {
        guard !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return }
        let newCandidate = PendingCandidate(text: text, confidence: confidence, isTrackA: isTrackA)

        DispatchQueue.main.async { [weak self] in
            guard let self = self, self.currentSessionID == sessionID else { return }

            if let existing = self.pendingCandidate {
                if existing.isTrackA == isTrackA {
                    // 同一路又搶先送來下一句：代表上一句其實沒等到對方，先把上一句寫入，
                    // 再讓這一句重新排隊等待對方，避免同一路的兩句話被誤判成互相競爭。
                    self.pendingTimer?.invalidate()
                    self.pendingTimer = nil
                    self.appendToFile(existing.text)
                    self.pendingCandidate = nil
                    self.schedulePending(newCandidate, sessionID: sessionID)
                } else {
                    // 兩路各自的候選都到齊了，正式擇優寫入
                    self.pendingTimer?.invalidate()
                    self.pendingTimer = nil
                    self.pendingCandidate = nil
                    self.appendToFile(self.pickWinner(existing, newCandidate))
                }
            } else {
                self.schedulePending(newCandidate, sessionID: sessionID)
            }
        }
    }

    // 把候選存起來，限時等待另一路的對應候選；逾時就直接採用目前手上這個
    private func schedulePending(_ candidate: PendingCandidate, sessionID: UUID) {
        pendingCandidate = candidate
        pendingTimer = Timer.scheduledTimer(withTimeInterval: pendingWindow, repeats: false) { [weak self] _ in
            guard let self = self, self.currentSessionID == sessionID else { return }
            if let pending = self.pendingCandidate {
                self.appendToFile(pending.text)
                self.pendingCandidate = nil
            }
            self.pendingTimer = nil
        }
    }

    // MARK: - 停止聽抄

    func stop() {
        guard isRunning else { return }

        // 讓任何稍後才送達的回呼都被視為「舊工作」而被忽略
        currentSessionID = UUID()

        audioEngine.stop()
        audioEngine.inputNode.removeTap(onBus: 0)
        audioEngine.reset()

        // 單語模式收尾
        recognitionRequest?.endAudio()
        recognitionTask?.cancel()
        recognitionRequest = nil
        recognitionTask = nil

        // 雙語模式收尾
        requestA?.endAudio()
        requestB?.endAudio()
        taskA?.cancel()
        taskB?.cancel()
        requestA = nil
        requestB = nil
        taskA = nil
        taskB = nil

        pendingTimer?.invalidate()
        pendingTimer = nil

        // 不管有沒有等到官方判定的 isFinal，只要還有內容就強制寫入，避免遺失
        if isBilingualMode {
            if let candidate = pendingCandidate {
                appendToFile(candidate.text)
                pendingCandidate = nil
            } else if !latestTextA.isEmpty || !latestTextB.isEmpty {
                // 兩邊都還沒 final，沒有信心值可比較時，權宜選字數較多的那邊
                let fallback = latestTextA.count >= latestTextB.count ? latestTextA : latestTextB
                if !fallback.isEmpty {
                    appendToFile(fallback)
                }
            }
            latestTextA = ""
            latestTextB = ""
        } else {
            if !latestText.isEmpty {
                appendToFile(latestText)
                latestText = ""
            }
        }

        outputFileHandle?.closeFile()
        isRunning = false
    }

    // MARK: - 自動斷句寫檔（單語 / 雙語共用）

    private func appendToFile(_ text: String) {
        guard !text.isEmpty else { return }

        let now = Date() // 用同一個 Date 產生檔名與時間戳記，確保兩者完全一致

        // 延遲建檔：第一句話真正要寫入時才建立檔案，檔名時間 = 這句話的時間
        if outputFileHandle == nil {
            guard let directory = pendingOutputDirectory else { return }
            let fileNameFormatter = DateFormatter()
            fileNameFormatter.dateFormat = "yyyy-MM-dd_HHmmss"
            let fileName = "transcript_\(fileNameFormatter.string(from: now)).txt"
            let fileURL = directory.appendingPathComponent(fileName)
            FileManager.default.createFile(atPath: fileURL.path, contents: nil)
            outputFileHandle = try? FileHandle(forWritingTo: fileURL)
            DispatchQueue.main.async {
                self.outputFileURL = fileURL
            }
        }

        let timeFormatter = DateFormatter()
        timeFormatter.dateFormat = "HH:mm:ss"
        let timePrefix = timeFormatter.string(from: now)

        func isSentenceEnder(_ ch: Character) -> Bool {
            return "。！？.!?".contains(ch)
        }

        var sentences: [String] = []
        var current = ""
        for ch in text {
            current.append(ch)
            if isSentenceEnder(ch) {
                let trimmed = current.trimmingCharacters(in: .whitespacesAndNewlines)
                if !trimmed.isEmpty { sentences.append(trimmed) }
                current = ""
            }
        }
        let remaining = current.trimmingCharacters(in: .whitespacesAndNewlines)
        if !remaining.isEmpty { sentences.append(remaining) }
        if sentences.isEmpty {
            sentences = [text.trimmingCharacters(in: .whitespacesAndNewlines)]
        }

        var fileOutput = ""
        for sentence in sentences where !sentence.isEmpty {
            let line = "[\(timePrefix)] \(sentence)"
            fileOutput += line + "\n"
            DispatchQueue.main.async {
                self.savedSentences.append(line)
            }
        }
        fileOutput += "\n" // 每次寫入之間加空行區隔

        if let data = fileOutput.data(using: .utf8) {
            outputFileHandle?.seekToEndOfFile()
            outputFileHandle?.write(data)
        }
    }
}

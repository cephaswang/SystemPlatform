import SwiftUI
import AppKit

/// 共用的「開啟使用說明」邏輯。
/// 抽成獨立的 enum，是為了讓選單列（RootApp.swift）可以直接呼叫，
/// 不需要透過 NotificationCenter 或是把 HelpView 塞進畫面階層才能觸發。
///
/// 使用說明改成網頁版教學（index.html + images/），打包成 `helpdocs.zip` 放進 App Bundle。
/// 每次點擊「使用說明」時：
///   1. 先強制刪除暫存區裡上一次解壓的舊版本，避免使用者看到過期內容
///   2. 重新解壓 helpdocs.zip 到暫存區
///   3. 用系統預設瀏覽器開啟解壓出來的 index.html
///
/// 找不到 zip、解壓失敗、或解壓後找不到 index.html 時，會跳出系統警示視窗說明原因。
enum HelpDocsOpener {

    /// 解壓縮後在暫存區使用的資料夾名稱
    private static let folderName = "helpdocs"

    /// 暫存區內，本次要解壓縮到的目的地資料夾
    /// （每次開啟都會先整個刪除重建，確保內容一定是 Bundle 裡最新的 helpdocs.zip）
    private static var destinationURL: URL {
        FileManager.default.temporaryDirectory.appendingPathComponent(folderName)
    }

    static func open() {
        guard let zipURL = Bundle.main.url(forResource: "helpdocs", withExtension: "zip") else {
            showAlert(
                title: "找不到使用說明檔案",
                message: "請確認「helpdocs.zip」已加入 Xcode 專案，並勾選 Target Membership。"
            )
            return
        }

        let fileManager = FileManager.default
        let destination = destinationURL

        // 1. 強制刪除先前解壓的舊版本
        if fileManager.fileExists(atPath: destination.path) {
            do {
                try fileManager.removeItem(at: destination)
            } catch {
                showAlert(
                    title: "無法清除舊的使用說明暫存檔",
                    message: "刪除「\(destination.path)」時發生錯誤：\(error.localizedDescription)"
                )
                return
            }
        }

        do {
            try fileManager.createDirectory(at: destination, withIntermediateDirectories: true)
        } catch {
            showAlert(
                title: "無法建立暫存資料夾",
                message: error.localizedDescription
            )
            return
        }

        // 2. 呼叫系統內建的 /usr/bin/unzip 解壓縮（-o 覆蓋、-q 安靜模式）
        let process = Process()
        process.executableURL = URL(fileURLWithPath: "/usr/bin/unzip")
        process.arguments = ["-o", "-q", zipURL.path, "-d", destination.path]

        do {
            try process.run()
            process.waitUntilExit()
        } catch {
            showAlert(
                title: "解壓縮使用說明失敗",
                message: "無法啟動 unzip 程序：\(error.localizedDescription)"
            )
            return
        }

        guard process.terminationStatus == 0 else {
            showAlert(
                title: "解壓縮使用說明失敗",
                message: "unzip 指令回傳錯誤代碼 \(process.terminationStatus)。"
            )
            return
        }

        // 3. helpdocs.zip 內若還包了一層 helpdocs/ 資料夾（例如在 Mac 上用 Finder／zip 指令
        //    直接壓縮資料夾產生的結構），這裡兩種路徑都嘗試找找看
        let candidateURLs = [
            destination.appendingPathComponent("index.html"),
            destination.appendingPathComponent(folderName).appendingPathComponent("index.html")
        ]

        guard let indexURL = candidateURLs.first(where: { fileManager.fileExists(atPath: $0.path) }) else {
            showAlert(
                title: "找不到使用說明首頁",
                message: "已解壓縮 helpdocs.zip，但找不到 index.html，請確認 zip 內容是否正確。"
            )
            return
        }

        NSWorkspace.shared.open(indexURL)
    }

    private static func showAlert(title: String, message: String) {
        let alert = NSAlert()
        alert.messageText = title
        alert.informativeText = message
        alert.alertStyle = .warning
        alert.runModal()
    }
}

/// 保留這個 View 是為了相容舊的呼叫方式
/// （例如 .sheet(isPresented:) { HelpView() } 或其他仍直接建立 HelpView() 的地方）。
/// 這個 View 本身不會顯示任何畫面：一出現就開啟使用說明網頁，然後立刻關閉自己。
///
/// 注意：選單列「Dictation Helper > Help」現在已經改成直接呼叫
/// HelpDocsOpener.open()（見 RootApp.swift），不會再經過這個 View。
struct HelpView: View {
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        let _ = print("🖼️ [\(Self.self)] body (\(#fileID))")
        Color.clear
            .onAppear {
                HelpDocsOpener.open()
                dismiss()
            }
    }
}

#Preview {
    HelpView()
}

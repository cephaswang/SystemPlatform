import Foundation

// 將 App Bundle 內附的 setup.sh 複製到使用者桌面，
// 讓 App 在偵測到前置軟體缺失時可直接引導使用者執行。
//
// ⚠️ 注意：改為直接複製檔案後，setup.sh 必須加入 Xcode 專案的
//         Target -> Build Phases -> Copy Bundle Resources，
//         才能透過 Bundle.main 找到它。
enum SetupScript {
    static let fileName = "setup.sh"

    enum SetupScriptError: LocalizedError {
        case resourceNotFound
        case desktopNotFound

        var errorDescription: String? {
            switch self {
            case .resourceNotFound:
                return "找不到內附的 \(SetupScript.fileName)，請確認已加入 Bundle Resource。"
            case .desktopNotFound:
                return "找不到使用者桌面路徑。"
            }
        }
    }

    /// 取得桌面上目標檔案的 URL（~/Desktop/setup.sh）
    static func desktopDestinationURL() throws -> URL {
        guard let desktopURL = FileManager.default.urls(for: .desktopDirectory, in: .userDomainMask).first else {
            throw SetupScriptError.desktopNotFound
        }
        return desktopURL.appendingPathComponent(fileName)
    }

    /// 若桌面已存在同名檔案，先刪除，再把 Bundle 內附的 setup.sh 複製到桌面。
    /// - Returns: 複製完成後的桌面檔案 URL
    @discardableResult
    static func installToDesktop() throws -> URL {
        try copy(to: try desktopDestinationURL().deletingLastPathComponent())
    }

    /// 若指定資料夾已存在同名檔案，先刪除，再把 Bundle 內附的 setup.sh 複製過去。
    /// - Parameter directory: 目標資料夾（例如桌面、下載、文件）
    /// - Returns: 複製完成後的檔案 URL
    @discardableResult
    static func copy(to directory: URL) throws -> URL {
        guard let bundledURL = Bundle.main.url(forResource: "setup", withExtension: "sh") else {
            throw SetupScriptError.resourceNotFound
        }

        let destinationURL = directory.appendingPathComponent(fileName)
        let fileManager = FileManager.default

        // 若目標資料夾已存在同名檔案，先刪除
        if fileManager.fileExists(atPath: destinationURL.path) {
            try fileManager.removeItem(at: destinationURL)
        }

        // 直接複製 setup.sh 到目標資料夾
        try fileManager.copyItem(at: bundledURL, to: destinationURL)

        // 賦予可執行權限，讓使用者可直接 ./setup.sh 執行
        try fileManager.setAttributes([.posixPermissions: 0o755], ofItemAtPath: destinationURL.path)

        return destinationURL
    }
}

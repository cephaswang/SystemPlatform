import SwiftUI
import AppKit
import Speech
import CoreAudio

// MARK: - 輸入裝置過濾

/// CoreAudio 會在行程使用「預設裝置」時，臨時建立私有聚合裝置
/// 「CADefaultDeviceAggregate-<PID>-<編號>」。它不是真實的麥克風，
/// 名稱含行程 PID、每次啟動都不同，選它會收不到聲音、無法聽抄，
/// 所以不讓它出現在輸入裝置選單裡，也不會被當成預設選擇。
private extension Collection {
    func excludingInternalAggregates(by name: KeyPath<Element, String>) -> [Element] {
        filter { !$0[keyPath: name].hasPrefix("CADefaultDeviceAggregate") }
    }
}

struct ContentView: View {
    @StateObject private var transcriber = SpeechTranscriber()
    @StateObject private var deviceManager = AudioDeviceManager()

    @AppStorage("selectedLocale") private var selectedLocale: String = Locale.current.identifier
    @State private var availableLocales: [String] = []

    // 雙語模式（記住使用者上次的選擇）
    @AppStorage("bilingualMode") private var bilingualMode: Bool = false
    @AppStorage("localeA") private var localeA: String = "zh-TW"
    @AppStorage("localeB") private var localeB: String = "en-US"

    // 前置軟體檢查（BlackHole）相關狀態
    @State private var showSetupAlert = false
    @State private var setupScriptURL: URL?

    // 停止聽抄確認對話框
    @State private var showStopConfirmation = false

    // 尚無逐字稿內容時的提示
    @State private var showNoTranscriptAlert = false

    // 使用者在選單上選擇的輸入裝置（麥克風或 BlackHole 2ch）。
    // 這只是畫面上的「意圖」，不會一選就立刻切換系統的預設輸入裝置；
    // 真正套用到系統是在按下「開始聽抄」的當下（見 startTranscription()）。
    @State private var selectedInputDeviceID: AudioDeviceID?

    // 記住使用者上次選的輸入裝置名稱，下次開啟 App／重新整理裝置清單時優先沿用
    @AppStorage("selectedInputDeviceName") private var selectedInputDeviceName: String = "BlackHole 2ch"

    // 自動切換系統輸出裝置到 Multi-Output Device 失敗時（例如環境還沒設置好，
    // 根本沒有這個裝置），用來顯示提示訊息
    @State private var outputSwitchWarning: String?

    var body: some View {
        let _ = print("🖼️ [\(Self.self)] body (\(#fileID))")
        
        VStack(alignment: .leading, spacing: 16) {

            Text("聽抄")
                .font(.title2)
                .bold()

            // 雙語模式開關
            /*
            Toggle(isOn: $bilingualMode) {
                Text("雙語模式（同時辨識兩種語言，自動選信心較高者）")
            }
            .disabled(transcriber.isRunning)
            */

            if bilingualMode {
                // 雙語模式：兩個語言各自選單
                HStack {
                    Text("語言 A：")
                    Picker("", selection: $localeA) {
                        ForEach(availableLocales, id: \.self) { code in
                            Text("\(displayName(for: code))（\(code)）").tag(code)
                        }
                    }
                    .frame(width: 280)
                    .disabled(transcriber.isRunning)
                }
                HStack {
                    Text("語言 B：")
                    Picker("", selection: $localeB) {
                        ForEach(availableLocales, id: \.self) { code in
                            Text("\(displayName(for: code))（\(code)）").tag(code)
                        }
                    }
                    .frame(width: 280)
                    .disabled(transcriber.isRunning)
                }
                Text("💡 雙語模式會同時跑兩個辨識引擎，CPU 用量較高；每句話說完後系統會自動比較兩邊的信心分數，選較高者存檔。無法辨識「同一句話裡中英夾雜」的情況，適合「整段話都用同一種語言、但不同段落切換語言」的場景。")
                    .font(.caption)
                    .foregroundColor(.secondary)
            } else {
                // 單語模式：動態列出「這台 Mac 目前」支援語音辨識的所有語系
                HStack {
                    Text("語系：")
                    Picker("", selection: $selectedLocale) {
                        ForEach(availableLocales, id: \.self) { code in
                            Text("\(displayName(for: code))（\(code)）").tag(code)
                        }
                    }
                    .frame(width: 300)
                    .disabled(transcriber.isRunning)

                    Text("（共 \(availableLocales.count) 種）")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }

            // 輸入裝置選單
            // 選單本身只是「使用者想用哪個輸入裝置」的本地選擇，不會一選就立刻改系統預設輸入；
            // 真正切換系統輸入裝置的時機是按下「開始聽抄」的當下（見下方按鈕動作）。
            HStack {
                Text("輸入裝置：")
                Picker("", selection: Binding(
                    get: { selectedInputDeviceID ?? deviceManager.currentInputDeviceID ?? 0 },
                    set: { newID in
                        selectedInputDeviceID = newID
                        if let name = deviceManager.inputDevices.excludingInternalAggregates(by: \.name).first(where: { $0.id == newID })?.name {
                            selectedInputDeviceName = name
                        }
                    }
                )) {
                    ForEach(deviceManager.inputDevices.excludingInternalAggregates(by: \.name)) { device in
                        Text(inputDeviceLabel(for: device.name)).tag(device.id)
                    }
                }
                .frame(width: 260)
                .disabled(transcriber.isRunning)

                Button("重新整理") {
                    deviceManager.refreshDevices()
                    reconcileSelectedInputDevice()
                }
                .disabled(transcriber.isRunning)
            }

            if isSelectedInputBlackHole {
                Text("✅ 按下「開始聽抄」時，會自動把系統輸出裝置切換為 Multi-Output Device，同時把輸入裝置切成 BlackHole 2ch，不需要自己跑一趟「系統設定 > 聲音」")
                   // .font(.title3)
                   // .bold()
                    .foregroundColor(.black)
                    .padding(10)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.green)
                    .cornerRadius(8)

                if let outputSwitchWarning {
                    Text("⚠️ \(outputSwitchWarning)")
                        .foregroundColor(.black)
                        .padding(10)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(Color.yellow.opacity(0.6))
                        .cornerRadius(8)
                }
            } else {
                Text("🎤 目前選擇的是麥克風，會直接收錄您說話與周圍環境的聲音，不需要另外設定 Multi-Output Device。\n如果要改成擷取系統播放的聲音（例如影片、會議錄影），請在上方選單改選 BlackHole 2ch")
                    .foregroundColor(.black)
                    .padding(10)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.blue.opacity(0.15))
                    .cornerRadius(8)
            }

            // 開始 / 停止
            HStack {
                Button(transcriber.isRunning ? "停止聽抄" : "開始聽抄") {
                    if transcriber.isRunning {
                        showStopConfirmation = true
                    } else {
                        outputSwitchWarning = nil

                        // 不管使用者有沒有手動碰過選單，開始前一律重新對齊一次，
                        // 確保 selectedInputDeviceID 反映「目前真的存在」的裝置，
                        // 避免用到啟動當下還沒枚舉完成、或裝置已經拔掉的過期資料。
                        reconcileSelectedInputDevice()

                        let outputDir = FileManager.default
                            .urls(for: .documentDirectory, in: .userDomainMask)
                            .first!
                        // AudioDeviceID 0（kAudioObjectUnknown）不是有效裝置，
                        // 絕對不能傳給 CoreAudio，否則會被 HAL 直接回絕（"nope" 錯誤）。
                        let deviceID = [selectedInputDeviceID, deviceManager.currentInputDeviceID, deviceManager.inputDevices.excludingInternalAggregates(by: \.name).first?.id]
                            .compactMap { $0 }
                            .first { $0 != 0 }
                        let shouldSwitchOutput = isSelectedInputBlackHole

                        Task {
                            // 開始聽抄前，把系統預設輸入裝置自動切成使用者在選單上選的那個
                            // （麥克風或 BlackHole 2ch），使用者不需要自己再跑一趟「系統設定 > 聲音」。
                            let allNames = deviceManager.inputDevices.map(\.name)
                            let pickedName = deviceManager.inputDevices.first(where: { $0.id == deviceID })?.name ?? "nil"
                            print("[Audio] 開始聽抄：deviceID=\(deviceID.map { String($0) } ?? "nil")，name=\(pickedName)，系統列出的輸入裝置=\(allNames)")
                            var inputSwitchConfirmed = true
                            if let deviceID {
                                let inputOK = deviceManager.setDefaultInputDevice(deviceID)
                                print("[Audio] 切換輸入裝置 → \(pickedName)：\(inputOK ? "成功" : "失敗")")
                                if inputOK {
                                    inputSwitchConfirmed = await deviceManager.waitForDefaultInputDeviceChange(expected: deviceID)
                                    print("[Audio] 確認系統輸入裝置已真正切換完成：\(inputSwitchConfirmed)")
                                }
                            } else {
                                print("[Audio] 沒有可用的輸入裝置 ID，略過切換輸入")
                            }

                            // 只有在用 BlackHole 擷取系統聲音時才需要 Multi-Output Device；
                            // 選麥克風的話完全不用動系統輸出，維持使用者原本在聽的裝置。
                            if shouldSwitchOutput {
                                let outputOK = switchSystemOutputToMultiOutputDevice()
                                print("[Audio] 切換輸出裝置 → Multi-Output Device：\(outputOK ? "成功" : "失敗")")
                                if !outputOK {
                                    outputSwitchWarning = "無法切換到「Multi-Output Device」（找不到這個裝置，或系統拒絕切換），請先完成環境設置，或自行到「系統設定 > 聲音」手動切換輸出裝置"
                                }
                            } else {
                                print("[Audio] 選的不是 BlackHole，不切換輸出裝置")
                            }

                            // 上面 waitForDefaultInputDeviceChange 已經確認系統「預設輸入裝置」
                            // 真的切換完成了；但 HAL 發出通知的當下，硬體格式（sample rate 等）
                            // 有時還要再幾十毫秒才完全穩定，所以保留一段很短的緩衝時間。
                            // 如果上面等到逾時都沒收到確認通知，就用比較保守的緩衝時間，
                            // 讓後面 SpeechTranscriber 啟動前系統有更多機會把格式穩定下來。
                            let settleNanoseconds: UInt64 = inputSwitchConfirmed ? 80_000_000 : 300_000_000
                            try? await Task.sleep(nanoseconds: settleNanoseconds)

                            // 讀回系統「實際」的預設輸入 / 輸出裝置，確認切換真的生效
                            logCurrentDefaultDevices()

                            if bilingualMode {
                                transcriber.startBilingual(localeA: localeA, localeB: localeB, outputDirectory: outputDir, inputDeviceID: deviceID)
                            } else {
                                transcriber.start(localeIdentifier: selectedLocale, outputDirectory: outputDir, inputDeviceID: deviceID)
                            }
                        }
                    }
                }
                .buttonStyle(.borderedProminent)
                .confirmationDialog(
                    "確定要停止聽抄嗎？",
                    isPresented: $showStopConfirmation,
                    titleVisibility: .visible
                ) {
                    Button("停止聽抄", role: .destructive) {
                        transcriber.stop()
                    }
                    Button("取消", role: .cancel) { }
                } message: {
                    Text("停止後，目前尚未定案的內容會強制寫入檔案，不會遺失。")
                }

                Button("在 Finder 中顯示逐字稿") {
                    if let url = transcriber.outputFileURL,
                       FileManager.default.fileExists(atPath: url.path) {
                        NSWorkspace.shared.activateFileViewerSelecting([url])
                    } else {
                        showNoTranscriptAlert = true
                    }
                }
            }

            if !transcriber.statusMessage.isEmpty {
                Text(transcriber.statusMessage)
                    .foregroundColor(.red)
            }

            Divider()

            if bilingualMode {
                // 雙語模式：兩個引擎各自的即時假設分開顯示
                Text("即時辨識（語言 A：\(displayName(for: localeA))）：")
                    .font(.headline)
                ScrollView {
                    Text(transcriber.liveTextA)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .textSelection(.enabled)
                }
                .padding(8)
                .frame(maxWidth: .infinity, minHeight: 36, maxHeight: 80, alignment: .leading)
                .background(Color.gray.opacity(0.1))
                .cornerRadius(6)

                Text("即時辨識（語言 B：\(displayName(for: localeB))）：")
                    .font(.headline)
                ScrollView {
                    Text(transcriber.liveTextB)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .textSelection(.enabled)
                }
                .padding(8)
                .frame(maxWidth: .infinity, minHeight: 36, maxHeight: 80, alignment: .leading)
                .background(Color.gray.opacity(0.1))
                .cornerRadius(6)
            } else {
                Text("即時辨識：")
                    .font(.headline)
                ScrollView {
                    Text(transcriber.liveText)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .textSelection(.enabled)
                }
                .padding(8)
                .frame(maxWidth: .infinity, minHeight: 40, maxHeight: 120, alignment: .leading)
                .background(Color.gray.opacity(0.1))
                .cornerRadius(6)
            }

            HStack {
                Text("已存檔內容：")
                    .font(.headline)
                if let url = transcriber.outputFileURL {
                    Text("(\(url.lastPathComponent))")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
            ScrollView {
                VStack(alignment: .leading, spacing: 4) {
                    ForEach(Array(transcriber.savedSentences.enumerated()), id: \.offset) { _, sentence in
                        Text(sentence)
                    }
                }
                .frame(maxWidth: .infinity, alignment: .leading)
            }
            .frame(minHeight: 200)
            .background(Color.gray.opacity(0.05))
            .cornerRadius(6)


        }
        .padding(20)
        .frame(minWidth: 560, minHeight: 640)
        .onAppear {
            loadAvailableLocales()
            checkPrerequisites()
            reconcileSelectedInputDevice()
        }
        .alert("尚未有逐字稿內容", isPresented: $showNoTranscriptAlert) {
            Button("好，我知道了", role: .cancel) { }
        } message: {
            Text("請先按下「開始聽抄」並播放/說話，系統辨識出第一句話後，才會建立逐字稿檔案。")
        }
        .sheet(isPresented: $showSetupAlert) {
            SetupInstructionsView(
                locationDescription: setupScriptLocationDescription,
                command: setupScriptCommand,
                onCopy: copyInstallCommandToClipboard,
                onDismiss: { showSetupAlert = false }
            )
        }
    }

    // MARK: - 前置軟體檢查

    private func checkPrerequisites() {
        guard !PrerequisiteChecker.isBlackHoleInstalled() else { return }

        if let url = PrerequisiteChecker.copySetupScriptToDesktop() {
            setupScriptURL = url
            showSetupAlert = true
        }
    }

    private func copyInstallCommandToClipboard() {
        let pasteboard = NSPasteboard.general
        pasteboard.clearContents()
        pasteboard.setString(setupScriptCommand, forType: .string)
    }

    // 依實際寫入的資料夾路徑，動態組出人看得懂的位置說明
    private var setupScriptLocationDescription: String {
        guard let url = setupScriptURL else { return SetupScript.fileName }
        let folderName = url.deletingLastPathComponent().lastPathComponent
        return "「\(folderName)」資料夾：\(SetupScript.fileName)"
    }

    // 依實際寫入的資料夾路徑，動態組出對應的終端機指令
    private var setupScriptCommand: String {
        guard let url = setupScriptURL else {
            return "cd ~/Desktop && ./\(SetupScript.fileName)"
        }
        let folderPath = url.deletingLastPathComponent().path
        return "cd \"\(folderPath)\" && bash ./\(SetupScript.fileName)"
    }

    // MARK: - 動態載入這台 Mac 目前支援語音辨識的所有語系

    private func loadAvailableLocales() {
        let supported = SFSpeechRecognizer.supportedLocales()
            .map { $0.identifier }
            .sorted { lhs, rhs in
                displayName(for: lhs).localizedStandardCompare(displayName(for: rhs)) == .orderedAscending
            }

        availableLocales = supported

        // 正規化比對（zh-TW / zh_TW 視為相同，大小寫也忽略），避免因格式差異比對失敗
        func normalize(_ s: String) -> String {
            s.replacingOccurrences(of: "_", with: "-").lowercased()
        }

        func firstMatch(_ target: String) -> String? {
            supported.first { normalize($0) == normalize(target) }
        }

        // 單語模式：如果上次存的選擇這台系統目前仍支援，就沿用；否則才套用預設邏輯
        let preferredCandidates = ["zh-TW", "zh-Hant-TW", "zh-Hant_TW", "zh_TW"]

        if let keep = firstMatch(selectedLocale) {
            selectedLocale = keep // 統一成系統實際回傳的字串格式，避免底線/大小寫差異
        } else if let match = preferredCandidates.compactMap({ firstMatch($0) }).first {
            selectedLocale = match
        } else if let match = firstMatch(Locale.current.identifier) {
            selectedLocale = match
        } else if let first = supported.first {
            selectedLocale = first
        }

        // 雙語模式：同樣優先沿用上次存下來的選擇
        if let keepA = firstMatch(localeA) {
            localeA = keepA
        } else if let matchA = firstMatch("zh-TW") ?? preferredCandidates.compactMap({ firstMatch($0) }).first {
            localeA = matchA
        } else if let first = supported.first {
            localeA = first
        }

        if let keepB = firstMatch(localeB) {
            localeB = keepB
        } else if let matchB = firstMatch("en-US") {
            localeB = matchB
        } else if let second = supported.first(where: { $0 != localeA }) {
            localeB = second
        }
    }

    // 把語系代碼（如 "zh-TW"）轉成人類看得懂的名稱（如 "中文（台灣）"）
    private func displayName(for code: String) -> String {
        Locale.current.localizedString(forIdentifier: code) ?? code
    }

    // MARK: - 輸入裝置（麥克風 / BlackHole）

    /// 選單裡每個裝置後面加註「（系統聲音）」或「（麥克風）」，讓使用者一眼看出用途差異
    private func inputDeviceLabel(for deviceName: String) -> String {
        deviceName == "BlackHole 2ch" ? "\(deviceName)（系統聲音）" : "\(deviceName)（麥克風）"
    }

    /// 目前選單上選的是不是 BlackHole 2ch（用來決定要顯示哪一種提示文字）
    private var isSelectedInputBlackHole: Bool {
        let currentID = selectedInputDeviceID ?? deviceManager.currentInputDeviceID
        guard let currentID else { return false }
        return deviceManager.inputDevices.excludingInternalAggregates(by: \.name).first(where: { $0.id == currentID })?.name == "BlackHole 2ch"
    }

    /// 讓 `selectedInputDeviceID` 對齊目前真的存在的裝置清單：
    /// - 優先沿用使用者上次選過的裝置名稱（`selectedInputDeviceName`）
    /// - 找不到（例如裝置被拔掉、或第一次使用）就 fallback 用系統目前的預設輸入裝置
    /// - 兩者都找不到，就選清單第一個裝置
    /// 會在 App 啟動時、以及使用者按「重新整理」之後呼叫
    private func reconcileSelectedInputDevice() {
        if let match = deviceManager.inputDevices.excludingInternalAggregates(by: \.name).first(where: { $0.name == selectedInputDeviceName }) {
            selectedInputDeviceID = match.id
        } else if let currentID = deviceManager.currentInputDeviceID,
                  deviceManager.inputDevices.excludingInternalAggregates(by: \.name).contains(where: { $0.id == currentID }) {
            selectedInputDeviceID = currentID
        } else if let first = deviceManager.inputDevices.excludingInternalAggregates(by: \.name).first {
            selectedInputDeviceID = first.id
        }

        if let id = selectedInputDeviceID,
           let name = deviceManager.inputDevices.excludingInternalAggregates(by: \.name).first(where: { $0.id == id })?.name {
            selectedInputDeviceName = name
        }
    }

    // MARK: - 輸出裝置（Multi-Output Device）自動切換
    //
    // AudioDeviceManager 目前只管理「輸入」裝置，這裡用最小範圍的 CoreAudio 呼叫
    // 直接處理「輸出」裝置的查詢與切換，避免為了這一個小功能去動 AudioDeviceManager
    // 既有的介面。裝置名稱固定找「Multi-Output Device」，對應 AudioSetupManager
    // 一鍵設置時建立的那個聚合裝置（見 AudioSetupManager.swift 的 aggregateDeviceName）。

    /// 把系統目前的預設輸出裝置切到名為「Multi-Output Device」的裝置。
    /// 回傳 false 代表找不到這個裝置（例如環境設置精靈還沒跑過），呼叫端可以藉此提示使用者。
    @discardableResult
    private func switchSystemOutputToMultiOutputDevice() -> Bool {
        guard let deviceID = findOutputDeviceID(named: "Multi-Output Device"), deviceID != 0 else {
            print("[Audio] 系統裡找不到名為「Multi-Output Device」的裝置")
            return false
        }
        print("[Audio] 找到 Multi-Output Device：id=\(deviceID)")
        return setDefaultOutputDevice(deviceID)
    }

    private func findOutputDeviceID(named targetName: String) -> AudioDeviceID? {
        var address = AudioObjectPropertyAddress(
            mSelector: kAudioHardwarePropertyDevices,
            mScope: kAudioObjectPropertyScopeGlobal,
            mElement: kAudioObjectPropertyElementMain)

        var dataSize: UInt32 = 0
        guard AudioObjectGetPropertyDataSize(AudioObjectID(kAudioObjectSystemObject), &address, 0, nil, &dataSize) == noErr else {
            return nil
        }
        let count = Int(dataSize) / MemoryLayout<AudioDeviceID>.size
        var deviceIDs = [AudioDeviceID](repeating: 0, count: count)
        guard AudioObjectGetPropertyData(AudioObjectID(kAudioObjectSystemObject), &address, 0, nil, &dataSize, &deviceIDs) == noErr else {
            return nil
        }

        return deviceIDs.first { deviceName(for: $0) == targetName }
    }

    private func deviceName(for deviceID: AudioDeviceID) -> String? {
        var address = AudioObjectPropertyAddress(
            mSelector: kAudioObjectPropertyName,
            mScope: kAudioObjectPropertyScopeGlobal,
            mElement: kAudioObjectPropertyElementMain)
        var name: CFString = "" as CFString
        var size = UInt32(MemoryLayout<CFString>.size)
        let status = withUnsafeMutablePointer(to: &name) { ptr -> OSStatus in
            AudioObjectGetPropertyData(deviceID, &address, 0, nil, &size, ptr)
        }
        return status == noErr ? (name as String) : nil
    }

    @discardableResult
    private func setDefaultOutputDevice(_ deviceID: AudioDeviceID) -> Bool {
        var address = AudioObjectPropertyAddress(
            mSelector: kAudioHardwarePropertyDefaultOutputDevice,
            mScope: kAudioObjectPropertyScopeGlobal,
            mElement: kAudioObjectPropertyElementMain)
        var mutableID = deviceID
        let status = AudioObjectSetPropertyData(
            AudioObjectID(kAudioObjectSystemObject), &address, 0, nil,
            UInt32(MemoryLayout<AudioDeviceID>.size), &mutableID)
        print("[Audio] 設定預設輸出裝置 id=\(deviceID)：status=\(status)（0 = 成功）")
        return status == noErr
    }

    /// 讀回系統目前實際的預設輸入 / 輸出裝置並印出（除錯用）
    private func logCurrentDefaultDevices() {
        let inputID = AudioDeviceManager.getDefaultInputDevice()
        let outputID = currentDefaultOutputDeviceID()
        let inputName = inputID.flatMap { deviceName(for: $0) } ?? "nil"
        let outputName = outputID.flatMap { deviceName(for: $0) } ?? "nil"
        print("[Audio] 目前系統預設輸入 = \(inputName)（id=\(inputID.map { String($0) } ?? "nil")）")
        print("[Audio] 目前系統預設輸出 = \(outputName)（id=\(outputID.map { String($0) } ?? "nil")）")
    }

    private func currentDefaultOutputDeviceID() -> AudioDeviceID? {
        var deviceID = AudioDeviceID(0)
        var size = UInt32(MemoryLayout<AudioDeviceID>.size)
        var address = AudioObjectPropertyAddress(
            mSelector: kAudioHardwarePropertyDefaultOutputDevice,
            mScope: kAudioObjectPropertyScopeGlobal,
            mElement: kAudioObjectPropertyElementMain)
        let status = AudioObjectGetPropertyData(
            AudioObjectID(kAudioObjectSystemObject), &address, 0, nil, &size, &deviceID)
        return status == noErr ? deviceID : nil
    }
}

// 需要先安裝 BlackHole 時顯示的自訂視窗（取代原本的 .alert，
// 因為系統原生 alert 的內文無法自訂顏色／底色）
struct SetupInstructionsView: View {
    let locationDescription: String
    let command: String
    let onCopy: () -> Void
    let onDismiss: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("需要先安裝 BlackHole")
                .font(.title2)
                .bold()

            Text("偵測不到 BlackHole 虛擬音訊裝置，這是把喇叭聲音送進辨識引擎必要的元件。")

            VStack(alignment: .leading, spacing: 6) {
                Text("已經把安裝腳本複製到：")
                Text(locationDescription)
                    .font(.system(.body, design: .monospaced))
            }

            VStack(alignment: .leading, spacing: 6) {
                Text("請打開「終端機」App，執行以下指令完成安裝：")
                Text(command)
                    .font(.system(.body, design: .monospaced))
                    .textSelection(.enabled)
                    .padding(8)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.gray.opacity(0.1))
                    .cornerRadius(6)
            }

            Text("⚠️ 安裝完成後，請務必「重新開機」，BlackHole 才會正式生效！")
                .bold()
                .foregroundColor(.black)
                .padding(10)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(Color.green)
                .cornerRadius(8)

            HStack {
                Spacer()
                Button("複製指令", action: onCopy)
                Button("知道了", role: .cancel, action: onDismiss)
                    .buttonStyle(.borderedProminent)
            }
        }
        .padding(24)
        .frame(width: 480)
    }
}

#Preview {
    ContentView()
}

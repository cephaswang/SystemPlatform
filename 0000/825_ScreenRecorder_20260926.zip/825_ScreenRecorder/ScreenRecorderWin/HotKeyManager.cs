using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Windows.Input;
using System.Windows.Interop;

namespace ScreenRecorderWin
{
    /// <summary>
    /// 全域快捷鍵管理員。
    /// 對應企劃書第 4 節預設組合鍵：
    ///   開始錄影 Ctrl+Alt+Win+R、暫停 Ctrl+Alt+Win+P、繼續 Ctrl+Alt+Win+C、停止 Ctrl+Alt+Win+S。
    /// 實作方式：建立一個不可見的「訊息專用視窗」（HWND_MESSAGE），呼叫 Win32 RegisterHotKey
    /// 將按鍵組合綁定到該視窗，並攔截 WM_HOTKEY 訊息派發給對應的回呼委派。
    /// 已知限制（與 macOS 版相同）：快捷鍵僅支援固定組合鍵，觸發的「開始錄影」固定為全螢幕，
    /// 使用者自訂快捷鍵設定畫面列為 Phase 4 項目。
    /// </summary>
    public sealed class HotKeyManager : IDisposable
    {
        public enum Action
        {
            StartRecording,
            Pause,
            Resume,
            Stop
        }

        [Flags]
        private enum Modifiers : uint
        {
            None = 0x0000,
            Alt = 0x0001,
            Control = 0x0002,
            Shift = 0x0004,
            Win = 0x0008,
            NoRepeat = 0x4000 // 避免按住不放時重複觸發
        }

        private const int WM_HOTKEY = 0x0312;

        // 自訂 ID 起始值，避開常見保留區段（有效範圍為 0x0000–0xBFFF）。
        private const int FirstHotKeyId = 0xA000;

        private readonly HwndSource _messageWindow;
        private readonly Dictionary<int, System.Action> _callbacksById = new();
        private readonly Dictionary<Action, int> _idsByAction = new();
        private int _nextId = FirstHotKeyId;
        private bool _disposed;

        public HotKeyManager()
        {
            var parameters = new HwndSourceParameters("ScreenRecorderWin_HotKeyMessageWindow")
            {
                Width = 0,
                Height = 0,
                WindowStyle = 0,
                // HWND_MESSAGE（-3）：純訊息視窗，不會顯示、不會出現在工作列或 Alt+Tab 清單中。
                ParentWindow = new IntPtr(-3)
            };

            _messageWindow = new HwndSource(parameters);
            _messageWindow.AddHook(WndProc);
        }

        /// <summary>
        /// 註冊指定動作對應的預設快捷鍵，並綁定觸發時要執行的回呼。
        /// 若該組合鍵已被系統或其他程式佔用，註冊會失敗但不會擲出例外——
        /// 僅記錄除錯訊息，避免單一按鍵衝突導致整個程式無法啟動。
        /// </summary>
        public bool Register(Action action, System.Action callback)
        {
            if (callback == null) throw new ArgumentNullException(nameof(callback));

            var (modifiers, key) = GetDefaultBinding(action);
            uint virtualKey = (uint)KeyInterop.VirtualKeyFromKey(key);
            int id = _nextId++;

            bool success = RegisterHotKey(
                _messageWindow.Handle,
                id,
                (uint)modifiers | (uint)Modifiers.NoRepeat,
                virtualKey);

            if (!success)
            {
                System.Diagnostics.Debug.WriteLine(
                    $"[HotKeyManager] 註冊快捷鍵失敗（可能已被其他程式佔用）：{action} -> {DescribeBinding(modifiers, key)}");
                return false;
            }

            _callbacksById[id] = callback;
            _idsByAction[action] = id;
            return true;
        }

        /// <summary>取消單一動作的快捷鍵註冊；例如未來 Phase 4 開放使用者自訂快捷鍵時，重新綁定前需先呼叫。</summary>
        public void Unregister(Action action)
        {
            if (!_idsByAction.TryGetValue(action, out int id))
            {
                return;
            }

            UnregisterHotKey(_messageWindow.Handle, id);
            _callbacksById.Remove(id);
            _idsByAction.Remove(action);
        }

        private static (Modifiers modifiers, Key key) GetDefaultBinding(Action action) => action switch
        {
            Action.StartRecording => (Modifiers.Control | Modifiers.Alt | Modifiers.Win, Key.R),
            Action.Pause => (Modifiers.Control | Modifiers.Alt | Modifiers.Win, Key.P),
            Action.Resume => (Modifiers.Control | Modifiers.Alt | Modifiers.Win, Key.C),
            Action.Stop => (Modifiers.Control | Modifiers.Alt | Modifiers.Win, Key.S),
            _ => throw new ArgumentOutOfRangeException(nameof(action), action, null)
        };

        private static string DescribeBinding(Modifiers modifiers, Key key)
        {
            var parts = new List<string>();
            if (modifiers.HasFlag(Modifiers.Control)) parts.Add("Ctrl");
            if (modifiers.HasFlag(Modifiers.Alt)) parts.Add("Alt");
            if (modifiers.HasFlag(Modifiers.Shift)) parts.Add("Shift");
            if (modifiers.HasFlag(Modifiers.Win)) parts.Add("Win");
            parts.Add(key.ToString());
            return string.Join("+", parts);
        }

        private IntPtr WndProc(IntPtr hwnd, int msg, IntPtr wParam, IntPtr lParam, ref bool handled)
        {
            if (msg == WM_HOTKEY)
            {
                int id = wParam.ToInt32();
                if (_callbacksById.TryGetValue(id, out var callback))
                {
                    // 回呼可能牽動 UI（例如更新按鈕狀態），但本訊息視窗與主視窗同屬 UI 執行緒的
                    // 訊息迴圈，因此可直接呼叫，不需額外派送至 Dispatcher。
                    callback.Invoke();
                    handled = true;
                }
            }

            return IntPtr.Zero;
        }

        public void Dispose()
        {
            if (_disposed) return;

            foreach (int id in _callbacksById.Keys)
            {
                UnregisterHotKey(_messageWindow.Handle, id);
            }
            _callbacksById.Clear();
            _idsByAction.Clear();

            _messageWindow.RemoveHook(WndProc);
            _messageWindow.Dispose();

            _disposed = true;
        }

        #region Win32 Interop

        [DllImport("user32.dll", SetLastError = true)]
        private static extern bool RegisterHotKey(IntPtr hWnd, int id, uint fsModifiers, uint vk);

        [DllImport("user32.dll", SetLastError = true)]
        private static extern bool UnregisterHotKey(IntPtr hWnd, int id);

        #endregion
    }
}

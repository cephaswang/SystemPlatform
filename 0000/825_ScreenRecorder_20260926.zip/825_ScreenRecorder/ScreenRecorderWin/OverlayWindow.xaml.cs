using System;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Interop;
using System.Windows.Threading;
using Forms = System.Windows.Forms;

namespace ScreenRecorderWin
{
    /// <summary>
    /// 共用覆蓋層視窗：螢幕編號提示、錄影中範圍紅框。
    /// 兩種用途皆為「不可互動、不吃滑鼠事件」的疊加視窗，透過 WS_EX_TRANSPARENT
    /// 讓滑鼠點擊直接穿透到底下的視窗／桌面。
    /// </summary>
    public partial class OverlayWindow : Window
    {
        public enum OverlayKind
        {
            /// <summary>多螢幕時於畫面中央短暫顯示編號，對應主視窗下拉選單順序。</summary>
            ScreenNumber,

            /// <summary>自訂範圍錄製中，於實際擷取範圍疊加穿透紅框。</summary>
            RegionBorder
        }

        private const double ScreenNumberDisplaySeconds = 1.5;

        private readonly OverlayKind _kind;
        private readonly Forms.Screen _screen;
        private readonly int _number;
        private readonly Rect? _region;

        private DispatcherTimer? _autoCloseTimer;

        /// <param name="kind">覆蓋層用途。</param>
        /// <param name="screen">目標螢幕；ScreenNumber 用於決定顯示位置，RegionBorder 於未指定 <paramref name="region"/> 時作為備援（覆蓋整台螢幕）。</param>
        /// <param name="number">ScreenNumber 用途下要顯示的編號。</param>
        /// <param name="region">RegionBorder 用途下要疊加紅框的實際擷取範圍（虛擬桌面座標），對應 RecorderManager／RegionSelectorWindow 使用的座標系。</param>
        public OverlayWindow(OverlayKind kind, Forms.Screen screen, int number = 0, Rect? region = null)
        {
            _kind = kind;
            _screen = screen ?? throw new ArgumentNullException(nameof(screen));
            _number = number;
            _region = region;

            InitializeComponent();
            Loaded += OverlayWindow_OnLoaded;
        }

        private void OverlayWindow_OnLoaded(object sender, RoutedEventArgs e)
        {
            switch (_kind)
            {
                case OverlayKind.ScreenNumber:
                    SetupScreenNumber();
                    break;

                case OverlayKind.RegionBorder:
                    SetupRegionBorder();
                    break;
            }

            MakeClickThrough();
        }

        private void SetupScreenNumber()
        {
            // 覆蓋整台目標螢幕，讓「置中」的徽章確實對齊該螢幕中央，而非虛擬桌面整體中央。
            var bounds = _screen.Bounds;
            Left = bounds.Left;
            Top = bounds.Top;
            Width = bounds.Width;
            Height = bounds.Height;

            NumberBadge.Visibility = Visibility.Visible;
            RegionBorderRect.Visibility = Visibility.Collapsed;
            NumberText.Text = _number.ToString();

            _autoCloseTimer = new DispatcherTimer
            {
                Interval = TimeSpan.FromSeconds(ScreenNumberDisplaySeconds)
            };
            _autoCloseTimer.Tick += (_, _) =>
            {
                _autoCloseTimer?.Stop();
                Close();
            };
            _autoCloseTimer.Start();
        }

        private void SetupRegionBorder()
        {
            // 未提供明確 region 時退回覆蓋整台螢幕，避免呼叫端疏漏參數導致視窗尺寸為 0。
            Rect region = _region ?? new Rect(
                _screen.Bounds.Left, _screen.Bounds.Top,
                _screen.Bounds.Width, _screen.Bounds.Height);

            Left = region.X;
            Top = region.Y;
            Width = region.Width;
            Height = region.Height;

            NumberBadge.Visibility = Visibility.Collapsed;
            RegionBorderRect.Visibility = Visibility.Visible;

            // 停留到呼叫端（例如 MainWindow 收到 RecordingStopped 後）主動呼叫 Close()，
            // 不設自動關閉計時器。
        }

        /// <summary>
        /// 將視窗設為 click-through：加入 WS_EX_TRANSPARENT（滑鼠事件穿透）與
        /// WS_EX_LAYERED（搭配 AllowsTransparency 的分層視窗合成）擴充樣式。
        /// </summary>
        private void MakeClickThrough()
        {
            IntPtr hwnd = new WindowInteropHelper(this).Handle;
            int exStyle = GetWindowLong(hwnd, GWL_EXSTYLE);
            SetWindowLong(hwnd, GWL_EXSTYLE, exStyle | WS_EX_TRANSPARENT | WS_EX_LAYERED);
        }

        #region Win32 Interop

        private const int GWL_EXSTYLE = -20;
        private const int WS_EX_TRANSPARENT = 0x00000020;
        private const int WS_EX_LAYERED = 0x00080000;

        // 注意：此處使用 32 位元版本的 GetWindowLong/SetWindowLong。在純 64 位元建置下 IntPtr 樣式值
        // 仍落在 32 位元範圍內可正常運作；若日後改用 GetWindowLongPtr/SetWindowLongPtr 需一併調整簽章。
        [DllImport("user32.dll", SetLastError = true)]
        private static extern int GetWindowLong(IntPtr hWnd, int nIndex);

        [DllImport("user32.dll", SetLastError = true)]
        private static extern int SetWindowLong(IntPtr hWnd, int nIndex, int dwNewLong);

        #endregion
    }
}

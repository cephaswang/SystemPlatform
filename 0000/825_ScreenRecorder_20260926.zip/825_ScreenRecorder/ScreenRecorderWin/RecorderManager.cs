using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using Forms = System.Windows.Forms;               // Screen（多螢幕資訊、DPI）
using Windows.Graphics.Capture;                    // WGC：GraphicsCaptureItem / Session / FramePool
using Windows.Graphics.DirectX;                     // DirectXPixelFormat
using Windows.Graphics.DirectX.Direct3D11;          // IDirect3DDevice / IDirect3DSurface
using SharpDX.Direct3D11;
using SharpDX.DXGI;
using SharpDX.MediaFoundation;
using Device = SharpDX.Direct3D11.Device;
using Resource = SharpDX.Direct3D11.Resource;

namespace ScreenRecorderWin
{
    /// <summary>錄影結束事件的結果資料。</summary>
    public sealed class RecordingStoppedEventArgs : EventArgs
    {
        public bool Success { get; }
        public string? OutputPath { get; }
        public string? ErrorMessage { get; }

        public RecordingStoppedEventArgs(bool success, string? outputPath, string? errorMessage = null)
        {
            Success = success;
            OutputPath = outputPath;
            ErrorMessage = errorMessage;
        }
    }

    /// <summary>
    /// 共用的錄影時鐘：負責「暫停/續錄時間戳位移」演算法。
    /// 錄製中的每一顆畫面／音訊樣本，時間戳一律取「牆鐘經過時間 － 累計暫停時間」，
    /// 暫停期間本身不產生任何樣本（畫面直接丟棄、音訊擷取暫停），因此續錄後輸出時間軸維持連續、不留空隙。
    /// 音訊（AudioMixer）與視訊（RecorderManager）共用同一顆時鐘，確保兩軌對齊。
    /// </summary>
    public sealed class RecordingClock
    {
        private readonly Stopwatch _stopwatch = new();
        private readonly object _lock = new();
        private TimeSpan _accumulatedPause = TimeSpan.Zero;
        private DateTime? _pauseStartedAtUtc;

        public bool IsPaused { get; private set; }

        public void Start() => _stopwatch.Start();

        public void Pause()
        {
            lock (_lock)
            {
                if (IsPaused) return;
                IsPaused = true;
                _pauseStartedAtUtc = DateTime.UtcNow;
            }
        }

        public void Resume()
        {
            lock (_lock)
            {
                if (!IsPaused) return;
                if (_pauseStartedAtUtc.HasValue)
                {
                    _accumulatedPause += DateTime.UtcNow - _pauseStartedAtUtc.Value;
                    _pauseStartedAtUtc = null;
                }
                IsPaused = false;
            }
        }

        public void Stop() => _stopwatch.Stop();

        /// <summary>目前錄影「有效經過時間」（已扣除暫停區間），供 UI 顯示已錄製時長。</summary>
        public TimeSpan Elapsed => _stopwatch.Elapsed - _accumulatedPause;

        /// <summary>取得目前樣本應使用的時間戳，單位為 100 奈秒（Media Foundation 慣用單位）。</summary>
        public long GetTimestamp100Ns() => Elapsed.Ticks; // TimeSpan.Ticks 本身即為 100ns 單位，無需換算
    }

    /// <summary>
    /// 核心錄影邏輯。
    /// 資料流：Windows.Graphics.Capture 取得畫面 frame → （視需要裁切自訂範圍）→
    ///         寫入 Media Foundation SinkWriter 視訊串流；WASAPI（由 AudioMixer 負責）
    ///         同步寫入音訊串流；兩者共用 <see cref="RecordingClock"/> 時間戳，暫停時兩者同步停寫。
    /// </summary>
    public sealed class RecorderManager : IDisposable
    {
        private const int TargetFrameRate = 30;
        private const int VideoBitrate = 8_000_000; // 8 Mbps，MVP 階段固定值，後續可視解析度調整

        public event EventHandler<RecordingStoppedEventArgs>? RecordingStopped;

        public bool IsRecording { get; private set; }
        public TimeSpan Elapsed => _clock.Elapsed;

        private readonly Forms.Screen _targetScreen;
        private readonly Rect? _customRegion;
        private readonly string _outputPath;
        private readonly RecordingClock _clock = new();

        // WGC / D3D11
        private Device? _d3dDevice;
        private IDirect3DDevice? _winrtDevice;
        private GraphicsCaptureItem? _captureItem;
        private Direct3D11CaptureFramePool? _framePool;
        private GraphicsCaptureSession? _captureSession;
        private int _captureWidth;
        private int _captureHeight;

        // 輸出裁切區域（相對於擷取畫面左上角的像素座標），null 表示輸出整個擷取畫面（全螢幕）
        private System.Drawing.Rectangle? _cropRegionPx;

        // Media Foundation
        private SinkWriter? _sinkWriter;
        private int _videoStreamIndex;
        private int _audioStreamIndex;
        private bool _mfStarted;

        // 音訊（實作見 AudioMixer.cs）：系統音效（WASAPI Loopback）＋ 麥克風混音後寫入音訊串流
        private AudioMixer? _audioMixer;

        private readonly object _stateLock = new();
        private volatile bool _isStopping;

        /// <summary>視訊（本類別）與音訊（AudioMixer）分別在不同執行緒呼叫 SinkWriter.WriteSample，
        /// 依 Media Foundation 文件要求由呼叫端自行同步，故提供此共用鎖物件。</summary>
        internal readonly object SinkWriterLock = new();

        public RecorderManager(Forms.Screen targetScreen, Rect? customRegion)
        {
            _targetScreen = targetScreen ?? throw new ArgumentNullException(nameof(targetScreen));
            _customRegion = customRegion;
            _outputPath = BuildOutputPath();
        }

        public static string GetOutputFolder() =>
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyVideos));

        private static string BuildOutputPath()
        {
            string folder = GetOutputFolder();
            Directory.CreateDirectory(folder);
            string fileName = $"ScreenRecorder_{DateTime.Now:yyyyMMdd_HHmmss}.mp4";
            return Path.Combine(folder, fileName);
        }

        #region 開始錄影

        public void Start()
        {
            lock (_stateLock)
            {
                if (IsRecording) return;

                InitializeCropRegion();
                InitializeCapture();
                InitializeSinkWriter();

                _audioMixer = new AudioMixer(_sinkWriter!, _audioStreamIndex, _clock, SinkWriterLock);
                _audioMixer.Start();

                _clock.Start();
                _captureSession!.StartCapture();

                IsRecording = true;
            }
        }

        /// <summary>
        /// 依自訂範圍與螢幕 DPI 縮放比例，換算出「擷取畫面像素座標」下的裁切矩形。
        /// 對應企劃書已知風險項：高 DPI／多螢幕混合縮放下的擷取解析度校正。
        /// </summary>
        private void InitializeCropRegion()
        {
            if (_customRegion is not Rect region)
            {
                _cropRegionPx = null;
                return;
            }

            double dpiScale = GetDpiScaleForScreen(_targetScreen);

            // region 為 WPF 裝置無關座標（相對於選取當下的視窗座標系），乘上 DPI 縮放比例
            // 換算為實際擷取畫面（裝置像素）座標；並扣除目標螢幕左上角座標做基準平移。
            var screenBounds = _targetScreen.Bounds;
            int x = (int)Math.Round((region.X - screenBounds.Left) * dpiScale);
            int y = (int)Math.Round((region.Y - screenBounds.Top) * dpiScale);
            int width = (int)Math.Round(region.Width * dpiScale);
            int height = (int)Math.Round(region.Height * dpiScale);

            _cropRegionPx = new System.Drawing.Rectangle(x, y, Math.Max(width, 2), Math.Max(height, 2));
        }

        #endregion

        #region 暫停 / 繼續

        public void Pause()
        {
            if (!IsRecording || _clock.IsPaused) return;
            _clock.Pause();
            _audioMixer?.Pause();
        }

        public void Resume()
        {
            if (!IsRecording || !_clock.IsPaused) return;
            _clock.Resume();
            _audioMixer?.Resume();
        }

        #endregion

        #region 停止 / 收尾

        public void Stop()
        {
            lock (_stateLock)
            {
                if (!IsRecording || _isStopping) return;
                _isStopping = true;
            }

            // Finalize（SinkWriter.Finalize + 釋放 WGC 資源）可能耗費數百毫秒，於背景執行緒執行避免卡住 UI。
            Task.Run(() =>
            {
                string? errorMessage = null;
                bool success = true;

                try
                {
                    _captureSession?.Dispose();
                    _framePool?.Dispose();

                    _audioMixer?.Stop();
                    _clock.Stop();

                    if (_mfStarted)
                    {
                        _sinkWriter?.Finalize();
                    }
                }
                catch (Exception ex)
                {
                    success = false;
                    errorMessage = ex.Message;
                }
                finally
                {
                    DisposeMediaFoundationResources();
                    DisposeCaptureResources();
                    IsRecording = false;
                    _isStopping = false;
                }

                RecordingStopped?.Invoke(this, new RecordingStoppedEventArgs(success, success ? _outputPath : null, errorMessage));
            });
        }

        #endregion

        #region Windows.Graphics.Capture 初始化與畫面擷取

        private void InitializeCapture()
        {
            _d3dDevice = CreateD3DDevice();
            _winrtDevice = CreateDirect3DDeviceFromD3DDevice(_d3dDevice);

            IntPtr hMonitor = GetHMonitorForScreen(_targetScreen);
            _captureItem = CreateCaptureItemForMonitor(hMonitor);

            _captureWidth = _captureItem.Size.Width;
            _captureHeight = _captureItem.Size.Height;

            _framePool = Direct3D11CaptureFramePool.CreateFreeThreaded(
                _winrtDevice,
                DirectXPixelFormat.B8G8R8A8UIntNormalized,
                numberOfBuffers: 2,
                size: _captureItem.Size);

            _framePool.FrameArrived += OnFrameArrived;

            _captureSession = _framePool.CreateCaptureSession(_captureItem);
            // 部分 Windows 10 版本不支援 IsCursorCaptureEnabled；以 try/catch 保守處理相容性。
            try { _captureSession.IsCursorCaptureEnabled = true; } catch { /* 該版本不支援，忽略 */ }
        }

        private void OnFrameArrived(Direct3D11CaptureFramePool sender, object args)
        {
            if (_isStopping) return;

            using var frame = sender.TryGetNextFrame();
            if (frame == null) return;

            // 暫停中：直接丟棄畫面，不寫入 SinkWriter（維持暫停期間不產生任何樣本）。
            if (_clock.IsPaused) return;

            try
            {
                byte[] pixelBuffer = ExtractFrameBytes(frame.Surface, out int outWidth, out int outHeight, out int rowPitch);
                WriteVideoSample(pixelBuffer, outWidth, outHeight, rowPitch);
            }
            catch (Exception)
            {
                // 單一畫面轉換失敗不應中斷整段錄影；可視需要加入次數統計，超過門檻才觸發錯誤收尾。
            }
        }

        /// <summary>
        /// 將 WGC 回傳的 IDirect3DSurface 複製到 CPU 記憶體，並依 _cropRegionPx 裁切出實際要輸出的區域。
        /// 採用 CPU 複製（Staging Texture + Map）以簡化實作；若需更高效能，可改為 GPU 端 DXGI Surface 直接送入 SinkWriter。
        /// </summary>
        private byte[] ExtractFrameBytes(IDirect3DSurface surface, out int outWidth, out int outHeight, out int outRowPitch)
        {
            using var sourceTexture = GetTexture2DFromSurface(surface);

            var cropRect = _cropRegionPx ?? new System.Drawing.Rectangle(0, 0, _captureWidth, _captureHeight);
            outWidth = cropRect.Width;
            outHeight = cropRect.Height;

            var stagingDesc = new Texture2DDescription
            {
                Width = outWidth,
                Height = outHeight,
                MipLevels = 1,
                ArraySize = 1,
                Format = Format.B8G8R8A8_UNorm,
                SampleDescription = new SharpDX.DXGI.SampleDescription(1, 0),
                Usage = ResourceUsage.Staging,
                BindFlags = BindFlags.None,
                CpuAccessFlags = CpuAccessFlags.Read,
                OptionFlags = ResourceOptionFlags.None
            };

            using var stagingTexture = new Texture2D(_d3dDevice!, stagingDesc);

            var sourceRegion = new ResourceRegion(
                cropRect.Left, cropRect.Top, 0,
                cropRect.Right, cropRect.Bottom, 1);

            _d3dDevice!.ImmediateContext.CopySubresourceRegion(sourceTexture, 0, sourceRegion, stagingTexture, 0);

            var dataBox = _d3dDevice.ImmediateContext.MapSubresource(stagingTexture, 0, MapMode.Read, SharpDX.Direct3D11.MapFlags.None);
            try
            {
                outRowPitch = dataBox.RowPitch;
                int bufferSize = outRowPitch * outHeight;
                byte[] buffer = new byte[bufferSize];
                Marshal.Copy(dataBox.DataPointer, buffer, 0, bufferSize);
                return buffer;
            }
            finally
            {
                _d3dDevice.ImmediateContext.UnmapSubresource(stagingTexture, 0);
            }
        }

        #endregion

        #region Media Foundation SinkWriter 設定

        private void InitializeSinkWriter()
        {
            MediaManager.Startup();

            int outWidth = _cropRegionPx?.Width ?? _captureWidth;
            int outHeight = _cropRegionPx?.Height ?? _captureHeight;
            // Media Foundation 的 H.264 編碼器要求寬高為偶數。
            outWidth -= outWidth % 2;
            outHeight -= outHeight % 2;

            using var attributes = new MediaAttributes(1);
            attributes.Set(SinkWriterAttributeKeys.ReadwriteEnableHardwareTransforms, 1);

            _sinkWriter = MediaFactory.CreateSinkWriterFromURL(_outputPath, null, attributes);

            // --- 視訊輸出（H.264） ---
            using (var videoOutType = new MediaType())
            {
                videoOutType.Set(MediaTypeAttributeKeys.MajorType, MediaTypeGuids.Video);
                videoOutType.Set(MediaTypeAttributeKeys.Subtype, VideoFormatGuids.H264);
                videoOutType.Set(MediaTypeAttributeKeys.AvgBitrate, VideoBitrate);
                videoOutType.Set(MediaTypeAttributeKeys.InterlaceMode, (int)VideoInterlaceMode.Progressive);
                videoOutType.Set(MediaTypeAttributeKeys.FrameSize, PackToLong(outWidth, outHeight));
                videoOutType.Set(MediaTypeAttributeKeys.FrameRate, PackToLong(TargetFrameRate, 1));
                videoOutType.Set(MediaTypeAttributeKeys.PixelAspectRatio, PackToLong(1, 1));
                _videoStreamIndex = _sinkWriter.AddStream(videoOutType);
            }

            // --- 視訊輸入（未壓縮 BGRA32，對應 ExtractFrameBytes 輸出格式） ---
            using (var videoInType = new MediaType())
            {
                videoInType.Set(MediaTypeAttributeKeys.MajorType, MediaTypeGuids.Video);
                videoInType.Set(MediaTypeAttributeKeys.Subtype, VideoFormatGuids.Argb32);
                videoInType.Set(MediaTypeAttributeKeys.InterlaceMode, (int)VideoInterlaceMode.Progressive);
                videoInType.Set(MediaTypeAttributeKeys.FrameSize, PackToLong(outWidth, outHeight));
                videoInType.Set(MediaTypeAttributeKeys.FrameRate, PackToLong(TargetFrameRate, 1));
                videoInType.Set(MediaTypeAttributeKeys.PixelAspectRatio, PackToLong(1, 1));
                _sinkWriter.SetInputMediaType(_videoStreamIndex, videoInType, null);
            }

            // --- 音訊輸出（AAC，48kHz 立體聲，對應 AudioMixer 混音後格式） ---
            using (var audioOutType = new MediaType())
            {
                audioOutType.Set(MediaTypeAttributeKeys.MajorType, MediaTypeGuids.Audio);
                audioOutType.Set(MediaTypeAttributeKeys.Subtype, AudioFormatGuids.Aac);
                audioOutType.Set(MediaTypeAttributeKeys.AudioBitsPerSample, 16);
                audioOutType.Set(MediaTypeAttributeKeys.AudioSamplesPerSecond, 48000);
                audioOutType.Set(MediaTypeAttributeKeys.AudioNumChannels, 2);
                audioOutType.Set(MediaTypeAttributeKeys.AudioAvgBytesPerSecond, 16000);
                _audioStreamIndex = _sinkWriter.AddStream(audioOutType);
            }

            // --- 音訊輸入（未壓縮 Float32，AudioMixer 內部相加後即為此格式） ---
            using (var audioInType = new MediaType())
            {
                audioInType.Set(MediaTypeAttributeKeys.MajorType, MediaTypeGuids.Audio);
                audioInType.Set(MediaTypeAttributeKeys.Subtype, AudioFormatGuids.Float);
                audioInType.Set(MediaTypeAttributeKeys.AudioBitsPerSample, 32);
                audioInType.Set(MediaTypeAttributeKeys.AudioSamplesPerSecond, 48000);
                audioInType.Set(MediaTypeAttributeKeys.AudioNumChannels, 2);
                _sinkWriter.SetInputMediaType(_audioStreamIndex, audioInType, null);
            }

            _sinkWriter.BeginWriting();
            _mfStarted = true;
        }

        private void WriteVideoSample(byte[] pixelBuffer, int width, int height, int rowPitch)
        {
            if (_sinkWriter == null) return;

            int tightRowPitch = width * 4;
            using var mediaBuffer = MediaFactory.CreateMemoryBuffer(tightRowPitch * height);

            IntPtr dest = mediaBuffer.Lock(out int _, out int _);
            try
            {
                if (rowPitch == tightRowPitch)
                {
                    Marshal.Copy(pixelBuffer, 0, dest, tightRowPitch * height);
                }
                else
                {
                    // Staging texture 的 RowPitch 可能因對齊而大於實際寬度所需位元組數，逐行複製去除 padding。
                    for (int row = 0; row < height; row++)
                    {
                        Marshal.Copy(pixelBuffer, row * rowPitch, IntPtr.Add(dest, row * tightRowPitch), tightRowPitch);
                    }
                }
            }
            finally
            {
                mediaBuffer.Unlock();
            }
            mediaBuffer.CurrentLength = tightRowPitch * height;

            using var sample = MediaFactory.CreateSample();
            sample.AddBuffer(mediaBuffer);
            sample.SampleTime = _clock.GetTimestamp100Ns();
            sample.SampleDuration = 10_000_000L / TargetFrameRate; // 100ns 單位

            // SinkWriter 允許多執行緒呼叫，但需由呼叫端自行同步；此處與 AudioMixer 共用 SinkWriterLock。
            lock (SinkWriterLock)
            {
                _sinkWriter.WriteSample(_videoStreamIndex, sample);
            }
        }

        #endregion

        #region 資源釋放

        private void DisposeMediaFoundationResources()
        {
            _sinkWriter?.Dispose();
            _sinkWriter = null;

            if (_mfStarted)
            {
                MediaManager.Shutdown();
                _mfStarted = false;
            }
        }

        private void DisposeCaptureResources()
        {
            _framePool?.Dispose();
            _framePool = null;
            _captureSession = null;
            _captureItem = null;

            _winrtDevice = null;
            _d3dDevice?.Dispose();
            _d3dDevice = null;

            _audioMixer?.Dispose();
            _audioMixer = null;
        }

        public void Dispose()
        {
            if (IsRecording)
            {
                Stop();
            }
            else
            {
                DisposeMediaFoundationResources();
                DisposeCaptureResources();
            }
        }

        #endregion

        #region DPI / 螢幕輔助

        private static double GetDpiScaleForScreen(Forms.Screen screen)
        {
            IntPtr hMonitor = GetHMonitorForScreen(screen);
            if (GetDpiForMonitor(hMonitor, MonitorDpiType.EffectiveDpi, out uint dpiX, out _) == 0)
            {
                return dpiX / 96.0;
            }
            return 1.0; // 取得失敗時退回 100% 縮放，避免整段擷取失敗
        }

        private static IntPtr GetHMonitorForScreen(Forms.Screen screen)
        {
            var bounds = screen.Bounds;
            var point = new NativePoint
            {
                X = bounds.Left + bounds.Width / 2,
                Y = bounds.Top + bounds.Height / 2
            };
            return MonitorFromPoint(point, MONITOR_DEFAULTTONEAREST);
        }

        #endregion

        #region Win32 / WinRT Interop
        // 下列 COM／WinRT 互通樣板參考自 Microsoft 官方 Windows.Graphics.Capture 範例
        // （如 robmikh/Win32CaptureSample）之慣用寫法。實際建置時請對照該範例確認
        // GUID／簽章與所使用的 Windows SDK / CsWinRT 版本相符。

        [ComImport, Guid("3628E81B-3CAC-4C60-B7F4-23CE0E0C3356"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        private interface IGraphicsCaptureItemInterop
        {
            IntPtr CreateForWindow([In] IntPtr window, [In] ref Guid iid);
            IntPtr CreateForMonitor([In] IntPtr monitor, [In] ref Guid iid);
        }

        [ComImport, Guid("A9B3D012-3DF2-4EE3-B8D1-8695F457D3C1"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        private interface IDirect3DDxgiInterfaceAccess
        {
            IntPtr GetInterface([In] ref Guid iid);
        }

        private static GraphicsCaptureItem CreateCaptureItemForMonitor(IntPtr hMonitor)
        {
            var interopFactory = (IGraphicsCaptureItemInterop)WinRT.ActivationFactory.Get(
                "Windows.Graphics.Capture.GraphicsCaptureItem");

            Guid itemGuid = typeof(GraphicsCaptureItem).GUID;
            IntPtr itemPointer = interopFactory.CreateForMonitor(hMonitor, ref itemGuid);

            var item = WinRT.MarshalInterface<GraphicsCaptureItem>.FromAbi(itemPointer);
            Marshal.Release(itemPointer);
            return item;
        }

        private static Texture2D GetTexture2DFromSurface(IDirect3DSurface surface)
        {
            var access = (IDirect3DDxgiInterfaceAccess)(object)surface;
            Guid textureGuid = typeof(Texture2D).GUID;
            IntPtr texturePointer = access.GetInterface(ref textureGuid);
            return new Texture2D(texturePointer);
        }

        [DllImport("d3d11.dll", EntryPoint = "CreateDirect3D11DeviceFromDXGIDevice", SetLastError = true)]
        private static extern int CreateDirect3D11DeviceFromDXGIDevice(IntPtr dxgiDevice, out IntPtr graphicsDevice);

        private static IDirect3DDevice CreateDirect3DDeviceFromD3DDevice(Device d3dDevice)
        {
            using var dxgiDevice = d3dDevice.QueryInterface<SharpDX.DXGI.Device>();
            int hr = CreateDirect3D11DeviceFromDXGIDevice(dxgiDevice.NativePointer, out IntPtr pUnknown);
            Marshal.ThrowExceptionForHR(hr);
            var device = WinRT.MarshalInterface<IDirect3DDevice>.FromAbi(pUnknown);
            Marshal.Release(pUnknown);
            return device;
        }

        private static Device CreateD3DDevice()
        {
            var flags = DeviceCreationFlags.BgraSupport;
#if DEBUG
            // 需安裝 Windows SDK 的 D3D11 偵錯層才可加上 DeviceCreationFlags.Debug。
#endif
            return new Device(SharpDX.Direct3D.DriverType.Hardware, flags);
        }

        private static long PackToLong(int high, int low) => ((long)high << 32) | (uint)low;

        [StructLayout(LayoutKind.Sequential)]
        private struct NativePoint { public int X; public int Y; }

        private const uint MONITOR_DEFAULTTONEAREST = 2;

        [DllImport("user32.dll")]
        private static extern IntPtr MonitorFromPoint(NativePoint pt, uint dwFlags);

        private enum MonitorDpiType { EffectiveDpi = 0 }

        [DllImport("shcore.dll")]
        private static extern int GetDpiForMonitor(IntPtr hMonitor, MonitorDpiType dpiType, out uint dpiX, out uint dpiY);

        #endregion
    }
}

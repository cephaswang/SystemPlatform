# ScreenRecorderWin

支援「暫停 / 繼續」的 Windows 10 螢幕錄影工具。錄製時即時編碼，停止後直接輸出 `.mp4`（H.264 視訊 + AAC 音訊），不需額外轉檔。功能對齊 macOS 版 ScreenRecorder Phase 1（MVP）：全螢幕 / 自訂範圍錄製、系統音效＋麥克風混音、全域快捷鍵、系統匣常駐操作。

詳細技術規劃請見《ScreenRecorder for Windows 10 — 軟體企劃書 v1.0》。

## 系統需求

- Windows 10 version 1903（19H1）以上（螢幕擷取需要 `Windows.Graphics.Capture` API）
- .NET 8（或 .NET 6 LTS）
- Visual Studio 2022

## 建置步驟

1. 以 Visual Studio 2022 開啟本專案（或建立新的 **.NET 8 WPF App** 專案，再將本資料夾內檔案加入）。

2. 於 `.csproj` 加入下列設定：

   ```xml
   <PropertyGroup>
     <TargetFramework>net8.0-windows10.0.19041.0</TargetFramework>
     <UseWPF>true</UseWPF>
     <UseWindowsForms>true</UseWindowsForms> <!-- Screen.AllScreens、NotifyIcon 需要 -->
   </PropertyGroup>
   ```

3. 安裝以下 NuGet 套件：

   | 套件 | 用途 |
   | --- | --- |
   | `SharpDX.MediaFoundation` | Media Foundation `SinkWriter` 互操作（H.264/MP4 編碼） |
   | `SharpDX.Direct3D11` | 螢幕擷取畫面（`Texture2D`）的 GPU/CPU 記憶體處理 |
   | `SharpDX.DXGI` | D3D11 裝置的 DXGI 介面查詢 |
   | `NAudio` | WASAPI 系統音效 Loopback 擷取、麥克風擷取與取樣率轉換 |

4. 於「應用程式資訊清單」（`app.manifest`）設定 DPI 感知為 **Per-Monitor V2**，並將其加入專案：

   ```xml
   <application xmlns="urn:schemas-microsoft-com:asm.v3">
     <windowsSettings>
       <dpiAwareness xmlns="http://schemas.microsoft.com/SMI/2016/WindowsSettings">PerMonitorV2</dpiAwareness>
     </windowsSettings>
   </application>
   ```

   > 缺少此設定會導致多螢幕混合縮放比例（125%/150% 等）下，`RegionSelectorWindow` 的選取座標與 `RecorderManager` 實際擷取範圍不一致。

5. 建置並執行，測試以下情境：
   - 多螢幕環境下切換錄製螢幕、顯示螢幕編號（🔢）。
   - 全螢幕與自訂範圍錄製，確認輸出解析度與選取範圍相符。
   - 暫停／繼續錄影，確認輸出影片時間軸連續、無跳格或空白畫面。
   - 系統音效與麥克風同時錄製時無明顯回音（建議戴耳機測試）。
   - 全域快捷鍵（`Ctrl+Alt+Win+R/P/C/S`）於背景視窗仍可正常觸發。
   - 關閉主視窗後程式隱藏至系統匣，錄影不中斷；由系統匣選單「結束」才會真正關閉程式。

## 專案結構

```
ScreenRecorderWin/
├── App.xaml / App.xaml.cs        # 進入點，Mutex 防多開、系統匣初始化
├── MainWindow.xaml               # 主視窗：選螢幕/範圍、開始錄影、查看輸出
├── TrayIconManager.cs            # 系統匣圖示與右鍵選單
├── RecorderManager.cs            # 核心錄影邏輯（WGC 擷取、暫停位移演算法、Media Foundation SinkWriter）
├── RegionSelectorWindow.xaml     # 自訂範圍拖曳選取遮罩視窗
├── OverlayWindow.xaml            # 螢幕編號提示、錄影中範圍紅框
├── HotKeyManager.cs              # 全域快捷鍵（RegisterHotKey + 隱藏訊息視窗）
├── AudioMixer.cs                 # WASAPI 系統音效＋麥克風混音
└── README.md
```

## 全域快捷鍵（預設）

| 動作 | 快捷鍵 |
| --- | --- |
| 開始錄影 | `Ctrl+Alt+Win+R` |
| 暫停 | `Ctrl+Alt+Win+P` |
| 繼續 | `Ctrl+Alt+Win+C` |
| 停止並輸出 MP4 | `Ctrl+Alt+Win+S` |

> 已知限制：快捷鍵觸發的「開始錄影」固定為全螢幕，自訂範圍仍需從主視窗滑鼠操作。

## 輸出位置

```
%USERPROFILE%\Videos\ScreenRecorder_yyyyMMdd_HHmmss.mp4
```

錄製完成後會自動開啟檔案總管並選取該檔案。

## 已知限制（Phase 1 範圍）

- 僅規劃整台顯示器全螢幕擷取為主要路徑，單一視窗擷取列為 Phase 3 項目。
- 全域快捷鍵僅支援固定組合鍵，使用者自訂快捷鍵設定畫面列為 Phase 4 項目。
- 高 DPI / 多螢幕混合縮放比例下的擷取解析度校正屬 Windows 平台特有風險項，`RecorderManager` 內已加入基礎 DPI 換算，但實機仍建議充分測試。
- `Windows.Graphics.Capture` 對部分具「安全內容保護」的視窗（如 DRM 播放器）擷取會顯示黑畫面，屬系統限制。
- `RecorderManager.cs` 中的 WGC／D3D11 COM 互通樣板（`IGraphicsCaptureItemInterop`、`IDirect3DDxgiInterfaceAccess` 等）取自 Microsoft 官方範例慣用寫法，實機建置時請對照官方範例核對 GUID／簽章是否與所用 Windows SDK 版本相符。

## 權限說明

- **麥克風**：一般 Win32/WPF 桌面程式不需額外 Manifest 宣告，但需處理使用者於「設定 → 隱私權 → 麥克風」拒絕存取時的錯誤（`AudioMixer` 已處理，會自動退回僅系統音效模式）。
- **螢幕擷取**：Windows 10 對桌面程式呼叫 WGC 通常不會跳出系統授權彈窗，但仍需留意使用者環境是否有相關企業原則限制存取。

using System;
using System.Runtime.InteropServices;
using System.Threading;
using NAudio.CoreAudioApi;
using NAudio.Wave;
using SharpDX.MediaFoundation;

namespace ScreenRecorderWin
{
    /// <summary>
    /// 系統音效（WASAPI Loopback）＋麥克風混音器。
    /// 對應企劃書：兩路個別轉為 48kHz 立體聲 Float32 後，以浮點相加方式混音，
    /// 寫入單一音訊串流（由 RecorderManager 設定為 AAC 輸出）。
    /// 與視訊共用同一顆 <see cref="RecordingClock"/>：暫停時停止擷取裝置並不寫入樣本，
    /// 續錄後時間戳自動接續，維持與視訊軌同步。
    /// </summary>
    public sealed class AudioMixer : IDisposable
    {
        private const int SampleRate = 48000;
        private const int Channels = 2;
        private const int BytesPerSample = 4; // IEEE Float32
        private const int BlockAlign = Channels * BytesPerSample;
        private const int MixChunkMilliseconds = 20; // 每次混音/寫入樣本的區塊長度

        private static readonly WaveFormat TargetFormat = WaveFormat.CreateIeeeFloatWaveFormat(SampleRate, Channels);

        private readonly SinkWriter _sinkWriter;
        private readonly int _audioStreamIndex;
        private readonly RecordingClock _clock;
        private readonly object _sinkWriterLock;

        private WasapiLoopbackCapture? _loopbackCapture;
        private WasapiCapture? _micCapture;

        private BufferedWaveProvider? _loopbackBuffer;
        private BufferedWaveProvider? _micBuffer;

        private IWaveProvider? _loopbackResampled;
        private IWaveProvider? _micResampled;
        private MediaFoundationResampler? _loopbackResampler;
        private MediaFoundationResampler? _micResampler;

        private Thread? _mixThread;
        private volatile bool _running;

        /// <summary>建構後若麥克風裝置不存在或無法開啟，會退回「僅系統音效」模式，不擲出例外。</summary>
        public bool MicrophoneAvailable { get; private set; }

        public AudioMixer(SinkWriter sinkWriter, int audioStreamIndex, RecordingClock clock, object sinkWriterLock)
        {
            _sinkWriter = sinkWriter ?? throw new ArgumentNullException(nameof(sinkWriter));
            _audioStreamIndex = audioStreamIndex;
            _clock = clock ?? throw new ArgumentNullException(nameof(clock));
            _sinkWriterLock = sinkWriterLock ?? throw new ArgumentNullException(nameof(sinkWriterLock));
        }

        #region 啟動 / 停止

        public void Start()
        {
            InitializeLoopbackCapture();
            InitializeMicrophoneCapture();

            _running = true;
            _mixThread = new Thread(MixLoop)
            {
                IsBackground = true,
                Name = "AudioMixer.MixLoop"
            };
            _mixThread.Start();

            _loopbackCapture?.StartRecording();
            if (MicrophoneAvailable)
            {
                _micCapture?.StartRecording();
            }
        }

        public void Stop()
        {
            _running = false;
            _mixThread?.Join(TimeSpan.FromMilliseconds(500));

            SafeStop(_loopbackCapture);
            SafeStop(_micCapture);
        }

        /// <summary>暫停：停止擷取裝置，避免暫停期間持續累積緩衝、造成續錄後產生延遲或漂移。</summary>
        public void Pause()
        {
            SafeStop(_loopbackCapture);
            SafeStop(_micCapture);
        }

        /// <summary>繼續：清空殘留緩衝後重新啟動擷取裝置，確保續錄第一個區塊即為當下即時音訊。</summary>
        public void Resume()
        {
            _loopbackBuffer?.ClearBuffer();
            _micBuffer?.ClearBuffer();

            _loopbackCapture?.StartRecording();
            if (MicrophoneAvailable)
            {
                _micCapture?.StartRecording();
            }
        }

        private static void SafeStop(IWaveIn? capture)
        {
            try { capture?.StopRecording(); }
            catch { /* 裝置已停止或已中斷連線時，StopRecording 可能擲例外，忽略即可 */ }
        }

        #endregion

        #region 裝置初始化

        private void InitializeLoopbackCapture()
        {
            // WasapiLoopbackCapture 預設擷取「目前預設輸出裝置」播放中的所有系統音效。
            _loopbackCapture = new WasapiLoopbackCapture();
            _loopbackBuffer = new BufferedWaveProvider(_loopbackCapture.WaveFormat)
            {
                DiscardOnBufferOverflow = true,
                BufferDuration = TimeSpan.FromSeconds(2)
            };
            _loopbackCapture.DataAvailable += (_, e) =>
                _loopbackBuffer.AddSamples(e.Buffer, 0, e.BytesRecorded);

            _loopbackResampler = new MediaFoundationResampler(_loopbackBuffer, TargetFormat)
            {
                ResamplerQuality = 60
            };
            _loopbackResampled = _loopbackResampler;
        }

        private void InitializeMicrophoneCapture()
        {
            try
            {
                _micCapture = new WasapiCapture(); // 預設輸入裝置（麥克風）
                _micBuffer = new BufferedWaveProvider(_micCapture.WaveFormat)
                {
                    DiscardOnBufferOverflow = true,
                    BufferDuration = TimeSpan.FromSeconds(2)
                };
                _micCapture.DataAvailable += (_, e) =>
                    _micBuffer.AddSamples(e.Buffer, 0, e.BytesRecorded);

                _micResampler = new MediaFoundationResampler(_micBuffer, TargetFormat)
                {
                    ResamplerQuality = 60
                };
                _micResampled = _micResampler;

                MicrophoneAvailable = true;
            }
            catch (Exception)
            {
                // 找不到麥克風裝置、裝置被停用，或使用者於「隱私權 → 麥克風」拒絕存取時會到此。
                // 對應企劃書：需處理裝置被拒絕存取的錯誤 → 退回「僅系統音效」模式，不中斷整體錄影。
                MicrophoneAvailable = false;
                _micCapture = null;
                _micResampled = null;
            }
        }

        #endregion

        #region 混音主迴圈

        private void MixLoop()
        {
            int bytesPerChunk = TargetFormat.AverageBytesPerSecond * MixChunkMilliseconds / 1000;
            bytesPerChunk -= bytesPerChunk % BlockAlign; // 對齊至完整取樣邊界

            byte[] loopbackBytes = new byte[bytesPerChunk];
            byte[] micBytes = new byte[bytesPerChunk];
            byte[] mixedBytes = new byte[bytesPerChunk];

            long sampleDuration100Ns = MixChunkMilliseconds * 10_000L; // 1ms = 10,000 * 100ns

            while (_running)
            {
                if (_clock.IsPaused)
                {
                    // 暫停中：不擷取、不寫入樣本，維持與視訊一致的時間軸位移邏輯。
                    Thread.Sleep(MixChunkMilliseconds);
                    continue;
                }

                // ReadFully 模式（BufferedWaveProvider 預設）：資料不足時自動補靜音，確保區塊長度固定。
                _loopbackResampled?.Read(loopbackBytes, 0, bytesPerChunk);

                if (MicrophoneAvailable && _micResampled != null)
                {
                    _micResampled.Read(micBytes, 0, bytesPerChunk);
                }
                else
                {
                    Array.Clear(micBytes, 0, micBytes.Length);
                }

                MixBuffers(loopbackBytes, micBytes, mixedBytes);
                WriteAudioSample(mixedBytes, _clock.GetTimestamp100Ns(), sampleDuration100Ns);

                Thread.Sleep(MixChunkMilliseconds);
                // 簡化排程：固定間隔寫入。若需避免長時間錄影後的些微時間漂移，
                // 可改用「累積應寫入樣本數」與 Stopwatch 實際經過時間比對做動態補償。
            }
        }

        /// <summary>將兩路 Float32 樣本相加，並限幅於 [-1, 1] 避免相加後爆音削波。</summary>
        private static void MixBuffers(byte[] a, byte[] b, byte[] output)
        {
            int floatCount = output.Length / BytesPerSample;

            for (int i = 0; i < floatCount; i++)
            {
                int offset = i * BytesPerSample;
                float sampleA = BitConverter.ToSingle(a, offset);
                float sampleB = BitConverter.ToSingle(b, offset);

                float mixed = Math.Clamp(sampleA + sampleB, -1f, 1f);

                var mixedBytes = BitConverter.GetBytes(mixed);
                Buffer.BlockCopy(mixedBytes, 0, output, offset, BytesPerSample);
            }
        }

        private void WriteAudioSample(byte[] mixedBytes, long timestamp100Ns, long duration100Ns)
        {
            using var mediaBuffer = MediaFactory.CreateMemoryBuffer(mixedBytes.Length);

            IntPtr dest = mediaBuffer.Lock(out int _, out int _);
            try
            {
                Marshal.Copy(mixedBytes, 0, dest, mixedBytes.Length);
            }
            finally
            {
                mediaBuffer.Unlock();
            }
            mediaBuffer.CurrentLength = mixedBytes.Length;

            using var sample = MediaFactory.CreateSample();
            sample.AddBuffer(mediaBuffer);
            sample.SampleTime = timestamp100Ns;
            sample.SampleDuration = duration100Ns;

            // 與 RecorderManager 的視訊寫入共用同一把鎖，避免兩條執行緒同時呼叫 SinkWriter。
            lock (_sinkWriterLock)
            {
                _sinkWriter.WriteSample(_audioStreamIndex, sample);
            }
        }

        #endregion

        public void Dispose()
        {
            _running = false;
            _mixThread?.Join(TimeSpan.FromMilliseconds(500));

            _loopbackCapture?.Dispose();
            _micCapture?.Dispose();
            _loopbackResampler?.Dispose();
            _micResampler?.Dispose();
        }
    }
}

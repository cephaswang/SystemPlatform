using System;
using System.Drawing;
using System.Windows.Forms;

namespace ScreenRecorderWin
{
    /// <summary>
    /// 系統匣圖示管理員。
    /// 對應企劃書「系統匣操作」需求：
    ///   - 右鍵選單：狀態／已錄製時長（唯讀顯示）、暫停/繼續、停止、查看上次輸出、開啟主視窗、結束。
    ///   - 雙擊圖示：開啟主視窗。
    ///
    /// 注意：本類別使用 System.Windows.Forms.NotifyIcon，因此專案檔（.csproj）需加入
    ///       &lt;UseWindowsForms&gt;true&lt;/UseWindowsForms&gt;，才能在 WPF 專案中參考 Windows Forms。
    /// </summary>
    public sealed class TrayIconManager : IDisposable
    {
        private readonly MainWindow _mainWindow;
        private NotifyIcon? _notifyIcon;

        // 選單項目保留為欄位，方便在 ContextMenuStrip.Opening 事件中依當前狀態更新文字。
        private ToolStripMenuItem? _statusItem;
        private ToolStripMenuItem? _pauseResumeItem;
        private ToolStripMenuItem? _stopItem;
        private ToolStripMenuItem? _viewLastOutputItem;

        private bool _disposed;

        public TrayIconManager(MainWindow mainWindow)
        {
            _mainWindow = mainWindow ?? throw new ArgumentNullException(nameof(mainWindow));
        }

        public void Initialize()
        {
            var menu = BuildContextMenu();

            _notifyIcon = new NotifyIcon
            {
                // TODO：替換為專案自訂 .ico（例如 Resources/AppIcon.ico，並於 .csproj 設為 Resource）。
                // 目前先以系統預設圖示佔位，避免因缺少圖示檔而編譯失敗。
                Icon = SystemIcons.Application,
                Text = "ScreenRecorder",
                Visible = true,
                ContextMenuStrip = menu
            };

            _notifyIcon.DoubleClick += (_, _) => _mainWindow.ShowAndActivate();
        }

        private ContextMenuStrip BuildContextMenu()
        {
            var menu = new ContextMenuStrip();

            // 狀態顯示（唯讀項目：不可點擊，僅顯示目前狀態／已錄製時長）
            _statusItem = new ToolStripMenuItem("就緒") { Enabled = false };
            menu.Items.Add(_statusItem);
            menu.Items.Add(new ToolStripSeparator());

            _pauseResumeItem = new ToolStripMenuItem("暫停", null, OnPauseResumeClicked) { Enabled = false };
            _stopItem = new ToolStripMenuItem("停止並輸出 MP4", null, OnStopClicked) { Enabled = false };
            menu.Items.Add(_pauseResumeItem);
            menu.Items.Add(_stopItem);
            menu.Items.Add(new ToolStripSeparator());

            _viewLastOutputItem = new ToolStripMenuItem("查看上次輸出", null, OnViewLastOutputClicked) { Enabled = false };
            menu.Items.Add(_viewLastOutputItem);

            var openMainWindowItem = new ToolStripMenuItem("開啟主視窗", null, (_, _) => _mainWindow.ShowAndActivate());
            menu.Items.Add(openMainWindowItem);
            menu.Items.Add(new ToolStripSeparator());

            var exitItem = new ToolStripMenuItem("結束", null, (_, _) => _mainWindow.ExitApplication());
            menu.Items.Add(exitItem);

            // 每次選單開啟前，依當前錄影狀態刷新文字與可用性，確保狀態一致。
            menu.Opening += (_, _) => RefreshMenuState();

            return menu;
        }

        private void RefreshMenuState()
        {
            if (_statusItem == null || _pauseResumeItem == null || _stopItem == null || _viewLastOutputItem == null)
            {
                return;
            }

            bool isRecording = _mainWindow.IsRecording;

            _statusItem.Text = isRecording
                ? $"{(_mainWindow.IsPaused ? "已暫停" : "錄影中")} - {_mainWindow.GetElapsedTimeText()}"
                : "就緒";

            _pauseResumeItem.Enabled = isRecording;
            _pauseResumeItem.Text = _mainWindow.IsPaused ? "繼續" : "暫停";

            _stopItem.Enabled = isRecording;

            _viewLastOutputItem.Enabled = !string.IsNullOrEmpty(_mainWindow.LastOutputPath);
        }

        private void OnPauseResumeClicked(object? sender, EventArgs e)
        {
            if (_mainWindow.IsPaused)
            {
                _mainWindow.ResumeRecording();
            }
            else
            {
                _mainWindow.PauseRecording();
            }
        }

        private void OnStopClicked(object? sender, EventArgs e)
        {
            _mainWindow.StopRecording();
        }

        private void OnViewLastOutputClicked(object? sender, EventArgs e)
        {
            string? path = _mainWindow.LastOutputPath;
            if (string.IsNullOrEmpty(path) || !System.IO.File.Exists(path))
            {
                return;
            }

            System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(
                "explorer.exe", $"/select,\"{path}\"")
            {
                UseShellExecute = true
            });
        }

        public void Dispose()
        {
            if (_disposed)
            {
                return;
            }

            if (_notifyIcon != null)
            {
                _notifyIcon.Visible = false;
                _notifyIcon.Dispose();
                _notifyIcon = null;
            }

            _disposed = true;
        }
    }
}

using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Windows;
using System.Windows.Threading;
using Forms = System.Windows.Forms; // 用於 Screen.AllScreens（多螢幕列舉）

namespace ScreenRecorderWin
{
    /// <summary>
    /// 主視窗。
    /// 職責：
    ///   1. 列舉並顯示可錄製的螢幕（多螢幕時顯示下拉選單）。
    ///   2. 全螢幕／自訂範圍模式切換，自訂範圍透過 RegionSelectorWindow 取得矩形。
    ///   3. 驅動 RecorderManager 的開始／暫停／繼續／停止流程，並同步 UI 狀態。
    ///   4. 關閉視窗時預設「隱藏至系統匣」而非結束程式；僅透過系統匣選單「結束」
    ///      或 TrayIconManager 呼叫 ExitApplication() 才會真正關閉。
    /// </summary>
    public partial class MainWindow : Window
    {
        /// <summary>下拉選單用的螢幕項目包裝，附上可讀名稱。</summary>
        private sealed class ScreenItem
        {
            public required Forms.Screen Screen { get; init; }
            public required string DisplayName { get; init; }
        }

        private RecorderManager? _recorder;
        private HotKeyManager? _hotKeyManager;
        private readonly DispatcherTimer _elapsedTimer;

        private Rect? _customRegion;         // 自訂範圍（螢幕座標），null 代表使用全螢幕
        private bool _isPaused;
        private bool _allowRealClose;        // true 時 Closing 事件才會真正關閉視窗（由 ExitApplication 設定）

        public bool IsRecording => _recorder?.IsRecording ?? false;

        /// <summary>上一次成功輸出的檔案完整路徑，供 TrayIconManager「查看上次輸出」使用；尚無輸出時為 null。</summary>
        public string? LastOutputPath { get; private set; }

        public MainWindow()
        {
            InitializeComponent();

            _elapsedTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(1) };
            _elapsedTimer.Tick += ElapsedTimer_OnTick;

            PopulateScreenList();
            RegisterGlobalHotKeys();
        }

        #region 螢幕列舉

        private void PopulateScreenList()
        {
            var screens = Forms.Screen.AllScreens;

            var items = screens.Select((s, index) => new ScreenItem
            {
                Screen = s,
                DisplayName = $"螢幕 {index + 1}" + (s.Primary ? "（主要）" : string.Empty)
                              + $" - {s.Bounds.Width}x{s.Bounds.Height}"
            }).ToList();

            ScreenComboBox.ItemsSource = items;
            ScreenComboBox.SelectedIndex = 0;

            // 僅在偵測到多台螢幕時才顯示選擇區與「顯示螢幕編號」按鈕。
            MultiScreenPanel.Visibility = items.Count > 1 ? Visibility.Visible : Visibility.Collapsed;
        }

        private Forms.Screen GetSelectedScreen()
        {
            return (ScreenComboBox.SelectedItem as ScreenItem)?.Screen ?? Forms.Screen.PrimaryScreen!;
        }

        private void ScreenComboBox_OnSelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            // 切換螢幕時，先前選取的自訂範圍座標可能不再適用，重置為全螢幕較安全。
            if (_customRegion != null)
            {
                _customRegion = null;
                CustomRegionRadio.IsChecked = false;
                FullScreenRadio.IsChecked = true;
                UpdateRegionSummary();
            }
        }

        #endregion

        #region 全螢幕／自訂範圍

        private void CaptureModeRadio_OnChecked(object sender, RoutedEventArgs e)
        {
            bool isCustom = CustomRegionRadio.IsChecked == true;
            SelectRegionButton.IsEnabled = isCustom;

            if (!isCustom)
            {
                _customRegion = null;
            }

            UpdateRegionSummary();
        }

        private void SelectRegionButton_OnClick(object sender, RoutedEventArgs e)
        {
            // RegionSelectorWindow：透明無邊框視窗，讓使用者拖曳出矩形範圍，
            // 按 Esc 取消。回傳選取結果（螢幕座標）或 null（取消）。
            var selector = new RegionSelectorWindow(GetSelectedScreen());
            bool? result = selector.ShowDialog();

            if (result == true && selector.SelectedRegion is Rect region)
            {
                _customRegion = region;
            }

            UpdateRegionSummary();
        }

        private void UpdateRegionSummary()
        {
            RegionSummaryText.Text = _customRegion is Rect r
                ? $"擷取範圍：自訂 {(int)r.Width}x{(int)r.Height} @ ({(int)r.X},{(int)r.Y})"
                : "擷取範圍：全螢幕";
        }

        private void ShowScreenNumbersButton_OnClick(object sender, RoutedEventArgs e)
        {
            // 於每個螢幕中央短暫顯示對應下拉選單順序的數字浮層。
            // OverlayWindow 內部自行處理顯示時間與淡出後自動關閉。
            var screens = Forms.Screen.AllScreens;
            for (int i = 0; i < screens.Length; i++)
            {
                var overlay = new OverlayWindow(OverlayWindow.OverlayKind.ScreenNumber, screens[i], number: i + 1);
                overlay.Show();
            }
        }

        #endregion

        #region 錄影控制

        private void StartButton_OnClick(object sender, RoutedEventArgs e)
        {
            StartRecording();
        }

        /// <summary>開始錄影。供主視窗按鈕與全域快捷鍵共用。</summary>
        public void StartRecording()
        {
            if (IsRecording)
            {
                return;
            }

            try
            {
                var targetScreen = GetSelectedScreen();

                _recorder = new RecorderManager(targetScreen, _customRegion);
                _recorder.RecordingStopped += Recorder_OnRecordingStopped;
                _recorder.Start();

                _isPaused = false;
                _elapsedTimer.Start();

                UpdateUiForRecordingState(isRecording: true, isPaused: false);
                StatusText.Text = "錄影中… 00:00:00";
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, $"無法開始錄影：{ex.Message}", "ScreenRecorder",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void PauseResumeButton_OnClick(object sender, RoutedEventArgs e)
        {
            if (_isPaused)
            {
                ResumeRecording();
            }
            else
            {
                PauseRecording();
            }
        }

        /// <summary>暫停錄影。內部以 accumulatedOffset 概念捨棄暫停期間畫面，續錄時維持時間軸連續。</summary>
        public void PauseRecording()
        {
            if (!IsRecording || _isPaused)
            {
                return;
            }

            _recorder?.Pause();
            _isPaused = true;
            PauseResumeButton.Content = "繼續";
            StatusText.Text = $"已暫停 {FormatElapsed()}";
        }

        public void ResumeRecording()
        {
            if (!IsRecording || !_isPaused)
            {
                return;
            }

            _recorder?.Resume();
            _isPaused = false;
            PauseResumeButton.Content = "暫停";
        }

        private void StopButton_OnClick(object sender, RoutedEventArgs e)
        {
            StopRecording();
        }

        public void StopRecording()
        {
            if (!IsRecording)
            {
                return;
            }

            _recorder?.Stop(); // 觸發 SinkWriter Finalize，完成後由 Recorder_OnRecordingStopped 回呼更新 UI
        }

        private void Recorder_OnRecordingStopped(object? sender, RecordingStoppedEventArgs e)
        {
            // 錄製收尾可能在背景執行緒完成，切回 UI 執行緒更新畫面。
            Dispatcher.Invoke(() =>
            {
                _elapsedTimer.Stop();
                _isPaused = false;
                UpdateUiForRecordingState(isRecording: false, isPaused: false);

                if (e.Success)
                {
                    LastOutputPath = e.OutputPath;
                    StatusText.Text = $"已輸出：{System.IO.Path.GetFileName(e.OutputPath)}";
                    OpenExplorerAndSelect(e.OutputPath);
                }
                else
                {
                    StatusText.Text = "錄影失敗，請查看錯誤紀錄";
                    MessageBox.Show(this, e.ErrorMessage ?? "未知錯誤", "ScreenRecorder",
                        MessageBoxButton.OK, MessageBoxImage.Error);
                }
            });
        }

        private void UpdateUiForRecordingState(bool isRecording, bool isPaused)
        {
            StartButton.IsEnabled = !isRecording;
            PauseResumeButton.IsEnabled = isRecording;
            StopButton.IsEnabled = isRecording;
            PauseResumeButton.Content = isPaused ? "繼續" : "暫停";

            ScreenComboBox.IsEnabled = !isRecording;
            FullScreenRadio.IsEnabled = !isRecording;
            CustomRegionRadio.IsEnabled = !isRecording;
            SelectRegionButton.IsEnabled = !isRecording && CustomRegionRadio.IsChecked == true;
        }

        private void ElapsedTimer_OnTick(object? sender, EventArgs e)
        {
            if (!_isPaused)
            {
                StatusText.Text = $"錄影中… {FormatElapsed()}";
            }
        }

        private string FormatElapsed()
        {
            var elapsed = _recorder?.Elapsed ?? TimeSpan.Zero;
            return elapsed.ToString(@"hh\:mm\:ss");
        }

        /// <summary>供 TrayIconManager 顯示於右鍵選單的已錄製時長文字（HH:mm:ss）。</summary>
        public string GetElapsedTimeText() => FormatElapsed();

        /// <summary>供 TrayIconManager 判斷目前是否處於暫停狀態，以決定選單顯示「暫停」或「繼續」。</summary>
        public bool IsPaused => _isPaused;

        #endregion

        #region 輸出檔案

        private void OpenOutputButton_OnClick(object sender, RoutedEventArgs e)
        {
            string outputFolder = RecorderManager.GetOutputFolder();
            System.IO.Directory.CreateDirectory(outputFolder);
            Process.Start(new ProcessStartInfo(outputFolder) { UseShellExecute = true });
        }

        private static void OpenExplorerAndSelect(string filePath)
        {
            if (string.IsNullOrEmpty(filePath) || !System.IO.File.Exists(filePath))
            {
                return;
            }

            // 開啟檔案總管並選取指定檔案。
            Process.Start(new ProcessStartInfo("explorer.exe", $"/select,\"{filePath}\"")
            {
                UseShellExecute = true
            });
        }

        #endregion

        #region 全域快捷鍵

        private void RegisterGlobalHotKeys()
        {
            // 對應企劃書第 4 節：Ctrl+Alt+Win+R / P / C / S。
            // HotKeyManager 內部建立隱藏訊息視窗接收 WM_HOTKEY 並轉呼叫下列委派。
            // 已知限制：快捷鍵觸發的「開始錄影」固定為全螢幕。
            _hotKeyManager = new HotKeyManager();
            _hotKeyManager.Register(HotKeyManager.Action.StartRecording, () =>
            {
                FullScreenRadio.IsChecked = true; // 快捷鍵啟動固定為全螢幕
                StartRecording();
            });
            _hotKeyManager.Register(HotKeyManager.Action.Pause, PauseRecording);
            _hotKeyManager.Register(HotKeyManager.Action.Resume, ResumeRecording);
            _hotKeyManager.Register(HotKeyManager.Action.Stop, StopRecording);
        }

        #endregion

        #region 視窗生命週期 / 系統匣互動

        private void MainWindow_OnClosing(object? sender, CancelEventArgs e)
        {
            if (_allowRealClose)
            {
                return; // 放行，交由 App.OnExit 收尾
            }

            // 預設行為：關閉視窗＝隱藏到系統匣，錄影（若進行中）不受影響地繼續。
            e.Cancel = true;
            Hide();
        }

        /// <summary>供 TrayIconManager「開啟主視窗」選項呼叫。</summary>
        public void ShowAndActivate()
        {
            Show();
            if (WindowState == WindowState.Minimized)
            {
                WindowState = WindowState.Normal;
            }
            Activate();
        }

        /// <summary>供 TrayIconManager「結束」選項呼叫：若正在錄影先停止，再真正關閉應用程式。</summary>
        public void ExitApplication()
        {
            if (IsRecording)
            {
                StopRecording();
            }

            _hotKeyManager?.Dispose();

            _allowRealClose = true;
            Close();
            Application.Current.Shutdown();
        }

        #endregion
    }
}

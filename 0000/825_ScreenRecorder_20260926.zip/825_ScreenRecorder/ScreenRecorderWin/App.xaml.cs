using System;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows;

namespace ScreenRecorderWin
{
    /// <summary>
    /// 應用程式進入點。
    /// 職責：
    ///   1. 使用具名 Mutex 防止多開；若已有實例在執行，嘗試喚醒既有主視窗後結束本次啟動。
    ///   2. 啟動時初始化系統匣圖示（TrayIconManager）。
    ///   3. 註冊全域未處理例外處理常式，避免錄影中程式無預警崩潰而遺失錄影檔。
    /// </summary>
    public partial class App : Application
    {
        // 具名 Mutex，跨處理程序辨識「是否已有一份 ScreenRecorderWin 在執行」。
        // 使用 GUID 而非簡短字串，降低與其他軟體撞名的機率。
        private const string MutexName = "ScreenRecorderWin_SingleInstance_9F1E3C2B-6C9A-4B3D-9D2E-2C6E1E3F7A11";

        private Mutex? _singleInstanceMutex;
        private TrayIconManager? _trayIconManager;

        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            // --- 1. 單一實例檢查 -------------------------------------------------
            _singleInstanceMutex = new Mutex(initiallyOwned: true, name: MutexName, createdNew: out bool isNewInstance);

            if (!isNewInstance)
            {
                // 已有實例在執行：嘗試把既有主視窗帶到最前面，然後結束這次啟動。
                ActivateExistingInstanceWindow();
                Shutdown();
                return;
            }

            // --- 2. 全域例外處理（錄影軟體崩潰代價高，務必記錄並嘗試安全結束）------
            DispatcherUnhandledException += OnDispatcherUnhandledException;
            AppDomain.CurrentDomain.UnhandledException += OnAppDomainUnhandledException;

            // --- 3. 建立主視窗（由 App.xaml 的 StartupUri 觸發）並初始化系統匣 -----
            // MainWindow 會在自身建構子/Loaded 事件中，視使用者設定決定是否直接隱藏到系統匣。
            var mainWindow = new MainWindow();
            MainWindow = mainWindow;

            // TrayIconManager 負責：建立 NotifyIcon、右鍵選單（暫停/繼續/停止、查看輸出、
            // 開啟主視窗、結束），以及依 RecorderManager 狀態更新選單文字（已錄製時長等）。
            _trayIconManager = new TrayIconManager(mainWindow);
            _trayIconManager.Initialize();

            mainWindow.Show();
        }

        protected override void OnExit(ExitEventArgs e)
        {
            // 結束前釋放資源：系統匣圖示、全域快捷鍵、Mutex。
            _trayIconManager?.Dispose();

            if (_singleInstanceMutex != null)
            {
                try
                {
                    _singleInstanceMutex.ReleaseMutex();
                }
                catch (ApplicationException)
                {
                    // 若目前執行緒未持有該 Mutex（理論上不應發生），忽略即可。
                }
                _singleInstanceMutex.Dispose();
            }

            base.OnExit(e);
        }

        /// <summary>
        /// 嘗試找到既有實例的主視窗並將其帶到最前景。
        /// 找不到（例如既有實例仍在初始化，或已隱藏到系統匣但視窗類別名稱不符）時，
        /// 僅安靜地結束本次啟動，不特別提示使用者。
        /// </summary>
        private static void ActivateExistingInstanceWindow()
        {
            // 視窗標題需與 MainWindow.xaml 中設定的 Title 一致。
            const string mainWindowTitle = "ScreenRecorder";

            IntPtr hWnd = FindWindow(null, mainWindowTitle);
            if (hWnd == IntPtr.Zero)
            {
                return;
            }

            // 若視窗被最小化或隱藏，先還原顯示，再設為前景視窗。
            const int SW_RESTORE = 9;
            ShowWindow(hWnd, SW_RESTORE);
            SetForegroundWindow(hWnd);
        }

        private void OnDispatcherUnhandledException(object sender, System.Windows.Threading.DispatcherUnhandledExceptionEventArgs e)
        {
            // TODO：串接實際的錄影狀態，若正在錄製中，嘗試呼叫 RecorderManager 的
            // 緊急收尾流程（Finalize SinkWriter），盡量保留已錄製內容再結束。
            LogUnhandledException(e.Exception);
            e.Handled = true;
        }

        private void OnAppDomainUnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            if (e.ExceptionObject is Exception ex)
            {
                LogUnhandledException(ex);
            }
        }

        private static void LogUnhandledException(Exception ex)
        {
            // MVP 階段先寫入應用程式資料夾下的 log 檔；後續可替換為正式的 logging 套件。
            try
            {
                string logDir = System.IO.Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                    "ScreenRecorderWin");
                System.IO.Directory.CreateDirectory(logDir);

                string logPath = System.IO.Path.Combine(logDir, "crash.log");
                string entry = $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] {ex}\n\n";
                System.IO.File.AppendAllText(logPath, entry);
            }
            catch
            {
                // 記錄例外過程中若再度失敗，不再向上拋出，避免死迴圈。
            }
        }

        #region Win32 Interop

        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern IntPtr FindWindow(string? lpClassName, string lpWindowName);

        [DllImport("user32.dll")]
        private static extern bool SetForegroundWindow(IntPtr hWnd);

        [DllImport("user32.dll")]
        private static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

        #endregion
    }
}

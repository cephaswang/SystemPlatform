using System;
using System.Windows;
using System.Windows.Input;
using Forms = System.Windows.Forms;

namespace ScreenRecorderWin
{
    /// <summary>
    /// 自訂範圍拖曳選取視窗。
    /// 使用方式：<c>new RegionSelectorWindow(screen).ShowDialog()</c>，
    /// 完成有效選取時 <see cref="ShowDialog"/> 回傳 true，並可從 <see cref="SelectedRegion"/> 取得結果；
    /// 按 Esc 或拖曳範圍過小則回傳 false，<see cref="SelectedRegion"/> 為 null。
    /// </summary>
    public partial class RegionSelectorWindow : Window
    {
        /// <summary>視為有效選取的最小邊長（裝置無關單位），避免誤觸產生 0 大小的錄製範圍。</summary>
        private const double MinimumSelectionSize = 8.0;

        private readonly Forms.Screen _targetScreen;
        private Point? _dragStartPoint;

        /// <summary>
        /// 選取結果，座標系與 <see cref="Forms.Screen.Bounds"/> 相同（虛擬桌面像素座標），
        /// 供 RecorderManager 換算實際擷取像素矩形使用。
        /// </summary>
        public Rect? SelectedRegion { get; private set; }

        public RegionSelectorWindow(Forms.Screen targetScreen)
        {
            _targetScreen = targetScreen ?? throw new ArgumentNullException(nameof(targetScreen));
            InitializeComponent();
        }

        private void RegionSelectorWindow_OnLoaded(object sender, RoutedEventArgs e)
        {
            // 覆蓋整台目標螢幕。假設 app.manifest 已設定 Per-Monitor V2 DPI 感知，
            // 此時 WPF 視窗的 Left/Top/Width/Height 會對應實際像素座標，可直接套用 Screen.Bounds。
            var bounds = _targetScreen.Bounds;
            Left = bounds.Left;
            Top = bounds.Top;
            Width = bounds.Width;
            Height = bounds.Height;

            Activate();
            Focus();
            Keyboard.Focus(this);
        }

        private void RegionSelectorWindow_OnPreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Escape)
            {
                SelectedRegion = null;
                DialogResult = false;
                Close();
            }
        }

        private void RootGrid_OnMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            _dragStartPoint = e.GetPosition(RootGrid);

            HintText.Visibility = Visibility.Collapsed;
            SelectionRect.Visibility = Visibility.Visible;
            SizeLabel.Visibility = Visibility.Visible;

            UpdateSelectionVisual(_dragStartPoint.Value, _dragStartPoint.Value);

            RootGrid.CaptureMouse();
        }

        private void RootGrid_OnMouseMove(object sender, MouseEventArgs e)
        {
            if (_dragStartPoint is not Point start)
            {
                return;
            }

            Point current = e.GetPosition(RootGrid);
            UpdateSelectionVisual(start, current);
        }

        private void RootGrid_OnMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (_dragStartPoint is not Point start)
            {
                return;
            }

            RootGrid.ReleaseMouseCapture();

            Point end = e.GetPosition(RootGrid);
            Rect localRect = BuildRect(start, end);
            _dragStartPoint = null;

            if (localRect.Width < MinimumSelectionSize || localRect.Height < MinimumSelectionSize)
            {
                // 拖曳範圍過小視為誤觸：重置畫面讓使用者重新選取，而不是直接取消整個流程。
                SelectionRect.Visibility = Visibility.Collapsed;
                SizeLabel.Visibility = Visibility.Collapsed;
                HintText.Visibility = Visibility.Visible;
                return;
            }

            // 將視窗內的區域座標加上視窗左上角（即目標螢幕左上角）座標，
            // 還原為虛擬桌面座標，供 RecorderManager 依螢幕 Bounds 做後續換算。
            SelectedRegion = new Rect(
                Left + localRect.X,
                Top + localRect.Y,
                localRect.Width,
                localRect.Height);

            DialogResult = true;
            Close();
        }

        private void UpdateSelectionVisual(Point start, Point current)
        {
            Rect rect = BuildRect(start, current);

            SelectionRect.Margin = new Thickness(rect.X, rect.Y, 0, 0);
            SelectionRect.Width = rect.Width;
            SelectionRect.Height = rect.Height;

            SizeLabel.Text = $"{(int)rect.Width} x {(int)rect.Height}";
            // 尺寸標籤跟隨選取框右下角，並預留少許邊距避免緊貼滑鼠游標。
            SizeLabel.Margin = new Thickness(rect.X + rect.Width + 6, rect.Y + rect.Height + 6, 0, 0);
        }

        private static Rect BuildRect(Point a, Point b)
        {
            double x = Math.Min(a.X, b.X);
            double y = Math.Min(a.Y, b.Y);
            double width = Math.Abs(a.X - b.X);
            double height = Math.Abs(a.Y - b.Y);
            return new Rect(x, y, width, height);
        }
    }
}

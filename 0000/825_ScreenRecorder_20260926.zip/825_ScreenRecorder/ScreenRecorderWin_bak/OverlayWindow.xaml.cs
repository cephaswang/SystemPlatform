using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Threading;
using DrawingRectangle = System.Drawing.Rectangle;
using Screen = System.Windows.Forms.Screen;

namespace ScreenRecorderWin
{
    /// <summary>疊加視窗的顯示模式。</summary>
    public enum OverlayMode
    {
        /// <summary>螢幕編號提示：於螢幕中央短暫顯示數字。</summary>
        ScreenNumber,

        /// <summary>錄影中範圍紅框：click-through 的紅色邊框，標示目前錄製範圍。</summary>
        RecordingBorder
    }

    /// <summary>
    /// 共用疊加視窗（對應企劃書 5. 建議專案結構 OverlayWindow.xaml）：
    ///   - 螢幕編號提示：多螢幕時協助使用者辨識主視窗下拉選單中「螢幕 1 / 螢幕 2 ...」對應的實際螢幕位置。
    ///   - 錄影中範圍紅框：自訂範圍錄製時，於錄製範圍外緣顯示 click-through 紅框（企劃書 3. 技術架構對照表
    ///     「錄製中範圍邊框」一列：WS_EX_TRANSPARENT + WS_EX_LAYERED 擴充樣式做穿透紅框）。
    ///
    /// 使用方式：
    ///   // 螢幕編號提示（多螢幕列舉順序需與 MainWindow 下拉選單一致）
    ///   OverlayWindow.ShowScreenNumbers(Screen.AllScreens);
    ///
    ///   // 錄影中範圍紅框（region 為實體像素座標，來自 RegionSelectorWindow 或 RecordingOptions.CustomRegion）
    ///   var borderOverlay = OverlayWindow.ShowRecordingBorder(region);
    ///   ...
    ///   borderOverlay.Close(); // 停止錄影或暫停時關閉
    ///
    /// 已知限制（比照企劃書第 6 節）：
    ///   - 與 RegionSelectorWindow 相同，實體像素座標換算為 WPF 視窗座標時，
    ///     採用「該視窗所在螢幕」的單一 DPI 縮放比例；跨越不同 DPI 螢幕邊界的範圍
    ///     可能有數像素誤差，Phase 1 不處理精細校正。
    /// </summary>
    public partial class OverlayWindow : Window
    {
        // ---- Win32 click-through 所需常數與 P/Invoke 宣告 ----
        private const int GWL_EXSTYLE = -20;
        private const int WS_EX_LAYERED = 0x00080000;
        private const int WS_EX_TRANSPARENT = 0x00000020;

        [DllImport("user32.dll", SetLastError = true)]
        private static extern int GetWindowLong(IntPtr hWnd, int nIndex);

        [DllImport("user32.dll", SetLastError = true)]
        private static extern int SetWindowLong(IntPtr hWnd, int nIndex, int dwNewLong);

        private readonly OverlayMode _mode;
        private DispatcherTimer? _autoCloseTimer;

        private OverlayWindow(OverlayMode mode)
        {
            InitializeComponent();
            _mode = mode;

            if (mode == OverlayMode.RecordingBorder)
            {
                // 紅框視窗需要在建立完成、取得 Win32 handle 後套用 click-through 樣式。
                SourceInitialized += (_, _) => ApplyClickThroughStyle();
            }
        }

        // ---------------------------------------------------------------
        // 模式一：螢幕編號提示
        // ---------------------------------------------------------------

        /// <summary>
        /// 依序在每個螢幕中央顯示編號浮層（編號 = 在 <paramref name="screensInOrder"/> 中的順序，從 1 開始），
        /// 對應主視窗下拉選單的螢幕順序。顯示 <paramref name="duration"/> 後自動關閉。
        /// 主視窗的 🔢 按鈕只需重新呼叫本方法即可重新顯示，不需額外狀態管理。
        /// </summary>
        /// <param name="screensInOrder">
        /// 螢幕清單，順序須與主視窗下拉選單一致（例如直接傳入列舉 Screen.AllScreens 的結果）。
        /// </param>
        /// <param name="duration">顯示時長，預設 1.5 秒。</param>
        public static void ShowScreenNumbers(IReadOnlyList<Screen> screensInOrder, TimeSpan? duration = null)
        {
            var displayDuration = duration ?? TimeSpan.FromSeconds(1.5);

            for (int i = 0; i < screensInOrder.Count; i++)
            {
                var screen = screensInOrder[i];
                int number = i + 1;

                var overlay = new OverlayWindow(OverlayMode.ScreenNumber);
                overlay.ConfigureAsScreenNumber(screen, number, displayDuration);
                overlay.Show();
            }
        }

        private void ConfigureAsScreenNumber(Screen screen, int number, TimeSpan duration)
        {
            NumberOverlayGrid.Visibility = Visibility.Visible;
            NumberText.Text = number.ToString();

            // 螢幕編號視窗只需要涵蓋單一螢幕的範圍即可（不像 RegionSelectorWindow 需要橫跨虛擬螢幕），
            // 直接使用 System.Windows.Forms.Screen.Bounds（實體像素）換算回該視窗的 DIP 座標。
            PositionOverScreen(screen);

            _autoCloseTimer = new DispatcherTimer { Interval = duration };
            _autoCloseTimer.Tick += (_, _) =>
            {
                _autoCloseTimer!.Stop();
                Close();
            };
            _autoCloseTimer.Start();
        }

        // ---------------------------------------------------------------
        // 模式二：錄影中範圍紅框
        // ---------------------------------------------------------------

        /// <summary>
        /// 顯示錄影中範圍紅框（click-through），對應自訂範圍錄製時提醒使用者目前的擷取範圍。
        /// 回傳的視窗實例由呼叫端負責在錄影停止（或暫停時視需求）呼叫 <see cref="Window.Close"/>。
        /// </summary>
        /// <param name="regionPhysicalPixels">錄製範圍，螢幕座標系下的實體像素矩形。</param>
        public static OverlayWindow ShowRecordingBorder(DrawingRectangle regionPhysicalPixels)
        {
            var overlay = new OverlayWindow(OverlayMode.RecordingBorder);
            overlay.ConfigureAsRecordingBorder(regionPhysicalPixels);
            overlay.Show();
            return overlay;
        }

        private void ConfigureAsRecordingBorder(DrawingRectangle regionPhysicalPixels)
        {
            RecordingBorderFrame.Visibility = Visibility.Visible;
            PositionOverPhysicalRegion(regionPhysicalPixels);
        }

        /// <summary>
        /// 套用 WS_EX_TRANSPARENT + WS_EX_LAYERED 擴充視窗樣式，讓滑鼠事件完全穿透本視窗，
        /// 使用者仍可正常操作紅框底下的其他應用程式（企劃書 3. 技術架構對照表「錄製中範圍邊框」一列）。
        /// </summary>
        private void ApplyClickThroughStyle()
        {
            var hwnd = new WindowInteropHelper(this).Handle;
            int extendedStyle = GetWindowLong(hwnd, GWL_EXSTYLE);
            SetWindowLong(hwnd, GWL_EXSTYLE, extendedStyle | WS_EX_LAYERED | WS_EX_TRANSPARENT);
        }

        // ---------------------------------------------------------------
        // 座標換算輔助
        // ---------------------------------------------------------------

        /// <summary>
        /// 將視窗定位、縮放至涵蓋指定的 <see cref="Screen"/> 整個範圍。
        /// Screen.Bounds 為實體像素，換算為該視窗對應的 DIP 座標後套用到 Left/Top/Width/Height，
        /// 讓內容（編號圓圈）可用 HorizontalAlignment/VerticalAlignment=Center 置中於該螢幕正中央。
        /// </summary>
        private void PositionOverScreen(Screen screen)
        {
            PositionOverPhysicalRegion(new DrawingRectangle(
                screen.Bounds.X, screen.Bounds.Y, screen.Bounds.Width, screen.Bounds.Height));
        }

        /// <summary>
        /// 將視窗定位、縮放至涵蓋指定的實體像素矩形範圍。
        /// 換算依據為系統目前主要的 DPI 縮放比例；若螢幕縮放比例不是 100%，
        /// 會在 SourceInitialized 後以該視窗實際取得的 DPI 重新校正一次（見 <see cref="RefinePositionForActualDpi"/>）。
        /// </summary>
        private void PositionOverPhysicalRegion(DrawingRectangle regionPhysicalPixels)
        {
            // 初次以 96 DPI（縮放比例 1.0）估算，避免視窗尚未建立、無法取得實際 DPI 前定位錯誤。
            Left = regionPhysicalPixels.X;
            Top = regionPhysicalPixels.Y;
            Width = Math.Max(1, regionPhysicalPixels.Width);
            Height = Math.Max(1, regionPhysicalPixels.Height);

            SourceInitialized += (_, _) => RefinePositionForActualDpi(regionPhysicalPixels);
        }

        /// <summary>
        /// 視窗建立完成、取得對應螢幕的實際 DPI 後，重新換算一次 Left/Top/Width/Height，
        /// 修正高 DPI 螢幕（125%/150% 等）下初次估算的定位誤差。
        /// </summary>
        private void RefinePositionForActualDpi(DrawingRectangle regionPhysicalPixels)
        {
            var dpi = VisualTreeHelper.GetDpi(this);
            if (Math.Abs(dpi.DpiScaleX - 1.0) < 0.001 && Math.Abs(dpi.DpiScaleY - 1.0) < 0.001)
            {
                return; // 100% 縮放，初次估算已經準確
            }

            Left = regionPhysicalPixels.X / dpi.DpiScaleX;
            Top = regionPhysicalPixels.Y / dpi.DpiScaleY;
            Width = Math.Max(1, regionPhysicalPixels.Width / dpi.DpiScaleX);
            Height = Math.Max(1, regionPhysicalPixels.Height / dpi.DpiScaleY);
        }
    }
}

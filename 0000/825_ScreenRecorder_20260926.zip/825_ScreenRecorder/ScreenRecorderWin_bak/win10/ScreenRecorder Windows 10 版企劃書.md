# ScreenRecorder for Windows 10 — 軟體企劃書 v1.0

對應 macOS 版 Phase 1（MVP）功能，改用 Windows 10 原生技術重新規劃。

## 1. 專案概述

支援「暫停 / 繼續」的 Windows 10 螢幕錄影工具，錄製時即時編碼，停止後直接得到 `.mp4`（H.264），不需額外轉檔。功能對齊 macOS 版：全螢幕 / 自訂範圍錄製、系統音效＋麥克風混音、全域快捷鍵、系統匣常駐操作。

## 2. 系統需求

- Windows 10 version 1903（19H1）以上 — 螢幕擷取需要 `Windows.Graphics.Capture` API 支援
- .NET 8（或 .NET 6 LTS）+ WPF
- Visual Studio 2022

> 若需支援 1903 以前的 Windows 10，畫面擷取需退回 GDI+ / BitBlt 逐格截圖方案，效能與相容性較差，本企劃書預設以 1903+ 為基準。

## 3. 技術架構對照表（macOS → Windows）

| 功能 | macOS 實作 | Windows 10 對應方案 |
| --- | --- | --- |
| UI 框架 | SwiftUI | WPF（或 WinUI 3） |
| 主視窗單例 | `Window(id:)` 場景 | `Application.Current.MainWindow` + 啟動時檢查既有實例（`Mutex` 防止多開） |
| 選單列常駐 | macOS 選單列圖示 | 系統匣圖示 `NotifyIcon`（右鍵選單：暫停/繼續/停止、查看輸出、開啟主視窗、結束） |
| 螢幕擷取 | ScreenCaptureKit (`SCShareableContent`) | `Windows.Graphics.Capture`（WGC）擷取畫面 frame |
| 自訂範圍錄製 | 拖曳半透明遮罩視窗 | 透明無邊框 `Window`（`AllowsTransparency`）做拖曳選取，邏輯相同 |
| 錄製中範圍邊框 | click-through 紅框視窗 | `WS_EX_TRANSPARENT` + `WS_EX_LAYERED` 擴充樣式做穿透紅框 |
| 編碼輸出 MP4 | `AVAssetWriter`（H.264） | Media Foundation `SinkWriter`（H.264 / MP4 容器） |
| 系統音效擷取 | ScreenCaptureKit 內建音訊 | WASAPI **Loopback** 模式擷取預設輸出裝置 |
| 麥克風擷取 | `AVCaptureSession` | WASAPI 擷取模式（預設輸入裝置） |
| 音訊混音 | 自製 `AudioMixer`（Float32 相加） | 相同邏輯：兩路轉 48kHz 立體聲 Float32 後相加，寫入單一 AAC 音軌 |
| 暫停/續錄演算法 | 時間戳位移（`accumulatedOffset`） | 相同演算法，套用在 Media Foundation 的 sample timestamp 上 |
| 全域快捷鍵 | Carbon `RegisterEventHotKey` | Win32 `RegisterHotKey` API（需搭配隱藏訊息視窗接收 `WM_HOTKEY`） |
| 麥克風權限 | Info.plist + Hardened Runtime | Windows 設定 → 隱私權 → 麥克風；App 需宣告使用麥克風（一般 Win32/WPF 桌面程式免額外 Manifest 宣告，但需處理裝置被拒絕存取時的錯誤） |
| 螢幕錄製權限 | 系統跳出「螢幕錄製」授權 | Windows 10 對桌面程式呼叫 WGC 通常免額外系統授權彈窗（與 macOS 沙盒機制不同），但需檢查使用者是否有「隱私權 → 相機/螢幕擷取」相關限制 |

## 4. 功能規劃（比照 macOS Phase 1）

- **多螢幕列表**：啟動時列舉所有螢幕（`System.Windows.Forms.Screen.AllScreens` 或 WGC 的 `GraphicsCaptureItem`），偵測到多台時主視窗顯示「錄製螢幕」下拉選單。
- **螢幕編號提示**：多螢幕時於各螢幕中央短暫顯示數字浮層，對應下拉選單順序；提供🔢按鈕可重新顯示。
- **全螢幕 / 自訂範圍切換**：邏輯與 macOS 版相同，自訂範圍以拖曳矩形決定擷取區域，按 `Esc` 取消。
- **輸出解析度**：依所選範圍與該螢幕 DPI 縮放比例（Windows 的 `DPI Awareness`）自動換算，避免高 DPI 螢幕擷取模糊或裁切錯位（此為 Windows 特有需注意項目，macOS 版對應 Retina 縮放）。
- **系統匣操作**：開始錄影後主視窗可選擇隱藏至系統匣，右鍵選單顯示狀態、已錄製時長、暫停/繼續/停止、查看上次輸出、於檔案總管開啟。
- **全域快捷鍵**（預設，可比照 macOS 選用少見組合鍵避免衝突）：

  | 動作 | 建議快捷鍵 |
  | --- | --- |
  | 開始錄影 | `Ctrl+Alt+Win+R` |
  | 暫停 | `Ctrl+Alt+Win+P` |
  | 繼續 | `Ctrl+Alt+Win+C` |
  | 停止並輸出 MP4 | `Ctrl+Alt+Win+S` |

  > 與 macOS 相同已知限制：快捷鍵觸發的「開始錄影」固定為全螢幕，自訂範圍仍需從主視窗滑鼠操作。
- **輸出位置**：`%USERPROFILE%\Videos\ScreenRecorder_yyyyMMdd_HHmmss.mp4`，完成後自動開啟檔案總管並選取檔案。
- **暫停/續錄**：捨棄暫停期間的畫面，續錄後以第一顆畫面時間戳計算累加位移，維持輸出時間軸連續。

## 5. 建議專案結構

```
ScreenRecorderWin/
├── App.xaml / App.xaml.cs        # 進入點，Mutex 防多開、系統匣初始化
├── MainWindow.xaml               # 主視窗：選螢幕/範圍、開始錄影、查看輸出
├── TrayIconManager.cs            # 系統匣圖示與右鍵選單
├── RecorderManager.cs            # 核心錄影邏輯（WGC 擷取、暫停位移演算法）
├── RegionSelectorWindow.xaml     # 自訂範圍拖曳選取遮罩視窗
├── OverlayWindow.xaml            # 螢幕編號提示、錄影中範圍紅框
├── HotKeyManager.cs              # 全域快捷鍵（RegisterHotKey + 隱藏訊息視窗）
├── AudioMixer.cs                 # WASAPI 系統音效＋麥克風混音
└── README.md
```

## 6. 已知限制（Phase 1 範圍，比照 macOS 版）

- 目前僅規劃整台顯示器全螢幕擷取為主要路徑，單一視窗擷取列為 Phase 3 項目。
- 全域快捷鍵僅支援固定組合鍵，使用者自訂快捷鍵設定畫面列為 Phase 4 項目。
- 需另行處理高 DPI / 多螢幕混合縮放比例（125%/150%等）下的擷取解析度校正，此為 Windows 平台特有風險項，macOS 版無對應問題（僅 Retina 單一縮放係數）。
- WGC 在部分需要「安全內容保護」的視窗（如 DRM 播放器）擷取會顯示黑畫面，此為系統限制，需於文件中註明。

## 7. 建置步驟（草案）

1. Visual Studio 2022 建立 **.NET 8 WPF App**。
2. 加入 NuGet 套件：`Microsoft.Windows.SDK.Contracts`（WGC）、`NAudio` 或直接呼叫 WASAPI COM 介面、Media Foundation 互操作套件（或使用 `SharpDX.MediaFoundation` / 手動 P/Invoke）。
3. 依上表建立各檔案，實作螢幕擷取 → Media Foundation 編碼 → 混音的資料流。
4. 於「應用程式資訊清單」（app.manifest）設定 DPI 感知（Per-Monitor V2），避免多螢幕縮放錯位。
5. 測試多螢幕、暫停續錄時間軸連續性、系統音效與麥克風混音是否有回音（建議測試情境比照 macOS 版建議戴耳機）。

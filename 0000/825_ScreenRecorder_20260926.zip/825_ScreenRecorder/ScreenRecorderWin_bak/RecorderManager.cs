using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Threading;
using Screen = System.Windows.Forms.Screen;

// WGC（Windows.Graphics.Capture）WinRT 投影型別。
// 專案需加入 NuGet：Microsoft.Windows.SDK.Contracts，
// 且目標 Framework 需為 net8.0-windows10.0.19041.0 以上才能直接 using 這些命名空間。
using Windows.Graphics.Capture;
using Windows.Graphics.DirectX;
using Windows.Graphics.DirectX.Direct3D11;

// Direct3D 11 裝置建立與 DXGI 互通。建置步驟中兩者擇一：
// 這裡示範以 SharpDX.Direct3D11 / SharpDX.DXGI 建立裝置（亦可改用 Vortice.Windows）。
using SharpDX.Direct3D;
using SharpDX.Direct3D11;
using SharpDX.DXGI;
using Device = SharpDX.Direct3D11.Device;

// Media Foundation 編碼（H.264 / AAC → MP4），對應建置步驟中的 SharpDX.MediaFoundation。
using SharpDX.MediaFoundation;
using MFDevice = SharpDX.MediaFoundation;

namespace ScreenRecorderWin
{
    /// <summary>
    /// 一次錄影工作的參數設定。
    /// </summary>
    public sealed class RecordingOptions
    {
        /// <summary>全螢幕模式下要擷取的螢幕；CustomRegion 有值時忽略此欄位。</summary>
        public Screen? TargetScreen { get; init; }

        /// <summary>自訂範圍（螢幕座標，實體像素）；null 表示全螢幕模式。</summary>
        public Rectangle? CustomRegion { get; init; }

        public bool CaptureSystemAudio { get; init; } = true;
        public bool CaptureMicrophone { get; init; } = true;

        /// <summary>輸出檔案完整路徑（.mp4）。未指定時由 RecorderManager 依規則自動產生。</summary>
        public string? OutputPath { get; init; }

        /// <summary>視訊位元率（bps）。</summary>
        public int VideoBitrate { get; init; } = 12_000_000;

        public int FrameRate { get; init; } = 30;
    }

    /// <summary>
    /// 核心錄影邏輯：
    ///   1. 透過 Windows.Graphics.Capture（WGC）擷取畫面 frame
    ///   2. 每一顆 frame 經過「暫停位移演算法」換算出正確的輸出時間戳
    ///   3. 交給 Media Foundation SinkWriter 編碼為 H.264，並容器化輸出 MP4
    ///   4. 系統音效 / 麥克風由 AudioMixer 擷取、混音後，以 AAC 音軌寫入同一個 SinkWriter
    ///
    /// 暫停/續錄演算法（對應企劃書）：
    ///   - WGC frame 的原始時間戳（相對於擷取工作階段起點）持續遞增，即使邏輯上已暫停。
    ///   - 暫停期間：捨棄所有到達的 frame，不寫入 SinkWriter。
    ///   - 每次「暫停 → 繼續」都會累積一段「暫停時長」，寫入 SinkWriter 前
    ///     以 (rawTimestamp - accumulatedPauseOffset) 校正，讓輸出檔案的時間軸
    ///     維持連續（沒有暫停期間造成的跳動）。
    /// </summary>
    public sealed class RecorderManager : IDisposable
    {
        private const int AudioSampleRate = 48000;
        private const int AudioChannels = 2;

        private GraphicsCaptureItem? _captureItem;
        private Direct3D11CaptureFramePool? _framePool;
        private GraphicsCaptureSession? _captureSession;
        private Device? _d3dDevice;
        private IDirect3DDevice? _winrtDevice;

        private SinkWriter? _sinkWriter;
        private int _videoStreamIndex;
        private int _audioStreamIndex;

        private AudioMixer? _audioMixer;

        private RecordingOptions? _options;
        private string _outputPath = string.Empty;

        // ---- 暫停位移演算法所需狀態 ----
        private TimeSpan _accumulatedPauseOffset = TimeSpan.Zero;
        private DateTime? _pauseStartedAtUtc;
        private long? _firstRawFrameTimestamp100ns; // 第一顆 frame 的原始時間戳，作為整體錄影的時間軸原點

        private readonly Stopwatch _elapsedStopwatch = new(); // 供 UI 顯示用的「已錄製時長」（已扣除暫停）
        private readonly DispatcherTimer _uiUpdateTimer;

        private RecordingState _state = RecordingState.Idle;
        private readonly object _stateLock = new();

        /// <summary>狀態或已錄製時長變化時觸發，供 MainWindow / TrayIconManager 同步 UI。</summary>
        public event EventHandler<(RecordingState State, TimeSpan Elapsed)>? StateChanged;

        /// <summary>錄影正常完成並產生檔案後觸發，帶出輸出檔案完整路徑。</summary>
        public event EventHandler<string>? Completed;

        /// <summary>錄影過程中發生無法復原的錯誤時觸發。</summary>
        public event EventHandler<Exception>? ErrorOccurred;

        public RecorderManager()
        {
            _uiUpdateTimer = new DispatcherTimer(DispatcherPriority.Background)
            {
                Interval = TimeSpan.FromSeconds(1)
            };
            _uiUpdateTimer.Tick += (_, _) => RaiseStateChanged();
        }

        public RecordingState State
        {
            get { lock (_stateLock) { return _state; } }
        }

        // ---------------------------------------------------------------
        // 開始錄影
        // ---------------------------------------------------------------

        public async Task StartAsync(RecordingOptions options)
        {
            if (State != RecordingState.Idle)
            {
                throw new InvalidOperationException("目前已在錄影中，請先停止目前的錄影。");
            }

            _options = options;
            _outputPath = options.OutputPath ?? BuildDefaultOutputPath();

            try
            {
                InitializeDirect3DDevice();
                _captureItem = CreateCaptureItem(options);

                var captureSize = GetCaptureSize(options);

                _framePool = Direct3D11CaptureFramePool.CreateFreeThreaded(
                    _winrtDevice,
                    DirectXPixelFormat.B8G8R8A8UIntNormalized,
                    numberOfBuffers: 2,
                    size: new Windows.Graphics.SizeInt32 { Width = captureSize.Width, Height = captureSize.Height });

                _framePool.FrameArrived += OnFrameArrived;

                _captureSession = _framePool.CreateCaptureSession(_captureItem);
                // Windows 10 的黃色錄製提示框（若系統支援 TryGetIsCursorCaptureEnabled）可視需要關閉：
                // _captureSession.IsCursorCaptureEnabled = false;

                InitializeSinkWriter(captureSize, options);

                if (options.CaptureSystemAudio || options.CaptureMicrophone)
                {
                    _audioMixer = new AudioMixer(options.CaptureSystemAudio, options.CaptureMicrophone);
                    _audioMixer.MixedSampleReady += OnMixedAudioSampleReady;
                    _audioMixer.Start();
                }

                ResetPauseOffsetState();
                _elapsedStopwatch.Restart();
                _uiUpdateTimer.Start();

                _captureSession.StartCapture();

                SetState(RecordingState.Recording);
            }
            catch (Exception ex)
            {
                CleanupCaptureResources();
                ErrorOccurred?.Invoke(this, ex);
                throw;
            }

            await Task.CompletedTask;
        }

        // ---------------------------------------------------------------
        // 暫停 / 繼續
        // ---------------------------------------------------------------

        public void Pause()
        {
            if (State != RecordingState.Recording)
            {
                return;
            }

            _pauseStartedAtUtc = DateTime.UtcNow;
            _elapsedStopwatch.Stop();

            SetState(RecordingState.Paused);
        }

        public void Resume()
        {
            if (State != RecordingState.Paused)
            {
                return;
            }

            if (_pauseStartedAtUtc.HasValue)
            {
                // 累加這一段暫停時長，後續 frame 的時間戳都要扣掉這個累積值，
                // 讓輸出檔案時間軸維持連續（等同企劃書所述 accumulatedOffset）。
                _accumulatedPauseOffset += DateTime.UtcNow - _pauseStartedAtUtc.Value;
                _pauseStartedAtUtc = null;
            }

            _elapsedStopwatch.Start();
            SetState(RecordingState.Recording);
        }

        // ---------------------------------------------------------------
        // 停止並輸出
        // ---------------------------------------------------------------

        public async Task<string> StopAsync()
        {
            if (State == RecordingState.Idle)
            {
                throw new InvalidOperationException("目前沒有進行中的錄影。");
            }

            _uiUpdateTimer.Stop();
            _elapsedStopwatch.Stop();

            _captureSession?.Dispose();
            if (_framePool != null)
            {
                _framePool.FrameArrived -= OnFrameArrived;
            }
            _framePool?.Dispose();

            if (_audioMixer != null)
            {
                _audioMixer.MixedSampleReady -= OnMixedAudioSampleReady;
                _audioMixer.Stop();
                _audioMixer.Dispose();
                _audioMixer = null;
            }

            try
            {
                _sinkWriter?.Finalize();
            }
            finally
            {
                _sinkWriter?.Dispose();
                _sinkWriter = null;
            }

            CleanupCaptureResources();

            SetState(RecordingState.Idle);
            Completed?.Invoke(this, _outputPath);

            return await Task.FromResult(_outputPath);
        }

        // ---------------------------------------------------------------
        // Frame / 音訊樣本處理（含暫停位移演算法核心）
        // ---------------------------------------------------------------

        private void OnFrameArrived(Direct3D11CaptureFramePool sender, object args)
        {
            using var frame = sender.TryGetNextFrame();
            if (frame == null)
            {
                return;
            }

            // 錄影邏輯上已暫停：直接捨棄畫面，不寫入 SinkWriter。
            // （WGC 擷取工作階段本身持續運作，只是我們不消費這段期間的 frame，
            //   這樣繼續錄影後才能立刻拿到最新畫面，不會有延遲的殘留影格。）
            if (State != RecordingState.Recording)
            {
                return;
            }

            long rawTimestamp100ns = frame.SystemRelativeTime.Ticks;
            _firstRawFrameTimestamp100ns ??= rawTimestamp100ns;

            long adjustedTimestamp100ns =
                (rawTimestamp100ns - _firstRawFrameTimestamp100ns.Value)
                - _accumulatedPauseOffset.Ticks;

            if (adjustedTimestamp100ns < 0)
            {
                // 理論上不會發生（第一顆 frame 必為時間軸原點），保底避免寫入負時間戳。
                adjustedTimestamp100ns = 0;
            }

            try
            {
                WriteVideoSample(frame, adjustedTimestamp100ns);
            }
            catch (Exception ex)
            {
                ErrorOccurred?.Invoke(this, ex);
            }
        }

        /// <summary>
        /// 將一顆 WGC frame 轉為 Media Foundation 的 IMFSample 並寫入視訊串流。
        /// </summary>
        private void WriteVideoSample(Direct3D11CaptureFrame frame, long adjustedTimestamp100ns)
        {
            if (_sinkWriter == null)
            {
                return;
            }

            // 1. 由 WinRT IDirect3DSurface 取得底層 DXGI Surface，複製到 CPU 可讀的 Staging Texture。
            //    （確切的 GetDXGIInterface / CopyResource 互通程式碼依 SharpDX 或 Vortice 版本略有差異，
            //      此處省略詳細互通轉型，實作時可參考 WGC 官方 C# 範例「Simple Capture」中的
            //      Direct3D11Helper.CreateSharpDXTexture2D 寫法。）
            using Texture2D stagingTexture = CopyFrameToStagingTexture(frame);

            var dataBox = _d3dDevice!.ImmediateContext.MapSubresource(
                stagingTexture, 0, MapMode.Read, SharpDX.Direct3D11.MapFlags.None, out var dataStream);

            try
            {
                int frameHeight = stagingTexture.Description.Height;
                int rowPitch = dataBox.RowPitch;
                int bufferSize = rowPitch * frameHeight;

                using var mediaBuffer = MediaFactory.CreateMemoryBuffer(bufferSize);
                var ptr = mediaBuffer.Lock(out _, out _);
                try
                {
                    Utilities.CopyMemory(ptr, dataBox.DataPointer, bufferSize);
                }
                finally
                {
                    mediaBuffer.Unlock();
                    mediaBuffer.CurrentLength = bufferSize;
                }

                using var sample = MediaFactory.CreateSample();
                sample.AddBuffer(mediaBuffer);
                sample.SampleTime = adjustedTimestamp100ns;
                sample.SampleDuration = 10_000_000L / Math.Max(1, _options?.FrameRate ?? 30);

                _sinkWriter.WriteSample(_videoStreamIndex, sample);
            }
            finally
            {
                _d3dDevice.ImmediateContext.UnmapSubresource(stagingTexture, 0);
            }
        }

        private void OnMixedAudioSampleReady(object? sender, MixedAudioSample sample)
        {
            if (_sinkWriter == null || State != RecordingState.Recording)
            {
                return;
            }

            long adjustedTimestamp100ns = sample.Timestamp.Ticks - _accumulatedPauseOffset.Ticks;
            if (adjustedTimestamp100ns < 0)
            {
                adjustedTimestamp100ns = 0;
            }

            try
            {
                using var mediaBuffer = MediaFactory.CreateMemoryBuffer(sample.Data.Length);
                var ptr = mediaBuffer.Lock(out _, out _);
                try
                {
                    Marshal.Copy(sample.Data, 0, ptr, sample.Data.Length);
                }
                finally
                {
                    mediaBuffer.Unlock();
                    mediaBuffer.CurrentLength = sample.Data.Length;
                }

                using var mfSample = MediaFactory.CreateSample();
                mfSample.AddBuffer(mediaBuffer);
                mfSample.SampleTime = adjustedTimestamp100ns;
                mfSample.SampleDuration = sample.Duration.Ticks;

                _sinkWriter.WriteSample(_audioStreamIndex, mfSample);
            }
            catch (Exception ex)
            {
                ErrorOccurred?.Invoke(this, ex);
            }
        }

        // ---------------------------------------------------------------
        // WGC / Direct3D 初始化
        // ---------------------------------------------------------------

        private void InitializeDirect3DDevice()
        {
            _d3dDevice = new Device(
                DriverType.Hardware,
                DeviceCreationFlags.BgraSupport | DeviceCreationFlags.VideoSupport);

            using var dxgiDevice = _d3dDevice.QueryInterface<SharpDX.DXGI.Device>();
            _winrtDevice = Direct3D11Interop.CreateDirect3DDeviceFromDXGIDevice(dxgiDevice.NativePointer);
        }

        private static GraphicsCaptureItem CreateCaptureItem(RecordingOptions options)
        {
            // 自訂範圍模式：WGC 沒有「只擷取矩形」的原生 API，實務作法是擷取整個螢幕，
            // 再於 WriteVideoSample 階段依 CustomRegion 做裁切（此處先擷取全螢幕紋理，
            // 裁切邏輯留待 CopyFrameToStagingTexture 依 options.CustomRegion 處理）。
            Screen targetScreen = options.TargetScreen ?? Screen.PrimaryScreen!;
            IntPtr hMonitor = GetHMonitorForScreen(targetScreen);

            return Direct3D11Interop.CreateItemForMonitor(hMonitor);
        }

        private static IntPtr GetHMonitorForScreen(Screen screen)
        {
            // System.Windows.Forms.Screen 沒有直接暴露 HMONITOR，
            // 以螢幕中心點呼叫 User32 MonitorFromPoint 取得。
            var center = new System.Drawing.Point(
                screen.Bounds.X + screen.Bounds.Width / 2,
                screen.Bounds.Y + screen.Bounds.Height / 2);

            return NativeMethods.MonitorFromPoint(center, NativeMethods.MONITOR_DEFAULTTONEAREST);
        }

        private static Size GetCaptureSize(RecordingOptions options)
        {
            if (options.CustomRegion.HasValue)
            {
                return options.CustomRegion.Value.Size;
            }

            var screen = options.TargetScreen ?? Screen.PrimaryScreen!;
            return screen.Bounds.Size;
        }

        private Texture2D CopyFrameToStagingTexture(Direct3D11CaptureFrame frame)
        {
            // TODO：由 frame.Surface（IDirect3DSurface）取得對應的 SharpDX.Direct3D11.Texture2D，
            // 若 options.CustomRegion 有值，需以 CopySubresourceRegion 只複製該矩形區域到 staging texture，
            // 而非整張畫面，藉此實現「自訂範圍錄製」。完整互通程式碼請參考 WGC 官方範例。
            throw new NotImplementedException(
                "CopyFrameToStagingTexture 需依專案採用的 Direct3D 互通方式（SharpDX / Vortice）補上實作。");
        }

        // ---------------------------------------------------------------
        // Media Foundation SinkWriter 初始化
        // ---------------------------------------------------------------

        private void InitializeSinkWriter(Size captureSize, RecordingOptions options)
        {
            MediaManager.Startup();

            using var attributes = new MediaAttributes();
            attributes.Set(SinkWriterAttributeKeys.ReadwriteEnableHardwareTransforms, 1);

            _sinkWriter = MediaFactory.CreateSinkWriterFromURL(_outputPath, null, attributes);

            // --- 視訊輸出型別（H.264） ---
            using var videoOutputType = new MediaType();
            videoOutputType.Set(MediaTypeAttributeKeys.MajorType, MediaTypeGuids.Video);
            videoOutputType.Set(MediaTypeAttributeKeys.Subtype, VideoFormatGuids.H264);
            videoOutputType.Set(MediaTypeAttributeKeys.AvgBitrate, options.VideoBitrate);
            videoOutputType.Set(MediaTypeAttributeKeys.InterlaceMode, (int)VideoInterlaceMode.Progressive);
            MediaFactory.SetAttributeSize(videoOutputType, MediaTypeAttributeKeys.FrameSize.Guid, captureSize.Width, captureSize.Height);
            MediaFactory.SetAttributeRatio(videoOutputType, MediaTypeAttributeKeys.FrameRate.Guid, options.FrameRate, 1);
            MediaFactory.SetAttributeRatio(videoOutputType, MediaTypeAttributeKeys.PixelAspectRatio.Guid, 1, 1);

            _sinkWriter.AddStream(videoOutputType, out _videoStreamIndex);

            // --- 視訊輸入型別（來自 WGC 的 BGRA32 未壓縮畫面） ---
            using var videoInputType = new MediaType();
            videoInputType.Set(MediaTypeAttributeKeys.MajorType, MediaTypeGuids.Video);
            videoInputType.Set(MediaTypeAttributeKeys.Subtype, VideoFormatGuids.Argb32);
            MediaFactory.SetAttributeSize(videoInputType, MediaTypeAttributeKeys.FrameSize.Guid, captureSize.Width, captureSize.Height);
            MediaFactory.SetAttributeRatio(videoInputType, MediaTypeAttributeKeys.FrameRate.Guid, options.FrameRate, 1);

            _sinkWriter.SetInputMediaType(_videoStreamIndex, videoInputType, null);

            // --- 音訊輸出/輸入型別（AAC，48kHz 立體聲，對應 AudioMixer 的混音輸出格式） ---
            if (options.CaptureSystemAudio || options.CaptureMicrophone)
            {
                using var audioOutputType = new MediaType();
                audioOutputType.Set(MediaTypeAttributeKeys.MajorType, MediaTypeGuids.Audio);
                audioOutputType.Set(MediaTypeAttributeKeys.Subtype, AudioFormatGuids.Aac);
                audioOutputType.Set(MediaTypeAttributeKeys.AudioSamplesPerSecond, AudioSampleRate);
                audioOutputType.Set(MediaTypeAttributeKeys.AudioNumChannels, AudioChannels);
                audioOutputType.Set(MediaTypeAttributeKeys.AudioAvgBytesPerSecond, 16_000);

                _sinkWriter.AddStream(audioOutputType, out _audioStreamIndex);

                using var audioInputType = new MediaType();
                audioInputType.Set(MediaTypeAttributeKeys.MajorType, MediaTypeGuids.Audio);
                audioInputType.Set(MediaTypeAttributeKeys.Subtype, AudioFormatGuids.Float);
                audioInputType.Set(MediaTypeAttributeKeys.AudioSamplesPerSecond, AudioSampleRate);
                audioInputType.Set(MediaTypeAttributeKeys.AudioNumChannels, AudioChannels);
                audioInputType.Set(MediaTypeAttributeKeys.AudioBitsPerSample, 32);

                _sinkWriter.SetInputMediaType(_audioStreamIndex, audioInputType, null);
            }
            else
            {
                _audioStreamIndex = -1;
            }

            _sinkWriter.BeginWriting();
        }

        // ---------------------------------------------------------------
        // 輔助
        // ---------------------------------------------------------------

        private void ResetPauseOffsetState()
        {
            _accumulatedPauseOffset = TimeSpan.Zero;
            _pauseStartedAtUtc = null;
            _firstRawFrameTimestamp100ns = null;
        }

        private static string BuildDefaultOutputPath()
        {
            string videosFolder = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.MyVideos));

            Directory.CreateDirectory(videosFolder);

            string fileName = $"ScreenRecorder_{DateTime.Now:yyyyMMdd_HHmmss}.mp4";
            return Path.Combine(videosFolder, fileName);
        }

        private void SetState(RecordingState newState)
        {
            lock (_stateLock)
            {
                _state = newState;
            }

            RaiseStateChanged();
        }

        private void RaiseStateChanged()
        {
            StateChanged?.Invoke(this, (State, _elapsedStopwatch.Elapsed));
        }

        private void CleanupCaptureResources()
        {
            _captureSession = null;
            _framePool = null;
            _captureItem = null;

            _winrtDevice = null;
            _d3dDevice?.Dispose();
            _d3dDevice = null;
        }

        public void Dispose()
        {
            _uiUpdateTimer.Stop();
            _sinkWriter?.Dispose();
            _audioMixer?.Dispose();
            CleanupCaptureResources();
        }
    }

    /// <summary>
    /// Win32 / WinRT 互通所需的低階宣告集中處。
    /// </summary>
    internal static class NativeMethods
    {
        public const uint MONITOR_DEFAULTTONEAREST = 2;

        [DllImport("user32.dll")]
        public static extern IntPtr MonitorFromPoint(System.Drawing.Point pt, uint dwFlags);
    }

    /// <summary>
    /// Windows.Graphics.Capture 相關的 COM 互通輔助方法：
    ///   - 從 HMONITOR 建立 GraphicsCaptureItem（IGraphicsCaptureItemInterop）
    ///   - 從 IDXGIDevice 建立 WinRT IDirect3DDevice（CreateDirect3D11DeviceFromDXGIDevice）
    /// 這兩個 API 都不在一般 WinRT 投影裡，需自行宣告 COM interface 呼叫。
    /// 對應官方 C# WGC 範例（microsoft/Windows-universal-samples「SimpleRecorder」/
    /// 「Direct3D11Helper.cs」）中的標準做法。
    /// </summary>
    internal static class Direct3D11Interop
    {
        [ComImport]
        [Guid("3628E81B-3CAC-4C60-B7F4-23CE0E0C3356")]
        [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        private interface IGraphicsCaptureItemInterop
        {
            IntPtr CreateForWindow(IntPtr window, ref Guid iid);
            IntPtr CreateForMonitor(IntPtr monitor, ref Guid iid);
        }

        [DllImport("d3d11.dll", EntryPoint = "CreateDirect3D11DeviceFromDXGIDevice", PreserveSig = false)]
        private static extern IntPtr CreateDirect3D11DeviceFromDXGIDeviceNative(IntPtr dxgiDevice);

        public static GraphicsCaptureItem CreateItemForMonitor(IntPtr hMonitor)
        {
            var factory = (IGraphicsCaptureItemInterop)WinRTActivation.GetActivationFactory(
                "Windows.Graphics.Capture.GraphicsCaptureItem");

            var iid = typeof(GraphicsCaptureItem).GUID;
            IntPtr itemPointer = factory.CreateForMonitor(hMonitor, ref iid);

            return GraphicsCaptureItem.FromAbi(itemPointer);
        }

        public static IDirect3DDevice CreateDirect3DDeviceFromDXGIDevice(IntPtr dxgiDevicePointer)
        {
            IntPtr winrtDevicePointer = CreateDirect3D11DeviceFromDXGIDeviceNative(dxgiDevicePointer);
            return MarshalInterface<IDirect3DDevice>.FromAbi(winrtDevicePointer);
        }
    }

    /// <summary>
    /// 依 WinRT class name 取得 Activation Factory 的極簡封裝（RoGetActivationFactory）。
    /// </summary>
    internal static class WinRTActivation
    {
        [DllImport("combase.dll", CharSet = CharSet.Unicode, PreserveSig = false)]
        private static extern void RoGetActivationFactory(
            IntPtr activatableClassId, ref Guid iid, out IntPtr factory);

        public static object GetActivationFactory(string runtimeClassName)
        {
            // 實作註記：實務上會透過 WindowsCreateString 建立 HSTRING 再呼叫 RoGetActivationFactory，
            // 詳細字串生命週期管理省略，建議改用 CsWinRT 產生的 GraphicsCaptureItem.As<...>()
            // 或社群套件（如 Windows.Graphics.Capture.Interop）取代本手動實作。
            throw new NotImplementedException(
                "WinRTActivation.GetActivationFactory 需補上 HSTRING 互通實作，" +
                "建議改用 CsWinRT 提供的高階 API。");
        }
    }
}

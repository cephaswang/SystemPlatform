using System;
using System.Threading;
using System.Windows;
using System.Windows.Threading;

namespace ScreenRecorderWin
{
    /// <summary>
    /// App.xaml 的程式碼後置檔（Interaction logic）。
    /// 負責：
    ///   1. 啟動時以具名 Mutex 檢查是否已有實例在執行（防止多開）。
    ///   2. 檢查通過後才建立主視窗、初始化系統匣圖示（TrayIconManager）。
    ///   3. 攔截未處理例外，避免錄影中的程式無預警閃退。
    /// </summary>
    public partial class App : Application
    {
        // 具名 Mutex：同一台機器上、同一個使用者 session 內唯一。
        // 命名建議使用 GUID 或足夠獨特的字串，避免與其他程式衝突。
        private const string MutexName = "ScreenRecorderWin_SingleInstance_Mutex_9F3B2E7E-4C2D-4B9C-9E7D-2E2F1B7B1A10";

        private Mutex? _singleInstanceMutex;

        // MainWindow / TrayIconManager 為本專案結構中規劃的其他檔案，
        // 此處先以欄位形式掛接，實際建構邏輯於各自檔案中實作。
        private TrayIconManager? _trayIconManager;

        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            // 攔截 UI 執行緒未處理例外，避免錄影過程中整個 App 無預警崩潰
            DispatcherUnhandledException += App_DispatcherUnhandledException;
            AppDomain.CurrentDomain.UnhandledException += CurrentDomain_UnhandledException;

            bool isNewInstance;
            _singleInstanceMutex = new Mutex(initiallyOwned: true, name: MutexName, createdNew: out isNewInstance);

            if (!isNewInstance)
            {
                // 已有實例在執行：提示使用者後直接結束，不建立第二個視窗/系統匣圖示。
                MessageBox.Show(
                    "ScreenRecorder 已在執行中，請至系統匣查看圖示。",
                    "ScreenRecorder",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);

                // 因為 ShutdownMode 為 OnExplicitShutdown，必須明確呼叫 Shutdown()
                Shutdown();
                return;
            }

            // --- 通過單一實例檢查，開始正式啟動流程 ---

            // 1. 建立並顯示主視窗
            var mainWindow = new MainWindow();
            MainWindow = mainWindow;
            mainWindow.Show();

            // 2. 初始化系統匣圖示（暫停/繼續/停止、查看輸出、開啟主視窗、結束 等選單）
            _trayIconManager = new TrayIconManager(mainWindow);
            _trayIconManager.Initialize();

            // 3. 將主視窗按鈕與系統匣選單這兩個操作入口，串接到同一組事件 handler。
            //    實際錄影邏輯（RecorderManager）尚未實作，此處先讓兩者狀態互相同步，
            //    確保 UI 一致；RecorderManager 完成後再接手處理 StartRequested 等事件
            //    並回呼 ApplyState / SetLastOutputPath。
            mainWindow.StartRequested += (_, _) => SyncState(RecordingState.Recording, TimeSpan.Zero);
            mainWindow.PauseRequested += (_, _) => SyncState(RecordingState.Paused, TimeSpan.Zero);
            mainWindow.ResumeRequested += (_, _) => SyncState(RecordingState.Recording, TimeSpan.Zero);
            mainWindow.StopRequested += (_, _) => SyncState(RecordingState.Idle, TimeSpan.Zero);

            _trayIconManager.StartRequested += (_, _) => mainWindow.ApplyState(RecordingState.Recording, TimeSpan.Zero);
            _trayIconManager.PauseRequested += (_, _) => mainWindow.ApplyState(RecordingState.Paused, TimeSpan.Zero);
            _trayIconManager.ResumeRequested += (_, _) => mainWindow.ApplyState(RecordingState.Recording, TimeSpan.Zero);
            _trayIconManager.StopRequested += (_, _) => mainWindow.ApplyState(RecordingState.Idle, TimeSpan.Zero);
            _trayIconManager.ExitRequested += (_, _) =>
            {
                mainWindow.PrepareForExit();
                Shutdown();
            };
        }

        /// <summary>
        /// 暫時的雙向狀態同步（RecorderManager 完成前的過渡實作）：
        /// 將主視窗按鈕觸發的狀態變化，同步套用到主視窗自身與系統匣圖示。
        /// </summary>
        private void SyncState(RecordingState state, TimeSpan elapsed)
        {
            (MainWindow as MainWindow)?.ApplyState(state, elapsed);
            _trayIconManager?.ApplyState(state, elapsed);
        }

        protected override void OnExit(ExitEventArgs e)
        {
            _trayIconManager?.Dispose();

            // 釋放 Mutex 所有權，讓其他程式實例判斷得到「這是新實例」
            _singleInstanceMutex?.ReleaseMutex();
            _singleInstanceMutex?.Dispose();

            base.OnExit(e);
        }

        private void App_DispatcherUnhandledException(object sender, DispatcherUnhandledExceptionEventArgs e)
        {
            MessageBox.Show(
                $"發生未預期的錯誤：{e.Exception.Message}",
                "ScreenRecorder - 錯誤",
                MessageBoxButton.OK,
                MessageBoxImage.Error);

            // 標記為已處理，避免程式直接崩潰（尤其是在錄影中途）
            e.Handled = true;
        }

        private void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            if (e.ExceptionObject is Exception ex)
            {
                MessageBox.Show(
                    $"發生嚴重錯誤，程式即將結束：{ex.Message}",
                    "ScreenRecorder - 嚴重錯誤",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
        }
    }
}

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Forms;
using Screen = System.Windows.Forms.Screen;

namespace ScreenRecorderWin
{
    /// <summary>
    /// 下拉選單用的螢幕項目包裝，附上易讀的顯示名稱（對應「螢幕編號提示」的順序）。
    /// </summary>
    public sealed class ScreenItem
    {
        public int Index { get; init; }
        public Screen Screen { get; init; } = null!;
        public string DisplayName => $"螢幕 {Index + 1}"
            + (Screen.Primary ? "（主要）" : string.Empty)
            + $" - {Screen.Bounds.Width}x{Screen.Bounds.Height}";
    }

    /// <summary>
    /// 主視窗：選螢幕/範圍、開始錄影、查看輸出。
    ///
    /// 本檔案只負責 UI 呈現與使用者互動，實際錄影邏輯（WGC 擷取、編碼、混音、
    /// 暫停位移演算法）交由 RecorderManager 處理；本類別對外用事件通知操作意圖，
    /// 與 TrayIconManager 的事件形狀刻意保持一致，方便 App.xaml.cs 用同一組
    /// handler 同時串接「主視窗按鈕」與「系統匣選單」兩個入口。
    /// </summary>
    public partial class MainWindow : Window
    {
        /// <summary>使用者按下「開始錄影」。</summary>
        public event EventHandler? StartRequested;

        /// <summary>使用者按下「暫停」。</summary>
        public event EventHandler? PauseRequested;

        /// <summary>使用者按下「繼續」。</summary>
        public event EventHandler? ResumeRequested;

        /// <summary>使用者按下「停止」。</summary>
        public event EventHandler? StopRequested;

        /// <summary>使用者變更了自訂錄製範圍（Rectangle 為螢幕座標，單位為實體像素）。</summary>
        public event EventHandler<Rectangle?>? CustomRegionChanged;

        private RecordingState _state = RecordingState.Idle;
        private string? _lastOutputPath;

        // 使用者真正要結束程式（透過系統匣「結束」）時才會設為 true，
        // 否則按下視窗右上角 X 只會隱藏到系統匣，不會真正關閉程式。
        private bool _isExiting;

        private Rectangle? _customRegion;

        public MainWindow()
        {
            InitializeComponent();
            LoadScreenList();
            ApplyState(RecordingState.Idle, TimeSpan.Zero);
        }

        /// <summary>目前是否勾選錄製系統音效。</summary>
        public bool IsSystemAudioEnabled => SystemAudioCheckBox.IsChecked == true;

        /// <summary>目前是否勾選錄製麥克風。</summary>
        public bool IsMicrophoneEnabled => MicrophoneCheckBox.IsChecked == true;

        /// <summary>目前選取的螢幕（全螢幕模式時使用）。</summary>
        public Screen? SelectedScreen => (ScreenComboBox.SelectedItem as ScreenItem)?.Screen;

        /// <summary>是否為自訂範圍模式。</summary>
        public bool IsCustomRegionMode => CustomRegionRadioButton.IsChecked == true;

        /// <summary>目前選取的自訂範圍（螢幕座標）。IsCustomRegionMode 為 false 時無意義。</summary>
        public Rectangle? CustomRegion => _customRegion;

        // ---------- 螢幕列舉 / 編號提示 ----------

        private void LoadScreenList()
        {
            var items = new List<ScreenItem>();
            var allScreens = Screen.AllScreens;

            for (int i = 0; i < allScreens.Length; i++)
            {
                items.Add(new ScreenItem { Index = i, Screen = allScreens[i] });
            }

            ScreenComboBox.ItemsSource = items;
            ScreenComboBox.SelectedIndex = items.FindIndex(s => s.Screen.Primary) is var idx && idx >= 0 ? idx : 0;

            // 單螢幕時仍保留下拉選單（僅一項），維持 UI 一致性，不特別隱藏。
        }

        private void ShowScreenNumbersButton_OnClick(object sender, RoutedEventArgs e)
        {
            // TODO：於各螢幕中央建立短暫顯示數字的 OverlayWindow（對應企劃書「螢幕編號提示」）。
            // 依專案結構，OverlayWindow.xaml 同時也負責錄影中範圍紅框，將於該檔案中一併實作，
            // 此處先保留呼叫入口：
            //
            //   foreach (var item in (List<ScreenItem>)ScreenComboBox.ItemsSource)
            //   {
            //       OverlayWindow.ShowScreenNumber(item.Screen, item.Index + 1);
            //   }
            MessageBox.Show(
                "螢幕編號提示視窗尚未實作（對應 OverlayWindow.xaml）。",
                "ScreenRecorder",
                MessageBoxButton.OK,
                MessageBoxImage.Information);
        }

        private void ScreenComboBox_OnSelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            // 目前僅用於全螢幕模式的來源螢幕選擇；自訂範圍模式下改由 RegionSelectorWindow 決定範圍，
            // 此處不需額外處理，保留 handler 供未來擴充（例如切換螢幕後重設自訂範圍）。
        }

        // ---------- 全螢幕 / 自訂範圍 ----------

        private void CaptureModeRadioButton_OnChecked(object sender, RoutedEventArgs e)
        {
            if (CustomRegionSummaryTextBlock == null)
            {
                // XAML 初始化過程中 Checked 事件可能早於其他控制項就緒，安全跳出。
                return;
            }

            bool isCustom = IsCustomRegionMode;
            CustomRegionSummaryTextBlock.Visibility = isCustom ? Visibility.Visible : Visibility.Collapsed;
            ScreenComboBox.IsEnabled = !isCustom;

            if (isCustom && _customRegion == null)
            {
                OpenRegionSelector();
            }
        }

        private void OpenRegionSelector()
        {
            // TODO：對應企劃書「自訂範圍以拖曳矩形決定擷取區域，按 Esc 取消」。
            // 實際邏輯將於 RegionSelectorWindow.xaml 完成後串接，範例：
            //
            //   var selector = new RegionSelectorWindow();
            //   if (selector.ShowDialog() == true)
            //   {
            //       _customRegion = selector.SelectedRegion;
            //       CustomRegionSummaryTextBlock.Text =
            //           $"已選取範圍：{_customRegion.Value.Width}x{_customRegion.Value.Height}" +
            //           $" @ ({_customRegion.Value.X}, {_customRegion.Value.Y})";
            //   }
            //   else
            //   {
            //       // 使用者按 Esc 取消，退回全螢幕模式
            //       FullScreenRadioButton.IsChecked = true;
            //   }
            //   CustomRegionChanged?.Invoke(this, _customRegion);

            MessageBox.Show(
                "自訂範圍選取視窗尚未實作（對應 RegionSelectorWindow.xaml）。將暫時退回全螢幕模式。",
                "ScreenRecorder",
                MessageBoxButton.OK,
                MessageBoxImage.Information);

            FullScreenRadioButton.IsChecked = true;
        }

        // ---------- 開始 / 暫停 / 繼續 / 停止 ----------

        private void StartButton_OnClick(object sender, RoutedEventArgs e)
        {
            if (IsCustomRegionMode && _customRegion == null)
            {
                MessageBox.Show(
                    "請先選取自訂範圍，或切換為全螢幕模式。",
                    "ScreenRecorder",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);
                return;
            }

            StartRequested?.Invoke(this, EventArgs.Empty);
        }

        private void PauseResumeButton_OnClick(object sender, RoutedEventArgs e)
        {
            if (_state == RecordingState.Recording)
            {
                PauseRequested?.Invoke(this, EventArgs.Empty);
            }
            else if (_state == RecordingState.Paused)
            {
                ResumeRequested?.Invoke(this, EventArgs.Empty);
            }
        }

        private void StopButton_OnClick(object sender, RoutedEventArgs e)
        {
            StopRequested?.Invoke(this, EventArgs.Empty);
        }

        // ---------- 查看上次輸出 ----------

        private void OpenLastOutputButton_OnClick(object sender, RoutedEventArgs e)
        {
            OpenLastOutputInExplorer();
        }

        private void OpenLastOutputInExplorer()
        {
            if (string.IsNullOrEmpty(_lastOutputPath) || !File.Exists(_lastOutputPath))
            {
                MessageBox.Show(
                    "尚未有可開啟的輸出檔案。",
                    "ScreenRecorder",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);
                return;
            }

            Process.Start(new ProcessStartInfo
            {
                FileName = "explorer.exe",
                Arguments = $"/select,\"{_lastOutputPath}\"",
                UseShellExecute = true
            });
        }

        /// <summary>
        /// 由 RecorderManager 於錄影完成後呼叫，登記輸出檔案路徑並啟用「查看上次輸出」按鈕。
        /// 依企劃書規劃，完成錄影當下也會自動開啟檔案總管並選取檔案，此處僅負責登記狀態，
        /// 自動開啟的動作建議由呼叫端（RecorderManager）在拿到路徑後一併觸發。
        /// </summary>
        public void SetLastOutputPath(string path)
        {
            _lastOutputPath = path;
            OpenLastOutputButton.IsEnabled = true;
        }

        // ---------- 狀態同步 ----------

        /// <summary>
        /// 由 RecorderManager / App 呼叫，同步更新主視窗上的狀態文字、已錄製時長與按鈕可用狀態。
        /// 與 TrayIconManager.ApplyState 對應同一組資料，確保兩個 UI 入口顯示一致。
        /// </summary>
        public void ApplyState(RecordingState state, TimeSpan elapsed)
        {
            _state = state;

            StatusTextBlock.Text = state switch
            {
                RecordingState.Idle => "狀態：尚未開始",
                RecordingState.Recording => "狀態：錄影中",
                RecordingState.Paused => "狀態：已暫停",
                _ => "狀態：未知"
            };

            DurationTextBlock.Text = $"已錄製時長：{elapsed:hh\\:mm\\:ss}";

            StartButton.IsEnabled = state == RecordingState.Idle;
            PauseResumeButton.IsEnabled = state != RecordingState.Idle;
            PauseResumeButton.Content = state == RecordingState.Paused ? "繼續" : "暫停";
            StopButton.IsEnabled = state != RecordingState.Idle;

            // 錄影中鎖定來源設定，避免中途切換螢幕/範圍造成不一致
            bool locked = state != RecordingState.Idle;
            ScreenComboBox.IsEnabled = !locked && !IsCustomRegionMode;
            FullScreenRadioButton.IsEnabled = !locked;
            CustomRegionRadioButton.IsEnabled = !locked;
            SystemAudioCheckBox.IsEnabled = !locked;
            MicrophoneCheckBox.IsEnabled = !locked;
        }

        // ---------- 關閉行為：隱藏至系統匣而非結束程式 ----------

        /// <summary>
        /// 由 App.xaml.cs 於使用者透過系統匣「結束」選單真正要離開程式時呼叫，
        /// 設定後下一次 Closing 事件才會真正允許關閉視窗／結束應用程式。
        /// </summary>
        public void PrepareForExit()
        {
            _isExiting = true;
        }

        private void MainWindow_OnClosing(object? sender, System.ComponentModel.CancelEventArgs e)
        {
            if (_isExiting)
            {
                return; // 允許正常關閉
            }

            // 對應企劃書「系統匣操作：開始錄影後主視窗可選擇隱藏至系統匣」，
            // 這裡簡化為：任何時候按下 X 都只隱藏視窗，真正結束一律透過系統匣選單。
            e.Cancel = true;
            Hide();
        }
    }
}

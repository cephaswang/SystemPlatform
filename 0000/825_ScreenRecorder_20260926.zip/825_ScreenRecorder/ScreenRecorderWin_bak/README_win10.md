# ScreenRecorderWin

支援「暫停 / 繼續」的 Windows 10 螢幕錄影工具。錄製時即時編碼，停止後直接得到 `.mp4`（H.264 視訊 + AAC 音訊），不需額外轉檔。功能對齊 macOS 版 Phase 1（MVP）：全螢幕 / 自訂範圍錄製、系統音效＋麥克風混音、全域快捷鍵、系統匣常駐操作。

詳細規劃請見 [`ScreenRecorder Windows 10 版企劃書.md`](./ScreenRecorder%20Windows%2010%20版企劃書.md)。

## 功能特色

- 全螢幕 / 自訂範圍錄製（拖曳矩形選取，`Esc` 取消）
- 多螢幕列表與螢幕編號提示浮層
- 高 DPI（Per-Monitor V2）縮放校正，避免擷取模糊或裁切錯位
- 錄製時可暫停 / 繼續，輸出時間軸自動扣除暫停時長，維持連續
- 系統音效（WASAPI Loopback）＋麥克風混音，輸出單一 AAC 音軌
- 系統匣常駐操作（暫停/繼續/停止、查看輸出、開啟主視窗）
- 全域快捷鍵（`Ctrl+Alt+Win+R/P/C/S`）

## 系統需求

- Windows 10 version 1903（19H1）以上（螢幕擷取需要 `Windows.Graphics.Capture` API 支援）
- .NET 8（或 .NET 6 LTS）+ WPF
- Visual Studio 2022

> 若需支援 1903 以前的 Windows 10，畫面擷取需退回 GDI+ / BitBlt 逐格截圖方案，效能與相容性較差；本專案預設以 1903+ 為基準。

## 建置步驟

1. Visual Studio 2022 建立 **.NET 8 WPF App**。
2. 加入 NuGet 套件：
   - `Microsoft.Windows.SDK.Contracts`（`Windows.Graphics.Capture`）
   - `NAudio`（WASAPI 系統音效／麥克風擷取與重取樣，見 `AudioMixer.cs`）
   - Media Foundation 互操作套件（`SharpDX.MediaFoundation` 或手動 P/Invoke，見 `RecorderManager.cs`）
3. 依下方專案結構建立各檔案，實作螢幕擷取 → Media Foundation 編碼 → 混音的資料流。
4. 於「應用程式資訊清單」（`app.manifest`）設定 DPI 感知（Per-Monitor V2），避免多螢幕縮放錯位。
5. 測試項目：
   - 多螢幕切換與編號提示是否正確對應
   - 暫停 / 續錄時間軸是否連續（無跳動或負時間戳）
   - 系統音效與麥克風混音是否有回音或削波（建議戴耳機測試）
   - 高 DPI（125% / 150% 等）縮放下的擷取解析度是否正確

## 專案結構

```
ScreenRecorderWin/
├── App.xaml / App.xaml.cs        # 進入點，Mutex 防多開、系統匣初始化
├── MainWindow.xaml               # 主視窗：選螢幕/範圍、開始錄影、查看輸出
├── TrayIconManager.cs            # 系統匣圖示與右鍵選單
├── RecorderManager.cs            # 核心錄影邏輯（WGC 擷取、暫停位移演算法、Media Foundation 編碼）
├── RegionSelectorWindow.xaml     # 自訂範圍拖曳選取遮罩視窗
├── OverlayWindow.xaml            # 螢幕編號提示、錄影中範圍紅框
├── HotKeyManager.cs              # 全域快捷鍵（RegisterHotKey + 隱藏訊息視窗）
├── AudioMixer.cs                 # WASAPI 系統音效＋麥克風混音
└── README.md                     # 本檔案
```

各檔案與企劃書「技術架構對照表」的對應關係，請參考各檔案內的 XML 文件註解（`<summary>`）。

## 全域快捷鍵

| 動作 | 快捷鍵 |
| --- | --- |
| 開始錄影（固定全螢幕） | `Ctrl+Alt+Win+R` |
| 暫停 | `Ctrl+Alt+Win+P` |
| 繼續 | `Ctrl+Alt+Win+C` |
| 停止並輸出 MP4 | `Ctrl+Alt+Win+S` |

> 快捷鍵觸發的「開始錄影」固定為全螢幕；自訂範圍仍需從主視窗以滑鼠操作。若組合鍵已被其他程式佔用，`HotKeyManager` 會透過 `RegistrationFailed` 事件通知，不會中斷程式啟動。

## 輸出

- 檔案位置：`%USERPROFILE%\Videos\ScreenRecorder_yyyyMMdd_HHmmss.mp4`
- 完成後自動開啟檔案總管並選取檔案

## 已知限制（Phase 1 範圍）

- 目前僅規劃整台顯示器全螢幕擷取為主要路徑，單一視窗擷取列為 Phase 3 項目。
- 全域快捷鍵僅支援固定組合鍵，使用者自訂快捷鍵設定畫面列為 Phase 4 項目。
- 高 DPI / 多螢幕混合縮放比例（125%/150% 等）下的擷取解析度校正為 Windows 平台特有風險項。
- `Windows.Graphics.Capture` 在部分需要「安全內容保護」的視窗（如 DRM 播放器）擷取會顯示黑畫面，屬系統限制。
- 音訊混音僅做簡單相加＋削峰，未做自動增益 / 動態範圍壓縮；兩路音量都偏大時可能出現削波失真。
- 目前固定使用系統「預設」的音訊輸出／輸入裝置，錄影中途切換預設裝置不會自動跟隨。

## 授權

（依專案實際情況填寫授權條款，例如 MIT License。）

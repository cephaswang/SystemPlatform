using System;
using System.Runtime.InteropServices;
using System.Windows.Interop;
using Keys = System.Windows.Forms.Keys;

namespace ScreenRecorderWin
{
    /// <summary>
    /// 可由全域快捷鍵觸發的動作。對應企劃書 4. 功能規劃「全域快捷鍵」表格中的四個項目。
    /// </summary>
    public enum HotKeyAction
    {
        /// <summary>開始錄影（固定為全螢幕；自訂範圍仍需從主視窗以滑鼠操作，見企劃書已知限制）。</summary>
        StartRecording,
        Pause,
        Resume,

        /// <summary>停止並輸出 MP4。</summary>
        StopAndExport
    }

    /// <summary>
    /// 全域快捷鍵管理器：
    ///   對應企劃書 3. 技術架構對照表「全域快捷鍵」一列（Win32 RegisterHotKey API，
    ///   需搭配隱藏訊息視窗接收 WM_HOTKEY），以及 4. 功能規劃「全域快捷鍵」表格的四個預設組合鍵：
    ///
    ///     開始錄影           Ctrl+Alt+Win+R
    ///     暫停               Ctrl+Alt+Win+P
    ///     繼續               Ctrl+Alt+Win+C
    ///     停止並輸出 MP4      Ctrl+Alt+Win+S
    ///
    /// 實作方式：
    ///   RegisterHotKey 需要一個視窗 handle 才能接收 WM_HOTKEY 訊息，因此本類別建立一個
    ///   「訊息專用視窗」（HWND_MESSAGE，沒有 UI、不會顯示在畫面或工作列上），
    ///   透過 HwndSource.AddHook 攔截 WM_HOTKEY，轉換成 <see cref="HotKeyPressed"/> 事件，
    ///   交由 App / MainWindow 呼叫 RecorderManager 對應的方法（Start / Pause / Resume / Stop）。
    ///
    /// 已知限制（比照企劃書第 6 節）：
    ///   - 目前僅支援固定組合鍵；使用者自訂快捷鍵設定畫面列為 Phase 4 項目，本類別暫不提供
    ///     動態修改按鍵的 API（DefaultHotKeys 為唯讀設定表）。
    ///   - 快捷鍵觸發的「開始錄影」固定為全螢幕；若要自訂範圍錄製，
    ///     使用者仍須從主視窗以滑鼠操作（RegionSelectorWindow），快捷鍵無法指定範圍。
    ///   - 若組合鍵已被其他應用程式（或系統）註冊，RegisterHotKey 會失敗，
    ///     透過 <see cref="RegistrationFailed"/> 事件通知呼叫端，建議顯示提示但不中斷程式啟動。
    /// </summary>
    public sealed class HotKeyManager : IDisposable
    {
        private const int WM_HOTKEY = 0x0312;

        // 訊息專用視窗的固定 parent handle，此類視窗不會出現在畫面或工作列上，
        // 純粹用來接收 Windows 訊息（RegisterHotKey 要求的 hWnd 必須有效）。
        private static readonly IntPtr HWND_MESSAGE = new IntPtr(-3);

        [Flags]
        private enum HotKeyModifiers : uint
        {
            Alt = 0x0001,
            Control = 0x0002,
            Shift = 0x0004,
            Win = 0x0008,

            /// <summary>Windows 7 以上支援：避免使用者長按時系統重複觸發多次 WM_HOTKEY。</summary>
            NoRepeat = 0x4000
        }

        private readonly struct HotKeyDefinition
        {
            public HotKeyDefinition(HotKeyAction action, int id, HotKeyModifiers modifiers, Keys key)
            {
                Action = action;
                Id = id;
                Modifiers = modifiers;
                Key = key;
            }

            public HotKeyAction Action { get; }
            public int Id { get; }
            public HotKeyModifiers Modifiers { get; }
            public Keys Key { get; }
        }

        // 預設快捷鍵設定表：對應企劃書表格，選用 Ctrl+Alt+Win 三鍵組合以降低與其他軟體衝突的機率。
        private static readonly HotKeyDefinition[] DefaultHotKeys =
        {
            new(HotKeyAction.StartRecording, id: 1,
                HotKeyModifiers.Control | HotKeyModifiers.Alt | HotKeyModifiers.Win | HotKeyModifiers.NoRepeat, Keys.R),

            new(HotKeyAction.Pause, id: 2,
                HotKeyModifiers.Control | HotKeyModifiers.Alt | HotKeyModifiers.Win | HotKeyModifiers.NoRepeat, Keys.P),

            new(HotKeyAction.Resume, id: 3,
                HotKeyModifiers.Control | HotKeyModifiers.Alt | HotKeyModifiers.Win | HotKeyModifiers.NoRepeat, Keys.C),

            new(HotKeyAction.StopAndExport, id: 4,
                HotKeyModifiers.Control | HotKeyModifiers.Alt | HotKeyModifiers.Win | HotKeyModifiers.NoRepeat, Keys.S),
        };

        [DllImport("user32.dll", SetLastError = true)]
        private static extern bool RegisterHotKey(IntPtr hWnd, int id, uint fsModifiers, uint vk);

        [DllImport("user32.dll", SetLastError = true)]
        private static extern bool UnregisterHotKey(IntPtr hWnd, int id);

        private HwndSource? _messageWindowSource;
        private bool _hooksAttached;

        /// <summary>使用者按下已註冊的全域快捷鍵時觸發。</summary>
        public event EventHandler<HotKeyAction>? HotKeyPressed;

        /// <summary>某個快捷鍵註冊失敗（例如組合鍵已被其他程式佔用）時觸發。</summary>
        public event EventHandler<HotKeyRegistrationFailedEventArgs>? RegistrationFailed;

        /// <summary>目前是否已完成初始化並嘗試註冊快捷鍵。</summary>
        public bool IsInitialized => _messageWindowSource != null;

        /// <summary>
        /// 建立隱藏的訊息專用視窗並註冊企劃書表格中的四個預設快捷鍵。
        /// 應在 App.OnStartup（MainWindow 建立完成後即可）呼叫一次；重複呼叫會被忽略。
        /// </summary>
        public void Initialize()
        {
            if (IsInitialized)
            {
                return;
            }

            var parameters = new HwndSourceParameters("ScreenRecorderWin_HotKeyMessageWindow")
            {
                WindowStyle = 0,
                ExtendedWindowStyle = 0,
                PositionX = 0,
                PositionY = 0,
                Width = 0,
                Height = 0,
                ParentWindow = HWND_MESSAGE,
                UsesPerPixelOpacity = false
            };

            _messageWindowSource = new HwndSource(parameters);
            _messageWindowSource.AddHook(WndProc);
            _hooksAttached = true;

            RegisterAllHotKeys();
        }

        private void RegisterAllHotKeys()
        {
            var hwnd = _messageWindowSource!.Handle;

            foreach (var hotkey in DefaultHotKeys)
            {
                bool success = RegisterHotKey(hwnd, hotkey.Id, (uint)hotkey.Modifiers, (uint)hotkey.Key);
                if (!success)
                {
                    int errorCode = Marshal.GetLastWin32Error();
                    RegistrationFailed?.Invoke(this, new HotKeyRegistrationFailedEventArgs(hotkey.Action, errorCode));
                }
            }
        }

        private void UnregisterAllHotKeys()
        {
            if (_messageWindowSource == null)
            {
                return;
            }

            var hwnd = _messageWindowSource.Handle;
            foreach (var hotkey in DefaultHotKeys)
            {
                UnregisterHotKey(hwnd, hotkey.Id);
            }
        }

        /// <summary>
        /// 隱藏訊息視窗的訊息處理迴圈：攔截 WM_HOTKEY，依 wParam（註冊時的 id）
        /// 對應回 <see cref="HotKeyAction"/> 並觸發 <see cref="HotKeyPressed"/>。
        /// </summary>
        private IntPtr WndProc(IntPtr hwnd, int msg, IntPtr wParam, IntPtr lParam, ref bool handled)
        {
            if (msg != WM_HOTKEY)
            {
                return IntPtr.Zero;
            }

            int id = wParam.ToInt32();

            foreach (var hotkey in DefaultHotKeys)
            {
                if (hotkey.Id == id)
                {
                    HotKeyPressed?.Invoke(this, hotkey.Action);
                    handled = true;
                    break;
                }
            }

            return IntPtr.Zero;
        }

        public void Dispose()
        {
            UnregisterAllHotKeys();

            if (_hooksAttached)
            {
                _messageWindowSource?.RemoveHook(WndProc);
                _hooksAttached = false;
            }

            _messageWindowSource?.Dispose();
            _messageWindowSource = null;
        }
    }

    /// <summary>單一快捷鍵註冊失敗時的事件資料（例如組合鍵已被其他應用程式佔用）。</summary>
    public sealed class HotKeyRegistrationFailedEventArgs : EventArgs
    {
        public HotKeyRegistrationFailedEventArgs(HotKeyAction action, int win32ErrorCode)
        {
            Action = action;
            Win32ErrorCode = win32ErrorCode;
        }

        public HotKeyAction Action { get; }

        /// <summary>對應 Marshal.GetLastWin32Error() 的錯誤碼，可用於記錄或除錯。</summary>
        public int Win32ErrorCode { get; }
    }
}

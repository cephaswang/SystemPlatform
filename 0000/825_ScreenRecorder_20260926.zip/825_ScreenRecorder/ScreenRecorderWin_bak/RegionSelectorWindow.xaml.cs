using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using DrawingRectangle = System.Drawing.Rectangle;

namespace ScreenRecorderWin
{
    /// <summary>
    /// 自訂範圍拖曳選取遮罩視窗：
    ///   - 對應企劃書 3.「自訂範圍錄製」：以 AllowsTransparency 的透明無邊框視窗覆蓋整個虛擬螢幕，
    ///     讓使用者拖曳出一個矩形，做為 RecorderManager 的 RecordingOptions.CustomRegion 來源。
    ///   - 按 Esc 可隨時取消，對應企劃書 4.「全螢幕 / 自訂範圍切換」一節的行為。
    ///
    /// 使用方式（於 MainWindow 呼叫）：
    ///   if (RegionSelectorWindow.TrySelectRegion(out DrawingRectangle region))
    ///   {
    ///       var options = new RecordingOptions { CustomRegion = region, ... };
    ///       await _recorderManager.StartAsync(options);
    ///   }
    ///
    /// 座標系統說明：
    ///   WPF 視窗內部滑鼠座標為「裝置無關單位」（96 DPI 基準），
    ///   但 RecorderManager／WGC 擷取畫面需要的是「實體像素」座標，
    ///   因此選取完成後會透過 <see cref="ConvertToPhysicalPixels"/> 換算，
    ///   換算依據為目前視窗所在螢幕的 DPI 縮放比例（<see cref="VisualTreeHelper.GetDpi"/>）。
    ///
    /// 已知限制（比照企劃書第 6 節「已知限制」）：
    ///   - 多螢幕且各螢幕 DPI 縮放比例不同（Mixed DPI，例如一台 100% 一台 150%）時，
    ///     本視窗僅以「拖曳當下視窗回報的單一 DPI」做整體換算；若選取範圍跨越
    ///     不同 DPI 的螢幕邊界，換算結果可能有數像素誤差。此為 Windows 平台特有風險項，
    ///     Phase 1 不處理跨 DPI 邊界的精細校正，僅建議使用者避免拖曳跨越不同縮放比例的螢幕。
    ///   - App 需在 app.manifest 宣告 Per-Monitor V2 DPI 感知（企劃書 7. 建置步驟第 4 點），
    ///     否則 WPF 會以系統整體縮放做非原生換算，本視窗的尺寸與定位將不準確。
    /// </summary>
    public partial class RegionSelectorWindow : Window
    {
        private const double MinSelectionSizeDip = 4.0;

        private Point? _startPoint;
        private bool _isSelecting;

        /// <summary>選取結果（螢幕實體像素座標）。使用者按 Esc 取消或未完成有效拖曳時為 null。</summary>
        public DrawingRectangle? SelectedRegion { get; private set; }

        public RegionSelectorWindow()
        {
            InitializeComponent();

            // 覆蓋整個虛擬螢幕（所有螢幕組成的邏輯範圍），而非僅主螢幕，
            // 讓使用者可以在任一台已連接的螢幕上拖曳選取。
            Left = SystemParameters.VirtualScreenLeft;
            Top = SystemParameters.VirtualScreenTop;
            Width = SystemParameters.VirtualScreenWidth;
            Height = SystemParameters.VirtualScreenHeight;
        }

        /// <summary>
        /// 以 Modal 方式顯示選取畫面，並回傳是否成功選取。
        /// </summary>
        /// <param name="region">成功時為使用者選取的範圍（螢幕實體像素座標）。</param>
        /// <returns>使用者拖曳出有效矩形並放開滑鼠則為 true；按 Esc 取消或選取範圍過小則為 false。</returns>
        public static bool TrySelectRegion(out DrawingRectangle region)
        {
            var window = new RegionSelectorWindow();
            window.ShowDialog();

            if (window.SelectedRegion.HasValue)
            {
                region = window.SelectedRegion.Value;
                return true;
            }

            region = DrawingRectangle.Empty;
            return false;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            // 確保視窗一開啟就能接收鍵盤事件（Esc 取消），
            // 部分情況下透明無邊框視窗預設不會自動取得鍵盤焦點。
            Focus();
        }

        private void Window_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            _startPoint = e.GetPosition(this);
            _isSelecting = true;

            HintText.Visibility = Visibility.Collapsed;
            SelectionRectangle.Visibility = Visibility.Visible;
            SizeLabel.Visibility = Visibility.Visible;

            UpdateSelectionVisual(_startPoint.Value, _startPoint.Value);

            // 擷取滑鼠，避免拖曳過程中游標移出視窗範圍（理論上視窗已覆蓋整個虛擬螢幕，
            // 但仍以 CaptureMouse 確保拖曳期間不中斷）。
            CaptureMouse();
        }

        private void Window_MouseMove(object sender, MouseEventArgs e)
        {
            if (!_isSelecting || _startPoint is null)
            {
                return;
            }

            UpdateSelectionVisual(_startPoint.Value, e.GetPosition(this));
        }

        private void Window_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (!_isSelecting || _startPoint is null)
            {
                return;
            }

            _isSelecting = false;
            ReleaseMouseCapture();

            var endPoint = e.GetPosition(this);
            var selectionDip = BuildNormalizedRect(_startPoint.Value, endPoint);

            // 過濾掉「幾乎沒有拖曳」的誤觸（例如單純點擊一下），避免產生 0 或極小尺寸的錄製範圍。
            if (selectionDip.Width < MinSelectionSizeDip || selectionDip.Height < MinSelectionSizeDip)
            {
                SelectedRegion = null;
                Close();
                return;
            }

            SelectedRegion = ConvertToPhysicalPixels(selectionDip);
            Close();
        }

        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Escape)
            {
                _isSelecting = false;
                ReleaseMouseCapture();
                SelectedRegion = null;
                Close();
            }
        }

        /// <summary>依目前拖曳的起訖點，更新選取矩形與尺寸標籤的顯示。</summary>
        private void UpdateSelectionVisual(Point start, Point current)
        {
            var rect = BuildNormalizedRect(start, current);

            Canvas.SetLeft(SelectionRectangle, rect.X);
            Canvas.SetTop(SelectionRectangle, rect.Y);
            SelectionRectangle.Width = rect.Width;
            SelectionRectangle.Height = rect.Height;

            // 即時顯示換算後的「實體像素」尺寸，讓使用者確認實際錄製解析度
            // （對應企劃書「輸出解析度依螢幕 DPI 縮放比例自動換算」一節）。
            var physicalSize = ConvertToPhysicalPixels(rect);
            SizeLabel.Text = $"{physicalSize.Width} x {physicalSize.Height}";

            // 尺寸標籤預設顯示在選取矩形上方；若矩形太靠近畫面頂端則改顯示於矩形內部上緣，避免超出視窗範圍。
            double labelTop = rect.Y - 24;
            Canvas.SetLeft(SizeLabel, rect.X);
            Canvas.SetTop(SizeLabel, labelTop >= 0 ? labelTop : rect.Y + 4);
        }

        /// <summary>將任意兩個角點正規化為左上角 + 寬高的矩形（裝置無關單位）。</summary>
        private static Rect BuildNormalizedRect(Point start, Point end)
        {
            double x = Math.Min(start.X, end.X);
            double y = Math.Min(start.Y, end.Y);
            double width = Math.Abs(end.X - start.X);
            double height = Math.Abs(end.Y - start.Y);
            return new Rect(x, y, width, height);
        }

        /// <summary>
        /// 將視窗內的裝置無關單位矩形，換算為「螢幕座標系」下的實體像素矩形，
        /// 供 RecorderManager／WGC 擷取時使用（見類別註解「已知限制」）。
        /// </summary>
        private DrawingRectangle ConvertToPhysicalPixels(Rect dipRectInWindow)
        {
            var dpi = VisualTreeHelper.GetDpi(this);

            // 虛擬螢幕左上角座標可能為負值（例如主螢幕左側還有一台螢幕），
            // 需先換算成實體像素後，再加上矩形在視窗內的偏移量，
            // 才能得到正確的「螢幕座標系」實體像素矩形。
            double screenLeftPx = SystemParameters.VirtualScreenLeft * dpi.DpiScaleX;
            double screenTopPx = SystemParameters.VirtualScreenTop * dpi.DpiScaleY;

            int x = (int)Math.Round(screenLeftPx + dipRectInWindow.X * dpi.DpiScaleX);
            int y = (int)Math.Round(screenTopPx + dipRectInWindow.Y * dpi.DpiScaleY);
            int width = (int)Math.Round(dipRectInWindow.Width * dpi.DpiScaleX);
            int height = (int)Math.Round(dipRectInWindow.Height * dpi.DpiScaleY);

            return new DrawingRectangle(x, y, width, height);
        }
    }
}

using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Windows;
using System.Windows.Forms;
using Application = System.Windows.Application;
using MessageBox = System.Windows.MessageBox;

namespace ScreenRecorderWin
{
    /// <summary>
    /// 錄影狀態，供系統匣圖示決定顯示內容與選單啟用/停用狀態。
    /// 實際錄影邏輯由 RecorderManager 負責，本類別只負責「顯示」與「使用者操作入口」。
    /// </summary>
    public enum RecordingState
    {
        Idle,       // 尚未開始錄影
        Recording,  // 錄影中
        Paused      // 已暫停
    }

    /// <summary>
    /// 系統匣圖示管理器：
    ///   - 使用 System.Windows.Forms.NotifyIcon 建立系統匣圖示（WPF 本身無原生 NotifyIcon）
    ///   - 右鍵選單：顯示狀態 / 已錄製時長、暫停/繼續（同一項目依狀態切換文字）、停止、
    ///     查看上次輸出、開啟主視窗、結束
    ///   - 對外以事件（StartRequested / PauseRequested / ...）通知 App / RecorderManager，
    ///     自身不直接處理錄影邏輯，維持單一職責。
    /// </summary>
    public sealed class TrayIconManager : IDisposable
    {
        private readonly Window _mainWindow;
        private NotifyIcon? _notifyIcon;

        private ToolStripMenuItem? _statusMenuItem;      // 顯示目前狀態（唯讀，不可點擊）
        private ToolStripMenuItem? _durationMenuItem;     // 顯示已錄製時長（唯讀，不可點擊）
        private ToolStripMenuItem? _startMenuItem;        // 開始錄影
        private ToolStripMenuItem? _pauseResumeMenuItem;  // 暫停 / 繼續（同一項目切換文字）
        private ToolStripMenuItem? _stopMenuItem;         // 停止並輸出 MP4
        private ToolStripMenuItem? _openLastOutputMenuItem;
        private ToolStripMenuItem? _openMainWindowMenuItem;
        private ToolStripMenuItem? _exitMenuItem;

        private RecordingState _state = RecordingState.Idle;
        private string? _lastOutputPath;

        /// <summary>使用者於系統匣選單點選「開始錄影」。</summary>
        public event EventHandler? StartRequested;

        /// <summary>使用者於系統匣選單點選「暫停」。</summary>
        public event EventHandler? PauseRequested;

        /// <summary>使用者於系統匣選單點選「繼續」。</summary>
        public event EventHandler? ResumeRequested;

        /// <summary>使用者於系統匣選單點選「停止並輸出 MP4」。</summary>
        public event EventHandler? StopRequested;

        /// <summary>使用者要求結束整個應用程式。</summary>
        public event EventHandler? ExitRequested;

        public TrayIconManager(Window mainWindow)
        {
            _mainWindow = mainWindow ?? throw new ArgumentNullException(nameof(mainWindow));
        }

        /// <summary>
        /// 建立系統匣圖示與右鍵選單。應在 App.OnStartup 中，MainWindow 建立完成後呼叫一次。
        /// </summary>
        public void Initialize()
        {
            var contextMenu = BuildContextMenu();

            _notifyIcon = new NotifyIcon
            {
                Icon = LoadTrayIcon(),
                Text = TrimTooltip("ScreenRecorder - 尚未開始錄影"),
                Visible = true,
                ContextMenuStrip = contextMenu
            };

            // 雙擊圖示 = 開啟/還原主視窗（比照多數系統匣常駐程式的慣例操作）
            _notifyIcon.DoubleClick += (_, _) => ShowMainWindow();

            ApplyState(RecordingState.Idle, TimeSpan.Zero);
        }

        private ContextMenuStrip BuildContextMenu()
        {
            var menu = new ContextMenuStrip();

            _statusMenuItem = new ToolStripMenuItem("狀態：尚未開始") { Enabled = false };
            _durationMenuItem = new ToolStripMenuItem("已錄製時長：00:00:00") { Enabled = false };

            menu.Items.Add(_statusMenuItem);
            menu.Items.Add(_durationMenuItem);
            menu.Items.Add(new ToolStripSeparator());

            _startMenuItem = new ToolStripMenuItem("開始錄影", null, (_, _) => StartRequested?.Invoke(this, EventArgs.Empty));
            menu.Items.Add(_startMenuItem);

            _pauseResumeMenuItem = new ToolStripMenuItem("暫停", null, (_, _) => OnPauseResumeClicked());
            menu.Items.Add(_pauseResumeMenuItem);

            _stopMenuItem = new ToolStripMenuItem("停止並輸出 MP4", null, (_, _) => StopRequested?.Invoke(this, EventArgs.Empty));
            menu.Items.Add(_stopMenuItem);

            menu.Items.Add(new ToolStripSeparator());

            _openLastOutputMenuItem = new ToolStripMenuItem("於檔案總管開啟上次輸出", null, (_, _) => OpenLastOutputInExplorer());
            menu.Items.Add(_openLastOutputMenuItem);

            _openMainWindowMenuItem = new ToolStripMenuItem("開啟主視窗", null, (_, _) => ShowMainWindow());
            menu.Items.Add(_openMainWindowMenuItem);

            menu.Items.Add(new ToolStripSeparator());

            _exitMenuItem = new ToolStripMenuItem("結束", null, (_, _) => OnExitClicked());
            menu.Items.Add(_exitMenuItem);

            return menu;
        }

        private void OnPauseResumeClicked()
        {
            if (_state == RecordingState.Recording)
            {
                PauseRequested?.Invoke(this, EventArgs.Empty);
            }
            else if (_state == RecordingState.Paused)
            {
                ResumeRequested?.Invoke(this, EventArgs.Empty);
            }
        }

        private void OnExitClicked()
        {
            if (_state is RecordingState.Recording or RecordingState.Paused)
            {
                var result = MessageBox.Show(
                    "目前正在錄影中，結束程式將會中止錄影。確定要結束嗎？",
                    "ScreenRecorder",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Warning);

                if (result != MessageBoxResult.Yes)
                {
                    return;
                }
            }

            ExitRequested?.Invoke(this, EventArgs.Empty);
        }

        private void ShowMainWindow()
        {
            _mainWindow.Show();
            _mainWindow.WindowState = WindowState.Normal;
            _mainWindow.Activate();
        }

        private void OpenLastOutputInExplorer()
        {
            if (string.IsNullOrEmpty(_lastOutputPath) || !File.Exists(_lastOutputPath))
            {
                MessageBox.Show(
                    "尚未有可開啟的輸出檔案。",
                    "ScreenRecorder",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);
                return;
            }

            // 開啟檔案總管並選取該檔案
            Process.Start(new ProcessStartInfo
            {
                FileName = "explorer.exe",
                Arguments = $"/select,\"{_lastOutputPath}\"",
                UseShellExecute = true
            });
        }

        /// <summary>
        /// 由 RecorderManager / MainWindow 呼叫，更新系統匣顯示的狀態、已錄製時長。
        /// </summary>
        public void ApplyState(RecordingState state, TimeSpan elapsed)
        {
            _state = state;

            if (_statusMenuItem != null)
            {
                _statusMenuItem.Text = state switch
                {
                    RecordingState.Idle => "狀態：尚未開始",
                    RecordingState.Recording => "狀態：錄影中",
                    RecordingState.Paused => "狀態：已暫停",
                    _ => "狀態：未知"
                };
            }

            if (_durationMenuItem != null)
            {
                _durationMenuItem.Text = $"已錄製時長：{elapsed:hh\\:mm\\:ss}";
            }

            if (_startMenuItem != null)
            {
                _startMenuItem.Enabled = state == RecordingState.Idle;
            }

            if (_pauseResumeMenuItem != null)
            {
                _pauseResumeMenuItem.Enabled = state != RecordingState.Idle;
                _pauseResumeMenuItem.Text = state == RecordingState.Paused ? "繼續" : "暫停";
            }

            if (_stopMenuItem != null)
            {
                _stopMenuItem.Enabled = state != RecordingState.Idle;
            }

            if (_notifyIcon != null)
            {
                _notifyIcon.Text = TrimTooltip(state switch
                {
                    RecordingState.Idle => "ScreenRecorder - 尚未開始錄影",
                    RecordingState.Recording => $"ScreenRecorder - 錄影中 {elapsed:hh\\:mm\\:ss}",
                    RecordingState.Paused => $"ScreenRecorder - 已暫停 {elapsed:hh\\:mm\\:ss}",
                    _ => "ScreenRecorder"
                });
            }
        }

        /// <summary>
        /// 錄影完成後，由 RecorderManager 呼叫，登記最新輸出檔案路徑，
        /// 供「於檔案總管開啟上次輸出」選單使用。
        /// </summary>
        public void SetLastOutputPath(string path)
        {
            _lastOutputPath = path;
        }

        /// <summary>
        /// 系統匣提示文字（Tooltip）Windows 限制最長 63 字元，超出需截斷避免例外。
        /// </summary>
        private static string TrimTooltip(string text)
        {
            const int maxLength = 63;
            return text.Length <= maxLength ? text : text[..maxLength];
        }

        private static Icon LoadTrayIcon()
        {
            // 優先使用專案內建的 .ico 資源（Resources/tray.ico，Build Action 設為 Embedded Resource 或 Content）
            try
            {
                var iconPath = Path.Combine(AppContext.BaseDirectory, "Resources", "tray.ico");
                if (File.Exists(iconPath))
                {
                    return new Icon(iconPath);
                }
            }
            catch
            {
                // 忽略載入失敗，改用備援圖示
            }

            // 備援：使用系統內建圖示，確保即便資源遺失也不會啟動失敗
            return SystemIcons.Application;
        }

        public void Dispose()
        {
            if (_notifyIcon != null)
            {
                _notifyIcon.Visible = false;
                _notifyIcon.Dispose();
                _notifyIcon = null;
            }
        }
    }
}

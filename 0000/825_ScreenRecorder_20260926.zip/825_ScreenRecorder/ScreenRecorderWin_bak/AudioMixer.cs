using System;
using System.Threading;
using NAudio.CoreAudioApi;
using NAudio.Wave;

namespace ScreenRecorderWin
{
    /// <summary>
    /// 混音後的一顆音訊樣本：48kHz、立體聲、32-bit IEEE Float PCM，
    /// 交由 RecorderManager（<see cref="RecorderManager"/>）寫入 Media Foundation 的 AAC 音軌。
    /// </summary>
    public sealed class MixedAudioSample
    {
        public MixedAudioSample(TimeSpan timestamp, TimeSpan duration, byte[] data)
        {
            Timestamp = timestamp;
            Duration = duration;
            Data = data;
        }

        /// <summary>
        /// 相對於 AudioMixer.Start() 的累積時間戳（100ns tick，與 Media Foundation SampleTime 單位相同）。
        /// RecorderManager 會再套用「暫停位移演算法」（扣除 accumulatedPauseOffset）後才寫入 SinkWriter，
        /// 邏輯與影像 frame 的時間戳校正完全對稱。
        /// </summary>
        public TimeSpan Timestamp { get; }

        /// <summary>此樣本涵蓋的時長。</summary>
        public TimeSpan Duration { get; }

        /// <summary>32-bit Float、交錯（interleaved）的立體聲 PCM 原始資料。</summary>
        public byte[] Data { get; }
    }

    /// <summary>
    /// WASAPI 系統音效＋麥克風混音：
    ///   對應企劃書 3. 技術架構對照表「系統音效擷取」「麥克風擷取」「音訊混音」三列：
    ///     - 系統音效：WASAPI **Loopback** 模式擷取預設輸出裝置（<see cref="WasapiLoopbackCapture"/>）
    ///     - 麥克風：WASAPI 擷取模式擷取預設輸入裝置（<see cref="WasapiCapture"/>）
    ///     - 混音：兩路各自轉成 48kHz 立體聲 32-bit Float 後逐樣本相加（Float32 相加，並做 [-1, 1] 削峰），
    ///       寫入單一音軌，供 RecorderManager 交給 SinkWriter 編碼為 AAC。
    ///
    /// 實作方式：
    ///   兩個裝置各自在 NAudio 內部的獨立執行緒觸發 DataAvailable，彼此不同步、緩衝區長度也不固定，
    ///   因此本類別：
    ///     1. 把每一路原始 PCM 先寫進各自的 <see cref="BufferedWaveProvider"/>；
    ///     2. 外層各包一層 <see cref="MediaFoundationResampler"/>，統一轉成 48kHz / 雙聲道 / 32-bit Float；
    ///     3. 由一條固定間隔（每 <see cref="MixBlockMilliseconds"/> 毫秒）的背景執行緒（_mixLoopThread）
    ///        各拉一塊同樣長度的資料出來逐樣本相加，藉此把兩路非同步輸入對齊成單一連續時間軸，
    ///        對應企劃書所述「兩路轉 48kHz 立體聲 Float32 後相加」。
    ///   BufferedWaveProvider 在資料不足時（ReadFully 預設為 true）會自動補靜音，因此混音迴圈
    ///   永遠拿得到滿長度的區塊，輸出時間軸不會因為任一路暫時沒有資料而卡住或跳動。
    ///
    /// 使用前置條件：
    ///   建立本類別前，呼叫端須已完成 Media Foundation 初始化（RecorderManager.StartAsync 中，
    ///   InitializeSinkWriter 呼叫 MediaManager.Startup() 早於建立 AudioMixer，順序已滿足此需求），
    ///   否則 MediaFoundationResampler 可能初始化失敗。
    ///
    /// 已知限制（比照企劃書第 6 節精神）：
    ///   - 若系統沒有可用的預設輸出/輸入裝置（例如未插麥克風、或裝置被停用/拒絕存取），
    ///     對應那一路會在 Start() 時擲出例外，交由 RecorderManager 的 try/catch 處理並可選擇
    ///     只保留另一路正常運作。
    ///   - 混音僅做簡單相加＋削峰，未做自動增益 / 動態範圍壓縮；兩路音量都偏大時可能出現削波，
    ///     列為未來優化項目，非 Phase 1 範圍。
    ///   - 目前固定使用系統的「預設」輸出／輸入裝置，錄影中途切換預設裝置不會自動跟隨，
    ///     需重新開始錄影才會套用新裝置（與企劃書「Phase 1 範圍」精神一致，裝置選擇 UI 留待後續）。
    /// </summary>
    public sealed class AudioMixer : IDisposable
    {
        private const int TargetSampleRate = 48000;
        private const int TargetChannels = 2;

        private static readonly WaveFormat TargetFormat =
            WaveFormat.CreateIeeeFloatWaveFormat(TargetSampleRate, TargetChannels);

        // 每次混音打包的長度：20ms，是常見 WASAPI 緩衝區週期的整數倍，在延遲與 CPU 負擔間取得平衡。
        private const int MixBlockMilliseconds = 20;

        private static readonly int MixBlockBytes =
            TargetFormat.AverageBytesPerSecond * MixBlockMilliseconds / 1000;

        private readonly bool _captureSystemAudio;
        private readonly bool _captureMicrophone;

        private WasapiLoopbackCapture? _systemCapture;
        private WasapiCapture? _microphoneCapture;

        private BufferedWaveProvider? _systemRawBuffer;
        private BufferedWaveProvider? _microphoneRawBuffer;

        private MediaFoundationResampler? _systemResampler;
        private MediaFoundationResampler? _microphoneResampler;

        private Thread? _mixLoopThread;
        private volatile bool _running;

        // 每聲道已輸出的樣本數，換算成累積 Timestamp 用（見 MixedAudioSample.Timestamp 說明）。
        private long _totalSamplesWritten;

        /// <summary>每產生一顆混音樣本（預設每 20ms 一次）時觸發，交由 RecorderManager 寫入音軌。</summary>
        public event EventHandler<MixedAudioSample>? MixedSampleReady;

        /// <summary>初始化或錄製過程中發生無法復原的錯誤時觸發（例如找不到對應音訊裝置）。</summary>
        public event EventHandler<Exception>? ErrorOccurred;

        /// <param name="captureSystemAudio">是否以 WASAPI Loopback 擷取系統輸出音效。</param>
        /// <param name="captureMicrophone">是否以 WASAPI 擷取麥克風輸入。</param>
        public AudioMixer(bool captureSystemAudio, bool captureMicrophone)
        {
            _captureSystemAudio = captureSystemAudio;
            _captureMicrophone = captureMicrophone;
        }

        /// <summary>
        /// 啟動擷取與混音背景執行緒。呼叫端（RecorderManager.StartAsync）
        /// 應在 Media Foundation 初始化完成後才呼叫本方法。
        /// </summary>
        public void Start()
        {
            if (_running)
            {
                return;
            }

            if (!_captureSystemAudio && !_captureMicrophone)
            {
                // 兩路都沒開就不需要啟動任何裝置；RecorderManager 目前只會在至少一路為 true 時建立 AudioMixer。
                return;
            }

            if (_captureSystemAudio)
            {
                InitializeSystemAudioCapture();
            }

            if (_captureMicrophone)
            {
                InitializeMicrophoneCapture();
            }

            _totalSamplesWritten = 0;
            _running = true;

            _mixLoopThread = new Thread(MixLoop)
            {
                IsBackground = true,
                Name = "AudioMixer.MixLoop"
            };
            _mixLoopThread.Start();

            _systemCapture?.StartRecording();
            _microphoneCapture?.StartRecording();
        }

        /// <summary>停止擷取與混音執行緒，並釋放裝置資源。</summary>
        public void Stop()
        {
            if (!_running)
            {
                return;
            }

            _running = false;

            try { _systemCapture?.StopRecording(); }
            catch { /* 停止流程中裝置端拋出的例外可忽略，不影響已完成的錄影檔案 */ }

            try { _microphoneCapture?.StopRecording(); }
            catch { /* 同上 */ }

            _mixLoopThread?.Join(TimeSpan.FromSeconds(1));
            _mixLoopThread = null;

            CleanupDevices();
        }

        // ---------------------------------------------------------------
        // 裝置初始化：系統音效（Loopback）／麥克風
        // ---------------------------------------------------------------

        private void InitializeSystemAudioCapture()
        {
            try
            {
                using var enumerator = new MMDeviceEnumerator();
                MMDevice defaultRenderDevice = enumerator.GetDefaultAudioEndpoint(DataFlow.Render, Role.Multimedia);

                _systemCapture = new WasapiLoopbackCapture(defaultRenderDevice);
                _systemRawBuffer = new BufferedWaveProvider(_systemCapture.WaveFormat)
                {
                    DiscardOnBufferOverflow = true,
                    BufferDuration = TimeSpan.FromSeconds(2)
                };
                _systemResampler = new MediaFoundationResampler(_systemRawBuffer, TargetFormat)
                {
                    ResamplerQuality = 60
                };

                _systemCapture.DataAvailable += OnSystemAudioDataAvailable;
                _systemCapture.RecordingStopped += OnSystemAudioRecordingStopped;
            }
            catch (Exception ex)
            {
                ErrorOccurred?.Invoke(this, ex);
                throw;
            }
        }

        private void InitializeMicrophoneCapture()
        {
            try
            {
                using var enumerator = new MMDeviceEnumerator();
                MMDevice defaultCaptureDevice = enumerator.GetDefaultAudioEndpoint(DataFlow.Capture, Role.Multimedia);

                _microphoneCapture = new WasapiCapture(defaultCaptureDevice);
                _microphoneRawBuffer = new BufferedWaveProvider(_microphoneCapture.WaveFormat)
                {
                    DiscardOnBufferOverflow = true,
                    BufferDuration = TimeSpan.FromSeconds(2)
                };
                _microphoneResampler = new MediaFoundationResampler(_microphoneRawBuffer, TargetFormat)
                {
                    ResamplerQuality = 60
                };

                _microphoneCapture.DataAvailable += OnMicrophoneDataAvailable;
                _microphoneCapture.RecordingStopped += OnMicrophoneRecordingStopped;
            }
            catch (Exception ex)
            {
                ErrorOccurred?.Invoke(this, ex);
                throw;
            }
        }

        private void OnSystemAudioDataAvailable(object? sender, WaveInEventArgs e)
        {
            _systemRawBuffer?.AddSamples(e.Buffer, 0, e.BytesRecorded);
        }

        private void OnMicrophoneDataAvailable(object? sender, WaveInEventArgs e)
        {
            _microphoneRawBuffer?.AddSamples(e.Buffer, 0, e.BytesRecorded);
        }

        private void OnSystemAudioRecordingStopped(object? sender, StoppedEventArgs e)
        {
            if (e.Exception != null)
            {
                ErrorOccurred?.Invoke(this, e.Exception);
            }
        }

        private void OnMicrophoneRecordingStopped(object? sender, StoppedEventArgs e)
        {
            if (e.Exception != null)
            {
                ErrorOccurred?.Invoke(this, e.Exception);
            }
        }

        // ---------------------------------------------------------------
        // 混音主迴圈：定時各拉一塊同長度資料出來相加
        // ---------------------------------------------------------------

        private void MixLoop()
        {
            var systemBlock = new byte[MixBlockBytes];
            var microphoneBlock = new byte[MixBlockBytes];
            var mixedBlock = new byte[MixBlockBytes];

            int sampleCountPerBlock = MixBlockBytes / sizeof(float) / TargetChannels;
            long blockDurationTicks = (long)sampleCountPerBlock * TimeSpan.TicksPerSecond / TargetSampleRate;

            while (_running)
            {
                try
                {
                    bool hasSystem = _systemResampler != null;
                    bool hasMicrophone = _microphoneResampler != null;

                    // MediaFoundationResampler 底層讀自 BufferedWaveProvider，資料不足時會自動補靜音，
                    // 因此每次一定能讀滿 MixBlockBytes，不需額外等待，時間軸得以穩定前進。
                    int systemBytesRead = hasSystem
                        ? _systemResampler!.Read(systemBlock, 0, MixBlockBytes)
                        : 0;
                    int microphoneBytesRead = hasMicrophone
                        ? _microphoneResampler!.Read(microphoneBlock, 0, MixBlockBytes)
                        : 0;

                    MixFloatBuffers(
                        hasSystem ? systemBlock : null, systemBytesRead,
                        hasMicrophone ? microphoneBlock : null, microphoneBytesRead,
                        mixedBlock);

                    var timestamp = TimeSpan.FromTicks(
                        _totalSamplesWritten * TimeSpan.TicksPerSecond / TargetSampleRate);
                    var duration = TimeSpan.FromTicks(blockDurationTicks);

                    var mixedData = new byte[MixBlockBytes];
                    Array.Copy(mixedBlock, mixedData, MixBlockBytes);

                    MixedSampleReady?.Invoke(this, new MixedAudioSample(timestamp, duration, mixedData));

                    _totalSamplesWritten += sampleCountPerBlock;
                }
                catch (Exception ex)
                {
                    ErrorOccurred?.Invoke(this, ex);
                }

                Thread.Sleep(MixBlockMilliseconds);
            }
        }

        /// <summary>
        /// 將兩路 32-bit Float PCM 逐樣本相加（對應企劃書「Float32 相加」），
        /// 並以 [-1, 1] 削峰避免相加後溢位造成的爆音。任一路為 null 或該區塊資料不足時視為靜音（0）。
        /// </summary>
        private static void MixFloatBuffers(byte[]? a, int aLength, byte[]? b, int bLength, byte[] destination)
        {
            int floatCount = destination.Length / sizeof(float);

            for (int i = 0; i < floatCount; i++)
            {
                int byteOffset = i * sizeof(float);

                float sampleA = (a != null && byteOffset + sizeof(float) <= aLength)
                    ? BitConverter.ToSingle(a, byteOffset)
                    : 0f;
                float sampleB = (b != null && byteOffset + sizeof(float) <= bLength)
                    ? BitConverter.ToSingle(b, byteOffset)
                    : 0f;

                float mixed = Math.Clamp(sampleA + sampleB, -1f, 1f);

                var mixedBytes = BitConverter.GetBytes(mixed);
                Array.Copy(mixedBytes, 0, destination, byteOffset, sizeof(float));
            }
        }

        // ---------------------------------------------------------------
        // 清理
        // ---------------------------------------------------------------

        private void CleanupDevices()
        {
            if (_systemCapture != null)
            {
                _systemCapture.DataAvailable -= OnSystemAudioDataAvailable;
                _systemCapture.RecordingStopped -= OnSystemAudioRecordingStopped;
                _systemCapture.Dispose();
                _systemCapture = null;
            }

            _systemResampler?.Dispose();
            _systemResampler = null;
            _systemRawBuffer = null;

            if (_microphoneCapture != null)
            {
                _microphoneCapture.DataAvailable -= OnMicrophoneDataAvailable;
                _microphoneCapture.RecordingStopped -= OnMicrophoneRecordingStopped;
                _microphoneCapture.Dispose();
                _microphoneCapture = null;
            }

            _microphoneResampler?.Dispose();
            _microphoneResampler = null;
            _microphoneRawBuffer = null;
        }

        public void Dispose()
        {
            Stop();
        }
    }
}

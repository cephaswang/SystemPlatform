#!/usr/bin/env bash
#
# package-dmg.sh — ScreenRecorder 獨立分發版 DMG 打包
#
# 放在專案根目錄（與 ScreenRecorder.xcodeproj 同層）。
#
# 三種模式：
#   bash package-dmg.sh                 未簽章（ad-hoc）DMG，自己測試用
#   bash package-dmg.sh --sign          Developer ID 簽章（Hardened Runtime），不公證
#   NOTARY_PROFILE=xxx bash package-dmg.sh --notarize
#                                       簽章 + 公證 + staple，可對外發布
#
# 選項：
#   --clean     先刪除 build/ 內的舊 archive 與暫存
#
# 環境變數（皆可省略）：
#   SIGN_IDENTITY   例如 "Developer ID Application: Your Name (TEAMID)"
#                   省略時自動使用鑰匙圈中第一個 Developer ID Application
#   NOTARY_PROFILE  notarytool 的鑰匙圈設定檔名稱（--notarize 必填）。第一次先建立：
#                     xcrun notarytool store-credentials "SR-notary" \
#                       --apple-id "you@example.com" --team-id "TEAMID" \
#                       --password "app-specific-password"
#   PROJECT         預設自動偵測目錄內的 .xcodeproj
#   SCHEME          預設與 .xcodeproj 同名（ScreenRecorder）
#   CONFIGURATION   預設 Release
#
# 產出：build/ScreenRecorder.dmg
#
# 說明：
#   - 螢幕錄製（ScreenCaptureKit）不需要 entitlement，但麥克風在 Hardened Runtime
#     下需要 com.apple.security.device.audio-input；若 Info.plist 有麥克風用途說明
#     而 entitlements 缺少它，本腳本會在簽章時自動補上，避免簽章後麥克風沒有聲音。
#   - 螢幕錄製權限綁定簽章身分：每次改用不同簽章（例如未簽章測試版 → 正式版）
#     系統都會要求重新授權；同一個 Developer ID 簽章的不同版本則會保留授權。

set -euo pipefail

# ---------------------------------------------------------------------------
# 參數
# ---------------------------------------------------------------------------
MODE="unsigned"
DO_CLEAN=0
for arg in "$@"; do
  case "${arg}" in
    --sign)      [[ "${MODE}" == "notarize" ]] || MODE="sign" ;;
    --notarize)  MODE="notarize" ;;
    --clean)     DO_CLEAN=1 ;;
    -h|--help)   sed -n '2,34p' "$0"; exit 0 ;;
    *) echo "未知參數：${arg}（可用：--sign --notarize --clean）"; exit 1 ;;
  esac
done

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "${ROOT}"

step() { echo; echo "==> $*"; }
fail() { echo "錯誤：$*" >&2; exit 1; }
warn() { echo "警告：$*" >&2; }

if [[ -z "${PROJECT:-}" ]]; then
  for candidate in *.xcodeproj; do
    [[ -d "${candidate}" ]] && PROJECT="${candidate}" && break
  done
fi
[[ -n "${PROJECT:-}" && -d "${PROJECT}" ]] || fail "找不到 .xcodeproj，請把腳本放在專案根目錄。"

SCHEME="${SCHEME:-${PROJECT%.xcodeproj}}"
CONFIGURATION="${CONFIGURATION:-Release}"
BUILD_DIR="${ROOT}/build"
ARCHIVE="${BUILD_DIR}/${SCHEME}.xcarchive"
STAGING="${BUILD_DIR}/dmg-staging"
DMG="${BUILD_DIR}/${SCHEME}.dmg"
ENT_FILE="${BUILD_DIR}/app.entitlements"

# ---------------------------------------------------------------------------
# 前置檢查
# ---------------------------------------------------------------------------
step "前置檢查（模式：${MODE}）"

command -v xcodebuild >/dev/null || fail "找不到 xcodebuild，請安裝 Xcode。"
command -v hdiutil >/dev/null || fail "找不到 hdiutil。"

IDENTITY="-"
if [[ "${MODE}" != "unsigned" ]]; then
  IDENTITY="${SIGN_IDENTITY:-}"
  if [[ -z "${IDENTITY}" ]]; then
    IDENTITY="$(security find-identity -v -p codesigning \
      | awk -F'"' '/Developer ID Application/ {print $2; exit}')"
  fi
  [[ -n "${IDENTITY}" ]] || fail "鑰匙圈找不到「Developer ID Application」憑證，請安裝或設定 SIGN_IDENTITY。"
  echo "   簽章身分：${IDENTITY}"
fi
if [[ "${MODE}" == "notarize" ]]; then
  [[ -n "${NOTARY_PROFILE:-}" ]] || fail "--notarize 需要設定 NOTARY_PROFILE（見腳本開頭說明）。"
  xcrun notarytool --version >/dev/null 2>&1 || fail "找不到 notarytool（需要 Xcode 13 以上）。"
fi

BUILD_SETTINGS="$(xcodebuild -project "${PROJECT}" -scheme "${SCHEME}" -configuration "${CONFIGURATION}" \
  -showBuildSettings 2>/dev/null || true)"
[[ -n "${BUILD_SETTINGS}" ]] || fail "讀不到 scheme「${SCHEME}」的建置設定，請確認 scheme 名稱（可用 SCHEME=... 指定）。"

setting() {
  printf '%s\n' "${BUILD_SETTINGS}" | awk -F' = ' -v k="$1" '$1 ~ "^ *"k"$" {v=$2} END {print v}'
}

# ScreenCaptureKit 需要 macOS 13 以上
DEPLOY="$(setting MACOSX_DEPLOYMENT_TARGET)"
if [[ -n "${DEPLOY}" && "${DEPLOY%%.*}" -lt 13 ]]; then
  warn "Deployment Target 是 ${DEPLOY}，但 ScreenCaptureKit 需要 macOS 13 以上。"
fi
echo "   Scheme：${SCHEME}　Configuration：${CONFIGURATION}　Deployment Target：${DEPLOY:-未知}"

# ---------------------------------------------------------------------------
# 建置
# ---------------------------------------------------------------------------
step "建置 Archive"
mkdir -p "${BUILD_DIR}"
if [[ ${DO_CLEAN} -eq 1 ]]; then
  rm -rf "${DMG}"
fi
rm -rf "${ARCHIVE}" "${STAGING}" "${ENT_FILE}"

# 先以 ad-hoc 簽章建置：Xcode 會把專案設定產生的 entitlements（含以建置設定啟用的
# Sandbox、麥克風等）一併嵌入，之後可從成品讀出來，再用 Developer ID 重新簽章。
xcodebuild archive \
  -project "${PROJECT}" \
  -scheme "${SCHEME}" \
  -configuration "${CONFIGURATION}" \
  -archivePath "${ARCHIVE}" \
  CODE_SIGN_STYLE=Manual \
  CODE_SIGN_IDENTITY="-" \
  CODE_SIGNING_REQUIRED=YES \
  CODE_SIGNING_ALLOWED=YES \
  | tail -n 25

APP_SRC=""
for candidate in "${ARCHIVE}/Products/Applications/"*.app; do
  [[ -d "${candidate}" ]] && APP_SRC="${candidate}" && break
done
[[ -n "${APP_SRC}" ]] || fail "Archive 內找不到 .app（${ARCHIVE}/Products/Applications）。"

APP_NAME="$(basename "${APP_SRC}")"
APP="${BUILD_DIR}/${APP_NAME}"
rm -rf "${APP}"
ditto "${APP_SRC}" "${APP}"
echo "   App：${APP_NAME}"

# ---------------------------------------------------------------------------
# 驗證 App 內容
# ---------------------------------------------------------------------------
step "驗證 App 內容"
RES="${APP}/Contents/Resources"
INFO="${APP}/Contents/Info.plist"

BUNDLE_ID="$(plutil -extract CFBundleIdentifier raw -o - "${INFO}" 2>/dev/null || echo '?')"
echo "   Bundle ID：${BUNDLE_ID}"

# 不該隨 App 散布的文件（docs/ 若被加入 Copy Bundle Resources 會出現在這裡）
for junk in ScreenRecorder_proposal.txt dir.txt helpdocs.zip README.md; do
  if [[ -n "$(find "${RES}" -name "${junk}" 2>/dev/null)" ]]; then
    warn "Resources 內含 ${junk}，正式發布前建議自 Copy Bundle Resources 移除。"
  fi
done
if [[ -n "$(find "${APP}" -name ".DS_Store" 2>/dev/null)" ]]; then
  warn "App 內含 .DS_Store。"
fi
if [[ -z "$(find "${RES}" -name "helpdoc*.html" 2>/dev/null)" ]]; then
  warn "Resources 內找不到 helpdoc*.html，App 內的說明中心可能開不起來。"
fi

# ---------------------------------------------------------------------------
# 取出 entitlements（簽章時沿用）
# ---------------------------------------------------------------------------
step "整理 entitlements"
codesign -d --entitlements :- "${APP}" > "${ENT_FILE}" 2>/dev/null || true
if [[ ! -s "${ENT_FILE}" ]] || ! plutil -lint "${ENT_FILE}" >/dev/null 2>&1; then
  rm -f "${ENT_FILE}"
fi

PB="/usr/libexec/PlistBuddy"
if [[ "${MODE}" != "unsigned" ]]; then
  # get-task-allow 是除錯用，帶著它會被公證拒絕
  if [[ -f "${ENT_FILE}" ]]; then
    "${PB}" -c "Delete :com.apple.security.get-task-allow" "${ENT_FILE}" >/dev/null 2>&1 || true
  fi

  # 有用到麥克風：Hardened Runtime 下必須有 audio-input entitlement
  if "${PB}" -c "Print :NSMicrophoneUsageDescription" "${INFO}" >/dev/null 2>&1; then
    HAS_AUDIO="no"
    if [[ -f "${ENT_FILE}" ]] \
       && "${PB}" -c "Print :com.apple.security.device.audio-input" "${ENT_FILE}" >/dev/null 2>&1; then
      HAS_AUDIO="yes"
    fi
    if [[ "${HAS_AUDIO}" == "no" ]]; then
      "${PB}" -c "Add :com.apple.security.device.audio-input bool true" "${ENT_FILE}" >/dev/null
      echo "   已補上 com.apple.security.device.audio-input（Info.plist 有麥克風用途說明）"
    fi
  fi
fi

if [[ -f "${ENT_FILE}" ]]; then
  echo "   將使用的 entitlements："
  "${PB}" -c "Print" "${ENT_FILE}" | sed 's/^/     /'
  if [[ "$("${PB}" -c 'Print :com.apple.security.app-sandbox' "${ENT_FILE}" 2>/dev/null || true)" == "true" ]]; then
    echo "   （偵測到 App Sandbox：DMG 版仍可運作，但存檔位置受沙盒限制）"
  fi
else
  echo "   無 entitlements"
fi

# ---------------------------------------------------------------------------
# 簽章
# ---------------------------------------------------------------------------
sign_file() {   # sign_file <檔案> [entitlements]
  local f="$1" ent="${2:-}"
  if [[ -n "${ent}" ]]; then
    codesign --force --timestamp --options runtime --entitlements "${ent}" --sign "${IDENTITY}" "${f}"
  else
    codesign --force --timestamp --options runtime --sign "${IDENTITY}" "${f}"
  fi
}

if [[ "${MODE}" != "unsigned" ]]; then
  step "簽章內部執行檔（Frameworks、dylib 等，由內而外）"
  MAIN_EXEC="${APP}/Contents/MacOS/$(plutil -extract CFBundleExecutable raw -o - "${INFO}")"
  COUNT=0
  while IFS= read -r -d '' f; do
    [[ "${f}" == "${MAIN_EXEC}" ]] && continue
    if [[ "$(file -b "${f}")" == *Mach-O* ]]; then
      sign_file "${f}"
      echo "   已簽章：${f#${APP}/}"
      COUNT=$((COUNT + 1))
    fi
  done < <(find "${APP}/Contents" -type f -print0)
  echo "   共 ${COUNT} 個"

  step "簽章 App 本體"
  if [[ -f "${ENT_FILE}" ]]; then
    sign_file "${APP}" "${ENT_FILE}"
  else
    sign_file "${APP}"
  fi
fi

step "驗證簽章"
codesign --verify --deep --strict --verbose=2 "${APP}"
SIGN_INFO="$(codesign -dv "${APP}" 2>&1 || true)"
if [[ "${MODE}" != "unsigned" && "${SIGN_INFO}" != *"runtime"* ]]; then
  fail "App 未啟用 Hardened Runtime，公證會失敗。"
fi
echo "   ✓ 簽章有效"

# ---------------------------------------------------------------------------
# 公證（App）
# ---------------------------------------------------------------------------
notarize() {   # notarize <zip 或 dmg>
  xcrun notarytool submit "$1" --keychain-profile "${NOTARY_PROFILE}" --wait
}

if [[ "${MODE}" == "notarize" ]]; then
  step "公證 App（通常需要數分鐘）"
  APP_ZIP="${BUILD_DIR}/notary-app.zip"
  rm -f "${APP_ZIP}"
  ditto -c -k --keepParent "${APP}" "${APP_ZIP}"
  notarize "${APP_ZIP}"
  rm -f "${APP_ZIP}"
  xcrun stapler staple "${APP}"
fi

# ---------------------------------------------------------------------------
# 製作 DMG
# ---------------------------------------------------------------------------
step "製作 DMG"
rm -rf "${STAGING}" "${DMG}"
mkdir -p "${STAGING}"
ditto "${APP}" "${STAGING}/${APP_NAME}"
ln -s /Applications "${STAGING}/Applications"
hdiutil create -volname "${APP_NAME%.app}" -srcfolder "${STAGING}" -ov -format UDZO "${DMG}" >/dev/null
rm -rf "${STAGING}"

if [[ "${MODE}" != "unsigned" ]]; then
  codesign --force --timestamp --sign "${IDENTITY}" "${DMG}"
fi

if [[ "${MODE}" == "notarize" ]]; then
  step "公證 DMG"
  notarize "${DMG}"
  xcrun stapler staple "${DMG}"
fi

# ---------------------------------------------------------------------------
# 收尾
# ---------------------------------------------------------------------------
step "收尾檢查"
rm -f "${ENT_FILE}"
if [[ "${MODE}" == "notarize" ]]; then
  xcrun stapler validate "${DMG}"
  spctl -a -t open --context context:primary-signature -vv "${DMG}" || warn "spctl 對 DMG 檢查未通過，請確認公證結果。"
  spctl -a -t exec -vv "${APP}" || warn "spctl 對 App 檢查未通過，請確認公證結果。"
fi

VERSION="$(plutil -extract CFBundleShortVersionString raw -o - "${INFO}" 2>/dev/null || echo '?')"
BUILDNO="$(plutil -extract CFBundleVersion raw -o - "${INFO}" 2>/dev/null || echo '?')"

echo
echo "完成（模式：${MODE}）"
echo "  版本：${VERSION} (${BUILDNO})"
echo "  檔案：${DMG}"
echo "  大小：$(du -h "${DMG}" | cut -f1)"
echo "  SHA256：$(shasum -a 256 "${DMG}" | cut -d' ' -f1)"
if [[ "${MODE}" == "unsigned" ]]; then
  echo
  echo "這是未簽章版本：其他 Mac 開啟時會被 Gatekeeper 擋下，"
  echo "需要在「系統設定 → 隱私權與安全性」按「強制打開」，僅供自己測試。"
fi
echo
echo "提醒：首次執行需在「系統設定 → 隱私權與安全性 → 螢幕錄製」授權，授權後要重新開啟 App。"

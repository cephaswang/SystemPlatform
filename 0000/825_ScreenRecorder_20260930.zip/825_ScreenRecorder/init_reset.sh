#!/bin/bash

tccutil reset ScreenCapture org.share35app.ScreenRecorder
tccutil reset Microphone    org.share35app.ScreenRecorder

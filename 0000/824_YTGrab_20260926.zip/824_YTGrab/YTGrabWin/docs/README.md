# YTGrab for Windows

本專案骨架依據《yt-dlp Windows 10 App 企劃案》（YTGrab for Windows, v0.1 草案）產生。

## 專案結構對應表

| 專案位置 | 對應企劃案章節 |
| --- | --- |
| `App/App.xaml(.cs)` | 二、2.3：進入點，Mutex 防多開 |
| `App/AppState.cs` | 二、2.3：全域狀態 |
| `Core/ProcessRunner/` | 二、2.1：Process + 非同步讀取 stdout/stderr |
| `Core/YTDLPClient/` | 二、2.1：`-J`／`--flat-playlist`／`--progress-template`／`--print-to-file` 等 yt-dlp 整合邏輯 |
| `Core/Models/` | 二、2.3：VideoInfo、FormatInfo、SubtitleInfo、DownloadTask |
| `Core/DownloadQueue/` | 三、規格：下載佇列暫停/續傳/重試狀態機 |
| `Core/Utilities/ExplorerActions.cs` | 三、平台差異表：檔案總管顯示/開啟 |
| `Core/Utilities/FileNameSanitizer.cs` | 三、平台差異表：資料夾名稱清理字元 |
| `Core/Utilities/LanguageNameResolver.cs` | 二、2.2：語言名稱轉換（CultureInfo） |
| `Core/SettingsStore.cs` | 二、2.1：本地儲存（appsettings.json，SQLite 待 Phase 4 擴充） |
| `Features/MainWindow.xaml(.cs)` | 四：主畫面版面配置、網址分流 |
| `Features/UrlInput/` | 四：網址輸入列；三、平台差異表：拖放網址、剪貼簿偵測 |
| `Features/VideoInfoView/` | 四：影片資訊卡＋畫質/字幕/音訊 Tab |
| `Features/PlaylistView/` | 四：播放列表模式，勾選清單＋批次動作列 |
| `Features/DownloadQueueView/` | 一、1.2：下載佇列與多任務進度追蹤 |
| `Features/Settings/` | 四／第七章：設定頁 |
| `Resources/yt-dlp.exe`、`ffmpeg.exe` | 二、2.1／2.3：核心引擎打包 |

## 目前狀態（骨架，非完整實作）

已建立：UI 畫面（XAML）、模組拆分、`-J`/`--flat-playlist` 呼叫框架、下載佇列狀態機、
語言名稱轉換、檔名清理、檔案總管操作。

尚未實作（標記為 `TODO` 或需第七章定案後補上）：
- Windows Toast 通知（`Microsoft.Toolkit.Uwp.Notifications`，含 AUMID 註冊）
- 工作列縮圖進度（`ITaskbarList3` COM 介面）
- SQLite 下載歷史紀錄層
- 播放列表批次下載是否含字幕、檔名序號前綴規則
- 系統匣（Tray）常駐模式
- Cookies 匯入（`--cookies-from-browser`，需處理 Windows DPAPI 加密與跨使用者權限）
- 程式碼簽章、自動更新機制、安裝檔打包（Inno Setup / MSIX）

## 建置需求

- .NET 8 SDK
- Windows 10 (build ≥ 17763) 或 Windows 11
- NuGet 套件：Microsoft.Data.Sqlite、Microsoft.Toolkit.Uwp.Notifications（見 `YTGrabWin.csproj`）
- `Resources/yt-dlp.exe`、`Resources/ffmpeg.exe`（需另行下載放入，見 `Resources/README.md`）

## 待確認事項（原文照錄，見企劃案第七章）

- [ ] 發行路線：獨立安裝檔（Inno Setup / MSI）或 Microsoft Store（MSIX）
- [ ] 是否需要系統匣常駐模式
- [ ] 是否支援批次貼上多網址
- [ ] 播放列表批次下載是否支援字幕、檔名是否加播放列表序號前綴
- [ ] 常用語言置頂清單是否可自訂（本骨架已於 `SettingsStore` 預留 `PinnedSubtitleLanguages` 欄位）
- [ ] 若走 Microsoft Store：功能範圍是否需限縮，並準備對應審核說明文件

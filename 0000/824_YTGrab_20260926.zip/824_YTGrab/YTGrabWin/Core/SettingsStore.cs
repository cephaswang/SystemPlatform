using System;
using System.IO;
using System.Text.Json;

namespace YTGrabWin.Core;

/// <summary>
/// 對應企劃案二、2.1：本地儲存。
/// macOS 版用 UserDefaults + SQLite/SwiftData；Windows 版用 appsettings.json（一般設定）
/// + SQLite（下載歷史等結構化資料，透過 Microsoft.Data.Sqlite，見 csproj 套件參考）。
/// 此類別先實作 appsettings.json 部分；SQLite 存取層可於 Phase 4（下載佇列）擴充。
/// </summary>
public sealed class AppSettings
{
    /// <summary>預設下載資料夾。</summary>
    public string DownloadFolder { get; set; } =
        Environment.GetFolderPath(Environment.SpecialFolder.MyVideos);

    /// <summary>對應第七章待確認事項：是否需要系統匣常駐模式。</summary>
    public bool MinimizeToTray { get; set; }

    /// <summary>對應三、規格：播放列表批次畫質上限預設。</summary>
    public string DefaultPlaylistMaxQuality { get; set; } = "1080p";

    /// <summary>對應第七章待確認事項：常用語言置頂清單（可自訂與否待確認，先提供預設清單）。</summary>
    public string[] PinnedSubtitleLanguages { get; set; } = { "zh-Hant", "zh-Hans", "en", "ja" };
}

public sealed class SettingsStore
{
    private static string SettingsFilePath => Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
        "YTGrabWin", "appsettings.json");

    public AppSettings Current { get; private set; } = new();

    public SettingsStore()
    {
        Load();
    }

    public void Load()
    {
        try
        {
            if (File.Exists(SettingsFilePath))
            {
                var json = File.ReadAllText(SettingsFilePath);
                Current = JsonSerializer.Deserialize<AppSettings>(json) ?? new AppSettings();
            }
        }
        catch
        {
            // 讀取失敗時使用預設值，避免因設定檔損毀導致 App 無法啟動。
            Current = new AppSettings();
        }
    }

    public void Save()
    {
        var directory = Path.GetDirectoryName(SettingsFilePath)!;
        Directory.CreateDirectory(directory);
        var json = JsonSerializer.Serialize(Current, new JsonSerializerOptions { WriteIndented = true });
        File.WriteAllText(SettingsFilePath, json);
    }
}

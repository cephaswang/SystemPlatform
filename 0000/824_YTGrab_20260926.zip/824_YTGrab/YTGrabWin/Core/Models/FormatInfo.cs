using System.Text.Json.Serialization;

namespace YTGrabWin.Core;

/// <summary>
/// 對應企劃案 2.3：Core/Models/FormatInfo.cs。
/// 對應三、核心功能規格「畫質音訊分類過濾規則」（沿用 macOS 版邏輯，此處僅為資料結構）。
/// </summary>
public sealed class FormatInfo
{
    [JsonPropertyName("format_id")]
    public string FormatId { get; set; } = string.Empty;

    [JsonPropertyName("ext")]
    public string Extension { get; set; } = string.Empty;

    [JsonPropertyName("resolution")]
    public string? Resolution { get; set; }

    [JsonPropertyName("vcodec")]
    public string? VideoCodec { get; set; }

    [JsonPropertyName("acodec")]
    public string? AudioCodec { get; set; }

    [JsonPropertyName("filesize")]
    public long? FileSizeBytes { get; set; }

    [JsonPropertyName("fps")]
    public double? Fps { get; set; }

    /// <summary>對應三、規格：video-only 無聲判斷依據（acodec == "none"）。</summary>
    public bool IsVideoOnly => AudioCodec is null or "none";

    /// <summary>對應三、規格：audio-only 判斷依據（vcodec == "none"）。</summary>
    public bool IsAudioOnly => VideoCodec is null or "none";
}

using System;

namespace YTGrabWin.Core;

/// <summary>
/// 對應三、核心功能規格「下載佇列暫停/續傳/重試」的狀態機狀態。
/// </summary>
public enum DownloadTaskStatus
{
    Pending,
    Downloading,
    Paused,
    Completed,
    Failed,
    Canceled
}

/// <summary>
/// 對應企劃案 2.3：Core/Models/DownloadTask.cs。
/// 佇列中的單一下載任務，供 DownloadQueueManager 管理。
/// </summary>
public sealed class DownloadTask
{
    public required string Id { get; init; } = Guid.NewGuid().ToString();
    public required string Url { get; init; }
    public required string Title { get; set; }
    public required string FormatSelector { get; init; }
    public string? SubtitleLanguageCode { get; init; }
    public DownloadTaskStatus Status { get; set; } = DownloadTaskStatus.Pending;
    public double ProgressPercent { get; set; }
    public string? FinalFilePath { get; set; }
    public string? ErrorMessage { get; set; }
    public int RetryCount { get; set; }

    /// <summary>對應第七章待確認事項：播放列表批次下載檔名是否加序號前綴。</summary>
    public int? PlaylistIndex { get; init; }
}

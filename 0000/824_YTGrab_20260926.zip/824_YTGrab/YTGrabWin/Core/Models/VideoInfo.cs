using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace YTGrabWin.Core;

/// <summary>
/// 對應企劃案 2.3：Core/Models/VideoInfo.cs。
/// 對應 `yt-dlp -J` 的單支影片結構化輸出（-J / --dump-json），欄位對齊 macOS 版 Codable model。
/// </summary>
public sealed class VideoInfo
{
    [JsonPropertyName("id")]
    public string Id { get; set; } = string.Empty;

    [JsonPropertyName("title")]
    public string Title { get; set; } = string.Empty;

    [JsonPropertyName("uploader")]
    public string? Uploader { get; set; }

    [JsonPropertyName("duration")]
    public double? DurationSeconds { get; set; }

    [JsonPropertyName("thumbnail")]
    public string? ThumbnailUrl { get; set; }

    [JsonPropertyName("formats")]
    public List<FormatInfo> Formats { get; set; } = new();

    [JsonPropertyName("subtitles")]
    public Dictionary<string, List<SubtitleInfo>>? Subtitles { get; set; }

    [JsonPropertyName("automatic_captions")]
    public Dictionary<string, List<SubtitleInfo>>? AutomaticCaptions { get; set; }
}

using System.Text;

namespace YTGrabWin.Core;

/// <summary>
/// 對應企劃案三、平台差異表：資料夾/檔案名稱清理字元。
/// Windows 保留字元為 \ / : * ? " &lt; &gt; |，與 macOS 版清理規則字元集相同，邏輯可直接沿用。
/// </summary>
public static class FileNameSanitizer
{
    private static readonly char[] ReservedChars = { '\\', '/', ':', '*', '?', '"', '<', '>', '|' };

    public static string Sanitize(string name)
    {
        var sb = new StringBuilder(name.Length);
        foreach (var c in name)
        {
            sb.Append(System.Array.IndexOf(ReservedChars, c) >= 0 ? '_' : c);
        }
        // Windows 額外限制：檔名結尾不可為空白或句點。
        return sb.ToString().TrimEnd(' ', '.');
    }
}

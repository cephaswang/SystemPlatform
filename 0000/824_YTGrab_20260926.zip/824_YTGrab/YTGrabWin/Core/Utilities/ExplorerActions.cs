using System;
using System.Diagnostics;
using System.IO;

namespace YTGrabWin.Core;

/// <summary>
/// 對應企劃案 2.3：Core/Utilities/ExplorerActions.cs — 檔案總管顯示/開啟，含 fallback。
/// 對應三、平台差異表：
/// - 檔案總管顯示/選取：`explorer.exe /select,"完整路徑"`
/// - 開啟檔案：`Process.Start(new ProcessStartInfo(path) { UseShellExecute = true })`，模擬雙擊行為
/// </summary>
public static class ExplorerActions
{
    /// <summary>在檔案總管中開啟並選取指定檔案。含 fallback：檔案不存在時改開啟所在資料夾。</summary>
    public static void ShowInExplorer(string filePath)
    {
        if (File.Exists(filePath))
        {
            Process.Start(new ProcessStartInfo
            {
                FileName = "explorer.exe",
                Arguments = $"/select,\"{filePath}\"",
                UseShellExecute = true
            });
            return;
        }

        // Fallback：檔案可能已被移動/刪除，改為開啟所在資料夾。
        var directory = Path.GetDirectoryName(filePath);
        if (directory is not null && Directory.Exists(directory))
        {
            Process.Start(new ProcessStartInfo
            {
                FileName = "explorer.exe",
                Arguments = $"\"{directory}\"",
                UseShellExecute = true
            });
        }
    }

    /// <summary>以系統預設程式開啟檔案，模擬雙擊行為。</summary>
    public static void OpenFile(string filePath)
    {
        if (!File.Exists(filePath))
            throw new FileNotFoundException("找不到檔案，可能已被移動或刪除。", filePath);

        Process.Start(new ProcessStartInfo(filePath) { UseShellExecute = true });
    }
}

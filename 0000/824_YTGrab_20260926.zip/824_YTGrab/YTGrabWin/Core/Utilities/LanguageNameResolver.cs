using System;
using System.Globalization;

namespace YTGrabWin.Core;

/// <summary>
/// 對應企劃案二、2.2：語言名稱轉換。
/// macOS 版使用系統 Locale API；Windows 改用 System.Globalization.CultureInfo，
/// 查不到的代碼原樣顯示；`-orig` 後綴另外處理，邏輯不變（自動生成翻譯字幕的原文標記）。
/// </summary>
public sealed class LanguageNameResolver
{
    private const string OriginalSuffix = "-orig";

    /// <summary>
    /// 將語言代碼轉為繁中顯示名稱。
    /// 需將 UI culture 設為 zh-TW 才能取得 DisplayName 的繁中結果；
    /// 若該執行緒尚未設定，呼叫端應先設定 CultureInfo.CurrentUICulture。
    /// </summary>
    public string Resolve(string languageCode)
    {
        var isOriginal = languageCode.EndsWith(OriginalSuffix, StringComparison.OrdinalIgnoreCase);
        var baseCode = isOriginal
            ? languageCode[..^OriginalSuffix.Length]
            : languageCode;

        string displayName;
        try
        {
            var culture = CultureInfo.GetCultureInfo(baseCode);
            // DisplayName 需要 UI culture 為 zh-TW；NativeName 則固定回傳該語言的自稱名稱。
            displayName = culture.DisplayName;
        }
        catch (CultureNotFoundException)
        {
            // 對應五、風險：CultureInfo 資料可能不含冷門語言代碼，查不到時原樣顯示。
            displayName = baseCode;
        }

        return isOriginal ? $"{displayName}（原文）" : displayName;
    }
}

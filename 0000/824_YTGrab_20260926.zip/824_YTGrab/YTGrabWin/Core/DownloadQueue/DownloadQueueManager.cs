using System;
using System.Collections.Concurrent;
using System.Collections.ObjectModel;
using System.Threading;
using System.Threading.Tasks;

namespace YTGrabWin.Core;

/// <summary>
/// 對應企劃案 2.3：Core/DownloadQueue/。佇列管理、狀態機。
/// 對應三、規格：下載佇列暫停/續傳/重試；播放列表批次畫質上限預設。
/// 對應 5.2：暫停/取消狀態誤判——需明確區分「使用者要求取消」與「行程自然結束/失敗」，
/// 因此以 CancellationTokenSource 搭配 DownloadTaskStatus 雙重狀態記錄，避免誤判。
/// </summary>
public sealed class DownloadQueueManager : IDisposable
{
    private readonly YTDLPClient _ytDlpClient;
    private readonly ConcurrentDictionary<string, CancellationTokenSource> _cancellationTokens = new();

    public ObservableCollection<DownloadTask> Tasks { get; } = new();

    public event EventHandler<DownloadTask>? TaskUpdated;

    /// <summary>最大同時下載數，對應下載佇列多任務追蹤（一、1.2 核心價值主張）。</summary>
    public int MaxConcurrentDownloads { get; set; } = 2;

    public DownloadQueueManager(YTDLPClient ytDlpClient)
    {
        _ytDlpClient = ytDlpClient;
    }

    public void Enqueue(DownloadTask task)
    {
        Tasks.Add(task);
        TaskUpdated?.Invoke(this, task);
    }

    public async Task StartAsync(DownloadTask task, string outputTemplate)
    {
        task.Status = DownloadTaskStatus.Downloading;
        TaskUpdated?.Invoke(this, task);

        var cts = new CancellationTokenSource();
        _cancellationTokens[task.Id] = cts;

        try
        {
            await _ytDlpClient.DownloadAsync(
                task.Url,
                task.FormatSelector,
                outputTemplate,
                onProgress: percent =>
                {
                    task.ProgressPercent = percent;
                    TaskUpdated?.Invoke(this, task);
                },
                onFinalFilePath: path =>
                {
                    task.FinalFilePath = path;
                },
                cts.Token);

            // 對應 5.2：需以實際回報的 FinalFilePath 是否成功取得來判斷完成，
            // 而非僅依賴行程 ExitCode（同一問題在 macOS 版亦已知）。
            task.Status = task.FinalFilePath is not null
                ? DownloadTaskStatus.Completed
                : DownloadTaskStatus.Failed;
        }
        catch (OperationCanceledException)
        {
            // 對應三、規格：暫停/取消區分——這裡代表使用者主動觸發 Pause/Cancel。
            task.Status = task.Status == DownloadTaskStatus.Paused
                ? DownloadTaskStatus.Paused
                : DownloadTaskStatus.Canceled;
        }
        catch (Exception ex)
        {
            task.Status = DownloadTaskStatus.Failed;
            task.ErrorMessage = ex.Message;
        }
        finally
        {
            _cancellationTokens.TryRemove(task.Id, out _);
            TaskUpdated?.Invoke(this, task);
        }
    }

    /// <summary>對應三、規格：下載佇列暫停。</summary>
    public void Pause(DownloadTask task)
    {
        if (_cancellationTokens.TryGetValue(task.Id, out var cts))
        {
            task.Status = DownloadTaskStatus.Paused;
            cts.Cancel();
        }
    }

    /// <summary>對應三、規格：下載佇列續傳（yt-dlp 本身支援 --continue，重新以相同輸出路徑呼叫）。</summary>
    public Task ResumeAsync(DownloadTask task, string outputTemplate) => StartAsync(task, outputTemplate);

    /// <summary>對應三、規格：下載佇列取消。</summary>
    public void Cancel(DownloadTask task)
    {
        if (_cancellationTokens.TryGetValue(task.Id, out var cts))
        {
            task.Status = DownloadTaskStatus.Canceled;
            cts.Cancel();
        }
    }

    /// <summary>對應三、規格：下載佇列重試。</summary>
    public Task RetryAsync(DownloadTask task, string outputTemplate)
    {
        task.RetryCount++;
        task.ErrorMessage = null;
        task.ProgressPercent = 0;
        return StartAsync(task, outputTemplate);
    }

    public void Dispose()
    {
        foreach (var cts in _cancellationTokens.Values)
        {
            cts.Cancel();
            cts.Dispose();
        }
    }
}

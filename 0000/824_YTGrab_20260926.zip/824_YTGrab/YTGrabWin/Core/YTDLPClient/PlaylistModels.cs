using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace YTGrabWin.Core;

/// <summary>
/// 對應企劃案 2.1：`System.Text.Json` + POCO model，對應 macOS 版的 `Codable` 對應 JSON。
/// 對應 `yt-dlp --flat-playlist --yes-playlist -J` 的精簡回應（不含逐支影片完整格式清單）。
/// </summary>
public sealed class PlaylistEntry
{
    [JsonPropertyName("id")]
    public string Id { get; set; } = string.Empty;

    [JsonPropertyName("title")]
    public string Title { get; set; } = string.Empty;

    [JsonPropertyName("url")]
    public string Url { get; set; } = string.Empty;

    [JsonPropertyName("duration")]
    public double? DurationSeconds { get; set; }
}

/// <summary>播放列表整體資訊，對應「播放列表勾選批次下載或純文字匯出」（一、1.1）。</summary>
public sealed class PlaylistInfo
{
    [JsonPropertyName("id")]
    public string Id { get; set; } = string.Empty;

    [JsonPropertyName("title")]
    public string Title { get; set; } = string.Empty;

    [JsonPropertyName("entries")]
    public List<PlaylistEntry> Entries { get; set; } = new();
}

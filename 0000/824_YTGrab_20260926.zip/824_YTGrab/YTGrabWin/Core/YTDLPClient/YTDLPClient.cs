using System;
using System.IO;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace YTGrabWin.Core;

/// <summary>
/// 對應企劃案二、2.1：核心引擎包裝層。與 macOS 版共用邏輯：
/// - `-J` / `--dump-json` 結構化資料驅動，不解析文字輸出
/// - `--no-playlist` / `--flat-playlist --yes-playlist` 網址分流
/// - `--progress-template` 自訂分隔符進度
/// - `--write-subs` / `--write-auto-subs` 字幕
/// - `--print-to-file after_move:%(filepath)s` 回報最終路徑
/// 這些是 yt-dlp 本身的行為，與作業系統無關，Windows 版僅換底層的 ProcessRunner 實作（見同檔）。
/// </summary>
public sealed class YTDLPClient : IDisposable
{
    private static string YtDlpPath => Path.Combine(AppContext.BaseDirectory, "Resources", "yt-dlp.exe");

    private readonly ProcessRunner _processRunner = new();

    /// <summary>
    /// 對應企劃案 5.1：yt-dlp 版本更新/下限，需內建自動檢查機制；
    /// `--print-to-file` 等較新旗標需要對應版本支援。
    /// </summary>
    public async Task<string> CheckVersionAsync(CancellationToken cancellationToken = default)
    {
        var output = new StringBuilder();
        var runner = new ProcessRunner();
        runner.StandardOutputLineReceived += (_, line) => output.AppendLine(line);
        await runner.RunAsync(YtDlpPath, "--version", cancellationToken);
        return output.ToString().Trim();
    }

    /// <summary>
    /// 讀取單一網址資訊，對應一、1.1「貼上網址讀取資訊」。
    /// 依網址是單支影片或播放列表分流：單支用 `--no-playlist -J`，
    /// 播放列表用 `--flat-playlist --yes-playlist -J`（見二、2.1）。
    /// </summary>
    public async Task<VideoInfo?> FetchVideoInfoAsync(string url, CancellationToken cancellationToken = default)
    {
        var jsonOutput = new StringBuilder();
        var runner = new ProcessRunner();
        runner.StandardOutputLineReceived += (_, line) => jsonOutput.AppendLine(line);

        var arguments = $"--no-playlist -J \"{url}\"";
        await runner.RunAsync(YtDlpPath, arguments, cancellationToken);

        var json = jsonOutput.ToString();
        if (string.IsNullOrWhiteSpace(json)) return null;

        return JsonSerializer.Deserialize<VideoInfo>(json, JsonOptions);
    }

    /// <summary>
    /// 讀取播放列表資訊，對應一、1.1「播放列表勾選批次下載」。
    /// </summary>
    public async Task<PlaylistInfo?> FetchPlaylistInfoAsync(string url, CancellationToken cancellationToken = default)
    {
        var jsonOutput = new StringBuilder();
        var runner = new ProcessRunner();
        runner.StandardOutputLineReceived += (_, line) => jsonOutput.AppendLine(line);

        var arguments = $"--flat-playlist --yes-playlist -J \"{url}\"";
        await runner.RunAsync(YtDlpPath, arguments, cancellationToken);

        var json = jsonOutput.ToString();
        if (string.IsNullOrWhiteSpace(json)) return null;

        return JsonSerializer.Deserialize<PlaylistInfo>(json, JsonOptions);
    }

    /// <summary>
    /// 下載指定格式／字幕。使用 `--progress-template` 自訂分隔符進度，供 DownloadQueueManager 解析。
    /// `--print-to-file after_move:%(filepath)s` 回報最終路徑（含轉檔/合併後的檔名）。
    /// </summary>
    public async Task<int> DownloadAsync(
        string url,
        string formatSelector,
        string outputTemplate,
        Action<double>? onProgress,
        Action<string>? onFinalFilePath,
        CancellationToken cancellationToken = default)
    {
        // 分隔符自訂避免與檔名或其他輸出混淆，與 macOS 版做法相同。
        const string progressDelimiter = "@@YTGRAB_PROGRESS@@";
        const string pathDelimiter = "@@YTGRAB_FILEPATH@@";

        var arguments =
            $"-f \"{formatSelector}\" " +
            $"-o \"{outputTemplate}\" " +
            $"--progress-template \"{progressDelimiter}%(progress._percent_str)s\" " +
            $"--print-to-file after_move:\"{pathDelimiter}%(filepath)s\" \"-\" " +
            $"\"{url}\"";

        var runner = new ProcessRunner();
        runner.StandardOutputLineReceived += (_, line) =>
        {
            if (line.StartsWith(progressDelimiter))
            {
                var percentText = line[progressDelimiter.Length..].TrimEnd('%').Trim();
                if (double.TryParse(percentText, out var percent))
                    onProgress?.Invoke(percent);
            }
            else if (line.StartsWith(pathDelimiter))
            {
                onFinalFilePath?.Invoke(line[pathDelimiter.Length..].Trim());
            }
        };

        return await runner.RunAsync(YtDlpPath, arguments, cancellationToken);
    }

    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNameCaseInsensitive = true
    };

    public void Dispose()
    {
        // 保留擴充點：若未來持有長生命週期的行程或連線，於此釋放。
    }
}

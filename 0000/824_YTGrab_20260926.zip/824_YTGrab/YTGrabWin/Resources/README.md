# Resources

請將以下執行檔放置於此資料夾：

- `yt-dlp.exe`
- `ffmpeg.exe`

對應企劃案二、2.1／2.3：核心引擎 yt-dlp.exe 與 ffmpeg.exe 隨 App 打包（或首次啟動下載）。
`Core/YTDLPClient/YTDLPClient.cs` 與 `Core/ProcessRunner/` 皆假設這兩支執行檔位於
`AppContext.BaseDirectory/Resources/` 下。

對應五、風險：
- ffmpeg 授權（LGPL/GPL）組態需確認，尤其影響上架 Microsoft Store 的散布條件。
- yt-dlp 版本需定期更新，`YTDLPClient.CheckVersionAsync()` 提供版本檢查掛勾點，
  實際自動更新機制留待 Phase 7 規劃。

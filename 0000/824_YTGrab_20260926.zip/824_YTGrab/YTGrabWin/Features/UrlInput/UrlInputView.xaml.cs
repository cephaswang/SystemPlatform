using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace YTGrabWin.Features.UrlInput;

/// <summary>
/// 對應企劃案四：網址輸入列。
/// 對應三、平台差異表：剪貼簿偵測（此處先以按鈕觸發 Clipboard.GetText()，
/// 若第七章「批次貼上多網址」定案，可擴充為多行輸入＋自動輪詢偵測）。
/// </summary>
public partial class UrlInputView : UserControl
{
    /// <summary>使用者送出網址（按 Enter 或點擊「讀取資訊」）。</summary>
    public event EventHandler<string>? UrlSubmitted;

    public UrlInputView()
    {
        InitializeComponent();
    }

    public void SetUrl(string url) => UrlTextBox.Text = url;

    private void SubmitButton_Click(object sender, RoutedEventArgs e) => Submit();

    private void UrlTextBox_KeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.Enter) Submit();
    }

    private void PasteFromClipboardButton_Click(object sender, RoutedEventArgs e)
    {
        if (Clipboard.ContainsText())
        {
            UrlTextBox.Text = Clipboard.GetText().Trim();
        }
    }

    private void Submit()
    {
        var url = UrlTextBox.Text.Trim();
        if (!string.IsNullOrEmpty(url))
        {
            UrlSubmitted?.Invoke(this, url);
        }
    }
}

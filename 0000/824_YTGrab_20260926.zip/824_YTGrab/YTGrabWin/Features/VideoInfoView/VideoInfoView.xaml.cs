using System;
using System.Linq;
using System.Windows.Controls;
using YTGrabWin.Core;

namespace YTGrabWin.Features.VideoInfo;

/// <summary>
/// 對應企劃案四：影片資訊卡＋畫質/字幕/音訊 Tab。
/// 對應三、規格：畫質音訊分類過濾規則（IsVideoOnly／IsAudioOnly，見 Core.FormatInfo）、
/// 字幕分組排序搜尋（此處先提供基本清單＋搜尋框，分組排序邏輯沿用 macOS 版規格待補完整實作）。
/// </summary>
public partial class VideoInfoView : UserControl
{
    private Core.VideoInfo? _currentVideo;
    private string? _currentUrl;

    public VideoInfoView()
    {
        InitializeComponent();
        SubtitleSearchBox.TextChanged += (_, _) => FilterSubtitles();
    }

    public void LoadVideo(Core.VideoInfo video, string url)
    {
        _currentVideo = video;
        _currentUrl = url;

        TitleText.Text = video.Title;
        UploaderText.Text = video.Uploader ?? string.Empty;
        DurationText.Text = video.DurationSeconds is double seconds
            ? TimeSpan.FromSeconds(seconds).ToString(@"hh\:mm\:ss")
            : string.Empty;

        // 對應三、規格：畫質音訊分類過濾規則。
        QualityFormatsListView.ItemsSource = video.Formats.Where(f => !f.IsAudioOnly).ToList();
        AudioFormatsListView.ItemsSource = video.Formats.Where(f => f.IsAudioOnly).ToList();

        var allSubtitles = (video.Subtitles ?? new())
            .Concat(video.AutomaticCaptions ?? new())
            .SelectMany(kv => kv.Value.Select(s =>
            {
                s.LanguageCode = kv.Key;
                return s;
            }))
            .ToList();
        SubtitlesListView.ItemsSource = allSubtitles;
    }

    /// <summary>對應四：字幕 Tab 搜尋＋分組清單（此處先實作純文字搜尋過濾）。</summary>
    private void FilterSubtitles()
    {
        if (_currentVideo is null) return;

        var keyword = SubtitleSearchBox.Text.Trim();
        var allSubtitles = (_currentVideo.Subtitles ?? new())
            .Concat(_currentVideo.AutomaticCaptions ?? new())
            .SelectMany(kv => kv.Value.Select(s =>
            {
                s.LanguageCode = kv.Key;
                return s;
            }))
            .Where(s => string.IsNullOrEmpty(keyword) ||
                        s.LanguageCode.Contains(keyword, StringComparison.OrdinalIgnoreCase))
            .ToList();
        SubtitlesListView.ItemsSource = allSubtitles;
    }
}

using System.Windows;
using System.Windows.Controls;
using YTGrabWin.Core;

namespace YTGrabWin.Features.DownloadQueue;

/// <summary>
/// 對應企劃案一、1.2：下載佇列與多任務進度追蹤。
/// 對應三、規格：暫停/續傳/重試操作介面。
/// </summary>
public partial class DownloadQueueView : UserControl
{
    private Core.DownloadQueueManager? _queueManager;
    private string _outputTemplate = string.Empty;

    public DownloadQueueView()
    {
        InitializeComponent();
    }

    public void Bind(Core.DownloadQueueManager queueManager)
    {
        _queueManager = queueManager;
        _outputTemplate = System.IO.Path.Combine(
            App.App.State.Settings.Current.DownloadFolder, "%(title)s.%(ext)s");
        QueueListView.ItemsSource = queueManager.Tasks;
    }

    private void PauseButton_Click(object sender, RoutedEventArgs e)
    {
        if (((FrameworkElement)sender).Tag is DownloadTask task)
            _queueManager?.Pause(task);
    }

    private async void RetryButton_Click(object sender, RoutedEventArgs e)
    {
        if (((FrameworkElement)sender).Tag is DownloadTask task && _queueManager is not null)
            await _queueManager.RetryAsync(task, _outputTemplate);
    }

    private void CancelButton_Click(object sender, RoutedEventArgs e)
    {
        if (((FrameworkElement)sender).Tag is DownloadTask task)
            _queueManager?.Cancel(task);
    }
}

using System.Linq;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;

namespace YTGrabWin.Features.Settings;

/// <summary>
/// 對應企劃案四／第七章：設定頁（下載資料夾、播放列表批次畫質上限、系統匣常駐模式）。
/// </summary>
public partial class SettingsView : Window
{
    private readonly Core.SettingsStore _settingsStore = App.App.State.Settings;

    public SettingsView()
    {
        InitializeComponent();

        var current = _settingsStore.Current;
        DownloadFolderTextBox.Text = current.DownloadFolder;
        MinimizeToTrayCheckBox.IsChecked = current.MinimizeToTray;

        foreach (ComboBoxItem item in MaxQualityComboBox.Items)
        {
            if ((string)item.Content == current.DefaultPlaylistMaxQuality)
            {
                MaxQualityComboBox.SelectedItem = item;
                break;
            }
        }
    }

    private void BrowseButton_Click(object sender, RoutedEventArgs e)
    {
        // WPF 未內建資料夾選擇對話框，使用 OpenFileDialog 的資料夾選取變通做法，
        // 或於實作階段改用 Windows API Code Pack / WinForms FolderBrowserDialog。
        var dialog = new OpenFolderDialogFallback();
        var selected = dialog.SelectFolder(DownloadFolderTextBox.Text);
        if (selected is not null) DownloadFolderTextBox.Text = selected;
    }

    private void SaveButton_Click(object sender, RoutedEventArgs e)
    {
        var current = _settingsStore.Current;
        current.DownloadFolder = DownloadFolderTextBox.Text;
        current.MinimizeToTray = MinimizeToTrayCheckBox.IsChecked == true;
        current.DefaultPlaylistMaxQuality = (string)((ComboBoxItem)MaxQualityComboBox.SelectedItem).Content;
        _settingsStore.Save();
        Close();
    }

    private void CancelButton_Click(object sender, RoutedEventArgs e)
    {
        Close();
    }
}

/// <summary>
/// 佔位用資料夾選擇器。.NET 8 起 Microsoft.Win32.OpenFolderDialog 已可用；
/// 若目標 SDK 版本不含此類別，改用 System.Windows.Forms.FolderBrowserDialog（需加入 WinForms 參考）。
/// </summary>
internal sealed class OpenFolderDialogFallback
{
    public string? SelectFolder(string initialDirectory)
    {
        var dialog = new OpenFolderDialog { InitialDirectory = initialDirectory };
        return dialog.ShowDialog() == true ? dialog.FolderName : null;
    }
}

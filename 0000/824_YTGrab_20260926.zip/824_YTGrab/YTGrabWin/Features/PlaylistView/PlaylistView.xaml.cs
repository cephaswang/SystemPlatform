using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using YTGrabWin.Core;

namespace YTGrabWin.Features.Playlist;

/// <summary>可勾選的播放列表項目包裝類別，供 ListView 資料繫結使用。</summary>
public sealed class SelectablePlaylistEntry
{
    public required PlaylistEntry Entry { get; init; }
    public bool IsSelected { get; set; } = true;
}

/// <summary>
/// 對應企劃案四：播放列表模式，勾選清單＋批次動作列。
/// 對應第七章待確認事項：播放列表批次下載是否支援字幕、檔名是否加序號前綴
/// （此處先只處理畫質批次下載，字幕批次與序號前綴留待定案後於 MainWindow 的輸出樣板擴充）。
/// </summary>
public partial class PlaylistView : UserControl
{
    private readonly ObservableCollection<SelectablePlaylistEntry> _entries = new();

    /// <summary>使用者按下「批次下載選取項目」，回傳勾選的項目清單。</summary>
    public event EventHandler<IReadOnlyList<PlaylistEntry>>? BatchDownloadRequested;

    public PlaylistView()
    {
        InitializeComponent();
        EntriesListView.ItemsSource = _entries;
    }

    public void LoadPlaylist(PlaylistInfo playlistInfo)
    {
        PlaylistTitleText.Text = $"{playlistInfo.Title}（共 {playlistInfo.Entries.Count} 支影片）";
        _entries.Clear();
        foreach (var entry in playlistInfo.Entries)
        {
            _entries.Add(new SelectablePlaylistEntry { Entry = entry, IsSelected = true });
        }
    }

    private void SelectAllButton_Click(object sender, RoutedEventArgs e)
    {
        foreach (var item in _entries) item.IsSelected = true;
        EntriesListView.Items.Refresh();
    }

    private void DeselectAllButton_Click(object sender, RoutedEventArgs e)
    {
        foreach (var item in _entries) item.IsSelected = false;
        EntriesListView.Items.Refresh();
    }

    private void BatchDownloadButton_Click(object sender, RoutedEventArgs e)
    {
        var selected = _entries.Where(x => x.IsSelected).Select(x => x.Entry).ToList();
        if (selected.Count == 0)
        {
            MessageBox.Show("請至少勾選一支影片。", "提醒", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }
        BatchDownloadRequested?.Invoke(this, selected);
    }
}

using System;
using System.Threading;
using System.Windows;

namespace YTGrabWin.App;

/// <summary>
/// 對應企劃案 2.3：App 進入點，Mutex 防多開。
/// </summary>
public partial class App : Application
{
    private const string MutexName = "YTGrabWin.SingleInstance.Mutex";
    private Mutex? _singleInstanceMutex;

    public static AppState State { get; private set; } = new AppState();

    protected override void OnStartup(StartupEventArgs e)
    {
        // 對應企劃案 2.3：Mutex 防多開，避免多個實例同時操作同一個下載佇列/資料庫。
        _singleInstanceMutex = new Mutex(initiallyOwned: true, MutexName, out var createdNew);
        if (!createdNew)
        {
            MessageBox.Show("YTGrab 已在執行中。", "YTGrab", MessageBoxButton.OK, MessageBoxImage.Information);
            Shutdown();
            return;
        }

        base.OnStartup(e);

        // 對應企劃案 5.1：yt-dlp 版本更新/下限，需內建自動檢查機制。
        _ = State.YtDlpClient.CheckVersionAsync();
    }

    protected override void OnExit(ExitEventArgs e)
    {
        // 對應企劃案：離開前應暫停或標記進行中的下載，供下次啟動續傳（見 DownloadQueue）。
        State.Dispose();
        _singleInstanceMutex?.ReleaseMutex();
        base.OnExit(e);
    }
}

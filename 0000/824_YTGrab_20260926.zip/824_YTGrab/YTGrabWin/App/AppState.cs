using System;
using YTGrabWin.Core;

namespace YTGrabWin.App;

/// <summary>
/// 對應企劃案 2.3：App/AppState.cs 全域狀態容器。
/// 持有跨畫面共用的服務實例（yt-dlp 客戶端、下載佇列、設定）。
/// </summary>
public sealed class AppState : IDisposable
{
    /// <summary>對應企劃案 2.1／二 2.3：ProcessRunner + YTDLPClient，結構化資料驅動（-J）。</summary>
    public YTDLPClient YtDlpClient { get; } = new YTDLPClient();

    /// <summary>對應企劃案三：下載佇列暫停/續傳/重試的狀態機。</summary>
    public DownloadQueueManager DownloadQueue { get; }

    /// <summary>對應企劃案 2.1：appsettings.json / 機碼設定 + SQLite 本地儲存。</summary>
    public SettingsStore Settings { get; } = new SettingsStore();

    /// <summary>對應企劃案七：常用語言置頂清單（是否可自訂，見待確認事項）。</summary>
    public LanguageNameResolver LanguageResolver { get; } = new LanguageNameResolver();

    public AppState()
    {
        DownloadQueue = new DownloadQueueManager(YtDlpClient);
    }

    public void Dispose()
    {
        DownloadQueue.Dispose();
        YtDlpClient.Dispose();
    }
}

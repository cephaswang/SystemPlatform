# yt-dlp Windows 10 App 企劃案

**專案代號：YTGrab for Windows** **技術路線：.NET 8 / WPF** **版本：v0.1 草案（依 macOS 版 v0.4 改寫）**

---

## 一、專案概述

### 1.1 專案目標

與 macOS 版相同：原生 Windows 10 桌面應用，作為 yt-dlp 的圖形化前端——貼上網址讀取資訊、瀏覽並下載字幕（含自動生成/翻譯，繁中顯示）、選畫質下載、播放列表勾選批次下載或純文字匯出、完成後可直接開啟檔案或於檔案總管顯示。

### 1.2 核心價值主張

- 原生 WPF 介面，符合 Windows 使用習慣
- 結構化資料驅動（`-J` / `--dump-json`），不解析文字輸出
- 下載佇列與多任務進度追蹤

### 1.3 非目標（v1 暫不處理）

影片編輯、雲端同步、行動版。

---

## 二、技術架構

### 2.1 技術棧對照（macOS → Windows）

| 項目 | macOS 版 | Windows 版 |
| --- | --- | --- |
| UI 框架 | SwiftUI + AppKit 橋接 | WPF（.NET 8），或 WinUI 3 |
| 核心引擎 | yt-dlp 執行檔隨 App 打包 | 相同：yt-dlp.exe 隨 App 打包或首次啟動下載 |
| 音視訊合併/轉檔 | ffmpeg 打包 | ffmpeg.exe 打包（相同邏輯） |
| 程序通訊 | `Foundation.Process` + `Pipe` | `System.Diagnostics.Process` + 非同步讀取 `StandardOutput`/`StandardError` |
| 資料解析 | `Codable` 對應 JSON | `System.Text.Json` + POCO model |
| 本地儲存 | `UserDefaults` + SQLite/SwiftData | `appsettings.json` 或機碼設定 + SQLite（`Microsoft.Data.Sqlite`） |
| 檔案總管操作 | Finder 顯示/開啟 | `Explorer.exe /select,"路徑"`（顯示）、`Process.Start`（開啟預設程式） |
| 系統通知 | macOS 通知中心 | Windows Toast 通知（`Microsoft.Toolkit.Uwp.Notifications` 或 WinUI 通知 API） |
| Dock 進度 | Dock icon 進度 | 工作列縮圖進度（`ITaskbarList3` COM 介面） |

其餘整合邏輯（`-J` 結構化解析、`--no-playlist` / `--flat-playlist --yes-playlist` 網址分流、`--progress-template` 自訂分隔符進度、字幕 `--write-subs`/`--write-auto-subs`、`--print-to-file after_move:%(filepath)s` 回報最終路徑、雙背景執行緒讀取 stdout/stderr 至 EOF）**與 macOS 版完全相同**，因為這些是 yt-dlp 本身的行為，與作業系統無關。

### 2.2 語言名稱轉換

macOS 版使用系統 `Locale` API 轉語言代碼為繁中名稱。Windows 對應改用 `System.Globalization.CultureInfo`（`CultureInfo.GetCultureInfo(code).NativeName` / `.DisplayName`，`DisplayName` 需設定 UI culture 為 `zh-TW` 或以 ICU 資料表對照），查不到的代碼原樣顯示；`-orig` 後綴另外處理，邏輯不變。

### 2.3 專案模組拆分

```
YTGrabWin/
├── App/
│   ├── App.xaml(.cs)            # 進入點，Mutex 防多開
│   └── AppState.cs              # 全域狀態
├── Core/
│   ├── ProcessRunner/           # Process + 非同步 stdout/stderr 讀取
│   ├── YTDLPClient/
│   │   ├── YTDLPClient.cs
│   │   └── PlaylistModels.cs
│   ├── Models/                  # VideoInfo, FormatInfo, SubtitleInfo, DownloadTask
│   ├── DownloadQueue/           # 佇列管理、狀態機
│   └── Utilities/
│       └── ExplorerActions.cs   # 檔案總管顯示/開啟，含 fallback
├── Features/
│   ├── MainWindow.xaml          # 主畫面
│   ├── UrlInput/
│   ├── VideoInfoView/
│   ├── PlaylistView/
│   ├── DownloadQueueView/
│   └── Settings/
├── docs/
└── Resources/
    ├── yt-dlp.exe
    └── ffmpeg.exe
```

---

## 三、核心功能規格（與 macOS 版一致，僅列平台差異）

功能邏輯（單支/播放列表網址分流、畫質音訊分類過濾規則、字幕分組排序搜尋、下載佇列暫停/續傳/重試、播放列表批次畫質上限預設、純文字匯出格式）**全部沿用 macOS 版第三章規格**，此處僅列 Windows 平台需調整之處：

| 項目 | 差異說明 |
| --- | --- |
| 資料夾名稱清理字元 | Windows 保留字元為 `\ / : * ? " < > \|`，與 macOS 版清理規則相同字元集，可直接沿用 |
| 檔案總管顯示/選取 | 改用 `explorer.exe /select,"完整路徑"` |
| 開啟檔案 | `Process.Start(new ProcessStartInfo(path) { UseShellExecute = true })`，模擬雙擊行為 |
| 下載完成通知 | Windows Toast，需在 App 安裝時註冊 AUMID（Application User Model ID） |
| 拖放網址 | WPF `AllowDrop` + `Drop` 事件，取代 macOS 的拖放到 App 圖示 |
| 剪貼簿偵測 | `Clipboard.GetText()` 輪詢或監聽 `WM_CLIPBOARDUPDATE` |

---

## 四、UI / UX 規劃

版面配置（主畫面：網址輸入列、影片資訊卡＋畫質/字幕/音訊 Tab、下載資料夾列、下載佇列、設定入口；播放列表模式：勾選清單＋批次動作列；字幕 Tab：搜尋＋分組清單）**直接沿用 macOS 版第四章的畫面配置**，僅將 macOS 控制項替換為 WPF 對應元件（`TabControl`、`ListView`/`DataGrid`、`ProgressBar`）。是否提供系統匣（Tray）常駐模式，比照 macOS 版選單列模式的待確認事項，見第七章。

---

## 五、其他技術細節與風險

### 5.1 風險

| 項目 | 說明 |
| --- | --- |
| yt-dlp 版本更新/下限 | 與 macOS 版相同：需內建自動檢查機制；`--print-to-file` 需求較新版本 |
| ffmpeg 依賴與授權 | 隨 App 打包增加體積；LGPL/GPL 組態需確認，尤其影響上架 Microsoft Store 的散布條件 |
| 字幕限速與轉檔 | 與 macOS 版相同 |
| 語言名稱來源 | `CultureInfo` 資料可能不含冷門語言代碼 |
| Cookies 支援 | `--cookies-from-browser` 讀取瀏覽器資料，需注意瀏覽器儲存路徑與加密方式（Windows 上 Chrome/Edge 的 Cookie 以 DPAPI 加密，跨使用者權限存取需留意） |
| **應用程式簽章** | 未簽章的 .exe/安裝檔在 Windows 上會被 SmartScreen 標示「未知發行者」警告；需要程式碼簽章憑證（EV 憑證可即時建立信譽，避免警告） |
| **MSIX 封裝與 Store 上架限制** | 若上架 Microsoft Store，MSIX 套件的 App Container 沙盒對執行外部 exe（yt-dlp、ffmpeg）、任意檔案系統存取有限制，需以套件內容執行子行程並宣告 `runFullTrust`（Desktop Bridge）或改用非沙盒的獨立安裝程式 |
| **下載第三方平台媒體** | Microsoft Store 政策同樣禁止未經授權下載/轉存第三方媒體服務內容（對應 macOS 版 5.2.3 之障礙）；核心功能定位問題，與 macOS 版結論相同 |
| Store 版自動更新衝突 | Store 政策不允許下載並執行改變功能的程式碼；上架版 yt-dlp 需隨 App 更新發版 |
| 法律與條款考量 | 與 macOS 版相同 |

### 5.2 已知問題與技術債

沿用 macOS 版第五章已知問題清單中與 yt-dlp 邏輯相關的項目（video-only 無聲、暫停/取消狀態誤判、`readabilityHandler`/串流讀取遺失末段輸出、格式分類未經實機驗證等），這些屬於**核心引擎邏輯層**問題，移植至 Windows 版時需重新以 .NET 對應 API（如 `Process.OutputDataReceived` 事件模式同樣有「行程結束前緩衝區未讀完」的已知陷阱）驗證是否重現。

---

## 六、開發階段規劃（建議）

| 階段 | 內容 |
| --- | --- |
| Phase 1 | ProcessRunner + YTDLPClient，單一影片資訊讀取與 JSON 解析 |
| Phase 2 | 畫質選擇與基本下載（含進度） |
| Phase 3 | 字幕功能（讀取、語言/格式選擇、下載） |
| Phase 4 | 下載佇列（多任務、暫停/取消/重試） |
| Phase 5 | 播放列表支援、Cookies 匯入 |
| Phase 6 | UI 打磨、系統匣模式、Toast 通知、工作列進度、設定頁 |
| Phase 7 | yt-dlp/ffmpeg 打包、程式碼簽章、自動更新機制、發布（獨立安裝檔 或 Microsoft Store） |

---

## 七、待確認事項

- [ ] 發行路線：獨立安裝檔（Inno Setup / MSI，需程式碼簽章）或 Microsoft Store（MSIX，需處理 App Container 限制）
- [ ] 是否需要系統匣常駐模式
- [ ] 是否支援批次貼上多網址
- [ ] 播放列表批次下載是否支援字幕、檔名是否加播放列表序號前綴
- [ ] 常用語言置頂清單是否可自訂
- [ ] 若走 Microsoft Store：功能範圍是否需限縮（比照 macOS 版 5.2.3 障礙的因應方式），並準備對應的審核說明文件

> 第八章「App Store 送審回覆準備」為 macOS 專屬流程（App Review 六項資訊、Sandbox entitlements 等），不直接適用 Windows；若確定上架 Microsoft Store，建議另立一份對應 Microsoft Store 政策（尤其 4.9.1 第三方內容存取規範）的送審備忘，架構可比照 macOS 版第八章的「先列障礙、再備回覆稿」做法。

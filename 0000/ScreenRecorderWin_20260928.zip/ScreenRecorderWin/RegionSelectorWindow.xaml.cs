using System;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using Forms = System.Windows.Forms;

namespace ScreenRecorderWin
{
    /// <summary>
    /// 自訂範圍拖曳選取視窗。
    /// 使用方式：<c>new RegionSelectorWindow(screen).ShowDialog()</c>，
    /// 完成有效選取時 <see cref="ShowDialog"/> 回傳 true，並可從 <see cref="SelectedRegion"/> 取得結果；
    /// 按 Esc 則回傳 false，<see cref="SelectedRegion"/> 為 null。
    /// 拖曳範圍過小（小於 <see cref="RecorderManager.MinRegionEdgePx"/> 像素）時不會結束，讓使用者重選。
    /// </summary>
    public partial class RegionSelectorWindow : Window
    {
        private readonly Forms.Screen _targetScreen;
        private Point? _dragStartPoint;

        /// <summary>
        /// 選取結果：「虛擬桌面實體像素」座標（已取偶數寬高、已限制在目標螢幕內），
        /// 與 <see cref="Forms.Screen.Bounds"/> 在 Per-Monitor V2 下為同一座標系。
        /// RecorderManager 只需扣除螢幕左上角即可得到擷取畫面內的裁切矩形，不可再乘 DPI。
        /// </summary>
        public Rect? SelectedRegion { get; private set; }

        public RegionSelectorWindow(Forms.Screen targetScreen)
        {
            _targetScreen = targetScreen ?? throw new ArgumentNullException(nameof(targetScreen));
            InitializeComponent();
        }

        // ---- 視窗定位 ------------------------------------------------------------
        // 重要：WPF 的 Window.Left/Top/Width/Height 永遠是「裝置無關單位（DIP）」，
        // 即使 app.manifest 設為 PerMonitorV2 也一樣；不能把 Screen.Bounds（實體像素）直接指派給它們。
        // 這裡改用 SetWindowPos 以實體像素定位，並在 DPI 改變（視窗被搬到不同縮放的螢幕）時重新套用。

        protected override void OnSourceInitialized(EventArgs e)
        {
            base.OnSourceInitialized(e);
            PlaceOnTargetScreen();
        }

        protected override void OnDpiChanged(DpiScale oldDpi, DpiScale newDpi)
        {
            base.OnDpiChanged(oldDpi, newDpi);
            // WM_DPICHANGED 會讓系統依建議矩形重設大小；稍後再蓋回實體像素的螢幕範圍。
            Dispatcher.BeginInvoke(new Action(PlaceOnTargetScreen));
        }

        private void PlaceOnTargetScreen()
        {
            IntPtr hwnd = new WindowInteropHelper(this).Handle;
            if (hwnd == IntPtr.Zero)
            {
                return;
            }

            var b = _targetScreen.Bounds;
            SetWindowPos(hwnd, IntPtr.Zero, b.Left, b.Top, b.Width, b.Height, SWP_NOZORDER | SWP_NOACTIVATE);
        }

        private void RegionSelectorWindow_OnLoaded(object sender, RoutedEventArgs e)
        {
            PlaceOnTargetScreen();

            Activate();
            Focus();
            Keyboard.Focus(this);
        }

        private void RegionSelectorWindow_OnPreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Escape)
            {
                SelectedRegion = null;
                DialogResult = false; // 設定 DialogResult 本身就會關閉視窗，不需再呼叫 Close()
            }
        }

        private void RootGrid_OnMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            _dragStartPoint = e.GetPosition(RootGrid);

            HintText.Visibility = Visibility.Collapsed;
            SelectionRect.Visibility = Visibility.Visible;
            SizeLabel.Visibility = Visibility.Visible;

            UpdateSelectionVisual(_dragStartPoint.Value, _dragStartPoint.Value);

            RootGrid.CaptureMouse();
        }

        private void RootGrid_OnMouseMove(object sender, MouseEventArgs e)
        {
            if (_dragStartPoint is not Point start)
            {
                return;
            }

            Point current = e.GetPosition(RootGrid);
            UpdateSelectionVisual(start, current);
        }

        private void RootGrid_OnMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (_dragStartPoint is not Point start)
            {
                return;
            }

            RootGrid.ReleaseMouseCapture();

            Point end = e.GetPosition(RootGrid);
            _dragStartPoint = null;

            // DIP → 虛擬桌面實體像素（PerMonitorV2 下 PointToScreen 回傳實體像素）。
            Point screenStart = RootGrid.PointToScreen(start);
            Point screenEnd = RootGrid.PointToScreen(end);
            Rect physical = BuildRect(screenStart, screenEnd);

            // 限制在目標螢幕範圍內。
            var b = _targetScreen.Bounds;
            physical.Intersect(new Rect(b.Left, b.Top, b.Width, b.Height));

            int min = RecorderManager.MinRegionEdgePx;
            if (physical.IsEmpty)
            {
                ShowTooSmall(end, min);
                return;
            }

            int x = (int)Math.Round(physical.X);
            int y = (int)Math.Round(physical.Y);
            int w = (int)Math.Round(physical.Width) & ~1;   // H.264 要求偶數寬高
            int h = (int)Math.Round(physical.Height) & ~1;

            if (w < min || h < min)
            {
                // 過小的範圍會讓硬體 H.264 編碼器初始化失敗甚至卡死：提示並讓使用者重新拖曳。
                ShowTooSmall(end, min);
                return;
            }

            SelectedRegion = new Rect(x, y, w, h);
            DialogResult = true; // 會自動關閉視窗
        }

        private void ShowTooSmall(Point at, int min)
        {
            SelectionRect.Visibility = Visibility.Collapsed;
            HintText.Visibility = Visibility.Visible;

            SizeLabel.Text = $"範圍太小，至少 {min} x {min} 像素";
            SizeLabel.Margin = new Thickness(at.X + 6, at.Y + 6, 0, 0);
            SizeLabel.Visibility = Visibility.Visible;
        }

        private void UpdateSelectionVisual(Point start, Point current)
        {
            Rect rect = BuildRect(start, current);

            SelectionRect.Margin = new Thickness(rect.X, rect.Y, 0, 0);
            SelectionRect.Width = rect.Width;
            SelectionRect.Height = rect.Height;

            // 顯示實際輸出的「像素」尺寸（DIP × 縮放），與最後錄出來的解析度一致。
            DpiScale dpi = VisualTreeHelper.GetDpi(RootGrid);
            SizeLabel.Text = $"{(int)(rect.Width * dpi.DpiScaleX)} x {(int)(rect.Height * dpi.DpiScaleY)}";
            // 尺寸標籤跟隨選取框右下角，並預留少許邊距避免緊貼滑鼠游標。
            SizeLabel.Margin = new Thickness(rect.X + rect.Width + 6, rect.Y + rect.Height + 6, 0, 0);
        }

        private static Rect BuildRect(Point a, Point b)
        {
            double x = Math.Min(a.X, b.X);
            double y = Math.Min(a.Y, b.Y);
            double width = Math.Abs(a.X - b.X);
            double height = Math.Abs(a.Y - b.Y);
            return new Rect(x, y, width, height);
        }

        #region Win32

        private const uint SWP_NOZORDER = 0x0004;
        private const uint SWP_NOACTIVATE = 0x0010;

        [DllImport("user32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter,
            int x, int y, int cx, int cy, uint uFlags);

        #endregion
    }
}

using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using Forms = System.Windows.Forms;               // Screen（多螢幕資訊、DPI）
using Windows.Graphics.Capture;                    // WGC：GraphicsCaptureItem / Session / FramePool
using Windows.Graphics.DirectX;                     // DirectXPixelFormat
using Windows.Graphics.DirectX.Direct3D11;          // IDirect3DDevice / IDirect3DSurface
using SharpDX.Direct3D11;
using SharpDX.DXGI;
using SharpDX.MediaFoundation;
using Device = SharpDX.Direct3D11.Device;
using Resource = SharpDX.Direct3D11.Resource;

namespace ScreenRecorderWin
{
    /// <summary>錄影結束事件的結果資料。</summary>
    public sealed class RecordingStoppedEventArgs : EventArgs
    {
        public bool Success { get; }
        public string? OutputPath { get; }
        public string? ErrorMessage { get; }

        public RecordingStoppedEventArgs(bool success, string? outputPath, string? errorMessage = null)
        {
            Success = success;
            OutputPath = outputPath;
            ErrorMessage = errorMessage;
        }
    }

    /// <summary>
    /// 共用的錄影時鐘：負責「暫停/續錄時間戳位移」演算法。
    /// 錄製中的每一顆畫面／音訊樣本，時間戳一律取「牆鐘經過時間 － 累計暫停時間」，
    /// 暫停期間本身不產生任何樣本（畫面直接丟棄、音訊擷取暫停），因此續錄後輸出時間軸維持連續、不留空隙。
    /// 音訊（AudioMixer）與視訊（RecorderManager）共用同一顆時鐘，確保兩軌對齊。
    /// </summary>
    public sealed class RecordingClock
    {
        private readonly Stopwatch _stopwatch = new();
        private readonly object _lock = new();
        private TimeSpan _accumulatedPause = TimeSpan.Zero;
        private DateTime? _pauseStartedAtUtc;

        public bool IsPaused { get; private set; }

        public void Start() => _stopwatch.Start();

        public void Pause()
        {
            lock (_lock)
            {
                if (IsPaused) return;
                IsPaused = true;
                _pauseStartedAtUtc = DateTime.UtcNow;
            }
        }

        public void Resume()
        {
            lock (_lock)
            {
                if (!IsPaused) return;
                if (_pauseStartedAtUtc.HasValue)
                {
                    _accumulatedPause += DateTime.UtcNow - _pauseStartedAtUtc.Value;
                    _pauseStartedAtUtc = null;
                }
                IsPaused = false;
            }
        }

        public void Stop() => _stopwatch.Stop();

        /// <summary>目前錄影「有效經過時間」（已扣除暫停區間），供 UI 顯示已錄製時長。</summary>
        public TimeSpan Elapsed => _stopwatch.Elapsed - _accumulatedPause;

        /// <summary>取得目前樣本應使用的時間戳，單位為 100 奈秒（Media Foundation 慣用單位）。</summary>
        public long GetTimestamp100Ns() => Elapsed.Ticks; // TimeSpan.Ticks 本身即為 100ns 單位，無需換算
    }

    /// <summary>
    /// 核心錄影邏輯。
    /// 資料流：Windows.Graphics.Capture 取得畫面 frame → （視需要裁切自訂範圍）→
    ///         寫入 Media Foundation SinkWriter 視訊串流；WASAPI（由 AudioMixer 負責）
    ///         同步寫入音訊串流；兩者共用 <see cref="RecordingClock"/> 時間戳，暫停時兩者同步停寫。
    /// </summary>
    public sealed class RecorderManager : IDisposable
    {
        private const int TargetFrameRate = 30;
        /// <summary>自訂範圍每邊的最小像素數；過小的畫面會讓硬體 H.264 編碼器初始化失敗甚至卡死。</summary>
        public const int MinRegionEdgePx = 128;
        private const int VideoBitrate = 8_000_000; // 8 Mbps，MVP 階段固定值，後續可視解析度調整

        public event EventHandler<RecordingStoppedEventArgs>? RecordingStopped;

        public bool IsRecording { get; private set; }

        /// <summary>
        /// Start() 之後可讀取：要求的音訊來源中有無法使用者（例如沒有麥克風、被 Windows 隱私設定擋住）時的提示文字，
        /// 該路以靜音代替、錄影照常進行；一切正常或未要求音訊時為 null。
        /// </summary>
        public string? AudioWarning { get; private set; }

        private bool HasAudio => _recordSystemAudio || _recordMicrophone;
        public TimeSpan Elapsed => _clock.Elapsed;

        private readonly Forms.Screen _targetScreen;
        private readonly Rect? _customRegion;
        private readonly bool _recordSystemAudio;
        private readonly bool _recordMicrophone;
        private readonly string _outputPath;
        private readonly RecordingClock _clock = new();

        // WGC / D3D11
        private Device? _d3dDevice;
        private IDirect3DDevice? _winrtDevice;
        private GraphicsCaptureItem? _captureItem;
        private Direct3D11CaptureFramePool? _framePool;
        private GraphicsCaptureSession? _captureSession;
        private int _captureWidth;
        private int _captureHeight;

        // 輸出裁切區域（相對於擷取畫面左上角的像素座標），null 表示輸出整個擷取畫面（全螢幕）
        private System.Drawing.Rectangle? _cropRegionPx;

        // Media Foundation
        private SinkWriter? _sinkWriter;
        private int _videoStreamIndex;
        private int _audioStreamIndex;
        private bool _mfStarted;

        // 音訊（實作見 AudioMixer.cs）：系統音效（WASAPI Loopback）＋ 麥克風混音後寫入音訊串流
        private AudioMixer? _audioMixer;

        private readonly object _stateLock = new();
        private volatile bool _isStopping;
        private int _frameBusy;                    // 1 = 有畫面正在處理中（避免 FrameArrived 重入）
        private volatile bool _frameErrorLogged;   // 畫面處理錯誤只記錄第一次

        /// <summary>視訊（本類別）與音訊（AudioMixer）分別在不同執行緒呼叫 SinkWriter.WriteSample，
        /// 依 Media Foundation 文件要求由呼叫端自行同步，故提供此共用鎖物件。</summary>
        internal readonly object SinkWriterLock = new();

        /// <param name="recordSystemAudio">錄製系統音效（WASAPI Loopback）。</param>
        /// <param name="recordMicrophone">錄製麥克風。兩者皆為 false 時輸出純影片（不建立音訊串流）。</param>
        public RecorderManager(Forms.Screen targetScreen, Rect? customRegion,
            bool recordSystemAudio = true, bool recordMicrophone = true)
        {
            _targetScreen = targetScreen ?? throw new ArgumentNullException(nameof(targetScreen));
            _customRegion = customRegion;
            _recordSystemAudio = recordSystemAudio;
            _recordMicrophone = recordMicrophone;
            _outputPath = BuildOutputPath();
        }

        public static string GetOutputFolder() =>
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyVideos));

        private static string BuildOutputPath()
        {
            string folder = GetOutputFolder();
            Directory.CreateDirectory(folder);
            string fileName = $"電腦錄影_{DateTime.Now:yyyyMMdd_HHmmss}.mp4";
            return Path.Combine(folder, fileName);
        }

        #region 開始錄影

        public void Start()
        {
            lock (_stateLock)
            {
                if (IsRecording) return;

                try
                {
                    InitializeCropRegion();
                    InitializeCapture();
                    ClampCropRegion();   // 擷取尺寸已知後，才能把裁切區域限制在畫面範圍內並調成偶數
                    InitializeSinkWriter();

                    if (HasAudio)
                    {
                        _audioMixer = new AudioMixer(_sinkWriter!, _audioStreamIndex, _clock, SinkWriterLock,
                            _recordSystemAudio, _recordMicrophone);
                        _audioMixer.Start();

                        string? warning = null;
                        if (_recordSystemAudio && !_audioMixer.SystemAudioAvailable)
                        {
                            warning = "系統音效無法使用";
                        }
                        if (_recordMicrophone && !_audioMixer.MicrophoneAvailable)
                        {
                            warning = warning == null ? "麥克風無法使用" : warning + "、麥克風無法使用";
                        }
                        AudioWarning = warning;
                    }

                    _clock.Start();
                    _captureSession!.StartCapture();

                    IsRecording = true;
                }
                catch (Exception ex)
                {
                    // 啟動失敗時釋放已建立的資源（避免輸出檔被鎖住、Media Foundation 未關閉），再把例外往上拋。
                    Debug.WriteLine($"[Rec] 開始錄影失敗: {ex}");
                    DisposeMediaFoundationResources();
                    DisposeCaptureResources();
                    throw;
                }
            }
        }

        /// <summary>
        /// 依自訂範圍與螢幕 DPI 縮放比例，換算出「擷取畫面像素座標」下的裁切矩形。
        /// 對應企劃書已知風險項：高 DPI／多螢幕混合縮放下的擷取解析度校正。
        /// </summary>
        private void InitializeCropRegion()
        {
            if (_customRegion is not Rect region)
            {
                _cropRegionPx = null;
                return;
            }

            // region 為「虛擬桌面實體像素」座標（RegionSelectorWindow 已用 PointToScreen 換算完成），
            // 與 Screen.Bounds（Per-Monitor V2 下亦為實體像素）同一座標系，因此只需扣除螢幕左上角；
            // 不可再乘 DPI 縮放比例，否則會重複縮放而偏移或超出畫面。
            var screenBounds = _targetScreen.Bounds;
            int x = (int)Math.Round(region.X - screenBounds.Left);
            int y = (int)Math.Round(region.Y - screenBounds.Top);
            int width = (int)Math.Round(region.Width);
            int height = (int)Math.Round(region.Height);

            _cropRegionPx = new System.Drawing.Rectangle(x, y, Math.Max(width, 2), Math.Max(height, 2));
        }

        /// <summary>
        /// 擷取畫面尺寸確定後，將裁切區域限制在畫面範圍內，且寬高調為偶數（H.264 要求）。
        /// 避免選取範圍超出螢幕邊界造成 CopySubresourceRegion 失敗（結果是整段影片沒有畫面）。
        /// </summary>
        private void ClampCropRegion()
        {
            if (_cropRegionPx is not System.Drawing.Rectangle r) return;

            int x = Math.Clamp(r.X, 0, Math.Max(_captureWidth - 2, 0));
            int y = Math.Clamp(r.Y, 0, Math.Max(_captureHeight - 2, 0));
            int w = Math.Min(r.Width, _captureWidth - x) & ~1;
            int h = Math.Min(r.Height, _captureHeight - y) & ~1;

            // 範圍過小（或幾乎整個落在螢幕外被裁光）時直接以明確訊息拒絕，
            // 不要把極小的畫面交給硬體編碼器。例外會由 Start() 收尾並由 MainWindow 顯示。
            if (w < MinRegionEdgePx || h < MinRegionEdgePx)
            {
                throw new InvalidOperationException(
                    $"擷取範圍過小（{w}x{h}），請選取至少 {MinRegionEdgePx}x{MinRegionEdgePx} 像素的範圍。");
            }

            _cropRegionPx = new System.Drawing.Rectangle(x, y, w, h);
        }

        #endregion

        #region 暫停 / 繼續

        public void Pause()
        {
            if (!IsRecording || _clock.IsPaused) return;
            _clock.Pause();
            _audioMixer?.Pause();
        }

        public void Resume()
        {
            if (!IsRecording || !_clock.IsPaused) return;
            _clock.Resume();
            _audioMixer?.Resume();
        }

        #endregion

        #region 停止 / 收尾

        public void Stop()
        {
            lock (_stateLock)
            {
                if (!IsRecording || _isStopping) return;
                _isStopping = true;
            }

            // Finalize（SinkWriter.Finalize + 釋放 WGC 資源）可能耗費數百毫秒，於背景執行緒執行避免卡住 UI。
            Task.Run(() =>
            {
                string? errorMessage = null;
                bool success = true;

                // 每個收尾步驟各自 try/catch：任何一步失敗（例如 COM 執行緒相容性問題）都不能阻止 Finalize，
                // 否則 mp4 不會寫入檔尾（moov），檔案會無法播放。失敗詳情（含堆疊）寫入 recorder.log。
                TryStep("停止擷取工作階段", () => _captureSession?.Dispose());
                TryStep("釋放 FramePool", () => _framePool?.Dispose());
                // 等待已在處理中的畫面寫完，再 Finalize（避免與 WriteSample 競爭）。
                SpinWait.SpinUntil(() => Volatile.Read(ref _frameBusy) == 0, 2000);
                TryStep("停止音訊", () => _audioMixer?.Stop());
                _clock.Stop();

                try
                {
                    if (_mfStarted)
                    {
                        lock (SinkWriterLock)
                        {
                            _sinkWriter?.Finalize();
                        }
                    }
                }
                catch (Exception ex)
                {
                    success = false;
                    errorMessage = $"SinkWriter.Finalize 失敗：{ex.Message}";
                    LogRecorderError("SinkWriter.Finalize", ex);
                }

                TryStep("釋放 Media Foundation 資源", DisposeMediaFoundationResources);
                TryStep("釋放擷取／音訊資源", DisposeCaptureResources);
                IsRecording = false;
                _isStopping = false;

                RecordingStopped?.Invoke(this, new RecordingStoppedEventArgs(success, success ? _outputPath : null, errorMessage));
            });
        }

        private static void TryStep(string stepName, Action action)
        {
            try
            {
                action();
            }
            catch (Exception ex)
            {
                LogRecorderError(stepName, ex);
            }
        }

        /// <summary>將收尾階段的例外（含完整堆疊）寫入 %LOCALAPPDATA%\ScreenRecorderWin\recorder.log，並輸出到偵錯視窗。</summary>
        private static void LogRecorderError(string step, Exception ex)
        {
            Debug.WriteLine($"[Rec] {step} 失敗: {ex}");
            try
            {
                string dir = Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                    "ScreenRecorderWin");
                Directory.CreateDirectory(dir);
                File.AppendAllText(Path.Combine(dir, "recorder.log"),
                    $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] {step}: {ex}\n\n");
            }
            catch
            {
                // 記錄失敗不再往上拋。
            }
        }

        #endregion

        #region Windows.Graphics.Capture 初始化與畫面擷取

        private void InitializeCapture()
        {
            _d3dDevice = CreateD3DDevice();
            _winrtDevice = CreateDirect3DDeviceFromD3DDevice(_d3dDevice);

            IntPtr hMonitor = GetHMonitorForScreen(_targetScreen);
            _captureItem = CreateCaptureItemForMonitor(hMonitor);

            _captureWidth = _captureItem.Size.Width;
            _captureHeight = _captureItem.Size.Height;

            _framePool = Direct3D11CaptureFramePool.CreateFreeThreaded(
                _winrtDevice,
                DirectXPixelFormat.B8G8R8A8UIntNormalized,
                numberOfBuffers: 2,
                size: _captureItem.Size);

            _framePool.FrameArrived += OnFrameArrived;

            _captureSession = _framePool.CreateCaptureSession(_captureItem);
            // 部分 Windows 10 版本不支援 IsCursorCaptureEnabled；以 try/catch 保守處理相容性。
            if (OperatingSystem.IsWindowsVersionAtLeast(10, 0, 19041))
            {
                try { _captureSession.IsCursorCaptureEnabled = true; } catch { /* 該版本不支援，忽略 */ }
            }
        }

        private void OnFrameArrived(Direct3D11CaptureFramePool sender, object args)
        {
            if (_isStopping) return;

            using var frame = sender.TryGetNextFrame();
            if (frame == null) return;

            // 暫停中：直接丟棄畫面，不寫入 SinkWriter（維持暫停期間不產生任何樣本）。
            if (_clock.IsPaused) return;

            // 前一張畫面尚未處理完就丟棄這一張：FrameArrived 為自由執行緒，避免重入造成
            // 多執行緒同時使用 D3D11 ImmediateContext。
            if (Interlocked.Exchange(ref _frameBusy, 1) == 1) return;

            try
            {
                byte[] pixelBuffer = ExtractFrameBytes(frame.Surface, out int outWidth, out int outHeight, out int rowPitch);
                WriteVideoSample(pixelBuffer, outWidth, outHeight, rowPitch);
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[Rec] 畫面處理失敗: {ex}");
                // 單一畫面轉換失敗不應中斷整段錄影；但一定要留下紀錄（只記第一次，避免 30fps 洗爆 log），
                // 否則會出現「錄完是空檔案」卻毫無線索的情況。
                if (!_frameErrorLogged)
                {
                    _frameErrorLogged = true;
                    LogRecorderError("畫面處理", ex);
                }
            }
            finally
            {
                Interlocked.Exchange(ref _frameBusy, 0);
            }
        }

        /// <summary>
        /// 將 WGC 回傳的 IDirect3DSurface 複製到 CPU 記憶體，並依 _cropRegionPx 裁切出實際要輸出的區域。
        /// 採用 CPU 複製（Staging Texture + Map）以簡化實作；若需更高效能，可改為 GPU 端 DXGI Surface 直接送入 SinkWriter。
        /// </summary>
        private byte[] ExtractFrameBytes(IDirect3DSurface surface, out int outWidth, out int outHeight, out int outRowPitch)
        {
            using var sourceTexture = GetTexture2DFromSurface(surface);

            var cropRect = _cropRegionPx ?? new System.Drawing.Rectangle(0, 0, _captureWidth, _captureHeight);
            outWidth = cropRect.Width & ~1;    // H.264 要求偶數；需與 InitializeSinkWriter 的 FrameSize 一致
            outHeight = cropRect.Height & ~1;

            var stagingDesc = new Texture2DDescription
            {
                Width = outWidth,
                Height = outHeight,
                MipLevels = 1,
                ArraySize = 1,
                Format = Format.B8G8R8A8_UNorm,
                SampleDescription = new SharpDX.DXGI.SampleDescription(1, 0),
                Usage = ResourceUsage.Staging,
                BindFlags = BindFlags.None,
                CpuAccessFlags = CpuAccessFlags.Read,
                OptionFlags = ResourceOptionFlags.None
            };

            using var stagingTexture = new Texture2D(_d3dDevice!, stagingDesc);

            var sourceRegion = new ResourceRegion(
                cropRect.Left, cropRect.Top, 0,
                cropRect.Left + outWidth, cropRect.Top + outHeight, 1);

            _d3dDevice!.ImmediateContext.CopySubresourceRegion(sourceTexture, 0, sourceRegion, stagingTexture, 0);

            var dataBox = _d3dDevice.ImmediateContext.MapSubresource(stagingTexture, 0, MapMode.Read, SharpDX.Direct3D11.MapFlags.None);
            try
            {
                outRowPitch = dataBox.RowPitch;
                int bufferSize = outRowPitch * outHeight;
                byte[] buffer = new byte[bufferSize];
                Marshal.Copy(dataBox.DataPointer, buffer, 0, bufferSize);
                return buffer;
            }
            finally
            {
                _d3dDevice.ImmediateContext.UnmapSubresource(stagingTexture, 0);
            }
        }

        #endregion

        #region Media Foundation SinkWriter 設定

        private void InitializeSinkWriter()
        {
            MediaManager.Startup();
            _mfStarted = true;

            int outWidth = _cropRegionPx?.Width ?? _captureWidth;
            int outHeight = _cropRegionPx?.Height ?? _captureHeight;
            // Media Foundation 的 H.264 編碼器要求寬高為偶數。
            outWidth -= outWidth % 2;
            outHeight -= outHeight % 2;

            using var attributes = new MediaAttributes(1);
            attributes.Set(SinkWriterAttributeKeys.ReadwriteEnableHardwareTransforms, 1);

            _sinkWriter = MediaFactory.CreateSinkWriterFromURL(_outputPath, null, attributes);

            // --- 視訊輸出（H.264） ---
            using (var videoOutType = new MediaType())
            {
                videoOutType.Set(MediaTypeAttributeKeys.MajorType, MediaTypeGuids.Video);
                videoOutType.Set(MediaTypeAttributeKeys.Subtype, VideoFormatGuids.H264);
                videoOutType.Set(MediaTypeAttributeKeys.AvgBitrate, VideoBitrate);
                videoOutType.Set(MediaTypeAttributeKeys.InterlaceMode, (int)VideoInterlaceMode.Progressive);
                videoOutType.Set(MediaTypeAttributeKeys.FrameSize, PackToLong(outWidth, outHeight));
                videoOutType.Set(MediaTypeAttributeKeys.FrameRate, PackToLong(TargetFrameRate, 1));
                videoOutType.Set(MediaTypeAttributeKeys.PixelAspectRatio, PackToLong(1, 1));
                _sinkWriter.AddStream(videoOutType, out _videoStreamIndex);
            }

            // --- 視訊輸入（未壓縮 BGRA32，對應 ExtractFrameBytes 輸出格式） ---
            using (var videoInType = new MediaType())
            {
                videoInType.Set(MediaTypeAttributeKeys.MajorType, MediaTypeGuids.Video);
                videoInType.Set(MediaTypeAttributeKeys.Subtype, VideoFormatGuids.Argb32);
                videoInType.Set(MediaTypeAttributeKeys.InterlaceMode, (int)VideoInterlaceMode.Progressive);
                videoInType.Set(MediaTypeAttributeKeys.FrameSize, PackToLong(outWidth, outHeight));
                videoInType.Set(MediaTypeAttributeKeys.FrameRate, PackToLong(TargetFrameRate, 1));
                videoInType.Set(MediaTypeAttributeKeys.PixelAspectRatio, PackToLong(1, 1));
                // MF 預設未壓縮 RGB 為由下往上；擷取的畫面是由上往下，故指定正的 stride，避免影片上下顛倒。
                videoInType.Set(MediaTypeAttributeKeys.DefaultStride, outWidth * 4);
                _sinkWriter.SetInputMediaType(_videoStreamIndex, videoInType, null);
            }

            // 只在有勾選任一音訊來源時才建立音訊串流；否則輸出純影片。
            if (HasAudio)
            {
                // --- 音訊輸出（AAC，48kHz 立體聲，對應 AudioMixer 混音後格式） ---
                using (var audioOutType = new MediaType())
                {
                    audioOutType.Set(MediaTypeAttributeKeys.MajorType, MediaTypeGuids.Audio);
                    audioOutType.Set(MediaTypeAttributeKeys.Subtype, AudioFormatGuids.Aac);
                    audioOutType.Set(MediaTypeAttributeKeys.AudioBitsPerSample, 16);
                    audioOutType.Set(MediaTypeAttributeKeys.AudioSamplesPerSecond, 48000);
                    audioOutType.Set(MediaTypeAttributeKeys.AudioNumChannels, 2);
                    audioOutType.Set(MediaTypeAttributeKeys.AudioAvgBytesPerSecond, 16000);
                    _sinkWriter.AddStream(audioOutType, out _audioStreamIndex);
                }

                // --- 音訊輸入（未壓縮 Float32，AudioMixer 內部相加後即為此格式） ---
                using (var audioInType = new MediaType())
                {
                    audioInType.Set(MediaTypeAttributeKeys.MajorType, MediaTypeGuids.Audio);
                    audioInType.Set(MediaTypeAttributeKeys.Subtype, AudioFormatGuids.Float);
                    audioInType.Set(MediaTypeAttributeKeys.AudioBitsPerSample, 32);
                    audioInType.Set(MediaTypeAttributeKeys.AudioSamplesPerSecond, 48000);
                    audioInType.Set(MediaTypeAttributeKeys.AudioNumChannels, 2);
                    audioInType.Set(MediaTypeAttributeKeys.AudioBlockAlignment, 8);            // 2 聲道 × 4 bytes
                    audioInType.Set(MediaTypeAttributeKeys.AudioAvgBytesPerSecond, 384000);    // 48000 × 8
                    _sinkWriter.SetInputMediaType(_audioStreamIndex, audioInType, null);
                }
            }

            _sinkWriter.BeginWriting();
            _mfStarted = true;
        }

        private void WriteVideoSample(byte[] pixelBuffer, int width, int height, int rowPitch)
        {
            if (_sinkWriter == null) return;

            int tightRowPitch = width * 4;
            using var mediaBuffer = MediaFactory.CreateMemoryBuffer(tightRowPitch * height);

            IntPtr dest = mediaBuffer.Lock(out int _, out int _);
            try
            {
                if (rowPitch == tightRowPitch)
                {
                    Marshal.Copy(pixelBuffer, 0, dest, tightRowPitch * height);
                }
                else
                {
                    // Staging texture 的 RowPitch 可能因對齊而大於實際寬度所需位元組數，逐行複製去除 padding。
                    for (int row = 0; row < height; row++)
                    {
                        Marshal.Copy(pixelBuffer, row * rowPitch, IntPtr.Add(dest, row * tightRowPitch), tightRowPitch);
                    }
                }
            }
            finally
            {
                mediaBuffer.Unlock();
            }
            mediaBuffer.CurrentLength = tightRowPitch * height;

            using var sample = MediaFactory.CreateSample();
            sample.AddBuffer(mediaBuffer);
            sample.SampleTime = _clock.GetTimestamp100Ns();
            sample.SampleDuration = 10_000_000L / TargetFrameRate; // 100ns 單位

            // SinkWriter 允許多執行緒呼叫，但需由呼叫端自行同步；此處與 AudioMixer 共用 SinkWriterLock。
            lock (SinkWriterLock)
            {
                _sinkWriter.WriteSample(_videoStreamIndex, sample);
            }
        }

        #endregion

        #region 資源釋放

        private void DisposeMediaFoundationResources()
        {
            _sinkWriter?.Dispose();
            _sinkWriter = null;

            if (_mfStarted)
            {
                MediaManager.Shutdown();
                _mfStarted = false;
            }
        }

        private void DisposeCaptureResources()
        {
            _framePool?.Dispose();
            _framePool = null;
            _captureSession = null;
            _captureItem = null;

            _winrtDevice = null;
            _d3dDevice?.Dispose();
            _d3dDevice = null;

            _audioMixer?.Dispose();
            _audioMixer = null;
        }

        public void Dispose()
        {
            if (IsRecording)
            {
                Stop();
            }
            else
            {
                DisposeMediaFoundationResources();
                DisposeCaptureResources();
            }
        }

        #endregion

        #region DPI / 螢幕輔助

        private static double GetDpiScaleForScreen(Forms.Screen screen)
        {
            IntPtr hMonitor = GetHMonitorForScreen(screen);
            if (GetDpiForMonitor(hMonitor, MonitorDpiType.EffectiveDpi, out uint dpiX, out _) == 0)
            {
                return dpiX / 96.0;
            }
            return 1.0; // 取得失敗時退回 100% 縮放，避免整段擷取失敗
        }

        private static IntPtr GetHMonitorForScreen(Forms.Screen screen)
        {
            var bounds = screen.Bounds;
            var point = new NativePoint
            {
                X = bounds.Left + bounds.Width / 2,
                Y = bounds.Top + bounds.Height / 2
            };
            return MonitorFromPoint(point, MONITOR_DEFAULTTONEAREST);
        }

        #endregion

        #region Win32 / WinRT Interop
        // 下列 COM／WinRT 互通樣板參考自 Microsoft 官方 Windows.Graphics.Capture 範例
        // （如 robmikh/Win32CaptureSample）之慣用寫法。實際建置時請對照該範例確認
        // GUID／簽章與所使用的 Windows SDK / CsWinRT 版本相符。

        [ComImport, Guid("3628E81B-3CAC-4C60-B7F4-23CE0E0C3356"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        private interface IGraphicsCaptureItemInterop
        {
            IntPtr CreateForWindow([In] IntPtr window, [In] ref Guid iid);
            IntPtr CreateForMonitor([In] IntPtr monitor, [In] ref Guid iid);
        }

        [ComImport, Guid("A9B3D012-3DF2-4EE3-B8D1-8695F457D3C1"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        private interface IDirect3DDxgiInterfaceAccess
        {
            IntPtr GetInterface([In] ref Guid iid);
        }

        // IGraphicsCaptureItem 的 IID（Windows.Graphics.Capture.IGraphicsCaptureItem）。
        // 注意：不能用 typeof(GraphicsCaptureItem).GUID —— 投影後的 runtime class 沒有這個 IID。
        private static readonly Guid IID_IGraphicsCaptureItem = new("79C3F95B-31F7-4EC2-A464-632EF5D30760");

        private static GraphicsCaptureItem CreateCaptureItemForMonitor(IntPtr hMonitor)
        {
            // 直接用 combase 的 RoGetActivationFactory 取得 activation factory，
            // 並要求 IGraphicsCaptureItemInterop 介面（CsWinRT 的 ActivationFactory.Get 回傳的物件無法直接轉型為 ComImport 介面）。
            const string className = "Windows.Graphics.Capture.GraphicsCaptureItem";
            Guid interopIid = typeof(IGraphicsCaptureItemInterop).GUID;

            Marshal.ThrowExceptionForHR(WindowsCreateString(className, className.Length, out IntPtr hstring));
            IntPtr factoryPtr = IntPtr.Zero;
            IntPtr itemPtr = IntPtr.Zero;
            try
            {
                Marshal.ThrowExceptionForHR(RoGetActivationFactory(hstring, ref interopIid, out factoryPtr));
                var interop = (IGraphicsCaptureItemInterop)Marshal.GetObjectForIUnknown(factoryPtr);

                Guid itemIid = IID_IGraphicsCaptureItem;
                itemPtr = interop.CreateForMonitor(hMonitor, ref itemIid);

                return WinRT.MarshalInspectable<GraphicsCaptureItem>.FromAbi(itemPtr);
            }
            finally
            {
                if (itemPtr != IntPtr.Zero) Marshal.Release(itemPtr);
                if (factoryPtr != IntPtr.Zero) Marshal.Release(factoryPtr);
                WindowsDeleteString(hstring);
            }
        }

        [DllImport("combase.dll", PreserveSig = true)]
        private static extern int RoGetActivationFactory(IntPtr activatableClassId, ref Guid iid, out IntPtr factory);

        [DllImport("combase.dll", PreserveSig = true, CharSet = CharSet.Unicode)]
        private static extern int WindowsCreateString([MarshalAs(UnmanagedType.LPWStr)] string sourceString, int length, out IntPtr hstring);

        [DllImport("combase.dll", PreserveSig = true)]
        private static extern int WindowsDeleteString(IntPtr hstring);

        private static Texture2D GetTexture2DFromSurface(IDirect3DSurface surface)
        {
            // 投影後的 IDirect3DSurface 不是 RCW，不能直接轉型為 ComImport 介面；
            // 先取得 ABI 指標，再用 QueryInterface 取得 IDirect3DDxgiInterfaceAccess。
            IntPtr abi = WinRT.MarshalInterface<IDirect3DSurface>.FromManaged(surface);
            IntPtr accessPtr = IntPtr.Zero;
            try
            {
                Guid accessIid = typeof(IDirect3DDxgiInterfaceAccess).GUID;
                Marshal.ThrowExceptionForHR(Marshal.QueryInterface(abi, ref accessIid, out accessPtr));

                var access = (IDirect3DDxgiInterfaceAccess)Marshal.GetObjectForIUnknown(accessPtr);
                Guid textureIid = new("6f15aaf2-d208-4e89-9ab4-489535d34f9c"); // IID_ID3D11Texture2D
                IntPtr texturePointer = access.GetInterface(ref textureIid);
                return new Texture2D(texturePointer);
            }
            finally
            {
                if (accessPtr != IntPtr.Zero) Marshal.Release(accessPtr);
                if (abi != IntPtr.Zero) Marshal.Release(abi);
            }
        }

        [DllImport("d3d11.dll", EntryPoint = "CreateDirect3D11DeviceFromDXGIDevice", SetLastError = true)]
        private static extern int CreateDirect3D11DeviceFromDXGIDevice(IntPtr dxgiDevice, out IntPtr graphicsDevice);

        private static IDirect3DDevice CreateDirect3DDeviceFromD3DDevice(Device d3dDevice)
        {
            using var dxgiDevice = d3dDevice.QueryInterface<SharpDX.DXGI.Device>();
            int hr = CreateDirect3D11DeviceFromDXGIDevice(dxgiDevice.NativePointer, out IntPtr pUnknown);
            Marshal.ThrowExceptionForHR(hr);
            var device = WinRT.MarshalInterface<IDirect3DDevice>.FromAbi(pUnknown);
            Marshal.Release(pUnknown);
            return device;
        }

        private static Device CreateD3DDevice()
        {
            var flags = DeviceCreationFlags.BgraSupport;
#if DEBUG
            // 需安裝 Windows SDK 的 D3D11 偵錯層才可加上 DeviceCreationFlags.Debug。
#endif
            var device = new Device(SharpDX.Direct3D.DriverType.Hardware, flags);
            try
            {
                // WGC 與本類別（FrameArrived 執行緒）會同時使用此 device，需開啟 D3D11 多執行緒保護。
                using var multithread = device.QueryInterface<SharpDX.Direct3D11.Multithread>();
                multithread.SetMultithreadProtected(true);
            }
            catch (Exception ex)
            {
                LogRecorderError("啟用 D3D11 多執行緒保護", ex);
            }
            return device;
        }

        private static long PackToLong(int high, int low) => ((long)high << 32) | (uint)low;

        [StructLayout(LayoutKind.Sequential)]
        private struct NativePoint { public int X; public int Y; }

        private const uint MONITOR_DEFAULTTONEAREST = 2;

        [DllImport("user32.dll")]
        private static extern IntPtr MonitorFromPoint(NativePoint pt, uint dwFlags);

        private enum MonitorDpiType { EffectiveDpi = 0 }

        [DllImport("shcore.dll")]
        private static extern int GetDpiForMonitor(IntPtr hMonitor, MonitorDpiType dpiType, out uint dpiX, out uint dpiY);

        #endregion
    }
}
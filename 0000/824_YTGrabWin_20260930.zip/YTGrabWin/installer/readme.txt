installer\build-installer.cmd -DownloadTools


我做好了打包腳本,但沒有在這裡實際建置過。這個環境沒有 Windows、.NET 和 Inno Setup,所以只驗證過 yt-dlp 與 ffmpeg 的下載網址有效,腳本本身請你在自己的機器上試跑。

使用方式
把 installer 資料夾放到專案根目錄,與 YTGrabWin.csproj 同一層。
安裝建置工具(只需一次):
powershell
   winget install Microsoft.DotNet.SDK.8
   winget install JRSoftware.InnoSetup

Inno Setup 需要 6.3 以上。
3. 第一次建置,執行 installer\build-installer.cmd -DownloadTools。它會自動下載 yt-dlp.exe 和 ffmpeg.exe(LGPL 版)到 Resources\。
4. 之後改版時,執行 installer\build-installer.cmd -Version 1.0.1。

安裝檔會輸出到 dist\YTGrab-Setup-<版本>.exe,並顯示大小與 SHA256。建議把 build/ 和 dist/ 加進 .gitignore。

腳本會做的事
發佈 App: 使用 self-contained 的 win-x64 版本,使用者不必另外安裝 .NET。
打包 Firefox 外掛: 連同 node_modules 一起放進 {app}\Firefox\video-analyzer-extension,程式原本就從這個位置尋找外掛。這樣安裝後不必連網 npm install,也不必寫入安裝目錄。外掛若沒有 node_modules,腳本會先執行 npm ci。
內建工具: yt-dlp.exe 和 ffmpeg.exe 放在 {app}\Resources\。
安裝方式: 每位使用者安裝,免系統管理員權限,預設在 %LOCALAPPDATA%\Programs\YTGrab。
偵測執行中的 App: 安裝或解除安裝時,會用 App 的單一實例 Mutex 偵測,提示先關閉。
解除安裝: 移除 Native host 的登錄檔與 NativeHost 資料夾。使用者設定與 Firefox 專用 Profile(含登入狀態)會保留。
相依檢查: 安裝完成後偵測 Node.js 與 Python 3,缺少時提示並可一鍵開啟下載頁。
發佈前要知道的事
使用者仍需安裝 Node.js 與 Python 3。 前者用來以 web-ext 啟動 Firefox 外掛,後者用來執行 host.py。安裝程式只會提醒,不會強制。若想做到完全免安裝,可以改內建 Python embeddable 與 portable Node。這需要改動 NativeHostInstaller 和外掛尋找 npm 的邏輯,你要的話我可以接著做。
安裝檔未簽章。 Windows SmartScreen 會顯示「未知的發行者」警告。對外散布需要程式碼簽章憑證,簽章步驟可以另外加到腳本裡。
檢查授權。 ffmpeg 我選 LGPL 版,散布時仍需附上授權聲明。yt-dlp 是 Unlicense。
中文安裝介面是選配。 預設安裝精靈是英文,自訂提示訊息是中文。若要完整繁中介面,把 ChineseTraditional.isl 放到 installer\Languages\,腳本會自動加入。這個語言檔不隨 Inno Setup 附帶,需從其翻譯頁面自行下載。
路徑長度。 node_modules 路徑很深。如果使用者的使用者名稱很長,安裝到預設路徑可能超過 260 字元,遇到時請告訴我,我可以幫忙精簡。
在乾淨環境測試。 建議在沒裝任何開發工具的 Windows 虛擬機測試:安裝、按「Firefox 外掛」、用 popup 下載一支影片、解除安裝。
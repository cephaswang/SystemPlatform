﻿<#
.SYNOPSIS
  YTGrab 安裝包建置腳本：發佈 App → 打包 Firefox 外掛 → 以 Inno Setup 產生安裝檔。

.EXAMPLE
  .\build-installer.ps1 -Version 1.0.0 -DownloadTools
  第一次建置：自動下載 yt-dlp.exe 與 ffmpeg.exe 放進 Resources\。

.NOTES
  需求：.NET SDK 8 以上、Inno Setup 6.3 以上；外掛若沒有 node_modules 還需要 Node.js（npm）。
  輸出：<專案根目錄>\dist\YTGrab-Setup-<版本>.exe
#>
[CmdletBinding()]
param(
    [string]$Version = "1.0.0",
    [switch]$DownloadTools
)

$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"   # Windows PowerShell 5.1 顯示下載進度條會讓下載慢十倍以上
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$Root       = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
$Project    = Join-Path $Root "YTGrabWin.csproj"
$Resources  = Join-Path $Root "Resources"
$ExtDir     = Join-Path $Root "fireFoxPlug\video-analyzer-extension"
$PublishDir = Join-Path $Root "build\publish"
$DistDir    = Join-Path $Root "dist"

function Step([string]$text) { Write-Host ""; Write-Host "==> $text" -ForegroundColor Cyan }

function Invoke-Checked([string]$File, [string[]]$Arguments, [string]$WorkDir = "") {
    if ($WorkDir) { Push-Location $WorkDir }
    try {
        & $File @Arguments
        if ($LASTEXITCODE -ne 0) { throw "$File 執行失敗（ExitCode=$LASTEXITCODE）" }
    }
    finally { if ($WorkDir) { Pop-Location } }
}

try {
    # ── 1. 檢查建置環境 ──────────────────────────────────────────────
    Step "檢查建置環境"
    if (-not (Test-Path $Project)) { throw "找不到專案檔：$Project（請把 installer 資料夾放在專案根目錄）" }

    if (-not (Get-Command dotnet -ErrorAction SilentlyContinue)) {
        throw "找不到 dotnet。請安裝 .NET SDK 8：winget install Microsoft.DotNet.SDK.8"
    }
    if (-not ((& dotnet --list-sdks) | Where-Object { $_ -match '^(8|9|10)\.' })) {
        throw "找不到 .NET SDK 8 以上。請安裝：winget install Microsoft.DotNet.SDK.8"
    }

    $iscc = @(
        (Get-Command ISCC.exe -ErrorAction SilentlyContinue).Source,
        "${env:ProgramFiles(x86)}\Inno Setup 6\ISCC.exe",
        "$env:ProgramFiles\Inno Setup 6\ISCC.exe",
        "$env:LOCALAPPDATA\Programs\Inno Setup 6\ISCC.exe"
    ) | Where-Object { $_ -and (Test-Path $_) } | Select-Object -First 1
    if (-not $iscc) { throw "找不到 Inno Setup。請安裝：winget install JRSoftware.InnoSetup" }
    Write-Host "Inno Setup: $iscc"

    # ── 2. 內建工具 yt-dlp / ffmpeg ─────────────────────────────────
    Step "檢查內建工具（Resources\yt-dlp.exe、ffmpeg.exe）"
    New-Item -ItemType Directory -Force $Resources | Out-Null
    $ytdlp  = Join-Path $Resources "yt-dlp.exe"
    $ffmpeg = Join-Path $Resources "ffmpeg.exe"

    if (-not (Test-Path $ytdlp)) {
        if (-not $DownloadTools) { throw "缺少 $ytdlp。請自行放入，或加上 -DownloadTools 自動下載。" }
        Write-Host "下載 yt-dlp.exe ..."
        Invoke-WebRequest "https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp.exe" -OutFile $ytdlp -UseBasicParsing
    }

    if (-not (Test-Path $ffmpeg)) {
        if (-not $DownloadTools) { throw "缺少 $ffmpeg。請自行放入，或加上 -DownloadTools 自動下載。" }
        Write-Host "下載 ffmpeg（LGPL 版，約 170 MB，只取出 ffmpeg.exe）..."
        $zipPath = Join-Path $env:TEMP "ffmpeg-lgpl.zip"
        Invoke-WebRequest "https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-lgpl.zip" -OutFile $zipPath -UseBasicParsing
        Add-Type -AssemblyName System.IO.Compression.FileSystem
        $zip = [System.IO.Compression.ZipFile]::OpenRead($zipPath)
        try {
            $entry = $zip.Entries | Where-Object { $_.FullName -like "*/bin/ffmpeg.exe" } | Select-Object -First 1
            if (-not $entry) { throw "下載的壓縮檔內找不到 bin\ffmpeg.exe" }
            [System.IO.Compression.ZipFileExtensions]::ExtractToFile($entry, $ffmpeg, $true)
        }
        finally {
            $zip.Dispose()
            Remove-Item $zipPath -Force -ErrorAction SilentlyContinue
        }
    }
    Write-Host ("yt-dlp 版本: " + (& $ytdlp --version))

    # ── 3. Firefox 外掛（需含 node_modules，安裝後才不必連網、也不必寫入安裝目錄）──
    Step "檢查 Firefox 外掛"
    if (-not (Test-Path (Join-Path $ExtDir "manifest.json"))) { throw "找不到外掛資料夾：$ExtDir" }
    if (-not (Test-Path (Join-Path $ExtDir "node_modules\web-ext"))) {
        $npm = Get-Command npm.cmd -ErrorAction SilentlyContinue
        if (-not $npm) { throw "外掛缺少 node_modules，且找不到 npm.cmd。請安裝 Node.js：winget install OpenJS.NodeJS.LTS" }
        $npmCommand = if (Test-Path (Join-Path $ExtDir "package-lock.json")) { "ci" } else { "install" }
        Write-Host "npm $npmCommand ..."
        Invoke-Checked $npm.Source @($npmCommand) $ExtDir
    }
    else {
        Write-Host "node_modules 已存在，略過 npm install"
    }

    # ── 4. 發佈 App（self-contained：使用者不必另外安裝 .NET）────────
    Step "發佈 YTGrabWin（Release, win-x64, self-contained）"
    if (Test-Path $PublishDir) { Remove-Item $PublishDir -Recurse -Force }
    Invoke-Checked "dotnet" @(
        "publish", $Project,
        "-c", "Release",
        "-r", "win-x64",
        "--self-contained", "true",
        "-p:Version=$Version",
        "-p:DebugType=none",
        "-p:DebugSymbols=false",
        "-o", $PublishDir
    )
    if (-not (Test-Path (Join-Path $PublishDir "YTGrabWin.exe"))) { throw "發佈輸出找不到 YTGrabWin.exe" }

    # 不依賴 csproj 的 publish 行為，直接確保工具在 Resources\ 下（App 由此處尋找）
    $publishResources = Join-Path $PublishDir "Resources"
    New-Item -ItemType Directory -Force $publishResources | Out-Null
    Copy-Item $ytdlp, $ffmpeg $publishResources -Force

    # ── 5. 產生安裝檔 ────────────────────────────────────────────────
    Step "建立安裝包（Inno Setup）"
    New-Item -ItemType Directory -Force $DistDir | Out-Null
    Invoke-Checked $iscc @(
        "/Qp",
        "/DAppVersion=$Version",
        "/DPublishDir=$PublishDir",
        "/DExtensionDir=$ExtDir",
        "/DOutputDir=$DistDir",
        (Join-Path $PSScriptRoot "YTGrab.iss")
    )

    $setup = Join-Path $DistDir "YTGrab-Setup-$Version.exe"
    if (-not (Test-Path $setup)) { throw "沒有產生預期的安裝檔：$setup" }

    $sizeMb = [math]::Round((Get-Item $setup).Length / 1MB, 1)
    $hash = (Get-FileHash $setup -Algorithm SHA256).Hash
    Write-Host ""
    Write-Host "完成！" -ForegroundColor Green
    Write-Host "  安裝檔 : $setup"
    Write-Host "  大小   : $sizeMb MB"
    Write-Host "  SHA256 : $hash"
}
catch {
    Write-Host ""
    Write-Host "建置失敗：$($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

﻿; YTGrab 安裝包（Inno Setup 6.3+）
; 由 build-installer.ps1 呼叫；也可在 Inno Setup 編輯器中直接開啟編譯（會使用下方預設路徑）。

#ifndef AppVersion
  #define AppVersion "1.0.0"
#endif
#ifndef PublishDir
  #define PublishDir "..\build\publish"
#endif
#ifndef ExtensionDir
  #define ExtensionDir "..\fireFoxPlug\video-analyzer-extension"
#endif
#ifndef OutputDir
  #define OutputDir "..\dist"
#endif

#define AppName "YTGrab"
#define AppExe  "YTGrabWin.exe"

[Setup]
; AppId 請勿更改：升級安裝與解除安裝都靠它辨識同一個程式
AppId={{B8E6C2F1-4A7D-4F53-9C0E-6D2A1F7E3B91}
AppName={#AppName}
AppVersion={#AppVersion}
AppPublisher=YTGrab
; 每位使用者安裝（免系統管理員權限）。Native host 註冊在 HKCU，也是每位使用者一份。
PrivilegesRequired=lowest
DefaultDirName={autopf}\{#AppName}
DefaultGroupName={#AppName}
DisableProgramGroupPage=yes
OutputDir={#OutputDir}
OutputBaseFilename=YTGrab-Setup-{#AppVersion}
Compression=lzma2/max
SolidCompression=yes
WizardStyle=modern
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
UninstallDisplayIcon={app}\{#AppExe}
; 與 App.xaml.cs 的 MutexName 相同：App 執行中時，安裝／解除安裝會提示先關閉
AppMutex=YTGrabWin.SingleInstance.Mutex

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"
; 若把 ChineseTraditional.isl 放在 installer\Languages\，安裝精靈會多一個繁體中文選項
#if FileExists(SourcePath + "Languages\ChineseTraditional.isl")
Name: "chinesetraditional"; MessagesFile: "Languages\ChineseTraditional.isl"
#endif

[CustomMessages]
english.DesktopIcon=建立桌面捷徑
english.LaunchApp=立即啟動 YTGrab
english.NeedNode=・找不到 Node.js。「Firefox 外掛」功能需要它（用來在本機啟動 Firefox 並載入外掛）。
english.NeedPython=・找不到 Python 3。外掛的「進階下載（yt-dlp）」需要它。安裝時請勾選「Add python.exe to PATH」。
english.PrereqIntro=YTGrab 已安裝完成，但偵測到下列相依項目尚未安裝：
english.PrereqAsk=是否現在開啟下載頁面？（安裝後請重新啟動 YTGrab）

[Tasks]
Name: "desktopicon"; Description: "{cm:DesktopIcon}"; Flags: unchecked

[Files]
; App 本體（self-contained，含 .NET 執行階段、Resources\yt-dlp.exe、ffmpeg.exe）
Source: "{#PublishDir}\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs
; Firefox 外掛：放在 App 旁的 Firefox\video-analyzer-extension（FirefoxIntegrationService 由此尋找），
; 連同 node_modules，這樣安裝後不必再 npm install，也不必寫入安裝目錄。
Source: "{#ExtensionDir}\*"; DestDir: "{app}\Firefox\video-analyzer-extension"; Excludes: "web-ext-artifacts\*,.DS_Store"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{group}\{#AppName}"; Filename: "{app}\{#AppExe}"
Name: "{group}\解除安裝 {#AppName}"; Filename: "{uninstallexe}"
Name: "{autodesktop}\{#AppName}"; Filename: "{app}\{#AppExe}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#AppExe}"; Description: "{cm:LaunchApp}"; Flags: nowait postinstall skipifsilent

[Registry]
; Native Messaging host 的登錄檔由 App 在啟動外掛時建立；解除安裝時一併移除（dontcreatekey = 安裝時不建立）
Root: HKCU; Subkey: "Software\Mozilla\NativeMessagingHosts\com.example.ytdlp"; Flags: dontcreatekey uninsdeletekey

[UninstallDelete]
; App 產生的 host 檔案。使用者設定、下載記錄、Firefox 專用 Profile（含登入狀態）會保留。
Type: filesandordirs; Name: "{localappdata}\YTGrabWin\NativeHost"

[Code]
var
  HasNodeJs: Boolean;
  HasPython3: Boolean;

{ 執行 where 指令，回傳是否找到與輸出內容 }
function RunWhere(const ExeName: String; var Output: String): Boolean;
var
  ResultCode: Integer;
  TmpFile: String;
  Raw: AnsiString;
begin
  Output := '';
  TmpFile := ExpandConstant('{tmp}') + '\where_' + ExeName + '.txt';
  Result := Exec(ExpandConstant('{cmd}'),
    '/c where ' + ExeName + ' > "' + TmpFile + '" 2>nul',
    '', SW_HIDE, ewWaitUntilTerminated, ResultCode) and (ResultCode = 0);
  if Result and LoadStringFromFile(TmpFile, Raw) then
    Output := String(Raw);
end;

{ Microsoft Store 的 python.exe 只是導向商店的空殼（路徑含 WindowsApps），不算已安裝 }
function HasRealPath(const Lines: String): Boolean;
var
  Rest, Line: String;
  P: Integer;
begin
  Result := False;
  Rest := Lines;
  while Rest <> '' do
  begin
    P := Pos(#10, Rest);
    if P = 0 then
    begin
      Line := Rest;
      Rest := '';
    end
    else
    begin
      Line := Copy(Rest, 1, P - 1);
      Rest := Copy(Rest, P + 1, Length(Rest));
    end;
    Line := Trim(Line);
    if (Line <> '') and (Pos('windowsapps', LowerCase(Line)) = 0) then
    begin
      Result := True;
      Exit;
    end;
  end;
end;

procedure DetectPrerequisites;
var
  Output: String;
begin
  HasNodeJs := (RunWhere('npm.cmd', Output) and HasRealPath(Output))
    or FileExists(ExpandConstant('{commonpf64}') + '\nodejs\npm.cmd');

  HasPython3 := (RunWhere('py.exe', Output) and HasRealPath(Output))
    or (RunWhere('python.exe', Output) and HasRealPath(Output));
end;

procedure CurStepChanged(CurStep: TSetupStep);
var
  Msg: String;
  ResultCode: Integer;
begin
  if (CurStep = ssPostInstall) and (not WizardSilent) then
  begin
    DetectPrerequisites;
    Msg := '';
    if not HasNodeJs then Msg := Msg + CustomMessage('NeedNode') + #13#10#13#10;
    if not HasPython3 then Msg := Msg + CustomMessage('NeedPython') + #13#10#13#10;

    if Msg <> '' then
    begin
      Msg := CustomMessage('PrereqIntro') + #13#10#13#10 + Msg + CustomMessage('PrereqAsk');
      if MsgBox(Msg, mbInformation, MB_YESNO) = IDYES then
      begin
        if not HasNodeJs then
          ShellExec('open', 'https://nodejs.org/', '', '', SW_SHOWNORMAL, ewNoWait, ResultCode);
        if not HasPython3 then
          ShellExec('open', 'https://www.python.org/downloads/windows/', '', '', SW_SHOWNORMAL, ewNoWait, ResultCode);
      end;
    end;
  end;
end;

@echo off
rem Double-click or run from a terminal. Extra arguments are passed to the PowerShell script,
rem e.g.  build-installer.cmd -Version 1.0.1 -DownloadTools
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0build-installer.ps1" %*
set RC=%errorlevel%
echo.
pause
exit /b %RC%

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using YTGrabWin.Core;

namespace YTGrabWin.Features.VideoInfo;

/// <summary>使用者在畫質/音訊清單選好格式、要求下載時，由 VideoInfoView 對外發出。</summary>
public sealed record VideoDownloadRequest(string Url, string Title, string FormatSelector, OutputFormat OutputFormat);

/// <summary>
/// 對應企劃案四：影片資訊卡＋畫質/字幕/音訊 Tab。
/// 對應三、規格：畫質音訊分類過濾規則（IsVideoOnly／IsAudioOnly，見 Core.FormatInfo）、
/// 字幕分組排序搜尋（此處先提供基本清單＋搜尋框，分組排序邏輯沿用 macOS 版規格待補完整實作）。
/// </summary>
public partial class VideoInfoView : UserControl
{
    private Core.VideoInfo? _currentVideo;
    private string? _currentUrl;
    private List<SubtitleGroup> _allSubtitleGroups = new();
    private readonly YTDLPClient _client = new();
    private readonly string[] _pinnedLanguages = new SettingsStore().Current.PinnedSubtitleLanguages;

    /// <summary>要求下載選取的格式，由 MainWindow 接手建立 DownloadTask。</summary>
    public event EventHandler<VideoDownloadRequest>? DownloadRequested;

    public VideoInfoView()
    {
        InitializeComponent();
        SubtitleSearchBox.TextChanged += (_, _) => ApplySubtitleFilter();
        ShowTranslatedCheckBox.Checked += (_, _) => ApplySubtitleFilter();
        ShowTranslatedCheckBox.Unchecked += (_, _) => ApplySubtitleFilter();
    }

    public void LoadVideo(Core.VideoInfo video, string url)
    {
        _currentVideo = video;
        _currentUrl = url;

        TitleText.Text = video.Title;
        UploaderText.Text = video.Uploader ?? string.Empty;
        DurationText.Text = video.DurationSeconds is double seconds
            ? TimeSpan.FromSeconds(seconds).ToString(@"hh\:mm\:ss")
            : string.Empty;

        // 對應三、規格：畫質音訊分類過濾規則。
        QualityFormatsListView.ItemsSource = video.Formats.Where(f => !f.IsAudioOnly).ToList();
        AudioFormatsListView.ItemsSource = video.Formats.Where(f => f.IsAudioOnly && !f.IsVideoOnly).ToList();

        _allSubtitleGroups = BuildSubtitleGroups(video, _pinnedLanguages);
        ApplySubtitleFilter();
    }

    private void FormatsListView_MouseDoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
    {
        // 只在雙擊到「項目」時觸發，避免雙擊標題列或空白處。
        if (sender is ListView { SelectedItem: Core.FormatInfo format })
            RequestDownload(format);
    }

    private void DownloadButton_Click(object sender, RoutedEventArgs e)
    {
        var selected = InfoTabControl.SelectedIndex switch
        {
            0 => QualityFormatsListView.SelectedItem as Core.FormatInfo,
            1 => AudioFormatsListView.SelectedItem as Core.FormatInfo,
            _ => null
        };

        if (InfoTabControl.SelectedIndex == 2)
        {
            if (SubtitlesListView.SelectedItem is SubtitleGroup group)
                _ = DownloadSubtitleAsync(group);
            else
                MessageBox.Show("請先在清單中選擇要下載的字幕語言。", "提示",
                    MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }

        if (selected is null)
        {
            MessageBox.Show("請先在清單中選擇要下載的項目。", "提示",
                MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }

        RequestDownload(selected);
    }

    private void SubtitlesListView_MouseDoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
    {
        // 只在雙擊到「項目」時觸發。
        if (sender is ListView { SelectedItem: SubtitleGroup group })
            _ = DownloadSubtitleAsync(group);
    }

    /// <summary>
    /// 下載選取語言的字幕（只抓字幕，存成 .srt 到下載資料夾）。
    /// 目前直接呼叫 YTDLPClient，尚未經過 DownloadQueueManager 下載佇列。
    /// </summary>
    private async Task DownloadSubtitleAsync(SubtitleGroup group)
    {
        if (_currentUrl is null) return;

        // 每次重新讀取設定，取得使用者最新的下載資料夾。
        var folder = new SettingsStore().Current.DownloadFolder;
        try
        {
            Directory.CreateDirectory(folder);
        }
        catch (Exception ex)
        {
            MessageBox.Show($"無法建立下載資料夾：{folder}\n{ex.Message}", "字幕下載失敗",
                MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        DownloadButton.IsEnabled = false;
        SubtitleCountText.Text = $"正在下載字幕：{group.DisplayName} …";
        var startedAt = DateTime.Now.AddSeconds(-2);

        try
        {
            var outputTemplate = Path.Combine(folder, "%(title)s.%(ext)s");
            var exitCode = await _client.DownloadSubtitleAsync(
                _currentUrl, group.LanguageCode, group.Kind != SubtitleKind.Manual, outputTemplate);

            // 檔名格式：標題.語言代碼.srt；以「開始後才寫入」加語言代碼比對。
            var files = Directory.EnumerateFiles(folder, "*.srt")
                .Where(f => File.GetLastWriteTime(f) >= startedAt &&
                            Path.GetFileName(f).Contains($".{group.LanguageCode}.", StringComparison.OrdinalIgnoreCase))
                .ToList();

            if (files.Count > 0)
            {
                SubtitleCountText.Text = $"已儲存：{Path.GetFileName(files[0])}";
                Process.Start(new ProcessStartInfo("explorer.exe", $"/select,\"{files[0]}\"") { UseShellExecute = true });
            }
            else
            {
                FileLogger.Warn("VideoInfoView", $"字幕下載沒有產生檔案: lang={group.LanguageCode}, ExitCode={exitCode}");
                SubtitleCountText.Text = "字幕下載失敗";
                MessageBox.Show(
                    $"沒有取得「{group.DisplayName}」字幕檔（ExitCode={exitCode}）。\n" +
                    "自動翻譯字幕偶爾會被 YouTube 限流（HTTP 429），可稍後重試，或改選「自動產生」的原文字幕。\n" +
                    "詳細訊息請看 FileLogger 的記錄檔。",
                    "字幕下載失敗", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }
        catch (Exception ex)
        {
            FileLogger.Error("VideoInfoView", $"字幕下載發生例外: lang={group.LanguageCode}", ex);
            SubtitleCountText.Text = "字幕下載失敗";
            MessageBox.Show(ex.Message, "字幕下載失敗", MessageBoxButton.OK, MessageBoxImage.Warning);
        }
        finally
        {
            DownloadButton.IsEnabled = true;
        }
    }

    private void RequestDownload(Core.FormatInfo format)
    {
        if (_currentVideo is null || _currentUrl is null) return;

        // video-only（無聲）格式需自動搭配最佳音訊；其餘（含音訊）直接用 format_id。
        // "/b" 為備援：指定組合失敗時退回 yt-dlp 的最佳單檔。
        var selector = format.IsVideoOnly && !format.IsAudioOnly
            ? $"{format.FormatId}+ba/b"
            : format.FormatId;

        // 依目前所在分頁（畫質＝0／音訊＝1）套用對應的輸出格式單選鈕。
        // 雙擊清單時只會發生在使用者正在看的那個分頁，所以用 SelectedIndex 判斷是可靠的。
        var outputFormat = InfoTabControl.SelectedIndex == 1
            ? GetSelectedAudioOutputFormat()
            : GetSelectedVideoOutputFormat();

        DownloadRequested?.Invoke(this, new VideoDownloadRequest(_currentUrl, _currentVideo.Title, selector, outputFormat));
    }

    /// <summary>對應「輸出格式選項」：讀取「畫質」分頁目前選擇的輸出格式（原始格式／MP4）。</summary>
    private OutputFormat GetSelectedVideoOutputFormat() =>
        VideoOutputMp4Radio.IsChecked == true ? OutputFormat.Mp4 : OutputFormat.None;

    /// <summary>對應「輸出格式選項」：讀取「音訊」分頁目前選擇的輸出格式（原始格式／MP3／M4A）。</summary>
    private OutputFormat GetSelectedAudioOutputFormat()
    {
        if (AudioOutputMp3Radio.IsChecked == true) return OutputFormat.Mp3;
        if (AudioOutputM4aRadio.IsChecked == true) return OutputFormat.M4a;
        return OutputFormat.None;
    }

    /// <summary>
    /// 把 subtitles / automatic_captions 依「語言」分組：一種語言一列，格式收進 Formats。
    /// 排序：手動上傳 → 自動產生（原文）→ 自動翻譯；同類中常用語言（PinnedSubtitleLanguages）在前。
    /// </summary>
    private static List<SubtitleGroup> BuildSubtitleGroups(Core.VideoInfo video, string[] pinned)
    {
        var resolver = new LanguageNameResolver();
        var groups = new List<SubtitleGroup>();

        void AddGroups(IEnumerable<(string Code, IEnumerable<SubtitleInfo> Items)> source, bool isAuto)
        {
            foreach (var (code, items) in source)
            {
                var formats = items.ToList();
                if (formats.Count == 0) continue;

                foreach (var f in formats)
                {
                    f.LanguageCode = code;
                    f.IsAutoGenerated = isAuto;
                }

                var kind = !isAuto ? SubtitleKind.Manual
                    : code.EndsWith("-orig", StringComparison.OrdinalIgnoreCase) ? SubtitleKind.AutoOriginal
                    : SubtitleKind.AutoTranslated;

                var pinnedIndex = Array.FindIndex(pinned,
                    p => string.Equals(p, code, StringComparison.OrdinalIgnoreCase));

                groups.Add(new SubtitleGroup
                {
                    LanguageCode = code,
                    DisplayName = resolver.Resolve(code),
                    Kind = kind,
                    PinnedIndex = pinnedIndex < 0 ? int.MaxValue : pinnedIndex,
                    Formats = formats
                });
            }
        }

        AddGroups((video.Subtitles ?? new())
            .Select(kv => (Code: kv.Key, Items: kv.Value.AsEnumerable())), isAuto: false);
        AddGroups((video.AutomaticCaptions ?? new())
            .Select(kv => (Code: kv.Key, Items: kv.Value.AsEnumerable())), isAuto: true);

        return groups
            .OrderBy(g => g.Kind)
            .ThenBy(g => g.PinnedIndex)
            .ThenBy(g => g.DisplayName, StringComparer.CurrentCulture)
            .ToList();
    }

    /// <summary>
    /// 對應四：字幕 Tab 搜尋＋分組清單。
    /// 預設只顯示「手動上傳」「自動產生（原文）」與常用語言的自動翻譯；
    /// 勾選「顯示全部自動翻譯語言」或輸入搜尋文字時，才列出全部。
    /// </summary>
    private void ApplySubtitleFilter()
    {
        var keyword = SubtitleSearchBox.Text.Trim();
        var showAll = ShowTranslatedCheckBox.IsChecked == true;

        IEnumerable<SubtitleGroup> query = _allSubtitleGroups;
        if (keyword.Length > 0)
        {
            query = query.Where(g =>
                g.LanguageCode.Contains(keyword, StringComparison.OrdinalIgnoreCase) ||
                g.DisplayName.Contains(keyword, StringComparison.OrdinalIgnoreCase));
        }
        else if (!showAll)
        {
            query = query.Where(g => g.Kind != SubtitleKind.AutoTranslated || g.IsPinned);
        }

        var list = query.ToList();
        SubtitlesListView.ItemsSource = list;
        SubtitleEmptyText.Visibility = list.Count == 0 ? Visibility.Visible : Visibility.Collapsed;
        SubtitleCountText.Text = $"顯示 {list.Count} / 共 {_allSubtitleGroups.Count} 種語言";
    }
}

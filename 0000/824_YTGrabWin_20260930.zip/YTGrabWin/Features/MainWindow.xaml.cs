using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;
using YTGrabWin.Core;
using YTGrabWin.Features.Playlist;
using YTGrabWin.Features.Common;
using YTGrabWin.Features.Settings;
using YTGrabWin.Features.VideoInfo;

namespace YTGrabWin.Features;

/// <summary>
/// 對應企劃案四：主畫面邏輯。負責網址分流（單支/播放列表）、串接各子畫面。
/// </summary>
public partial class MainWindow : Window
{
    private readonly App.AppState _state = App.App.State;

    public MainWindow()
    {
        InitializeComponent();
        DownloadFolderTextBox.Text = _state.Settings.Current.DownloadFolder;
        DownloadQueue.Bind(_state.DownloadQueue);
        VideoInfo.DownloadRequested += VideoInfo_DownloadRequested;

        // Firefox 外掛按鍵：狀態改變時更新按鍵；視窗載入後先偵測一次；外掛異常結束時提示。
        _state.Firefox.StatusChanged += (_, _) => Dispatcher.BeginInvoke(ApplyFirefoxState);
        _state.Firefox.RunFailed += (_, message) => Dispatcher.BeginInvoke(() => ShowFirefoxError(message));
        Loaded += (_, _) => _state.Firefox.Refresh();
    }

    /// <summary>
    /// 對應二、2.1：網址分流——單支影片用 --no-playlist -J，播放列表用 --flat-playlist --yes-playlist -J。
    /// 此處以「是否含播放列表參數/回應是否有 entries」判斷，實際規則沿用 macOS 版邏輯（見三、規格）。
    /// </summary>
    private async void UrlInput_UrlSubmitted(object? sender, string url)
    {
        // 對應「讀取資訊時顯示運行中訊息，完成後自動消失」：顯示無按鈕提示視窗，
        // 並把主視窗鎖住（IsEnabled = false），避免使用者在讀取期間重複送出
        // 同一網址（先前造成同一網址被連續讀取多次的操作情境，也一併避免）。
        var loading = new LoadingWindow("讀取影片資訊中，請稍候...") { Owner = this };
        IsEnabled = false;
        loading.Show();

        try
        {
            var playlistInfo = await _state.YtDlpClient.FetchPlaylistInfoAsync(url);
            if (playlistInfo is { Entries.Count: > 1 })
            {
                VideoInfo.Visibility = Visibility.Collapsed;
                Playlist.Visibility = Visibility.Visible;
                Playlist.LoadPlaylist(playlistInfo);
                return;
            }

            var videoInfo = await _state.YtDlpClient.FetchVideoInfoAsync(url);
            if (videoInfo is not null)
            {
                Playlist.Visibility = Visibility.Collapsed;
                VideoInfo.Visibility = Visibility.Visible;
                VideoInfo.LoadVideo(videoInfo, url);
            }
            else
            {
                MessageBox.Show("無法讀取此網址的影片資訊，請確認網址是否正確。", "錯誤",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        finally
        {
            // 對應「完成後訊息框消失」：不論成功、失敗或例外都要關閉提示視窗、恢復主視窗可互動。
            loading.Close();
            IsEnabled = true;
        }
    }

    /// <summary>單支影片：使用者在畫質/音訊清單選好格式後，建立下載任務並開始下載。</summary>
    private void VideoInfo_DownloadRequested(object? sender, VideoDownloadRequest request)
    {
        var outputTemplate = System.IO.Path.Combine(
            _state.Settings.Current.DownloadFolder, "%(title)s.%(ext)s");

        var task = new DownloadTask
        {
            Id = Guid.NewGuid().ToString(),
            Url = request.Url,
            Title = request.Title,
            FormatSelector = request.FormatSelector,
            OutputFormat = request.OutputFormat
        };
        _state.DownloadQueue.Enqueue(task);
        _ = _state.DownloadQueue.StartAsync(task, outputTemplate);
    }

    /// <summary>對應三、規格：播放列表勾選批次下載。</summary>
    private void Playlist_BatchDownloadRequested(object? sender, IReadOnlyList<PlaylistEntry> selectedEntries)
    {
        var outputTemplate = System.IO.Path.Combine(
            _state.Settings.Current.DownloadFolder, "%(playlist_index)s - %(title)s.%(ext)s");

        foreach (var entry in selectedEntries)
        {
            var task = new DownloadTask
            {
                Id = Guid.NewGuid().ToString(),
                Url = entry.Url,
                Title = entry.Title,
                FormatSelector = $"bv*[height<={_state.Settings.Current.DefaultPlaylistMaxQuality.TrimEnd('p')}]+ba/b"
            };
            _state.DownloadQueue.Enqueue(task);
            _ = _state.DownloadQueue.StartAsync(task, outputTemplate);
        }
    }

    /// <summary>點擊「下載資料夾：」文字按鈕，直接開啟目前設定的下載資料夾。</summary>
    private void OpenDownloadFolderButton_Click(object sender, RoutedEventArgs e)
    {
        ExplorerActions.OpenFolder(_state.Settings.Current.DownloadFolder);
    }

    private void SettingsButton_Click(object sender, RoutedEventArgs e)
    {
        var settingsWindow = new SettingsView { Owner = this };
        settingsWindow.ShowDialog();
        DownloadFolderTextBox.Text = _state.Settings.Current.DownloadFolder;
    }

    // ───────────── Firefox 外掛按鍵（本地端運行） ─────────────

    private static readonly Brush DotGray = new SolidColorBrush(Color.FromRgb(0x9C, 0xA3, 0xAF));
    private static readonly Brush DotYellow = new SolidColorBrush(Color.FromRgb(0xF5, 0x9E, 0x0B));
    private static readonly Brush DotGreen = new SolidColorBrush(Color.FromRgb(0x16, 0xA3, 0x4A));

    /// <summary>依 FirefoxIntegrationService 的狀態更新按鍵文字、燈號與提示。</summary>
    private void ApplyFirefoxState()
    {
        switch (_state.Firefox.State)
        {
            case FirefoxIntegrationState.FirefoxNotFound:
                FirefoxButtonText.Text = "取得 Firefox";
                FirefoxStatusDot.Fill = DotGray;
                FirefoxButton.ToolTip = "找不到 Firefox，點一下開啟下載頁";
                break;

            case FirefoxIntegrationState.NodeNotFound:
                FirefoxButtonText.Text = "需要 Node.js";
                FirefoxStatusDot.Fill = DotGray;
                FirefoxButton.ToolTip = "本地執行外掛需要 Node.js（npm）。點一下開啟下載頁，安裝後請重新啟動 YTGrab";
                break;

            case FirefoxIntegrationState.ExtensionFolderMissing:
                FirefoxButtonText.Text = "選擇外掛資料夾";
                FirefoxStatusDot.Fill = DotGray;
                FirefoxButton.ToolTip = "找不到 video-analyzer-extension 資料夾，點一下手動選擇";
                break;

            case FirefoxIntegrationState.ReadyToRun:
                FirefoxButtonText.Text = "啟動 Firefox 外掛";
                FirefoxStatusDot.Fill = DotYellow;
                FirefoxButton.ToolTip = "在本地端以 npm start 啟動 Firefox 並載入外掛（首次會先執行 npm install）";
                break;

            case FirefoxIntegrationState.Running:
                FirefoxButtonText.Text = "外掛執行中";
                FirefoxStatusDot.Fill = DotGreen;
                FirefoxButton.ToolTip = "外掛已載入 Firefox；關閉該 Firefox 視窗即停止，也可右鍵選「停止外掛」";
                break;
        }
    }

    private async void FirefoxButton_Click(object sender, RoutedEventArgs e)
    {
        var service = _state.Firefox;
        string? error = null;
        var ok = true;

        FileLogger.Info("FirefoxUI", "按下「Firefox 外掛」按鍵");

        switch (service.Refresh())
        {
            case FirefoxIntegrationState.FirefoxNotFound:
                ok = service.TryOpenFirefoxDownloadPage(out error);
                break;

            case FirefoxIntegrationState.NodeNotFound:
                ok = service.TryOpenNodeDownloadPage(out error);
                break;

            case FirefoxIntegrationState.ExtensionFolderMissing:
                PickExtensionFolder();
                return;

            case FirefoxIntegrationState.Running:
                MessageBox.Show("外掛已在 Firefox 中執行。\n關閉該 Firefox 視窗即會停止；也可以在按鍵上按右鍵選「停止外掛」。",
                    "Firefox 外掛", MessageBoxButton.OK, MessageBoxImage.Information);
                return;

            case FirefoxIntegrationState.ReadyToRun:
                (ok, error) = await StartFirefoxExtensionAsync();
                break;
        }

        if (!ok) ShowFirefoxError(error);
    }

    /// <summary>啟動外掛；首次（沒有 node_modules）需要 npm install，顯示提示視窗並鎖住主視窗。</summary>
    private async Task<(bool Ok, string? Error)> StartFirefoxExtensionAsync()
    {
        LoadingWindow? loading = null;
        if (_state.Firefox.NeedsNpmInstall)
        {
            loading = new LoadingWindow("首次啟動，正在安裝外掛相依套件（npm install），請稍候...") { Owner = this };
            IsEnabled = false;
            loading.Show();
        }

        try
        {
            return await _state.Firefox.StartLocalExtensionAsync();
        }
        finally
        {
            if (loading is not null)
            {
                loading.Close();
                IsEnabled = true;
            }
        }
    }

    private void PickExtensionFolder()
    {
        var dialog = new Microsoft.Win32.OpenFolderDialog { Title = "選擇 video-analyzer-extension 資料夾" };
        if (dialog.ShowDialog(this) != true) return;

        if (!_state.Firefox.TrySetExtensionFolder(dialog.FolderName, out var error))
            ShowFirefoxError(error);
    }

    private void FirefoxStopMenuItem_Click(object sender, RoutedEventArgs e)
    {
        _state.Firefox.StopLocalExtension();
    }

    private void FirefoxPickFolderMenuItem_Click(object sender, RoutedEventArgs e)
    {
        PickExtensionFolder();
    }

    private void FirefoxDebugMenuItem_Click(object sender, RoutedEventArgs e)
    {
        _state.Firefox.Refresh();
        if (!_state.Firefox.TryOpenAboutDebugging(out var error)) ShowFirefoxError(error);
    }

    private void FirefoxRefreshMenuItem_Click(object sender, RoutedEventArgs e)
    {
        _state.Firefox.Refresh();
    }

    /// <summary>顯示錯誤，並詢問是否開啟記錄檔資料夾（按「是」）。</summary>
    private static void ShowFirefoxError(string? message)
    {
        FileLogger.Warn("FirefoxUI", $"顯示錯誤對話框: {message}");

        var result = MessageBox.Show(
            (message ?? "無法完成操作。") + "\n\n要開啟記錄檔所在資料夾嗎？",
            "Firefox 外掛",
            MessageBoxButton.YesNo, MessageBoxImage.Warning);

        if (result != MessageBoxResult.Yes) return;

        try { FileLogger.OpenLogFolder(); }
        catch (Exception ex) { FileLogger.Error("FirefoxUI", "開啟記錄檔資料夾失敗", ex); }
    }

    /// <summary>對應三、平台差異表：拖放網址，取代 macOS 拖放到 App 圖示。</summary>
    private void MainWindow_Drop(object sender, DragEventArgs e)
    {
        if (e.Data.GetDataPresent(DataFormats.Text))
        {
            var url = ((string)e.Data.GetData(DataFormats.Text)).Trim();
            UrlInput.SetUrl(url);
            UrlInput_UrlSubmitted(this, url);
        }
    }
}

#!/usr/bin/env python3
"""把 strings_batchNN.json 合併進 Localizable.xcstrings（可重複使用）。
用法（在專案根目錄）：
    python3 batch01/merge_strings.py batch01/strings_batch01.json
可選第二個參數指定 xcstrings 路徑，預設 "Dictation Helper/Localizable.xcstrings"。
- 同名 key 以批次檔為準（覆蓋），其他既有 key 不動；寫入前自動備份成 .bak
- 一律標記 extractionState=manual，避免 Xcode 把透過 L10n.t("key") 使用的 key 判為過時
"""
import json, sys, shutil, os
batch = sys.argv[1]
path = sys.argv[2] if len(sys.argv) > 2 else "Dictation Helper/Localizable.xcstrings"
data = json.load(open(path, encoding="utf-8")) if os.path.exists(path) else {"sourceLanguage": "en", "strings": {}, "version": "1.0"}
if os.path.exists(path): shutil.copy(path, path + ".bak")
new = json.load(open(batch, encoding="utf-8"))
for key, langs in new.items():
    data["strings"][key] = {
        "extractionState": "manual",
        "localizations": {lang: {"stringUnit": {"state": "translated", "value": v}} for lang, v in langs.items()},
    }
data["strings"] = dict(sorted(data["strings"].items()))
with open(path, "w", encoding="utf-8") as f:
    json.dump(data, f, ensure_ascii=False, indent=2, separators=(",", " : "))
    f.write("\n")
print(f"已合併 {len(new)} 個 key；目前共 {len(data['strings'])} 個 → {path}")

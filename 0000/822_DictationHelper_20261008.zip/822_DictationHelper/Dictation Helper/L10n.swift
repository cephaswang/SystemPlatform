import Foundation

/// 多語言輔助：非 SwiftUI 場合（狀態訊息、錯誤、NSAlert、NSOpenPanel）用 L10n.t("key")。
/// SwiftUI 的 Text("key") 會自動查 Localizable，不需經過這裡。
enum L10n {
    /// 目前實際採用的介面語言："en"、"zh-Hant"、"zh-Hans"
    static var uiLanguage: String {
        Bundle.main.preferredLocalizations.first ?? "en"
    }

    static func t(_ key: String, comment: String = "") -> String {
        NSLocalizedString(key, comment: comment)
    }

    /// 語系代碼轉成人看得懂的名稱，跟隨介面語言，例如 "en-US" →「英文（美國）」／"English (United States)"
    static func localeDisplayName(_ identifier: String) -> String {
        Locale(identifier: uiLanguage).localizedString(forIdentifier: identifier) ?? identifier
    }

    /// 辨識語言選單的完整顯示文字：
    /// 中文介面「英文（美國）（en-US）」；英文介面 "English (United States) · en-US"（避免兩層括號）
    static func recognitionLocaleName(_ identifier: String) -> String {
        let name = localeDisplayName(identifier)
        return uiLanguage == "en" ? "\(name) · \(identifier)" : "\(name)（\(identifier)）"
    }

    /// 首次使用的預設辨識語系：依介面語言，而非固定 zh-TW
    static var defaultRecognitionLocaleID: String {
        switch uiLanguage {
        case "zh-Hans": return "zh-CN"
        case "zh-Hant": return "zh-TW"
        default: return "en-US"
        }
    }

    /// 置頂排序用：en-US、zh-TW、zh-CN 排在前面
    static let pinnedRecognitionLocales = ["en-US", "zh-TW", "zh-CN"]
}

import SwiftUI
import AppKit

/// 共用的「開啟使用說明」邏輯。
/// 抽成獨立的 enum，是為了讓選單列（RootApp.swift）可以直接呼叫，
/// 不需要透過 NotificationCenter 或是把 HelpView 塞進畫面階層才能觸發。
///
/// 使用說明改成網頁版教學（index.html + images/），打包成 `helpdocs.zip` 放進 App Bundle。
/// 每次點擊「使用說明」時：
///   1. 先強制刪除暫存區裡上一次解壓的舊版本，避免使用者看到過期內容
///   2. 重新解壓 helpdocs.zip 到暫存區
///   3. 用系統預設瀏覽器開啟解壓出來的 index.html
///
/// 找不到 zip、解壓失敗、或解壓後找不到 index.html 時，會跳出系統警示視窗說明原因。
enum HelpDocsOpener {

    /// 解壓縮後在暫存區使用的資料夾名稱
    private static let folderName = "helpdocs"

    /// 暫存區內，本次要解壓縮到的目的地資料夾
    /// （每次開啟都會先整個刪除重建，確保內容一定是 Bundle 裡最新的 helpdocs.zip）
    private static var destinationURL: URL {
        FileManager.default.temporaryDirectory.appendingPathComponent(folderName)
    }

    /// 依介面語言決定要開哪一份說明首頁（依序嘗試，找到第一個存在的）。
    /// 繁中：index.html；英文：index_en.html；簡中：index_zh-Hans.html（尚未製作前退回英文版）。
    private static var indexFileNames: [String] {
        switch L10n.uiLanguage {
        case "zh-Hant": return ["index.html"]
        case "zh-Hans": return ["index_zh-Hans.html", "index_en.html", "index.html"]
        default:        return ["index_en.html", "index.html"]
        }
    }

    static func open() {
        guard let zipURL = Bundle.main.url(forResource: "helpdocs", withExtension: "zip") else {
            showAlert(
                title: L10n.t("help.alert.zipMissing.title"),
                message: L10n.t("help.alert.zipMissing.message")
            )
            return
        }

        let fileManager = FileManager.default
        let destination = destinationURL

        // 1. 強制刪除先前解壓的舊版本
        if fileManager.fileExists(atPath: destination.path) {
            do {
                try fileManager.removeItem(at: destination)
            } catch {
                showAlert(
                    title: L10n.t("help.alert.cleanFail.title"),
                    message: String(format: L10n.t("help.alert.cleanFail.message"), destination.path, error.localizedDescription)
                )
                return
            }
        }

        do {
            try fileManager.createDirectory(at: destination, withIntermediateDirectories: true)
        } catch {
            showAlert(
                title: L10n.t("help.alert.mkdirFail.title"),
                message: error.localizedDescription
            )
            return
        }

        // 2. 呼叫系統內建的 /usr/bin/unzip 解壓縮（-o 覆蓋、-q 安靜模式）
        let process = Process()
        process.executableURL = URL(fileURLWithPath: "/usr/bin/unzip")
        process.arguments = ["-o", "-q", zipURL.path, "-d", destination.path]

        do {
            try process.run()
            process.waitUntilExit()
        } catch {
            showAlert(
                title: L10n.t("help.alert.unzipFail.title"),
                message: String(format: L10n.t("help.alert.unzipStartFail.message"), error.localizedDescription)
            )
            return
        }

        guard process.terminationStatus == 0 else {
            showAlert(
                title: L10n.t("help.alert.unzipFail.title"),
                message: String(format: L10n.t("help.alert.unzipStatus.message"), process.terminationStatus)
            )
            return
        }

        // 3. helpdocs.zip 內若還包了一層 helpdocs/ 資料夾（例如在 Mac 上用 Finder／zip 指令
        //    直接壓縮資料夾產生的結構），這裡兩種路徑都嘗試找找看
        //    並依介面語言挑選對應的說明首頁（找不到對應語言時依序退回）
        let candidateURLs = indexFileNames.flatMap { name in
            [
                destination.appendingPathComponent(name),
                destination.appendingPathComponent(folderName).appendingPathComponent(name)
            ]
        }

        guard let indexURL = candidateURLs.first(where: { fileManager.fileExists(atPath: $0.path) }) else {
            showAlert(
                title: L10n.t("help.alert.indexMissing.title"),
                message: L10n.t("help.alert.indexMissing.message")
            )
            return
        }

        NSWorkspace.shared.open(indexURL)
    }

    private static func showAlert(title: String, message: String) {
        let alert = NSAlert()
        alert.messageText = title
        alert.informativeText = message
        alert.alertStyle = .warning
        alert.runModal()
    }
}

/// 保留這個 View 是為了相容舊的呼叫方式
/// （例如 .sheet(isPresented:) { HelpView() } 或其他仍直接建立 HelpView() 的地方）。
/// 這個 View 本身不會顯示任何畫面：一出現就開啟使用說明網頁，然後立刻關閉自己。
///
/// 注意：選單列「Dictation Helper > Help」現在已經改成直接呼叫
/// HelpDocsOpener.open()（見 RootApp.swift），不會再經過這個 View。
struct HelpView: View {
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        let _ = print("🖼️ [\(Self.self)] body (\(#fileID))")
        Color.clear
            .onAppear {
                HelpDocsOpener.open()
                dismiss()
            }
    }
}

#Preview {
    HelpView()
}

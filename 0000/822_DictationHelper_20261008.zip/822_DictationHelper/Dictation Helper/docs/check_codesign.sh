#!/bin/bash
# https://www.youtube.com/watch?v=Xg55nTrbYYY
# check_codesign.sh
#
# Read-only diagnostic script for "CodeSign failed with a nonzero exit code"
# in Xcode. Does not modify anything; only prints information to help narrow
# down the cause (see the troubleshooting checklist discussed in chat).
#
# Usage:
#   chmod +x check_codesign.sh
#   ./check_codesign.sh
#
# Optional: edit the CONFIG section below, or pass values as arguments:
#   ./check_codesign.sh /path/to/ProjectDir /path/to/Built.app
#

set -uo pipefail

# ---------- CONFIG (edit these or pass as arguments) ----------
PROJECT_DIR="${1:-.}"
APP_PATH="${2:-}"
BUNDLE_ID="org.share35app.Dictation-Helper"
APP_PROCESS_NAME="Dictation Helper"
# ----------------------------------------------------------------

separator() {
  echo ""
  echo "----------------------------------------------------------------------"
  echo "$1"
  echo "----------------------------------------------------------------------"
}

separator "1. macOS / Xcode version"
sw_vers
echo ""
xcodebuild -version 2>/dev/null || echo "(xcodebuild not found or Xcode not installed)"

separator "2. Is the app currently running? (can block CodeSign with 'Resource busy')"
if pgrep -f "$APP_PROCESS_NAME" > /dev/null 2>&1; then
  echo "WARNING: found a running process matching '$APP_PROCESS_NAME':"
  pgrep -fl "$APP_PROCESS_NAME"
  echo "-> Fully quit the app (Cmd+Q) before building, then try again."
else
  echo "OK: no running process matching '$APP_PROCESS_NAME'."
fi

separator "3. Valid code signing identities in Keychain"
IDENTITY_OUTPUT="$(security find-identity -v -p codesigning 2>&1)"
echo "$IDENTITY_OUTPUT"
VALID_COUNT="$(echo "$IDENTITY_OUTPUT" | grep -c "valid identities found" || true)"
if echo "$IDENTITY_OUTPUT" | grep -q "0 valid identities found"; then
  echo ""
  echo "WARNING: 0 valid signing identities found."
  echo "-> Check Xcode > Settings > Accounts, and Keychain Access > My Certificates"
  echo "   for an expired or missing-private-key certificate."
fi

separator "4. Login keychain lock status"
security show-keychain-info ~/Library/Keychains/login.keychain-db 2>&1 || \
  echo "(could not query login keychain; it may require unlocking manually)"

separator "5. Extended attributes / resource forks in project directory"
echo "Scanning: $PROJECT_DIR (excluding .git, DerivedData, build)"
FOUND_XATTR=0
while IFS= read -r -d '' f; do
  ATTRS="$(xattr "$f" 2>/dev/null)"
  if [ -n "$ATTRS" ]; then
    FOUND_XATTR=1
    echo "  $f"
    echo "$ATTRS" | sed 's/^/    - /'
  fi
done < <(find "$PROJECT_DIR" -type f \
  -not -path "*/.git/*" \
  -not -path "*/DerivedData/*" \
  -not -path "*/build/*" \
  -print0 2>/dev/null)

if [ "$FOUND_XATTR" -eq 0 ]; then
  echo "OK: no extended attributes found on project files."
else
  echo ""
  echo "-> Files above have extended attributes (often from network drives,"
  echo "   AirDrop, or Windows file shares) that can break CodeSign."
  echo "   To clear them, run:  xattr -cr \"$PROJECT_DIR\""
fi

separator "6. Entitlements files found in project"
ENTITLEMENTS_FILES="$(find "$PROJECT_DIR" -name "*.entitlements" -not -path "*/DerivedData/*" 2>/dev/null)"
if [ -z "$ENTITLEMENTS_FILES" ]; then
  echo "No .entitlements files found under $PROJECT_DIR."
else
  echo "$ENTITLEMENTS_FILES" | while IFS= read -r ent; do
    echo ""
    echo "File: $ent"
    plutil -p "$ent" 2>/dev/null || cat "$ent"
  done
fi

separator "7. Info.plist screen capture key check"
INFO_PLISTS="$(find "$PROJECT_DIR" -name "Info.plist" -not -path "*/DerivedData/*" 2>/dev/null)"
if [ -z "$INFO_PLISTS" ]; then
  echo "No Info.plist found under $PROJECT_DIR (may be generated at build time from build settings)."
else
  echo "$INFO_PLISTS" | while IFS= read -r plist; do
    echo ""
    echo "File: $plist"
    if grep -q "NSScreenCaptureUsageDescription" "$plist" 2>/dev/null; then
      echo "  OK: NSScreenCaptureUsageDescription present."
    else
      echo "  Not found in this file (may be injected via GENERATE_INFOPLIST_FILE / Info tab settings instead)."
    fi
  done
fi

separator "8. Built app signature check (only if APP_PATH given)"
if [ -z "$APP_PATH" ]; then
  echo "No app path given. Re-run with:"
  echo "  ./check_codesign.sh \"$PROJECT_DIR\" \"/path/to/Dictation Helper.app\""
elif [ ! -e "$APP_PATH" ]; then
  echo "APP_PATH does not exist: $APP_PATH"
else
  echo "Bundle ID from app: $(defaults read "$APP_PATH/Contents/Info" CFBundleIdentifier 2>/dev/null)"
  echo ""
  echo "-- codesign -dvvv --"
  codesign -dvvv "$APP_PATH" 2>&1
  echo ""
  echo "-- codesign --verify --deep --strict --"
  codesign --verify --deep --strict --verbose=2 "$APP_PATH" 2>&1
fi

separator "Done"
echo "Copy any WARNING lines above, plus the full red error text from Xcode's"
echo "Report Navigator (Cmd+9), for further diagnosis."

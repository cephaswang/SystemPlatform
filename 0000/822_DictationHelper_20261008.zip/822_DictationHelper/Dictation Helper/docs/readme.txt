Privacy - Screen Capture Usage Description 
本 App 需要「螢幕與系統音訊錄製」權限，才能擷取系統喇叭聲音來即時轉成文字稿。
 
Privacy - Microphone Usage Description
本 App 需要存取麥克風

Privacy - Speech Recognition Usage Description
本 App 使用語音辨識功能將音訊即時轉換成文字。

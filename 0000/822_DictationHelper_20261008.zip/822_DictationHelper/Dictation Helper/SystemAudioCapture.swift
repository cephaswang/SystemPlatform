import Foundation
import ScreenCaptureKit
import AVFAudio
import CoreMedia
import Combine

// v3.0 新增模組。
//
// 取代 v2.0 以 BlackHole 虛擬音訊裝置作為系統預設輸入來擷取系統聲音的做法。
// 改用 Apple 官方的 ScreenCaptureKit：透過 SCStream 開啟 capturesAudio，
// 直接擷取「整個系統」或「指定某個執行中的 App」播放的聲音，完全不需要
// 切換系統輸出／輸入裝置，使用者聽到的聲音不受任何影響。
//
// 技術限制（見企劃書 4.4）：ScreenCaptureKit 目前沒有純音訊模式，因此本
// 模組仍會內部啟動一個極低幀率、畫面極小的影像串流通道以取得音訊，但
// 畫面樣本會在 didOutputSampleBuffer 中直接捨棄，不使用、不儲存、不顯示。
//
// 使用方式：
//   1. 呼叫 refreshAvailableApps() 取得目前可擷取的 App 清單（來自
//      SCShareableContent），供「系統聲音」來源選單顯示
//   2. 呼叫 startCapture(source:) 開始擷取；PCM 樣本會經由
//      audioBufferPublisher 送出，SpeechTranscriber 訂閱後接上
//      SFSpeechAudioBufferRecognitionRequest.append(_:)
//   3. 呼叫 stopCapture() 結束擷取

/// 使用者可選擇的系統聲音來源
enum SystemAudioCaptureSource: Equatable {
    /// 整個系統：擷取所有 App 播放的聲音
    case entireSystem
    /// 指定單一執行中的 App
    case app(bundleIdentifier: String, displayName: String)
}

/// 可被擷取的執行中 App（清單資料來自 SCShareableContent）
struct CapturableApp: Identifiable, Hashable {
    let id: pid_t
    let bundleIdentifier: String
    let displayName: String
}

enum SystemAudioCaptureError: LocalizedError {
    case screenRecordingPermissionDenied
    case noDisplayAvailable
    case appNotFound
    case alreadyCapturing

    var errorDescription: String? {
        switch self {
        case .screenRecordingPermissionDenied:
            return L10n.t("error.screenPermission")
        case .noDisplayAvailable:
            return L10n.t("error.noDisplay")
        case .appNotFound:
            return L10n.t("error.appNotFound")
        case .alreadyCapturing:
            return L10n.t("error.alreadyCapturing")
        }
    }
}

@available(macOS 13.0, *)
final class SystemAudioCapture: NSObject, ObservableObject {

    @Published private(set) var isCapturing = false
    @Published private(set) var availableApps: [CapturableApp] = []

    /// PCM 音訊樣本輸出。SpeechTranscriber 訂閱這個 publisher，
    /// 將收到的 AVAudioPCMBuffer 送進辨識引擎，取代原本讀取
    /// BlackHole 輸入裝置的方式。
    var audioBufferPublisher: AnyPublisher<AVAudioPCMBuffer, Never> {
        audioBufferSubject.eraseToAnyPublisher()
    }

    private let audioBufferSubject = PassthroughSubject<AVAudioPCMBuffer, Never>()
    private var stream: SCStream?
    private let sampleHandlerQueue = DispatchQueue(label: "com.dictationhelper.systemaudio.sample")

    // MARK: - 螢幕錄製授權

    /// 目前是否已取得「螢幕錄製」授權
    static func hasScreenRecordingPermission() -> Bool {
        CGPreflightScreenCaptureAccess()
    }

    /// 觸發系統的螢幕錄製授權對話框。
    /// 依 ScreenCaptureKit 特性，授權後需要重新啟動 App 才會真正生效。
    @discardableResult
    static func requestScreenRecordingPermission() -> Bool {
        CGRequestScreenCaptureAccess()
    }

    // MARK: - 列舉可擷取來源

    /// 重新列舉目前執行中、可被擷取的 App 清單。
    /// 對應「聲音來源」選單中「系統聲音」的「重新整理」按鈕。
    @MainActor
    func refreshAvailableApps() async throws {
        guard Self.hasScreenRecordingPermission() else {
            throw SystemAudioCaptureError.screenRecordingPermissionDenied
        }

        let content = try await SCShareableContent.excludingDesktopWindows(
            false, onScreenWindowsOnly: false)

        let apps = content.applications
            .filter { !$0.applicationName.isEmpty }
            .map {
                CapturableApp(
                    id: $0.processID,
                    bundleIdentifier: $0.bundleIdentifier,
                    displayName: $0.applicationName)
            }
            .sorted { $0.displayName.localizedStandardCompare($1.displayName) == .orderedAscending }

        availableApps = apps
    }

    // MARK: - 開始／停止擷取

    /// 開始擷取指定來源的系統聲音。
    /// 不會更動系統預設輸出／輸入裝置，使用者聽到的聲音完全不受影響。
    func startCapture(source: SystemAudioCaptureSource) async throws {
        guard stream == nil else {
            throw SystemAudioCaptureError.alreadyCapturing
        }
        guard Self.hasScreenRecordingPermission() else {
            throw SystemAudioCaptureError.screenRecordingPermissionDenied
        }

        let content = try await SCShareableContent.excludingDesktopWindows(
            false, onScreenWindowsOnly: false)

        guard let display = content.displays.first else {
            throw SystemAudioCaptureError.noDisplayAvailable
        }

        let filter: SCContentFilter
        switch source {
        case .entireSystem:
            filter = SCContentFilter(display: display, excludingWindows: [])

        case .app(let bundleIdentifier, _):
            guard let targetApp = content.applications.first(where: {
                $0.bundleIdentifier == bundleIdentifier
            }) else {
                throw SystemAudioCaptureError.appNotFound
            }
            filter = SCContentFilter(display: display, including: [targetApp], exceptingWindows: [])
        }

        let config = SCStreamConfiguration()
        config.capturesAudio = true
        config.excludesCurrentProcessAudio = true // 避免收到 App 本身可能播放的提示音
        config.sampleRate = 48_000
        config.channelCount = 2

        // ScreenCaptureKit 目前無純音訊模式：維持一個極低幀率、極小畫面的
        // 影像串流通道以取得音訊，畫面樣本在 didOutputSampleBuffer 中直接
        // 捨棄，不使用、不儲存、不顯示，對效能影響極小。
        config.width = 2
        config.height = 2
        config.minimumFrameInterval = CMTime(value: 1, timescale: 1)
        config.showsCursor = false

        let newStream = SCStream(filter: filter, configuration: config, delegate: self)
        try newStream.addStreamOutput(self, type: .audio, sampleHandlerQueue: sampleHandlerQueue)
        try newStream.addStreamOutput(self, type: .screen, sampleHandlerQueue: sampleHandlerQueue)

        try await newStream.startCapture()
        stream = newStream

        await MainActor.run {
            self.isCapturing = true
        }
    }

    /// 結束擷取。使用者的系統輸出／輸入裝置從未被更動過，因此不需要任何還原步驟。
    func stopCapture() async {
        guard let currentStream = stream else { return }
        stream = nil
        try? await currentStream.stopCapture()

        await MainActor.run {
            self.isCapturing = false
        }
    }
}

// MARK: - SCStreamDelegate

@available(macOS 13.0, *)
extension SystemAudioCapture: SCStreamDelegate {
    func stream(_ stream: SCStream, didStopWithError error: Error) {
        print("[SystemAudioCapture] 串流意外中止：\(error.localizedDescription)")
        self.stream = nil
        Task { @MainActor in
            self.isCapturing = false
        }
    }
}

// MARK: - SCStreamOutput

@available(macOS 13.0, *)
extension SystemAudioCapture: SCStreamOutput {
    func stream(
        _ stream: SCStream,
        didOutputSampleBuffer sampleBuffer: CMSampleBuffer,
        of type: SCStreamOutputType
    ) {
        switch type {
        case .audio:
            guard let pcmBuffer = Self.makePCMBuffer(from: sampleBuffer) else { return }
            audioBufferSubject.send(pcmBuffer)

        case .screen:
            // 只是為了取得音訊而維持的極低幀率畫面通道，直接捨棄，
            // 不使用、不儲存、不顯示其影像內容。
            break

        case .microphone:
            break
            
        @unknown default:
            break
        }
    }

    /// 將 ScreenCaptureKit 送出的音訊 CMSampleBuffer 轉成 AVAudioPCMBuffer，
    /// 供 SpeechTranscriber 的辨識流程使用（取代原本讀取 BlackHole 輸入的方式）。
    private static func makePCMBuffer(from sampleBuffer: CMSampleBuffer) -> AVAudioPCMBuffer? {
        guard sampleBuffer.isValid,
              let formatDescription = sampleBuffer.formatDescription,
              let asbd = formatDescription.audioStreamBasicDescription
        else { return nil }

        var mutableASBD = asbd
        guard let avFormat = AVAudioFormat(streamDescription: &mutableASBD) else { return nil }

        let numSamples = sampleBuffer.numSamples
        guard numSamples > 0,
              let pcmBuffer = AVAudioPCMBuffer(pcmFormat: avFormat, frameCapacity: AVAudioFrameCount(numSamples))
        else { return nil }

        pcmBuffer.frameLength = AVAudioFrameCount(numSamples)

        // 注意：這裡「不能」寫成
        //   var audioBufferList = pcmBuffer.mutableAudioBufferList.pointee
        //   ...into: &audioBufferList
        // 因為 AudioBufferList 在 C 端是變長結構（mNumberBuffers 後面接著 N 個
        // AudioBuffer），Swift 匯入後卻是固定大小、只裝得下 1 個 AudioBuffer 的
        // struct。config.channelCount = 2 搭配 ScreenCaptureKit 常見的
        // Float32 非交錯（non-interleaved）格式時，實際會有 2 個獨立的
        // AudioBuffer（左右聲道各一）。用 .pointee 複製成區域變數會保留
        // mNumberBuffers = 2，卻把第二個聲道的緩衝區記憶體整個截斷遺失，導致
        // CMSampleBufferCopyPCMDataIntoAudioBufferList 內部依 mNumberBuffers
        // 推算出的目的地大小與實際傳入的記憶體大小對不上，回傳
        // -12731（kCMSampleBufferError_RequiredParameterMissing，內部訊息
        // 常見為 "bbuf vs. sbuf data size mismatch"），且完全不會複製任何資料。
        //
        // 正確做法：直接把 mutableAudioBufferList 這個指標本身傳進去，讓它
        // 指到 AVAudioPCMBuffer 內部真正配置好、大小與聲道數一致的記憶體。
        let status = CMSampleBufferCopyPCMDataIntoAudioBufferList(
            sampleBuffer,
            at: 0,
            frameCount: Int32(numSamples),
            into: pcmBuffer.mutableAudioBufferList)

        guard status == noErr else {
            print("[SystemAudioCapture] 複製 PCM 資料失敗：status=\(status)")
            return nil
        }

        return pcmBuffer
    }
}

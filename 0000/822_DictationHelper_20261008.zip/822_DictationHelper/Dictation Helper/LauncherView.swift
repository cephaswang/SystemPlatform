import SwiftUI
import AppKit

struct LauncherView: View {

    let onSelectImport: () -> Void
    let onSelectVoiceCapture: () -> Void

    // 三項權限（語音辨識、麥克風、螢幕錄製）的狀態由 PermissionCoordinator 統一管理，
    // 第一頁載入時依序請求；點狀態列可開啟說明視窗。
    @EnvironmentObject private var permissions: PermissionCoordinator
    @State private var showEnvironmentInfoSheet = false

    var body: some View {
        VStack(spacing: 24) {

            Text("app.name")
                .font(.title)
                .bold()

            Text("launcher.subtitle")
                .font(.subheadline)
                .foregroundColor(.secondary)


            HStack(spacing: 20) {

                LauncherButton(
                    title: "launcher.mode.import",
                    subtitle: "launcher.mode.import.subtitle",
                    systemImage: "waveform.badge.plus",
                    action: onSelectImport
                )

                LauncherButton(
                    title: "launcher.mode.capture",
                    subtitle: "launcher.mode.capture.subtitle",
                    systemImage: "speaker.wave.2.circle",
                    action: onSelectVoiceCapture
                )
            }

            // 權限狀態列：三項權限都就緒時顯示綠色打勾；
            // 有項目未授權時顯示摘要，點一下開啟說明視窗。
            Button {
                permissions.refresh()
                showEnvironmentInfoSheet = true
            } label: {
                HStack(spacing: 6) {
                    Image(systemName: permissions.summary == nil ? "checkmark.circle.fill" : "exclamationmark.circle.fill")
                        .foregroundColor(permissions.summary == nil ? .green : .orange)
                    // summary 由 PermissionCoordinator 提供，須已是當前語言的字串
                    if let summary = permissions.summary {
                        Text(verbatim: summary).font(.caption)
                    } else {
                        Text("launcher.permissions.ready").font(.caption)
                    }
                }
                .foregroundColor(.secondary)
            }
            .buttonStyle(.plain)
        }
        .padding(32)
        .frame(maxWidth: .infinity)
        // 第一頁載入時依序請求全部權限（只會執行一次，已決定的項目不會重複詢問）
        .task {
            await permissions.requestAllIfNeeded()
        }
        // 使用者從系統設定回到 App 時，重新讀取授權狀態
        .onReceive(NotificationCenter.default.publisher(for: NSApplication.didBecomeActiveNotification)) { _ in
            permissions.refresh()
        }
        .sheet(isPresented: $showEnvironmentInfoSheet) {
            EnvironmentInfoView()
                .environmentObject(permissions)
        }
    }
}

/// 權限說明視窗：列出三項權限目前的狀態，被拒絕時可直接前往對應的系統設定分頁。
private struct EnvironmentInfoView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var permissions: PermissionCoordinator

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("permsheet.title")
                .font(.title2)
                .bold()

            statusRow(
                ready: permissions.speech == .authorized,
                title: "perm.speech.title",
                readyText: "perm.speech.ready",
                notReadyText: LocalizedStringKey(permissions.speech == .notDetermined
                    ? "perm.speech.notDetermined"
                    : "perm.speech.denied"),
                settingsPane: permissions.speech == .denied ? "SpeechRecognition" : nil,
                settingsTitle: "perm.speech.openSettings"
            )

            statusRow(
                ready: permissions.microphone == .authorized,
                title: "perm.mic.title",
                readyText: "perm.mic.ready",
                notReadyText: LocalizedStringKey(permissions.microphone == .notDetermined
                    ? "perm.mic.notDetermined"
                    : "perm.mic.denied"),
                settingsPane: permissions.microphone == .denied ? "Microphone" : nil,
                settingsTitle: "perm.mic.openSettings"
            )

            statusRow(
                ready: permissions.screenRecording,
                title: "perm.screen.title",
                readyText: "perm.screen.ready",
                notReadyText: "perm.screen.notReady",
                settingsPane: permissions.screenRecording ? nil : "ScreenCapture",
                settingsTitle: "perm.screen.openSettings"
            )

            if permissions.screenRecordingNeedsAttention {
                VStack(alignment: .leading, spacing: 6) {
                    HStack(alignment: .center) {
                        Text("perm.screen.restartHint")
                            .font(.caption)
                            .foregroundColor(.secondary)
                            .fixedSize(horizontal: false, vertical: true)
                        Button("perm.screen.relaunch") { permissions.relaunch() }
                    }
                    Text("perm.screen.addManually")
                        .font(.caption)
                        .foregroundColor(.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                }
            }

            Text("perm.summary.note")
                .font(.caption)
                .foregroundColor(.secondary)
                .fixedSize(horizontal: false, vertical: true)

            HStack {
                Spacer()
                Button("common.close", role: .cancel) { dismiss() }
                    .buttonStyle(.borderedProminent)
            }
        }
        .padding(24)
        .frame(width: 520)
        .fixedSize(horizontal: false, vertical: true)
    }

    private func statusRow(
        ready: Bool,
        title: LocalizedStringKey,
        readyText: LocalizedStringKey,
        notReadyText: LocalizedStringKey,
        settingsPane: String?,
        settingsTitle: LocalizedStringKey
    ) -> some View {
        HStack(alignment: .top, spacing: 8) {
            Image(systemName: ready ? "checkmark.circle.fill" : "exclamationmark.triangle.fill")
                .foregroundColor(ready ? .green : .orange)
            VStack(alignment: .leading, spacing: 4) {
                Text(title).bold()
                Text(ready ? readyText : notReadyText)
                    .font(.caption)
                    .foregroundColor(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
                if !ready, let pane = settingsPane {
                    Button(settingsTitle) {
                        if pane == "ScreenCapture" {
                            permissions.openScreenRecordingSettings()
                        } else {
                            permissions.openSettings(pane)
                        }
                    }
                    .font(.caption)
                }
            }
        }
    }
}

/// 單一入口按鈕（純 UI 元件）
private struct LauncherButton: View {
    let title: LocalizedStringKey
    let subtitle: LocalizedStringKey
    let systemImage: String
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            VStack(spacing: 10) {
                Image(systemName: systemImage)
                    .font(.system(size: 36))
                Text(title)
                    .font(.headline)
                Text(subtitle)
                    .font(.caption)
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
            }
            .padding()
            .frame(maxWidth: .infinity, minHeight: 160)
            .background(Color(nsColor: .controlBackgroundColor))
            .cornerRadius(12)
        }
        .buttonStyle(.plain)
    }
}

#Preview {
    LauncherView(onSelectImport: {}, onSelectVoiceCapture: {})
        .environmentObject(PermissionCoordinator())
}

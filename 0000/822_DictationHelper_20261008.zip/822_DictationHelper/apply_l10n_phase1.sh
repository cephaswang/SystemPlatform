#!/bin/bash
# =====================================================================
# 多語言支援（en / zh-Hant / zh-Hans）第一階段腳本
# 對應修改順序表：第 2、5、6、7 項（建立），第 3、4 項（僅檢查）
# 用法：在專案根目錄（有 "Dictation Helper.xcodeproj" 的位置）執行
#   ./apply_l10n_phase1.sh --dry-run    先預覽，不寫入
#   ./apply_l10n_phase1.sh              正式執行
# 特性：寫入前自動備份；已存在的檔案一律不覆蓋，可重複執行
# =====================================================================
set -u
DRY=0; [ "${1:-}" = "--dry-run" ] && DRY=1
APP="Dictation Helper"
PLIST="Dictation-Helper-Info.plist"
TS=$(date +%Y%m%d_%H%M%S)
BK=".l10n_backup_$TS"

[ -d "$APP.xcodeproj" ] || { echo "錯誤：請在專案根目錄執行（找不到 $APP.xcodeproj）"; exit 1; }
say(){ echo "• $*"; }
run(){ if [ $DRY -eq 1 ]; then echo "  [預覽] $*"; else eval "$@"; fi; }
write_new(){ # write_new <path> ; 內容從 stdin
  local f="$1"
  if [ -e "$f" ]; then say "已存在，略過：$f"; cat >/dev/null; return; fi
  if [ $DRY -eq 1 ]; then say "[預覽] 將建立：$f"; cat >/dev/null
  else mkdir -p "$(dirname "$f")"; cat > "$f"; say "已建立：$f"; fi
}

echo "== 0. 備份 =="
if [ $DRY -eq 0 ]; then
  mkdir -p "$BK"
  for f in "$PLIST" "$APP/en.lproj/InfoPlist.strings" "$APP/zh-Hant.lproj/InfoPlist.strings" \
           "$APP/docs/"*企劃書*.txt "VoxNoteSuite/vdocs/VoxNote_專案企劃.md" make_infoplist_strings.sh; do
    [ -f "$f" ] && { mkdir -p "$BK/$(dirname "$f")"; cp "$f" "$BK/$f"; }
  done
  say "備份於 $BK/"
else say "[預覽] 略過備份"; fi

echo; echo "== 5a. zh-Hans InfoPlist.strings =="
write_new "$APP/zh-Hans.lproj/InfoPlist.strings" << 'EOF'
/* 簡體中文。措辭請對照 zh-Hant.lproj/InfoPlist.strings 做最後確認 */
"CFBundleDisplayName" = "听抄小帮手";
"CFBundleName" = "听抄小帮手";
"NSMicrophoneUsageDescription" = "“听抄小帮手”需要使用麦克风，才能把您说的话即时转成文字稿。";
"NSSpeechRecognitionUsageDescription" = "“听抄小帮手”需要使用语音识别，才能把声音转成文字稿。";
EOF
if [ -f "$APP/zh-Hant.lproj/InfoPlist.strings" ]; then
  say "對照：zh-Hant 現有的 key（zh-Hans 需涵蓋相同項目）："
  grep -o '^"[A-Za-z]*"' "$APP/zh-Hant.lproj/InfoPlist.strings" | sed 's/^/    /'
fi

echo; echo "== 5b. Info.plist 宣告 CFBundleLocalizations =="
if [ -f "$PLIST" ] && [ -x /usr/libexec/PlistBuddy ]; then
  run "/usr/libexec/PlistBuddy -c 'Delete :CFBundleLocalizations' '$PLIST' 2>/dev/null; \
/usr/libexec/PlistBuddy -c 'Add :CFBundleLocalizations array' -c 'Add :CFBundleLocalizations:0 string en' \
-c 'Add :CFBundleLocalizations:1 string zh-Hant' -c 'Add :CFBundleLocalizations:2 string zh-Hans' '$PLIST'"
  say "CFBundleLocalizations = en, zh-Hant, zh-Hans"
else say "略過：找不到 $PLIST 或 PlistBuddy（請在 Xcode 的 Info 頁手動加入 Localizations）"; fi

echo; echo "== 6. Localizable.xcstrings（含少量種子字串） =="
write_new "$APP/Localizable.xcstrings" << 'EOF'
{
  "sourceLanguage" : "en",
  "strings" : {
    "launcher.mode.import" : { "localizations" : {
      "en" : { "stringUnit" : { "state" : "translated", "value" : "Import Audio to Transcript" } },
      "zh-Hant" : { "stringUnit" : { "state" : "translated", "value" : "匯入音檔轉文字稿" } },
      "zh-Hans" : { "stringUnit" : { "state" : "translated", "value" : "导入音频转文字稿" } } } },
    "launcher.mode.capture" : { "localizations" : {
      "en" : { "stringUnit" : { "state" : "translated", "value" : "Live Dictation" } },
      "zh-Hant" : { "stringUnit" : { "state" : "translated", "value" : "聽抄" } },
      "zh-Hans" : { "stringUnit" : { "state" : "translated", "value" : "听抄" } } } },
    "capture.button.start" : { "localizations" : {
      "en" : { "stringUnit" : { "state" : "translated", "value" : "Start Dictation" } },
      "zh-Hant" : { "stringUnit" : { "state" : "translated", "value" : "開始聽抄" } },
      "zh-Hans" : { "stringUnit" : { "state" : "translated", "value" : "开始听抄" } } } },
    "capture.button.stop" : { "localizations" : {
      "en" : { "stringUnit" : { "state" : "translated", "value" : "Stop Dictation" } },
      "zh-Hant" : { "stringUnit" : { "state" : "translated", "value" : "停止聽抄" } },
      "zh-Hans" : { "stringUnit" : { "state" : "translated", "value" : "停止听抄" } } } },
    "capture.showInFinder" : { "localizations" : {
      "en" : { "stringUnit" : { "state" : "translated", "value" : "Show Transcript in Finder" } },
      "zh-Hant" : { "stringUnit" : { "state" : "translated", "value" : "在 Finder 中顯示逐字稿" } },
      "zh-Hans" : { "stringUnit" : { "state" : "translated", "value" : "在 Finder 中显示逐字稿" } } } },
    "export.includeTimestamps" : { "localizations" : {
      "en" : { "stringUnit" : { "state" : "translated", "value" : "Include timestamps" } },
      "zh-Hant" : { "stringUnit" : { "state" : "translated", "value" : "包含時間戳記" } },
      "zh-Hans" : { "stringUnit" : { "state" : "translated", "value" : "包含时间戳" } } } }
  },
  "version" : "1.0"
}
EOF

echo; echo "== 7. L10n.swift =="
write_new "$APP/L10n.swift" << 'EOF'
import Foundation

/// 多語言輔助：非 SwiftUI 場合（狀態訊息、錯誤、NSAlert、NSOpenPanel）用 L10n.t("key")。
/// SwiftUI 的 Text("key") 會自動查 Localizable，不需經過這裡。
enum L10n {
    /// 目前實際採用的介面語言："en"、"zh-Hant"、"zh-Hans"
    static var uiLanguage: String {
        Bundle.main.preferredLocalizations.first ?? "en"
    }

    static func t(_ key: String, comment: String = "") -> String {
        NSLocalizedString(key, comment: comment)
    }

    /// 辨識語言的顯示名稱，跟隨介面語言，例如「英文（en-US）」／"English (en-US)"
    static func recognitionLocaleName(_ identifier: String) -> String {
        let ui = Locale(identifier: uiLanguage)
        let name = ui.localizedString(forIdentifier: identifier) ?? identifier
        return "\(name)（\(identifier)）"
    }

    /// 首次使用的預設辨識語系：依介面語言，而非固定 zh-TW
    static var defaultRecognitionLocaleID: String {
        switch uiLanguage {
        case "zh-Hans": return "zh-CN"
        case "zh-Hant": return "zh-TW"
        default: return "en-US"
        }
    }

    /// 置頂排序用：en-US、zh-TW、zh-CN 排在前面
    static let pinnedRecognitionLocales = ["en-US", "zh-TW", "zh-CN"]
}
EOF

echo; echo "== 2. 企劃書增補 =="
python3 - "$DRY" "$APP" << 'PYEOF'
import sys, glob, os
dry, app = sys.argv[1]=="1", sys.argv[2]
MARK = "多語言支援（v3.1 增補）"
txt = f"""
--------------------------------------------------------------------
{MARK}
--------------------------------------------------------------------
決策（2026-10-07 確認）：
  - 介面語言：English（en）、繁體中文（zh-Hant）、簡體中文（zh-Hans）
  - 介面語言與辨識語言為兩件獨立的事；辨識語言仍由 Speech Framework
    動態列出，不受影響
  - 預設跟隨 macOS 系統語言；非上述三種時退回 English
  - 第一版不提供 App 內切換語言，僅跟隨系統
  - App 名稱：聽抄小幫手（zh-Hant）／Dictation Helper（en）／
    听抄小帮手（zh-Hans）
實作要點：
  - 字串集中於 Localizable.xcstrings（key 以 launcher./capture./
    import./export./perm./help. 為前綴）；非 SwiftUI 場合用 L10n.swift
  - 系統授權對話框文字由各語言的 InfoPlist.strings 提供
  - 辨識語系選單名稱跟隨介面語言；預設語系依介面語言決定
  - 逐字稿本文為辨識結果，不做繁簡轉換
  - 網頁教學提供 index.html（繁中）／index_en.html／index_zh-Hans.html
已知限制：介面僅三種語言；教學影片目前為中文
"""
md = f"""
---

## {MARK}

**決策（2026-10-07 確認）**

- 介面語言：English（en）、繁體中文（zh-Hant）、簡體中文（zh-Hans）
- 介面語言與辨識語言是兩件獨立的事，辨識語言仍由 Speech Framework 動態列出
- 預設跟隨 macOS 系統語言；非上述三種時退回 English
- 第一版不提供 App 內切換語言，僅跟隨系統
- App 名稱：聽抄小幫手（zh-Hant）／Dictation Helper（en）／听抄小帮手（zh-Hans）

**第四節 `Resources/Localizable.strings`**：由「未見」改為「待建立」，
實際採用 `Dictation Helper/Localizable.xcstrings`（兩個資料夾共用）與 `L10n.swift`。
"""
targets = [(p, txt, "文件結束") for p in glob.glob(f"{app}/docs/*企劃書*.txt")]
md_path = "VoxNoteSuite/vdocs/VoxNote_專案企劃.md"
for path, block, anchor in targets:
    s = open(path, encoding="utf-8").read()
    if MARK in s: print(f"• 已有增補，略過：{path}"); continue
    # 插在最後一條「=====」分隔線＋「文件結束」之前
    j = s.rfind(anchor)
    i = (s.rfind("\n", 0, j - 1) + 1) if j != -1 else -1   # 文件結束 上一行（分隔線）的行首
    new = s[:i] + block.lstrip("\n") + "\n" + s[i:] if i > 0 else s + block
    if dry: print(f"• [預覽] 將增補：{path}")
    else: open(path, "w", encoding="utf-8").write(new); print(f"• 已增補：{path}")
if os.path.exists(md_path):
    s = open(md_path, encoding="utf-8").read()
    if MARK in s: print(f"• 已有增補，略過：{md_path}")
    elif dry: print(f"• [預覽] 將增補：{md_path}")
    else: open(md_path, "w", encoding="utf-8").write(s.rstrip("\n") + "\n" + md); print(f"• 已增補：{md_path}")
PYEOF

echo; echo "== 檢查（不修改）=="
grep -q "zh-Hans" "$APP.xcodeproj/project.pbxproj" 2>/dev/null \
  && say "[第 4 項] pbxproj 已含 zh-Hans" \
  || say "[第 4 項] pbxproj 尚無 zh-Hans → 請在 Xcode：Project > Info > Localizations 按 + 加入 Chinese, Simplified"
[ -f "$APP/SetupScript.swift" ] && say "[第 3 項] 仍有 SetupScript.swift（BlackHole 時代檔案），請確認是否移除"
if [ -f VoxNoteSuite/AppLauncherService.swift ]; then
  n=$(grep -rl "AppLauncherService" --include=*.swift . 2>/dev/null | grep -v "AppLauncherService.swift" | wc -l | tr -d ' ')
  say "[第 3 項] AppLauncherService 被其他 $n 個 Swift 檔引用$([ "$n" = 0 ] && echo '（無人使用，可移除）')"
fi

echo; echo "== 各 Swift 檔含中文字串的行數（第 8–14 項的工作量）=="
python3 - << 'PYEOF'
import glob, re
cjk = re.compile(r'[\u4e00-\u9fff]')
rows = []
for p in glob.glob("**/*.swift", recursive=True):
    n = sum(1 for l in open(p, encoding="utf-8", errors="ignore") if cjk.search(l) and not l.strip().startswith("//"))
    if n: rows.append((n, p))
for n, p in sorted(rows, reverse=True): print(f"  {n:4d}  {p}")
print(f"  合計 {sum(n for n,_ in rows)} 行（含註解以外的中文行）")
PYEOF

echo; echo "== 完成。接下來必須在 Xcode 手動做 =="
cat << 'EOF'
  1. Project > Info > Localizations：加入 Chinese, Simplified
  2. 把以下新檔拖進 Xcode 專案（勾選 Target）：
       Dictation Helper/Localizable.xcstrings
       Dictation Helper/L10n.swift
       Dictation Helper/zh-Hans.lproj/InfoPlist.strings
  3. 選 InfoPlist.strings，在右側 File Inspector 勾選三種語言
  4. Command + B 確認可編譯
EOF
[ $DRY -eq 1 ] && echo "（本次為預覽，沒有寫入任何檔案）"

#!/bin/bash
# 產生 InfoPlist.strings(英文 en + 繁體中文 zh-Hant)
# 用法:在專案根目錄(Dictation Helper.xcodeproj 所在處)執行
#   bash make_infoplist_strings.sh
set -euo pipefail

SRC_DIR="${SRC_DIR:-Dictation Helper}"          # 原始碼資料夾
PLIST="${PLIST:-Dictation-Helper-Info.plist}"   # 專案根目錄的 Info.plist

[ -d "$SRC_DIR" ] || { echo "找不到資料夾:$SRC_DIR(請在專案根目錄執行)"; exit 1; }

mkdir -p "$SRC_DIR/en.lproj" "$SRC_DIR/zh-Hant.lproj"

# 已存在則先備份
for f in "$SRC_DIR/en.lproj/InfoPlist.strings" "$SRC_DIR/zh-Hant.lproj/InfoPlist.strings"; do
  [ -f "$f" ] && cp "$f" "$f.bak.$(date +%Y%m%d%H%M%S)"
done

# ---------- English ----------
cat > "$SRC_DIR/en.lproj/InfoPlist.strings" <<'STR'
/* Microphone */
"NSMicrophoneUsageDescription" = "When you click \"Start\" and choose Microphone as the source, this app uses the microphone to turn your speech or surrounding sound into a live text transcript. For example, during a meeting or lecture, the app listens through the microphone and writes the words to a text file you choose. Audio is not saved.";

/* Speech Recognition */
"NSSpeechRecognitionUsageDescription" = "This app uses speech recognition to turn the audio source you choose (microphone or system sound) into a text transcript. For example, if you play a tutorial video and start transcribing, the speech is sent to Apple's speech recognition service and the resulting text is saved to a file you choose.";

/* Screen & System Audio Recording */
"NSScreenCaptureUsageDescription" = "This app needs Screen & System Audio Recording permission to capture the sound your Mac is playing. For example, when you play an online course or a recorded meeting, the app captures its audio and turns it into a text transcript. Only audio is used; screen content is never displayed, saved, or uploaded.";
STR

# ---------- 繁體中文 ----------
cat > "$SRC_DIR/zh-Hant.lproj/InfoPlist.strings" <<'STR'
/* 麥克風 */
"NSMicrophoneUsageDescription" = "當你按下「開始聽抄」並選擇「麥克風」作為聲音來源時,「喇叭聽抄小幫手」會使用麥克風,把你的說話或現場聲音即時轉成文字稿。例如:你在開會或上課時開啟聽抄,App 會聽取麥克風的聲音並轉成文字,存成你指定的文字檔。App 不會把聲音錄成音檔保存。";

/* 語音辨識 */
"NSSpeechRecognitionUsageDescription" = "「喇叭聽抄小幫手」會使用語音辨識,將你選擇的聲音來源(麥克風或系統聲音)轉成文字稿。例如:你播放一段教學影片並開始聽抄,影片中的語音會傳送給 Apple 的語音辨識服務進行辨識,結果會存成你指定的文字檔。";

/* 螢幕與系統音訊錄製 */
"NSScreenCaptureUsageDescription" = "「喇叭聽抄小幫手」需要「螢幕與系統音訊錄製」權限,才能取得你的 Mac 正在播放的聲音。例如:你播放線上課程或會議錄影時,App 會擷取該聲音並轉成文字稿。App 只使用音訊,不會顯示、儲存或上傳螢幕畫面。";
STR

# ---------- 語法檢查(macOS 才有 plutil) ----------
if command -v plutil >/dev/null 2>&1; then
  plutil -lint "$SRC_DIR/en.lproj/InfoPlist.strings"
  plutil -lint "$SRC_DIR/zh-Hant.lproj/InfoPlist.strings"
fi

# ---------- 在 Info.plist 宣告支援的語系(macOS 才有 PlistBuddy) ----------
PB=/usr/libexec/PlistBuddy
if [ -x "$PB" ] && [ -f "$PLIST" ]; then
  "$PB" -c "Delete :CFBundleLocalizations" "$PLIST" 2>/dev/null || true
  "$PB" -c "Add :CFBundleLocalizations array" \
        -c "Add :CFBundleLocalizations:0 string en" \
        -c "Add :CFBundleLocalizations:1 string zh-Hant" "$PLIST"
  echo "已寫入 CFBundleLocalizations: en, zh-Hant"
  echo "目前 CFBundleDevelopmentRegion: $("$PB" -c 'Print :CFBundleDevelopmentRegion' "$PLIST" 2>/dev/null || echo '(未設定)')"
fi

echo
echo "完成:"
ls -l "$SRC_DIR"/en.lproj/InfoPlist.strings "$SRC_DIR"/zh-Hant.lproj/InfoPlist.strings

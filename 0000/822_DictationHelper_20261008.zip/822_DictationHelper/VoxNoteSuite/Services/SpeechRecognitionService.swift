import Foundation
import Speech
import AVFoundation

/// 🔎 偵錯用日誌（排查完成後可整段刪除，連同各檔案裡的 dbg(...) 呼叫）。
/// 寫到 stderr（不經緩衝）：即使 process 之後被 SIGKILL，最後一行也一定看得到；
/// print() 走 stdout 在 Xcode 下可能有緩衝，被殺時尾端幾行會遺失。
/// 前綴 🔎[DBG]，可在 Xcode Console 的篩選框輸入 DBG 只看這些行。
func dbg(_ message: @autoclosure () -> String, file: String = #fileID, line: Int = #line) {
    let t = Date().timeIntervalSince1970.truncatingRemainder(dividingBy: 1000)
    let ts = String(format: "%07.3f", t)
    let thread = Thread.isMainThread ? "main" : "bg"
    let name = file.split(separator: "/").last.map(String.init) ?? file
    fputs("🔎[DBG] \(ts) [\(thread)] \(name):\(line) \(message())\n", stderr)
}

enum SpeechRecognitionError: LocalizedError {
    case permissionDenied
    case recognizerUnavailable
    case recognitionFailed(String)
    case engineNotImplemented(String)
    /// 辨識流程「成功結束」，但沒有任何文字（例如辨識服務回傳空的最終結果）。
    /// 這種情況不能當成成功：否則畫面會顯示一句空白逐字稿。
    case emptyResult

    var errorDescription: String? {
        switch self {
        case .permissionDenied:
            return L10n.t("speech.error.permissionDenied")
        case .recognizerUnavailable:
            return L10n.t("speech.error.recognizerUnavailable")
        case .recognitionFailed(let reason):
            return String(format: L10n.t("speech.error.failed"), reason)
        case .engineNotImplemented(let name):
            return String(format: L10n.t("speech.error.engineNotImplemented"), name)
        case .emptyResult:
            return "The speech recognizer finished but returned no text. 辨識引擎結束了，但沒有回傳任何文字。"
        }
    }
}

/// 序列化佇列：確保同一時間只有一個 SFSpeechRecognizer 辨識任務在執行。
/// Apple Speech Framework 底層限制單一進程只允許一個辨識任務同時進行，
/// 若同時對多個檔案發起辨識，後發起的請求會把先前的任務 cancel 掉，
/// 進而導致該任務的 completion callback 被系統多呼叫一次（見 SpeechRecognitionService
/// 內的 resumeOnce 保護），並可能造成 continuation 重複 resume 而 crash。
/// 因此所有辨識請求一律先透過本佇列排隊，逐一執行。
actor RecognitionQueue {
    static let shared = RecognitionQueue()

    private var isBusy = false
    private var waiters: [CheckedContinuation<Void, Never>] = []

    /// 取得執行權；若目前有其他辨識任務正在跑，會在此暫停直到輪到自己
    func acquire() async {
        if !isBusy {
            isBusy = true
            return
        }
        await withCheckedContinuation { waiters.append($0) }
    }

    /// 釋放執行權，讓下一個排隊中的請求開始執行
    func release() {
        if waiters.isEmpty {
            isBusy = false
        } else {
            let next = waiters.removeFirst()
            next.resume()
        }
    }
}

/// 保存 SFSpeechRecognitionTask，讓外層 Swift Task 被取消時可以一併取消底層辨識任務。
/// 若取消發生在 task 建立之前，set(_:) 一收到 task 就立刻取消它。
private final class RecognitionTaskBox: @unchecked Sendable {
    private let lock = NSLock()
    private var task: SFSpeechRecognitionTask?
    private var cancelled = false

    func set(_ newTask: SFSpeechRecognitionTask) {
        lock.lock(); defer { lock.unlock() }
        task = newTask
        if cancelled { newTask.cancel() }
    }

    func cancel() {
        lock.lock(); defer { lock.unlock() }
        cancelled = true
        task?.cancel()
    }
}

/// 單次辨識工作的共享狀態（執行緒安全）：
/// - claimResume()：確保 continuation 只會被 resume 一次
/// - touch()／idleSeconds：記錄最後一次回呼時間，供看門狗判斷是否卡死
private final class RecognitionJobState: @unchecked Sendable {
    private let lock = NSLock()
    private var resumed = false
    private var lastActivity = Date()
    private var lastProgressLog = Date.distantPast

    func touch() {
        lock.lock(); defer { lock.unlock() }
        lastActivity = Date()
    }

    var idleSeconds: TimeInterval {
        lock.lock(); defer { lock.unlock() }
        return Date().timeIntervalSince(lastActivity)
    }

    var isResumed: Bool {
        lock.lock(); defer { lock.unlock() }
        return resumed
    }

    /// 只有第一次呼叫會回傳 true
    func claimResume() -> Bool {
        lock.lock(); defer { lock.unlock() }
        if resumed { return false }
        resumed = true
        return true
    }

    /// 進度 log 節流：距上次記錄超過 10 秒才回傳 true
    func shouldLogProgress() -> Bool {
        lock.lock(); defer { lock.unlock() }
        if Date().timeIntervalSince(lastProgressLog) >= 10 {
            lastProgressLog = Date()
            return true
        }
        return false
    }
}

/// 呼叫語音辨識引擎，將音檔轉為逐句文字結果。
/// 依 SettingsView 中選擇的引擎（Apple Speech / Whisper 本地 / Whisper 雲端）分派處理，
/// 對外統一回傳 [TranscriptSegment]。
struct SpeechRecognitionService {

    /// 詞與詞之間的靜音間隔超過此門檻（秒），即使沒有偵測到句尾標點，
    /// 也視為一個斷句點。用來避免整段音檔因為 recognizer 沒加標點
    /// 而被合併成單一超長句子（例如 log 中出現的 segments=1）。
    private let pauseBreakThreshold: TimeInterval = 0.6

    /// 對外主要入口：傳入已轉檔完成的音檔 URL 與語系，回傳逐句辨識結果
    ///
    /// @concurrent：明確要求在背景執行緒執行，不佔用呼叫端（主執行緒）。
    /// 專案開啟了「nonisolated async 函式沿用呼叫端 actor」的設定時，沒有這個標記，
    /// 建立 SFSpeechRecognizer、讀取音檔資訊、啟動辨識任務等同步工作都會卡在主執行緒，
    /// 造成畫面（例如音檔列表）延遲好幾秒才出現。
    @concurrent
    func recognize(
        audioURL: URL,
        locale: String,
        engine: SettingsView.RecognitionEngine
    ) async throws -> [TranscriptSegment] {
        switch engine {
        case .appleSpeech:
            return try await recognizeWithAppleSpeech(audioURL: audioURL, locale: locale)
        case .whisperLocal:
            throw SpeechRecognitionError.engineNotImplemented(engine.displayName)
        case .whisperCloud:
            throw SpeechRecognitionError.engineNotImplemented(engine.displayName)
        }
    }

    // MARK: - Apple Speech Framework

    private func recognizeWithAppleSpeech(audioURL: URL, locale: String) async throws -> [TranscriptSegment] {
        // 排隊等待，確保同一時間只有一個辨識任務在執行（Apple Speech 不支援多進程並發）
        dbg("recognize: waiting for queue file=\(audioURL.lastPathComponent)")
        await RecognitionQueue.shared.acquire()
        dbg("recognize: queue acquired")
        defer {
            dbg("recognize: leaving, releasing queue")
            Task { await RecognitionQueue.shared.release() }
        }

        print("🎙️ [SpeechRecognitionService] 開始辨識 file=\(audioURL.lastPathComponent) locale=\(locale)")

        dbg("auth: current status=\(PermissionManager().speechRecognitionStatus)")
        guard await requestAuthorizationIfNeeded() else {
            print("⚠️ [SpeechRecognitionService] 尚未取得語音辨識權限 file=\(audioURL.lastPathComponent)")
            throw SpeechRecognitionError.permissionDenied
        }

        dbg("auth: passed")
        let candidate = SFSpeechRecognizer(locale: Locale(identifier: locale))
        dbg("recognizer: locale=\(locale) created=\(candidate != nil) isAvailable=\(candidate?.isAvailable ?? false) supportsOnDevice=\(candidate?.supportsOnDeviceRecognition ?? false) inSupportedLocales=\(SFSpeechRecognizer.supportedLocales().contains(Locale(identifier: locale))) appLangs=\(Bundle.main.preferredLocalizations) systemLocale=\(Locale.current.identifier)")
        guard let recognizer = candidate,
              recognizer.isAvailable else {
            print("⚠️ [SpeechRecognitionService] recognizer 不可用 file=\(audioURL.lastPathComponent) locale=\(locale)")
            throw SpeechRecognitionError.recognizerUnavailable
        }

        // 🔎 音檔本身的狀態：存在？可讀？AVFoundation 開得起來？格式／長度？
        let path = audioURL.path
        let fileSize = (try? FileManager.default.attributesOfItem(atPath: path)[.size] as? Int) ?? nil
        dbg("file: exists=\(FileManager.default.fileExists(atPath: path)) readable=\(FileManager.default.isReadableFile(atPath: path)) size=\(fileSize.map(String.init) ?? "?") path=\(path)")
        var audioDuration: TimeInterval = -1
        do {
            let af = try AVAudioFile(forReading: audioURL)
            let sr = af.processingFormat.sampleRate
            audioDuration = sr > 0 ? Double(af.length) / sr : -1
            dbg("file: AVAudioFile ok sampleRate=\(sr) channels=\(af.processingFormat.channelCount) duration=\(audioDuration)s")
        } catch {
            dbg("file: AVAudioFile open FAILED error=\(error)")
        }

        // 兩種辨識模式，依序嘗試：
        //   第 1 次 onDevice=false：與「原本可正常運作的版本」完全相同的設定
        //            （不強制本機辨識、不開中間結果），由系統自行決定走本機或伺服器。
        //   第 2 次 onDevice=true ：強制本機辨識（音檔不離開這台電腦）並開啟中間結果。
        // 第 1 次若「空結果」或「辨識失敗」才會進第 2 次；使用者取消、權限問題不會重試。
        // 實測：只用第 2 種設定時，這個 zh-TW 音檔約 5 秒就回傳空結果。
        let modes: [Bool] = [false, true]
        for (index, onDevice) in modes.enumerated() {
            let attempt = index + 1
            do {
                return try await runAppleSpeechOnce(
                    recognizer: recognizer,
                    audioURL: audioURL,
                    locale: locale,
                    audioDuration: audioDuration,
                    attempt: attempt,
                    onDevice: onDevice
                )
            } catch {
                if Task.isCancelled { throw error }

                let retryable: Bool
                switch error as? SpeechRecognitionError {
                case .emptyResult?, .recognitionFailed?: retryable = true
                default: retryable = false
                }
                guard retryable, attempt < modes.count else { throw error }

                dbg("recognize: attempt \(attempt) (onDevice=\(onDevice)) failed: \(error.localizedDescription) — trying next mode")
                try await Task.sleep(nanoseconds: 1_000_000_000)
            }
        }
        throw SpeechRecognitionError.emptyResult
    }

    /// 執行一次辨識。每次都建立全新的 request（request 不能重複使用）。
    private func runAppleSpeechOnce(
        recognizer: SFSpeechRecognizer,
        audioURL: URL,
        locale: String,
        audioDuration: TimeInterval,
        attempt: Int,
        onDevice: Bool
    ) async throws -> [TranscriptSegment] {
        let request = SFSpeechURLRecognitionRequest(url: audioURL)

        if onDevice {
            // 本機模式：開啟中間結果，讓看門狗與進度 log 知道辨識還活著；
            // 真正採用的結果仍然只有 isFinal 的最終結果。
            request.shouldReportPartialResults = true
            if recognizer.supportsOnDeviceRecognition {
                request.requiresOnDeviceRecognition = true
            }
        } else {
            // 與原本可正常運作的版本一致：只要最終結果，不指定本機或伺服器。
            request.shouldReportPartialResults = false
        }
        dbg("recognitionTask: attempt=\(attempt) mode=\(onDevice ? "onDevice" : "legacy") partialResults=\(request.shouldReportPartialResults) requiresOnDeviceRecognition=\(request.requiresOnDeviceRecognition)")

        // 看門狗的容忍秒數：沒有中間結果時整段辨識期間都不會有回呼，
        // 因此依音檔長度放寬，避免長檔被誤判為卡死。
        let idleLimit: TimeInterval = onDevice
            ? Self.idleLimit
            : max(Self.idleLimit, max(audioDuration, 0) * 2 + 120)

        // 請 recognizer 自動加上標點符號（句號、問號等），作為斷句依據。
        if #available(macOS 13.0, *) {
            request.addsPunctuation = true
        }

        // 辨識回呼改在背景佇列執行（預設是主佇列），避免回呼處理佔用主執行緒。
        // 回呼裡用到的 state、continuation、dbg 都是執行緒安全的。
        let callbackQueue = OperationQueue()
        callbackQueue.maxConcurrentOperationCount = 1
        callbackQueue.qualityOfService = .userInitiated
        recognizer.queue = callbackQueue

        // 讓 recognizer 與 request 在整個辨識期間保持存活。
        defer { withExtendedLifetime((recognizer, request)) {} }

        // 共享狀態：防止 continuation 被重複 resume，並記錄最後一次回呼時間給看門狗用
        let state = RecognitionJobState()
        // 讓外層 Swift Task 被取消（例如使用者刪除檔案）時，能一併取消底層辨識任務
        let taskBox = RecognitionTaskBox()
        let startedAt = Date()

        dbg("recognitionTask: starting (addsPunctuation set, partialResults=true, onlyFinalAccepted)")
        let words: [TranscriptSegment] = try await withTaskCancellationHandler(
            operation: {
                try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<[TranscriptSegment], Error>) in
                    let task = recognizer.recognitionTask(with: request) { result, error in
                        state.touch()

                        if let error {
                            let ns = error as NSError
                            dbg("callback: error=\(ns.domain)/\(ns.code) \(ns.localizedDescription)")
                            guard state.claimResume() else { return }
                            print("❌ [SpeechRecognitionService] 辨識失敗 file=\(audioURL.lastPathComponent) locale=\(locale) error=\(error.localizedDescription)")
                            continuation.resume(throwing: SpeechRecognitionError.recognitionFailed(error.localizedDescription))
                            return
                        }

                        guard let result else { return }

                        guard result.isFinal else {
                            // 中間結果：不採用，只每 10 秒記一次進度，證明辨識仍在進行
                            if state.shouldLogProgress() {
                                let last = result.bestTranscription.segments.last
                                dbg("progress: partial words=\(result.bestTranscription.segments.count) reachedTime=\(last.map { $0.timestamp + $0.duration } ?? 0)s")
                            }
                            return
                        }

                        let segments = result.bestTranscription.segments.map { segment in
                            TranscriptSegment(
                                text: segment.substring,
                                startTime: segment.timestamp,
                                endTime: segment.timestamp + segment.duration,
                                confidence: Double(segment.confidence)
                            )
                        }

                        // 🔎 最終結果的內容與耗時：用來判斷是「真的辨識不到」還是「引擎提早結束」
                        let elapsed = Date().timeIntervalSince(startedAt)
                        let formatted = result.bestTranscription.formattedString
                        dbg("callback: isFinal segments=\(segments.count) textLength=\(formatted.count) alternatives=\(result.transcriptions.count) elapsed=\(String(format: "%.1f", elapsed))s audioDuration=\(String(format: "%.1f", audioDuration))s preview=\(formatted.prefix(40))")

                        guard state.claimResume() else {
                            print("⚠️ [SpeechRecognitionService] 偵測到重複的 resume 呼叫，已略過 file=\(audioURL.lastPathComponent)")
                            return
                        }
                        continuation.resume(returning: segments)
                    }
                    taskBox.set(task)
                    dbg("recognitionTask: created state=\(task.state.rawValue) (0=starting 1=running 2=finishing 3=canceling 4=completed)")

                    // 看門狗：超過 idleLimit 秒完全沒有任何回呼，就取消任務並回報失敗，
                    // 避免狀態永遠停在「轉錄中」。
                    Self.watchIdle(state: state, task: task, limit: idleLimit) {
                        continuation.resume(throwing: SpeechRecognitionError.recognitionFailed("No response from the speech recognizer for \(Int(idleLimit)) seconds."))
                    }
                }
            },
            onCancel: {
                dbg("recognitionTask: Swift Task cancelled, cancelling SFSpeechRecognitionTask")
                taskBox.cancel()
            }
        )

        // 過濾掉沒有文字的片段；若一個字都沒有，視為失敗而不是成功
        let nonEmptyWords = words.filter {
            !$0.text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
        }
        guard !nonEmptyWords.isEmpty else {
            print("⚠️ [SpeechRecognitionService] 辨識結果沒有任何文字 file=\(audioURL.lastPathComponent) attempt=\(attempt)")
            throw SpeechRecognitionError.emptyResult
        }

        let sentences = groupIntoSentences(nonEmptyWords)
        print("✅ [SpeechRecognitionService] 辨識完成 file=\(audioURL.lastPathComponent) locale=\(locale) segments=\(sentences.count)")
        return sentences
    }

    /// 超過這個秒數完全沒有回呼，視為辨識卡死
    private static let idleLimit: TimeInterval = 300

    /// 每 15 秒檢查一次；逾時時取消任務並呼叫 onTimeout（只會觸發一次）
    private static func watchIdle(
        state: RecognitionJobState,
        task: SFSpeechRecognitionTask,
        limit: TimeInterval,
        onTimeout: @escaping () -> Void
    ) {
        DispatchQueue.global(qos: .utility).asyncAfter(deadline: .now() + 15) {
            if state.isResumed { return }
            if state.idleSeconds > limit {
                if state.claimResume() {
                    dbg("watchdog: no callback for \(Int(limit))s, cancelling task")
                    task.cancel()
                    onTimeout()
                }
                return
            }
            watchIdle(state: state, task: task, limit: limit, onTimeout: onTimeout)
        }
    }

    /// 將逐字（word-level）辨識片段合併為逐句（sentence-level）片段。
    /// 斷句依據有二，任一成立即斷句：
    /// 1. 該詞以句尾標點結尾（。！？.!?）— 主要依據，前提是 recognizer 有加標點
    /// 2. 與下一個詞之間的靜音間隔超過 pauseBreakThreshold —
    ///    fallback，避免 recognizer 沒加標點時整段音檔變成單一句子
    private func groupIntoSentences(_ wordSegments: [TranscriptSegment]) -> [TranscriptSegment] {
        let sentenceEnders: Set<Character> = ["。", "！", "？", ".", "!", "?"]
        var sentences: [TranscriptSegment] = []
        var buffer: [TranscriptSegment] = []

        for (index, word) in wordSegments.enumerated() {
            buffer.append(word)

            let endsWithPunctuation: Bool
            if let lastChar = word.text.last {
                endsWithPunctuation = sentenceEnders.contains(lastChar)
            } else {
                endsWithPunctuation = false
            }

            let hasLongPauseAfter: Bool
            if index + 1 < wordSegments.count {
                let nextWord = wordSegments[index + 1]
                hasLongPauseAfter = (nextWord.startTime - word.endTime) >= pauseBreakThreshold
            } else {
                hasLongPauseAfter = false
            }

            if endsWithPunctuation || hasLongPauseAfter {
                sentences.append(merge(buffer))
                buffer.removeAll()
            }
        }

        if !buffer.isEmpty {
            sentences.append(merge(buffer))
        }

        return sentences
    }

    private func merge(_ words: [TranscriptSegment]) -> TranscriptSegment {
        TranscriptSegment(
            text: joinWords(words.map(\.text)),
            startTime: words.first?.startTime ?? 0,
            endTime: words.last?.endTime ?? 0,
            confidence: words.map(\.confidence).reduce(0, +) / Double(max(words.count, 1))
        )
    }

    /// 依語言特性智慧合併詞語文字：
    /// - 中日韓（CJK）字元前後緊鄰時不加空格（該語言本身不使用空格斷詞）
    /// - 其餘情況（例如英文單字接英文單字）之間補一個空格
    /// 修正原本 `words.map(\.text).joined()` 直接無空格拼接、
    /// 造成英文等語言辨識結果變成 "Helloeveryoneinthissession..." 的問題。
    private func joinWords(_ words: [String]) -> String {
        var result = ""
        for word in words {
            guard !word.isEmpty else { continue }
            if result.isEmpty {
                result = word
                continue
            }
            if needsSpace(before: result, after: word) {
                result += " "
            }
            result += word
        }
        return result
    }

    private func needsSpace(before: String, after: String) -> Bool {
        guard let lastChar = before.last, let firstChar = after.first else { return false }

        // 標點符號前不加空格（例如 "hello" + "." -> "hello."）
        if firstChar.isPunctuation && !isCJK(firstChar) {
            return false
        }

        // 任一側是 CJK 字元時不加空格（中日韓文字彼此相鄰或與標點相鄰皆不需空格）
        if isCJK(lastChar) || isCJK(firstChar) {
            return false
        }

        return true
    }

    private func isCJK(_ character: Character) -> Bool {
        for scalar in character.unicodeScalars {
            switch scalar.value {
            case 0x4E00...0x9FFF,   // CJK 統一表意文字
                 0x3400...0x4DBF,   // CJK 擴展 A
                 0x3040...0x309F,   // 平假名
                 0x30A0...0x30FF,   // 片假名
                 0xAC00...0xD7A3:   // 韓文音節
                return true
            default:
                continue
            }
        }
        return false
    }

    /// 權限已由第一頁統一請求；這裡先看目前狀態，只有「尚未決定」才補請求一次
    private func requestAuthorizationIfNeeded() async -> Bool {
        let pm = PermissionManager()
        switch pm.speechRecognitionStatus {
        case .authorized:
            return true
        case .denied:
            return false
        case .notDetermined:
            dbg("auth: status notDetermined, requesting now")
            let granted = await pm.requestSpeechRecognitionPermission()
            dbg("auth: request finished granted=\(granted)")
            return granted
        }
    }
}

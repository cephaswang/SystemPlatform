import SwiftUI
import UniformTypeIdentifiers

struct ImportView: View {

    /// 匯入完成後回傳新建立的 AudioFile 清單，交由呼叫端（AudioLibraryView）併入資料來源
    var onImport: ([AudioFile]) -> Void

    @Environment(\.dismiss) private var dismiss
    @State private var isDropTargeted = false
    @State private var pendingURLs: [URL] = []
    /// 每個待匯入檔案各自選定的語系，key 為該檔案的 URL
    @State private var localeSelections: [URL: String] = [:]
    /// 每個檔案目前的處理狀態，用於在清單上即時顯示「等待中／處理中／已完成／失敗」
    @State private var itemStatuses: [URL: ImportItemStatus] = [:]
    @State private var errorMessage: String?
    @State private var isImporting = false

    private let importService = AudioImportService()

    /// mp3 / m4a / wav，皆為 AVFoundation 可直接讀取的原生格式
    private let supportedExtensions = ["mp3", "m4a", "wav"]

    /// 新加入的檔案預設用哪個語系；沿用 Settings 裡的全域偏好值當預設，
    /// 使用者仍可針對個別檔案單獨覆蓋，不受此值之後變動影響
    @AppStorage("selectedLocale") private var defaultLocale: String = L10n.defaultRecognitionLocaleID

    private var supportedTypes: [UTType] {
        [.mp3, .wav, .mpeg4Audio].compactMap { $0 }
    }

    /// 單一待匯入檔案目前的處理階段
    private enum ImportItemStatus: Equatable {
        case waiting
        case processing
        case done
        case failed(String)

        var label: String {
            switch self {
            case .waiting: return L10n.t("import.status.waiting")
            case .processing: return L10n.t("import.status.processing")
            case .done: return L10n.t("import.status.done")
            case .failed(let reason): return String(format: L10n.t("import.status.failed"), reason)
            }
        }

        var color: Color {
            switch self {
            case .waiting: return .secondary
            case .processing: return .blue
            case .done: return .green
            case .failed: return .red
            }
        }
    }

    // MARK: - 語系清單（對應 Apple Speech Framework / SFSpeechRecognizer 支援的地區語系）
    // 實際可用語系會因系統版本與裝置已安裝的聽寫語言而略有差異；
    // 這裡列出目前 Apple 平台常見支援的語系，供匯入時逐檔選擇。
    private static let availableLocales: [(code: String, label: String)] = [
        ("ar-SA", "Arabic (Saudi Arabia)"),
        ("yue-CN", "Cantonese (China mainland)"),
        ("ca-ES", "Catalan (Spain)"),
        ("zh-CN", "Chinese (China mainland)"),
        ("zh-HK", "Chinese (Hong Kong)"),
        ("zh-TW", "Chinese (Taiwan)"),
        ("hr-HR", "Croatian (Croatia)"),
        ("cs-CZ", "Czech (Czechia)"),
        ("da-DK", "Danish (Denmark)"),
        ("nl-BE", "Dutch (Belgium)"),
        ("nl-NL", "Dutch (Netherlands)"),
        ("en-AU", "English (Australia)"),
        ("en-CA", "English (Canada)"),
        ("en-IN", "English (India)"),
        ("en-ID", "English (Indonesia)"),
        ("en-IE", "English (Ireland)"),
        ("en-NZ", "English (New Zealand)"),
        ("en-PH", "English (Philippines)"),
        ("en-SA", "English (Saudi Arabia)"),
        ("en-SG", "English (Singapore)"),
        ("en-ZA", "English (South Africa)"),
        ("en-AE", "English (United Arab Emirates)"),
        ("en-GB", "English (United Kingdom)"),
        ("en-US", "English (United States)"),
        ("fi-FI", "Finnish (Finland)"),
        ("fr-BE", "French (Belgium)"),
        ("fr-CA", "French (Canada)"),
        ("fr-FR", "French (France)"),
        ("fr-CH", "French (Switzerland)"),
        ("de-AT", "German (Austria)"),
        ("de-DE", "German (Germany)"),
        ("de-CH", "German (Switzerland)"),
        ("el-GR", "Greek (Greece)"),
        ("he-IL", "Hebrew (Israel)"),
        ("hi-IN-translit", "Hindi (India, transliterated)"),
        ("hi-IN", "Hindi (India)"),
        ("hi-Latn", "Hindi (Latin)"),
        ("hu-HU", "Hungarian (Hungary)"),
        ("id-ID", "Indonesian (Indonesia)"),
        ("it-IT", "Italian (Italy)"),
        ("it-CH", "Italian (Switzerland)"),
        ("ja-JP", "Japanese (Japan)"),
        ("ko-KR", "Korean (South Korea)"),
        ("ms-MY", "Malay (Malaysia)"),
        ("nb-NO", "Norwegian Bokmål (Norway)"),
        ("pl-PL", "Polish (Poland)"),
        ("pt-BR", "Portuguese (Brazil)"),
        ("pt-PT", "Portuguese (Portugal)"),
        ("ro-RO", "Romanian (Romania)"),
        ("ru-RU", "Russian (Russia)"),
        ("sk-SK", "Slovak (Slovakia)"),
        ("es-AR", "Spanish (Argentina)"),
        ("es-CL", "Spanish (Chile)"),
        ("es-CO", "Spanish (Colombia)"),
        ("es-ES", "Spanish (Spain)"),
        ("es-MX", "Spanish (Mexico)"),
        ("es-US", "Spanish (United States)"),
        ("sv-SE", "Swedish (Sweden)"),
        ("th-TH", "Thai (Thailand)"),
        ("tr-TR", "Turkish (Turkey)"),
        ("uk-UA", "Ukrainian (Ukraine)"),
        ("vi-VN", "Vietnamese (Vietnam)"),
        ("wuu-CN", "Wu Chinese / Shanghainese (China mainland)")
    ]

    /// 語系選單的顯示文字：優先用「介面語言」產生的名稱；
    /// 系統查不到名稱的特殊代碼（例如 hi-Latn）退回上方清單的英文標籤。
    private static func localeLabel(code: String, fallback: String) -> String {
        L10n.localeDisplayName(code) == code
            ? "\(fallback) (\(code))"
            : L10n.recognitionLocaleName(code)
    }

    var body: some View {
        VStack(spacing: 20) {

            Text("import.title")
                .font(.title2)
                .bold()

            dropZone

            // 固定顯示這個區塊（而非用 if 讓它憑空出現/消失），
            // 避免拖放結束瞬間窗口高度改變，與尚未收尾的 AppKit 拖放事務相撞
            pendingFilesList
                .frame(height: 200)

            Text(errorMessage ?? " ")
                .font(.caption)
                .foregroundColor(.red)
                .textSelection(.enabled)
                .fixedSize(horizontal: false, vertical: true)
                .frame(minHeight: 14, alignment: .leading)

            HStack {
                Button("import.chooseFiles") {
                    presentFilePicker()
                }
                .disabled(isImporting)

                Spacer()

                Button("common.cancel") { dismiss() }
                    .disabled(isImporting)

                Button {
                    Task { await confirmImport() }
                } label: {
                    if isImporting {
                        HStack(spacing: 6) {
                            ProgressView().controlSize(.small)
                            Text("import.importing")
                        }
                    } else {
                        Text("import.start")
                    }
                }
                .keyboardShortcut(.defaultAction)
                .disabled(pendingURLs.isEmpty || isImporting)
            }
        }
        .padding(24)
        .frame(width: 560)
    }

    @ViewBuilder
    private var pendingFilesList: some View {
        if pendingURLs.isEmpty {
            RoundedRectangle(cornerRadius: 8)
                .fill(Color.clear)
                .overlay(
                    Text("import.empty")
                        .font(.caption)
                        .foregroundColor(.secondary)
                )
        } else {
            List(pendingURLs, id: \.self) { url in
                HStack {
                    VStack(alignment: .leading, spacing: 2) {
                        Label(url.lastPathComponent, systemImage: "waveform")
                            .lineLimit(1)
                            .truncationMode(.middle)

                        // 逐檔即時狀態：等待中／處理中…／已完成／失敗：原因
                        HStack(spacing: 6) {
                            let status = itemStatuses[url] ?? .waiting

                            if status == .processing {
                                ProgressView()
                                    .controlSize(.mini)
                            }

                            Text(status.label)
                                .font(.caption2)
                                .foregroundColor(status.color)
                        }
                    }

                    Spacer()

                    // 每個檔案各自的辨識語系選單；預設帶入 Settings 全域偏好，
                    // 使用者可針對這一個檔案單獨覆蓋，不影響清單裡其他檔案
                    Picker("", selection: localeBinding(for: url)) {
                        ForEach(Self.availableLocales, id: \.code) { item in
                            Text(verbatim: Self.localeLabel(code: item.code, fallback: item.label)).tag(item.code)
                        }
                    }
                    .labelsHidden()
                    .frame(width: 210)
                    .disabled(isImporting)
                }
                .padding(.vertical, 4)
            }
        }
    }

    /// 提供給每個檔案獨立的語系綁定；若尚未有紀錄，第一次讀取時用 defaultLocale 補上
    private func localeBinding(for url: URL) -> Binding<String> {
        Binding(
            get: { localeSelections[url] ?? defaultLocale },
            set: { newValue in
                dbg("import: locale picked file=\(url.lastPathComponent) -> \(newValue)")
                localeSelections[url] = newValue
            }
        )
    }

    private var dropZone: some View {
        RoundedRectangle(cornerRadius: 12)
            .strokeBorder(style: StrokeStyle(lineWidth: 2, dash: [6]))
            .foregroundColor(isDropTargeted ? .accentColor : .secondary)
            .background(
                RoundedRectangle(cornerRadius: 12)
                    .fill(isDropTargeted ? Color.accentColor.opacity(0.08) : Color.clear)
            )
            .frame(height: 90)
            .overlay(
                VStack(spacing: 8) {
                    Image(systemName: "square.and.arrow.down")
                        .font(.system(size: 28))
                    Text("import.drop")
                        .font(.callout)
                        .foregroundColor(.secondary)
                }
            )
            .onDrop(of: [.fileURL], isTargeted: $isDropTargeted) { providers in
                handleDrop(providers: providers)
                return true
            }
    }

    private func handleDrop(providers: [NSItemProvider]) {
        for provider in providers {
            provider.loadItem(forTypeIdentifier: UTType.fileURL.identifier, options: nil) { item, _ in
                guard let data = item as? Data,
                      let url = URL(dataRepresentation: data, relativeTo: nil) else { return }

                // 刻意延後一點點時間再變更狀態：onDrop 的 completion handler
                // 仍在 AppKit 的拖放事務（drag session）收尾過程中被呼叫，
                // 這時如果立刻同步改動會觸發畫面結構變化的 @State，
                // 容易撞上尚未結束的 kDragIPCWithinWindow，
                // 產生 layout recursion 與「Publishing changes from within view updates」的警告。
                // 等到下一輪 runloop（拖放事務已完全收尾）再更新，可以避開這個衝突。
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.05) {
                    var transaction = Transaction()
                    transaction.disablesAnimations = true
                    withTransaction(transaction) {
                        addURLIfSupported(url)
                    }
                }
            }
        }
    }

    private func presentFilePicker() {
        let panel = NSOpenPanel()
        panel.allowsMultipleSelection = true
        panel.canChooseDirectories = false
        panel.allowedContentTypes = supportedTypes

        if panel.runModal() == .OK {
            panel.urls.forEach { addURLIfSupported($0) }
        }
    }

    private func addURLIfSupported(_ url: URL) {
        let fileExtension = url.pathExtension.lowercased()
        guard supportedExtensions.contains(fileExtension) else {
            errorMessage = String(format: L10n.t("import.error.unsupported"), url.lastPathComponent)
            return
        }
        errorMessage = nil
        if !pendingURLs.contains(url) {
            pendingURLs.append(url)
            localeSelections[url] = defaultLocale
            itemStatuses[url] = .waiting
            dbg("import: added \(url.lastPathComponent) defaultLocale=\(defaultLocale) storedSelectedLocale=\(UserDefaults.standard.string(forKey: "selectedLocale") ?? "nil") L10nDefault=\(L10n.defaultRecognitionLocaleID)")
        }
    }

    /// 實際呼叫 AudioImportService：讀取每個檔案的時長並組成 AudioFile；
    /// 每個檔案帶著自己選定的 locale 一起送進去，並透過 onItemStart / onItemFinish
    /// 即時更新畫面上每一列的狀態文字，讓使用者看得到目前處理到哪個檔案。
    private func confirmImport() async {
        isImporting = true
        errorMessage = nil

        let items = pendingURLs.map { url in
            (url: url, locale: localeSelections[url] ?? defaultLocale)
        }

        dbg("import: confirmImport items=\(items.map { "\($0.url.lastPathComponent)[\($0.locale)]" })")

        let result = await importService.makeAudioFiles(
            from: items,
            onItemStart: { url in
                dbg("import: item start \(url.lastPathComponent)")
                Task { @MainActor in
                    itemStatuses[url] = .processing
                }
            },
            onItemFinish: { url, outcome in
                dbg("import: item finish \(url.lastPathComponent) outcome=\(outcome)")
                Task { @MainActor in
                    switch outcome {
                    case .success:
                        itemStatuses[url] = .done
                    case .failure(let error):
                        itemStatuses[url] = .failed(error.localizedDescription)
                    }
                }
            }
        )
        dbg("import: makeAudioFiles returned imported=\(result.imported.count) failures=\(result.failures.count)")

        // 趁使用者剛選完檔、仍有讀取權限的此刻，把音檔複製進 App 自己的目錄，
        // 並讓 AudioFile.sourceURL 指向副本。否則 App 重啟後（Sandbox）
        // 會再也讀不到原路徑（例如 ~/Downloads）的檔案，轉錄必定失敗。
        // originalSourceURL 刻意保留為使用者選的原始位置，下方比對 pendingURLs 要用。
        var importedFiles: [AudioFile] = []
        var failures: [(URL, Error)] = result.failures.map { ($0.0, $0.1) }

        for var file in result.imported {
            let pickedURL = file.originalSourceURL
            do {
                let copiedURL = try await Task.detached(priority: .userInitiated) {
                    try AudioFileStorage.importCopy(of: pickedURL)
                }.value
                file.sourceURL = copiedURL
                importedFiles.append(file)
                dbg("import: copied \(pickedURL.lastPathComponent) -> \(copiedURL.path)")
            } catch {
                dbg("import: copy FAILED \(pickedURL.lastPathComponent) error=\(error)")
                failures.append((pickedURL, error))
                itemStatuses[pickedURL] = .failed(error.localizedDescription)
            }
        }

        isImporting = false

        if !failures.isEmpty {
            let names = failures.map { $0.0.lastPathComponent }
                .joined(separator: L10n.t("common.listSeparator"))
            let reasons = failures
                .map { String(format: L10n.t("import.error.reasonLine"), $0.0.lastPathComponent, $0.1.localizedDescription) }
                .joined(separator: "\n")
            errorMessage = importedFiles.isEmpty
                ? String(format: L10n.t("import.error.allFailed"), reasons)
                : String(format: L10n.t("import.error.partialFailed"), names, reasons)
        }

        guard !importedFiles.isEmpty else { return }

        dbg("import: calling onImport(\(importedFiles.count))")
        onImport(importedFiles)
        dbg("import: onImport returned")

        if failures.isEmpty {
            dismiss()
        } else {
            // 有部分失敗時保留視窗，讓使用者看清楚錯誤訊息，並移除已成功的檔案避免重複匯入
            let importedURLs = Set(importedFiles.map(\.originalSourceURL))
            pendingURLs.removeAll { importedURLs.contains($0) }
        }
    }
}

#Preview {
    ImportView(onImport: { _ in })
}

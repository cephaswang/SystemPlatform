import SwiftUI
import UniformTypeIdentifiers

struct ExportSheetView: View {

    enum ExportFormat: String, CaseIterable, Identifiable {
        case txt = "TXT 純文字"
        case srt = "SRT 字幕檔"
        case docx = "DOCX 文件"
        case pdf = "PDF 文件"

        var id: String { rawValue }

        /// 畫面顯示名稱（rawValue 僅作內部識別，不直接顯示）
        var displayName: String {
            switch self {
            case .txt: return L10n.t("export.format.txt")
            case .srt: return L10n.t("export.format.srt")
            case .docx: return L10n.t("export.format.docx")
            case .pdf: return L10n.t("export.format.pdf")
            }
        }

        var fileExtension: String {
            switch self {
            case .txt: return "txt"
            case .srt: return "srt"
            case .docx: return "docx"
            case .pdf: return "pdf"
            }
        }
    }

    let audioFile: AudioFile

    @Environment(\.dismiss) private var dismiss
    @State private var selectedFormat: ExportFormat = .txt
    @State private var includeTimestamps = true
    @State private var isExporting = false
    @State private var errorMessage: String?

    var body: some View {
        let _ = print("🖼️ [\(Self.self)] body (\(#fileID))")
        
        VStack(alignment: .leading, spacing: 20) {

            Text("export.title")
                .font(.title2)
                .bold()

            Text(audioFile.displayName)
                .font(.subheadline)
                .foregroundColor(.secondary)

            Picker("export.format.label", selection: $selectedFormat) {
                ForEach(ExportFormat.allCases) { format in
                    Text(verbatim: format.displayName).tag(format)
                }
            }
            .pickerStyle(.radioGroup)

            Toggle("export.includeTimestamps", isOn: $includeTimestamps)
                .disabled(selectedFormat == .docx || selectedFormat == .pdf)

            if let errorMessage {
                Text(errorMessage)
                    .font(.caption)
                    .foregroundColor(.red)
            }

            Spacer()

            HStack {
                Spacer()
                Button("common.cancel") { dismiss() }
                Button {
                    performExport()
                } label: {
                    if isExporting {
                        ProgressView().controlSize(.small)
                    } else {
                        Text("export.button.export")
                    }
                }
                .keyboardShortcut(.defaultAction)
                .disabled(isExporting)
            }
        }
        .padding(24)
        .frame(width: 380, height: 300)
    }

    private func performExport() {
        let panel = NSSavePanel()
        panel.nameFieldStringValue = "\(audioFile.displayName).\(selectedFormat.fileExtension)"
        panel.allowedContentTypes = [UTType(filenameExtension: selectedFormat.fileExtension) ?? .plainText]

        guard panel.runModal() == .OK, let destinationURL = panel.url else { return }

        isExporting = true
        errorMessage = nil

        // 實際匯出邏輯由 Services/ExportService.swift 負責，
        // 此畫面僅收集使用者設定並觸發匯出動作
        ExportService().export(
            audioFile: audioFile,
            format: selectedFormat,
            includeTimestamps: includeTimestamps,
            to: destinationURL
        ) { result in
            isExporting = false
            switch result {
            case .success:
                dismiss()
            case .failure(let error):
                errorMessage = error.localizedDescription
            }
        }
    }
}

#Preview {
    ExportSheetView(
        audioFile: AudioFile(
            id: UUID(),
            sourceURL: URL(fileURLWithPath: "/tmp/demo.m4a"),
            displayName: "會議錄音 0922",
            durationSeconds: 125,
            status: .completed
        )
    )
}

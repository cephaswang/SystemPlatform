import SwiftUI
import AppKit

// MARK: - 結構說明
//
// 這一版回到原本的 SwiftUI 結構：NavigationSplitView + 側邊欄 toolbar + detail，
// 所以「返回上一頁」、工具列配置、視窗標題都由 SwiftUI 照原樣處理。
//
// 只有「側邊欄的 List」換成 AppKit：
//   SidebarListView（NSViewControllerRepresentable）
//     └─ SidebarViewController（NSScrollView + NSTableView，source list 樣式）
//
// 這樣不會去動視窗的 NSToolbar，也就不會把 SwiftUI 的返回按鈕弄丟。

struct AudioLibraryView: View {

    @EnvironmentObject private var library: AudioLibraryStore
    @State private var showingImportSheet = false
    @State private var showingExportSheet = false

    // 個別刪除：先記下「使用者想刪的那一筆」，跳出確認後才真的執行，
    // 避免手滑誤刪、且能在提示文字裡帶出檔名。
    @State private var fileAwaitingDeleteConfirmation: AudioFile?

    // 全部刪除：用 confirmationDialog 二次確認，措辭要比單筆刪除更明確警示。
    @State private var showingDeleteAllConfirmation = false

    // 側邊欄固定展開，避免預設就被收起而看不到列表
    @State private var columnVisibility: NavigationSplitViewVisibility = .all

    var body: some View {
        let debugStatus: AudioFile.TranscriptionStatus = library.selectedAudioFile?.status ?? .pending
        let _ = dbg("🖼️ AudioLibraryView body 重新評估，selectedAudioFile.status=\(debugStatus) files=\(library.audioFiles.count)")
        GeometryReader { outer in
        NavigationSplitView(columnVisibility: $columnVisibility) {
            // 側邊欄：AppKit 的 NSTableView（選取、Delete 鍵、右鍵選單都在 AppKit 端處理）
            // 用 Color.clear 讓 SwiftUI 決定欄位大小，AppKit 側邊欄放在 overlay 裡：
            // overlay 的內容不會回頭影響欄位／視窗的尺寸計算。
            // （之前直接給 AppKit view 固定高度，高度會被當成視窗的最小／理想尺寸，
            //   視窗一變大小就又改變高度，形成佈局無限迴圈，出現
            //   「Update Constraints in Window passes」錯誤與當機。）
            Color.clear
                .overlay(alignment: .top) {
                    SidebarListView(
                files: library.audioFiles,
                selectedID: library.selectedAudioFileID,
                onSelect: { newID in
                    guard library.selectedAudioFileID != newID else { return }
                    library.selectedAudioFileID = newID
                },
                onRequestDelete: { file in
                    fileAwaitingDeleteConfirmation = file
                }
                    )
                    .frame(height: outer.size.height)
                }
            // 工具列維持原本寫法（掛在側邊欄內容上，會顯示在側邊欄那一側）
            .toolbar {
                ToolbarItem {
                    Button {
                        showingImportSheet = true
                    } label: {
                        Label("import.title", systemImage: "plus")
                    }
                }
                // 刪除「目前選取的那一筆」（會先跳確認）
                ToolbarItem {
                    Button {
                        if let selected = library.selectedAudioFile {
                            fileAwaitingDeleteConfirmation = selected
                        }
                    } label: {
                        Label("common.delete", systemImage: "trash")
                    }
                    .disabled(library.selectedAudioFile == nil)
                }
                // 刪除「全部」（會先跳更明確的確認）
                ToolbarItem {
                    Button(role: .destructive) {
                        showingDeleteAllConfirmation = true
                    } label: {
                        Label("library.deleteAll", systemImage: "trash.fill")
                    }
                    .disabled(library.audioFiles.isEmpty)
                }
            }
            // 明確指定側邊欄寬度，避免被 detail 的 .frame(minWidth:) 擠到 0 寬
            .navigationSplitViewColumnWidth(min: 260, ideal: 300, max: 420)
        } detail: {
            if let selected = library.selectedAudioFile {
                TranscriptEditorView(audioFile: selected)
                    .id("\(selected.id)-\(selected.status)")
                    .toolbar {
                        ToolbarItem {
                            Button {
                                showingExportSheet = true
                            } label: {
                                Label("library.export", systemImage: "square.and.arrow.up")
                            }
                            .disabled(selected.status != .completed)
                        }
                    }
            } else {
                // ContentUnavailableView 需要 macOS 14；為了支援 macOS 13，
                // 改用下方自製的相容版空狀態畫面。
                LibraryEmptyStateView(
                    title: "library.empty.title",
                    systemImage: "waveform",
                    description: "library.empty.description"
                )
            }
        }
        }
        .frame(minWidth: 700, idealWidth: 920, minHeight: 480, idealHeight: 720)
        .logSize("AudioLibraryView 整體")
        .onAppear {
            // 列表畫面出現後，才重新啟動上次被中斷的轉錄
            library.resumeInterruptedTranscriptions()
        }
        .sheet(isPresented: $showingImportSheet) {
            ImportView { importedFiles in
                library.appendImportedFiles(importedFiles)
            }
        }
        .sheet(isPresented: $showingExportSheet) {
            if let selected = library.selectedAudioFile {
                ExportSheetView(audioFile: selected)
            }
        }
        // 個別刪除確認
        .alert(
            "library.delete.title \(fileAwaitingDeleteConfirmation?.displayName ?? "")",
            isPresented: Binding(
                get: { fileAwaitingDeleteConfirmation != nil },
                set: { if !$0 { fileAwaitingDeleteConfirmation = nil } }
            ),
            presenting: fileAwaitingDeleteConfirmation
        ) { file in
            Button("common.delete", role: .destructive) {
                library.deleteAudioFile(file)
            }
            Button("common.cancel", role: .cancel) {}
        } message: { _ in
            Text("library.delete.message")
        }
        // 全部刪除確認
        .confirmationDialog(
            "library.deleteAll.title \(library.audioFiles.count)",
            isPresented: $showingDeleteAllConfirmation,
            titleVisibility: .visible
        ) {
            Button("library.deleteAll.confirm", role: .destructive) {
                library.deleteAllAudioFiles()
            }
            Button("common.cancel", role: .cancel) {}
        } message: {
            Text("library.deleteAll.message")
        }
    }
}

// MARK: - NSViewControllerRepresentable（只包側邊欄）

private struct SidebarListView: NSViewControllerRepresentable {
    let files: [AudioFile]
    let selectedID: AudioFile.ID?
    let onSelect: (AudioFile.ID?) -> Void
    let onRequestDelete: (AudioFile) -> Void

    func makeNSViewController(context: Context) -> SidebarViewController {
        SidebarViewController()
    }

    func updateNSViewController(_ controller: SidebarViewController, context: Context) {
        controller.onSelect = onSelect
        controller.onRequestDelete = onRequestDelete
        controller.apply(files: files, selectedID: selectedID)
    }

    /// 重點：明確告訴 SwiftUI「側邊欄就是你給我的那麼大」。
    /// 沒有這個的話，SwiftUI 會用 AppKit view 自己的 fittingSize 當理想尺寸，
    /// 你的 log 顯示側邊欄被量成 406x1137（視窗內容區才 ~575 高），
    /// 列表被排到視窗可視範圍之外，所以看起來是空的。
    func sizeThatFits(
        _ proposal: ProposedViewSize,
        nsViewController: SidebarViewController,
        context: Context
    ) -> CGSize? {
        dbg("📐 sizeThatFits proposal=\(String(describing: proposal.width))x\(String(describing: proposal.height))")
        let width = proposal.width.flatMap { $0.isFinite ? $0 : nil } ?? 300
        let height = proposal.height.flatMap { $0.isFinite ? $0 : nil } ?? 500
        return CGSize(width: width, height: height)
    }
}

// MARK: - 側邊欄（NSTableView）

/// 列的顯示資料。獨立成 Equatable，用來判斷是否真的需要 reloadData，
/// 避免每次 SwiftUI 更新都重載表格而閃爍或丟失選取。
private struct SidebarRowModel: Equatable {
    let id: AudioFile.ID
    let name: String
    let duration: String
    let status: AudioFile.TranscriptionStatus

    init(_ file: AudioFile) {
        id = file.id
        name = file.displayName
        duration = file.durationDescription
        status = file.status
    }

    var symbolName: String {
        switch status {
        case .pending: return "clock"
        case .processing: return "waveform.circle"
        case .completed: return "checkmark.circle.fill"
        case .failed: return "exclamationmark.triangle.fill"
        }
    }

    var tintColor: NSColor {
        switch status {
        case .pending: return .secondaryLabelColor
        case .processing: return .systemBlue
        case .completed: return .systemGreen
        case .failed: return .systemRed
        }
    }
}

/// 支援 Delete / Forward Delete 鍵的 NSTableView
private final class SidebarTableView: NSTableView {
    var onDeleteKey: (() -> Void)?

    override func keyDown(with event: NSEvent) {
        // 51 = Delete（⌫），117 = Forward Delete（⌦）
        if event.keyCode == 51 || event.keyCode == 117 {
            onDeleteKey?()
        } else {
            super.keyDown(with: event)
        }
    }
}

/// 座標原點在左上角的容器。容器高度改變（例如 SwiftUI 先給 1137、再給 540）時，
/// 內容會以頂端為準，不會被擠到底部。
private final class FlippedContainerView: NSView {
    override var isFlipped: Bool { true }
}

private final class SidebarViewController: NSViewController,
                                           NSTableViewDataSource,
                                           NSTableViewDelegate,
                                           NSMenuDelegate {

    var onSelect: (AudioFile.ID?) -> Void = { _ in }
    var onRequestDelete: (AudioFile) -> Void = { _ in }

    private let scrollView = NSScrollView()
    private let tableView = SidebarTableView()
    private let emptyLabel = NSTextField(labelWithString: NSLocalizedString("library.empty.title", comment: ""))

    private var files: [AudioFile] = []
    private var rows: [SidebarRowModel] = []

    /// 程式端更新表格（reloadData / 改選取）時為 true，避免把這些變動當成使用者操作回報給 Store
    private var isApplyingUpdate = false

    private static let cellIdentifier = NSUserInterfaceItemIdentifier("AudioFileCell")

    // MARK: Lifecycle

    override func loadView() {
        let container = FlippedContainerView()
        view = container

        // 單欄、無表頭、source list 樣式
        let column = NSTableColumn(identifier: NSUserInterfaceItemIdentifier("main"))
        column.resizingMask = .autoresizingMask
        tableView.addTableColumn(column)
        tableView.headerView = nil
        tableView.style = .sourceList
        tableView.selectionHighlightStyle = .sourceList
        tableView.allowsEmptySelection = true
        tableView.allowsMultipleSelection = false
        tableView.usesAutomaticRowHeights = false
        tableView.rowHeight = 44
        tableView.columnAutoresizingStyle = .uniformColumnAutoresizingStyle
        tableView.dataSource = self
        tableView.delegate = self
        tableView.onDeleteKey = { [weak self] in
            guard let self, self.tableView.selectedRow >= 0,
                  self.tableView.selectedRow < self.files.count else { return }
            self.onRequestDelete(self.files[self.tableView.selectedRow])
        }

        // 右鍵選單
        let menu = NSMenu()
        menu.delegate = self
        tableView.menu = menu

        // 重點：讓 NSScrollView 自動處理標題列／工具列的頂端內縮
        scrollView.documentView = tableView
        scrollView.hasVerticalScroller = true
        scrollView.drawsBackground = false
        scrollView.automaticallyAdjustsContentInsets = true
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        container.addSubview(scrollView)

        // 空狀態文字
        emptyLabel.font = .preferredFont(forTextStyle: .callout)
        emptyLabel.textColor = .secondaryLabelColor
        emptyLabel.alignment = .center
        emptyLabel.translatesAutoresizingMaskIntoConstraints = false
        container.addSubview(emptyLabel)

        // scrollView 用約束貼齊容器四邊；空狀態文字置中
        NSLayoutConstraint.activate([
            scrollView.topAnchor.constraint(equalTo: container.topAnchor),
            scrollView.bottomAnchor.constraint(equalTo: container.bottomAnchor),
            scrollView.leadingAnchor.constraint(equalTo: container.leadingAnchor),
            scrollView.trailingAnchor.constraint(equalTo: container.trailingAnchor),
            emptyLabel.centerXAnchor.constraint(equalTo: container.centerXAnchor),
            emptyLabel.centerYAnchor.constraint(equalTo: container.centerYAnchor)
        ])
    }

    override func viewDidLayout() {
        super.viewDidLayout()
        // ⚠️ 這裡只做「讀取」，不要在 viewDidLayout 裡改 frame、捲動位置或任何會觸發再次佈局的東西：
        // 在 AppKit 的佈局過程中重入佈局，會造成 swift_beginAccess（獨佔存取）當機。
        // scrollView 的大小由 loadView 裡設定的 Auto Layout 約束負責。
        let docFrame = scrollView.documentView?.frame ?? .zero
        dbg("📐 AppKit 側邊欄 view=\(Int(view.bounds.width))x\(Int(view.bounds.height)) scrollFrame=\(Int(scrollView.frame.height)) docH=\(Int(docFrame.height)) rows=\(rows.count)")
    }

    // MARK: 由 SwiftUI 推資料進來

    func apply(files newFiles: [AudioFile], selectedID: AudioFile.ID?) {
        // loadViewIfNeeded() 需要 macOS 14；存取 view 屬性同樣會觸發 loadView()，macOS 13 也能用
        _ = view

        isApplyingUpdate = true
        defer { isApplyingUpdate = false }

        files = newFiles
        let newRows = newFiles.map(SidebarRowModel.init)
        if newRows != rows {
            rows = newRows
            tableView.reloadData()
        }
        emptyLabel.isHidden = !newFiles.isEmpty

        // Store → 表格選取
        let targetRow = selectedID.flatMap { id in newFiles.firstIndex(where: { $0.id == id }) }
        if let targetRow {
            if tableView.selectedRow != targetRow {
                tableView.selectRowIndexes(IndexSet(integer: targetRow), byExtendingSelection: false)
                tableView.scrollRowToVisible(targetRow)
            }
        } else if tableView.selectedRow != -1 {
            tableView.deselectAll(nil)
        }
    }

    // MARK: NSTableViewDataSource / Delegate

    func numberOfRows(in tableView: NSTableView) -> Int { rows.count }

    func tableView(_ tableView: NSTableView, heightOfRow row: Int) -> CGFloat { 44 }

    func tableView(_ tableView: NSTableView, viewFor tableColumn: NSTableColumn?, row: Int) -> NSView? {
        guard row < rows.count else { return nil }
        let cell = (tableView.makeView(withIdentifier: Self.cellIdentifier, owner: self) as? AudioFileCellView)
            ?? AudioFileCellView()
        cell.identifier = Self.cellIdentifier
        cell.configure(with: rows[row])
        return cell
    }

    // 表格 → Store（只回報使用者的操作）
    func tableViewSelectionDidChange(_ notification: Notification) {
        guard !isApplyingUpdate else { return }
        let row = tableView.selectedRow
        onSelect((row >= 0 && row < files.count) ? files[row].id : nil)
    }

    // MARK: 右鍵選單

    func menuNeedsUpdate(_ menu: NSMenu) {
        menu.removeAllItems()
        let row = tableView.clickedRow
        guard row >= 0, row < files.count else { return }
        let item = NSMenuItem(
            title: NSLocalizedString("common.delete", comment: ""),
            action: #selector(deleteFromContextMenu(_:)),
            keyEquivalent: ""
        )
        item.target = self
        item.representedObject = row
        item.image = NSImage(systemSymbolName: "trash", accessibilityDescription: nil)
        menu.addItem(item)
    }

    @objc private func deleteFromContextMenu(_ sender: NSMenuItem) {
        guard let row = sender.representedObject as? Int, row >= 0, row < files.count else { return }
        onRequestDelete(files[row])
    }
}

// MARK: - 列（NSTableCellView）

private final class AudioFileCellView: NSTableCellView {

    private let statusImageView = NSImageView()
    private let titleField = NSTextField(labelWithString: "")
    private let subtitleField = NSTextField(labelWithString: "")

    init() {
        super.init(frame: .zero)

        // 固定圖示欄寬：狀態切換時列高／排版不會跳動
        statusImageView.translatesAutoresizingMaskIntoConstraints = false
        statusImageView.imageScaling = .scaleProportionallyDown

        titleField.font = .systemFont(ofSize: 13)
        titleField.lineBreakMode = .byTruncatingMiddle
        titleField.maximumNumberOfLines = 1

        subtitleField.font = .systemFont(ofSize: 11)
        subtitleField.textColor = .secondaryLabelColor
        subtitleField.lineBreakMode = .byTruncatingTail
        subtitleField.maximumNumberOfLines = 1

        let textStack = NSStackView(views: [titleField, subtitleField])
        textStack.orientation = .vertical
        textStack.alignment = .leading
        textStack.spacing = 2
        textStack.translatesAutoresizingMaskIntoConstraints = false

        addSubview(statusImageView)
        addSubview(textStack)

        NSLayoutConstraint.activate([
            statusImageView.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 4),
            statusImageView.centerYAnchor.constraint(equalTo: centerYAnchor),
            statusImageView.widthAnchor.constraint(equalToConstant: 20),
            statusImageView.heightAnchor.constraint(equalToConstant: 20),

            textStack.leadingAnchor.constraint(equalTo: statusImageView.trailingAnchor, constant: 10),
            textStack.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -4),
            textStack.centerYAnchor.constraint(equalTo: centerYAnchor)
        ])
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }

    func configure(with row: SidebarRowModel) {
        titleField.stringValue = row.name
        subtitleField.stringValue = row.duration
        statusImageView.image = NSImage(systemSymbolName: row.symbolName, accessibilityDescription: nil)
        statusImageView.contentTintColor = row.tintColor
    }
}

// MARK: - 偵錯：印出 view 的寬、高

/// 🔎 偵錯用（排查完成後可整段刪除，連同 .logSize(...)）。
/// 在 Xcode Console 篩選框輸入 📐 即可只看這些行。
private struct SizeLogger: ViewModifier {
    let label: String

    func body(content: Content) -> some View {
        content.background(
            GeometryReader { geo in
                Color.clear
                    .onAppear { log(geo.size, safeTop: geo.safeAreaInsets.top, event: "appear") }
                    .onChange(of: geo.size) { newSize in
                        log(newSize, safeTop: geo.safeAreaInsets.top, event: "changed")
                    }
            }
        )
    }

    private func log(_ size: CGSize, safeTop: CGFloat, event: String) {
        let window = NSApp.keyWindow ?? NSApp.mainWindow
        let windowText: String
        if let window {
            let frame = window.frame.size
            let content = window.contentView?.frame.size ?? .zero
            windowText = "window=\(Int(frame.width))x\(Int(frame.height)) windowContent=\(Int(content.width))x\(Int(content.height))"
        } else {
            windowText = "window=nil"
        }
        dbg("📐 \(label) [\(event)] view=\(Int(size.width))x\(Int(size.height)) safeTop=\(Int(safeTop)) \(windowText)")
    }
}

private extension View {
    func logSize(_ label: String) -> some View {
        modifier(SizeLogger(label: label))
    }
}

// MARK: - 空狀態（相容 macOS 13，取代 macOS 14 才有的 ContentUnavailableView）

private struct LibraryEmptyStateView: View {
    let title: LocalizedStringKey
    let systemImage: String
    var description: LocalizedStringKey? = nil

    var body: some View {
        VStack(spacing: 8) {
            Image(systemName: systemImage)
                .font(.system(size: 40))
                .foregroundColor(.secondary)
            Text(title)
                .font(.title3)
                .bold()
            if let description {
                Text(description)
                    .font(.callout)
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
        .padding()
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}

#Preview {
    AudioLibraryView()
        .environmentObject(AudioLibraryStore())
}

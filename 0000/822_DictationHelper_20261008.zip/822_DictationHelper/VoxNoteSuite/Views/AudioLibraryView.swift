import SwiftUI

struct AudioLibraryView: View {

    @EnvironmentObject private var library: AudioLibraryStore
    @State private var showingImportSheet = false
    @State private var showingExportSheet = false

    // 個別刪除：先記下「使用者想刪的那一筆」，跳出確認後才真的執行，
    // 避免手滑誤刪、且能在提示文字裡帶出檔名。
    @State private var fileAwaitingDeleteConfirmation: AudioFile?

    // 全部刪除：用 confirmationDialog 二次確認，措辭要比單筆刪除更明確警示。
    @State private var showingDeleteAllConfirmation = false

    // 側邊欄固定展開，避免預設就被收起而看不到列表
    @State private var columnVisibility: NavigationSplitViewVisibility = .all

    // 列表的選取狀態用本地 @State，再同步回 library.selectedAudioFileID。
    // 原本 List(selection:) 直接綁定 @Published：列表資料更新時，AppKit 的表格會在
    // view update 期間回寫選取，就會觸發「Publishing changes from within view updates」。
    @State private var listSelection: AudioFile.ID?

    /// 列表頂端為了避開標題列（紅黃綠按鈕與工具列）而保留的高度
    private let titlebarSpacerHeight: CGFloat = 52

    var body: some View {
        let debugStatus: AudioFile.TranscriptionStatus = library.selectedAudioFile?.status ?? .pending
        let _ = dbg("🖼️ AudioLibraryView body 重新評估，selectedAudioFile.status=\(debugStatus) files=\(library.audioFiles.count)")
        NavigationSplitView(columnVisibility: $columnVisibility) {
            // 側邊欄列表。
            // 為什麼不再用「VStack { Color.clear.frame(height: 52); List }」：
            // 那個做法讓 List 變成 VStack 的子視圖，列表高度 = 視窗高度 − 52，
            // 並且與 AppKit 對 List 自動計算的頂端內縮（標題列／工具列）互相干擾，
            // 視窗在預設（最小）高度時，前幾列會被擠到標題列後面看不到，拉高視窗才出現。
            // 現在 List 直接作為側邊欄的內容、填滿整個欄位，
            // 並把避開標題列用的留白改成「列表裡的第一列」，與列表一起捲動：
            // 即使系統另外也加了內縮，最壞情況只是多一點空白，不會再有列被遮住。
            List(selection: $listSelection) {
                // 頂端留白列：沒有 .tag，所以不能被選取；不顯示分隔線、不吃點擊
                /*
                Color.clear
                    .frame(height: titlebarSpacerHeight)
                    .listRowSeparator(.hidden)
                    .listRowInsets(EdgeInsets())
                    .allowsHitTesting(false)
                */

                ForEach(library.audioFiles) { file in
                    AudioFileRow(file: file, statusIcon: statusIcon, statusColor: statusColor)
                        .tag(file.id)
                        .contextMenu { deleteButton(for: file) }
                }
            }
            .listStyle(.sidebar)
            .frame(maxHeight: .infinity)
            .logSize("側邊欄 List")
            // 本地選取 → Store：延後到下一輪 main queue，避免在 view update 中發布變更
            .onChange(of: listSelection) { newValue in
                guard library.selectedAudioFileID != newValue else { return }
                DispatchQueue.main.async { library.selectedAudioFileID = newValue }
            }
            // Store → 本地選取（例如刪除檔案後 Store 清掉選取）
            .onChange(of: library.selectedAudioFileID) { newValue in
                if listSelection != newValue { listSelection = newValue }
            }
            // 狀態變化時不要做列的插入／高度動畫，這是列互相疊在一起的常見來源
            .transaction { $0.animation = nil }
            // 選到某一列後按 Delete 鍵 → 跳出確認（macOS 沒有滑動刪除，這是最順手的方式）
            .onDeleteCommand {
                if let selected = library.selectedAudioFile {
                    fileAwaitingDeleteConfirmation = selected
                }
            }
            .overlay {
                if library.audioFiles.isEmpty {
                    Text("library.empty.title")
                        .font(.callout)
                        .foregroundColor(.secondary)
                }
            }
            .toolbar {
                ToolbarItem {
                    Button {
                        showingImportSheet = true
                    } label: {
                        Label("import.title", systemImage: "plus")
                    }
                }
                // 刪除「目前選取的那一筆」（會先跳確認）
                ToolbarItem {
                    Button {
                        if let selected = library.selectedAudioFile {
                            fileAwaitingDeleteConfirmation = selected
                        }
                    } label: {
                        Label("common.delete", systemImage: "trash")
                    }
                    .disabled(library.selectedAudioFile == nil)
                }
                // 刪除「全部」（會先跳更明確的確認）
                ToolbarItem {
                    Button(role: .destructive) {
                        showingDeleteAllConfirmation = true
                    } label: {
                        Label("library.deleteAll", systemImage: "trash.fill")
                    }
                    .disabled(library.audioFiles.isEmpty)
                }
            }
            // 明確指定側邊欄寬度，避免被 detail 的 .frame(minWidth:) 擠到 0 寬
            .navigationSplitViewColumnWidth(min: 260, ideal: 300, max: 420)
        } detail: {
            if let selected = library.selectedAudioFile {
                TranscriptEditorView(audioFile: selected)
                    .id("\(selected.id)-\(selected.status)")   // 新增這行
                    .toolbar {
                        ToolbarItem {
                            Button {
                                showingExportSheet = true
                            } label: {
                                Label("library.export", systemImage: "square.and.arrow.up")
                            }
                            .disabled(selected.status != .completed)
                        }
                    }
            } else {
                // ContentUnavailableView 需要 macOS 14；為了支援 macOS 13，
                // 改用下方自製的相容版空狀態畫面。
                LibraryEmptyStateView(
                    title: "library.empty.title",
                    systemImage: "waveform",
                    description: "library.empty.description"
                )
            }
        }
        // 最小尺寸不變；另外給「理想尺寸」，視窗第一次開啟時就有足夠的高度與寬度，
        // 不會剛好停在最小尺寸而讓版面擁擠。
        // .frame(minWidth: 560, idealWidth: 920, minHeight: 640, idealHeight: 720)
       // .frame(minWidth: 700, idealWidth: 920, minHeight: 420, idealHeight: 720)
       // .frame(minWidth: 700, idealWidth: 920, minHeight: 480, idealHeight: 720)
        .logSize("AudioLibraryView 整體")
        .onAppear {
            listSelection = library.selectedAudioFileID
            // 列表畫面出現後，才重新啟動上次被中斷的轉錄
            library.resumeInterruptedTranscriptions()
        }
        .sheet(isPresented: $showingImportSheet) {
            // appendImportedFiles 內部已延後到下一輪 main queue，避免在 sheet dismiss 的
            // view-update 週期內同步修改 @Published 而觸發警告。
            ImportView { importedFiles in
                library.appendImportedFiles(importedFiles)
            }
        }
        .sheet(isPresented: $showingExportSheet) {
            if let selected = library.selectedAudioFile {
                ExportSheetView(audioFile: selected)
            }
        }
        // 個別刪除確認
        .alert(
            "library.delete.title \(fileAwaitingDeleteConfirmation?.displayName ?? "")",
            isPresented: Binding(
                get: { fileAwaitingDeleteConfirmation != nil },
                set: { if !$0 { fileAwaitingDeleteConfirmation = nil } }
            ),
            presenting: fileAwaitingDeleteConfirmation
        ) { file in
            Button("common.delete", role: .destructive) {
                library.deleteAudioFile(file)
            }
            Button("common.cancel", role: .cancel) {}
        } message: { _ in
            Text("library.delete.message")
        }
        // 全部刪除確認
        .confirmationDialog(
            "library.deleteAll.title \(library.audioFiles.count)",
            isPresented: $showingDeleteAllConfirmation,
            titleVisibility: .visible
        ) {
            Button("library.deleteAll.confirm", role: .destructive) {
                library.deleteAllAudioFiles()
            }
            Button("common.cancel", role: .cancel) {}
        } message: {
            Text("library.deleteAll.message")
        }
    }

    private func statusIcon(for status: AudioFile.TranscriptionStatus) -> String {
        switch status {
        case .pending: return "clock"
        case .processing: return "waveform.circle"
        case .completed: return "checkmark.circle.fill"
        case .failed: return "exclamationmark.triangle.fill"
        }
    }

    private func statusColor(for status: AudioFile.TranscriptionStatus) -> Color {
        switch status {
        case .pending: return .secondary
        case .processing: return .blue
        case .completed: return .green
        case .failed: return .red
        }
    }

    @ViewBuilder
    private func deleteButton(for file: AudioFile) -> some View {
        Button(role: .destructive) {
            fileAwaitingDeleteConfirmation = file
        } label: {
            Label("common.delete", systemImage: "trash")
        }
    }
}

// MARK: - 偵錯：印出 view 的寬、高

/// 🔎 偵錯用（排查完成後可整段刪除，連同上面的兩行 .logSize(...)）。
/// 在 view 第一次出現、以及尺寸每次改變時，印出：
///   - 這個 view 的寬、高
///   - 目前視窗的外框尺寸與內容區尺寸
///   - 螢幕可用範圍（visibleFrame，視窗最高就是這個高度）
/// 在 Xcode Console 篩選框輸入 📐 即可只看這些行。
private struct SizeLogger: ViewModifier {
    let label: String

    func body(content: Content) -> some View {
        content.background(
            GeometryReader { geo in
                Color.clear
                    .onAppear { log(geo.size, event: "appear") }
                    .onChange(of: geo.size) { newSize in log(newSize, event: "changed") }
            }
        )
    }

    private func log(_ size: CGSize, event: String) {
        let window = NSApp.keyWindow ?? NSApp.mainWindow
        let windowText: String
        if let window {
            let frame = window.frame.size
            let content = window.contentView?.frame.size ?? .zero
            windowText = "window=\(Int(frame.width))x\(Int(frame.height)) windowContent=\(Int(content.width))x\(Int(content.height))"
        } else {
            windowText = "window=nil"
        }
        let screen = NSScreen.main?.visibleFrame.size ?? .zero
        dbg("📐 \(label) [\(event)] view=\(Int(size.width))x\(Int(size.height)) \(windowText) screenVisible=\(Int(screen.width))x\(Int(screen.height))")
    }
}

private extension View {
    /// 尺寸改變時印出此 view 的寬、高（偵錯用）
    func logSize(_ label: String) -> some View {
        modifier(SizeLogger(label: label))
    }
}

/// 抽成獨立的列 view，避免整條 modifier chain（tag / swipeActions / contextMenu）
/// 和內部的 HStack 疊在同一個表達式裡，導致 type-checker 逾時。
private struct AudioFileRow: View {
    let file: AudioFile
    let statusIcon: (AudioFile.TranscriptionStatus) -> String
    let statusColor: (AudioFile.TranscriptionStatus) -> Color

    var body: some View {
        HStack(spacing: 10) {
            // 固定圖示欄寬：不同 SF Symbol 的寬高不一，狀態切換時才不會讓列高／排版跳動
            Image(systemName: statusIcon(file.status))
                .foregroundColor(statusColor(file.status))
                .frame(width: 20, height: 20)

            VStack(alignment: .leading, spacing: 2) {
                Text(file.displayName)
                    .font(.body)
                    .lineLimit(1)
                    .truncationMode(.middle)
                Text(file.durationDescription)
                    .font(.caption)
                    .foregroundColor(.secondary)
                    .lineLimit(1)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
        // 明確給列高：macOS 的 List（NSTableView）若算不出列高，所有列會疊在同一個位置
        .padding(.vertical, 4)
        .frame(maxWidth: .infinity, minHeight: 40, alignment: .leading)
        // .frame(height: 44)
        .contentShape(Rectangle())
        .onAppear { dbg("🧾 row appear: \(file.displayName) status=\(file.status)") }
    }
}

/// 相容 macOS 13 的空狀態畫面，取代 macOS 14 才有的 ContentUnavailableView
private struct LibraryEmptyStateView: View {
    let title: LocalizedStringKey
    let systemImage: String
    var description: LocalizedStringKey? = nil

    var body: some View {
        VStack(spacing: 8) {
            Image(systemName: systemImage)
                .font(.system(size: 40))
                .foregroundColor(.secondary)
            Text(title)
                .font(.title3)
                .bold()
            if let description {
                Text(description)
                    .font(.callout)
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
        .padding()
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}

#Preview {
    AudioLibraryView()
        .environmentObject(AudioLibraryStore())
}

import Foundation

/// 負責把使用者匯入的音檔複製一份到 App 自己的目錄。
///
/// 為什麼需要：App 在 Sandbox 下，使用者用 NSOpenPanel／拖放選到的檔案，
/// 只在「當次執行期間」有讀取權限；App 重啟後同一個路徑（例如 ~/Downloads）
/// 就讀不到了（log 會看到 readable=false、NSCocoaErrorDomain 257）。
/// 複製進自己的 Container 之後，權限永遠有效，也不怕原檔被搬動或刪除。
enum AudioFileStorage {

    /// App 保存音檔副本的根目錄
    static var directory: URL {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first!
        return base.appendingPathComponent("VoxNoteImport/Audio", isDirectory: true)
    }

    /// 這個 URL 是否為本 App 管理的副本（位於 directory 底下）
    static func isManagedCopy(_ url: URL) -> Bool {
        let root = directory.standardizedFileURL.path + "/"
        return url.standardizedFileURL.path.hasPrefix(root)
    }

    /// 把使用者選的檔案複製進 App 目錄，回傳副本的 URL。
    /// 每個副本放在獨立的 UUID 資料夾內：避免同名衝突，同時保留原始檔名。
    static func importCopy(of sourceURL: URL) throws -> URL {
        // 沒有 security scope 的 URL 回傳 false，不影響後續複製
        let accessing = sourceURL.startAccessingSecurityScopedResource()
        defer { if accessing { sourceURL.stopAccessingSecurityScopedResource() } }

        let folder = directory.appendingPathComponent(UUID().uuidString, isDirectory: true)
        try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)

        let destination = folder.appendingPathComponent(sourceURL.lastPathComponent)
        do {
            try FileManager.default.copyItem(at: sourceURL, to: destination)
        } catch {
            try? FileManager.default.removeItem(at: folder)   // 複製失敗就不要留下空資料夾
            throw error
        }
        return destination
    }

    /// 刪除某個音檔的副本（連同其 UUID 資料夾）。
    /// 只會刪除本 App 管理的副本；舊資料若仍指向 Downloads 等使用者目錄，一律不動。
    static func removeCopy(at url: URL) {
        guard isManagedCopy(url) else { return }
        try? FileManager.default.removeItem(at: url.deletingLastPathComponent())
    }

    /// 清空所有副本
    static func removeAllCopies() {
        try? FileManager.default.removeItem(at: directory)
    }
}

import Foundation
import Combine

/// 管理已匯入音檔與其轉錄狀態的共用資料來源
final class AudioLibraryStore: ObservableObject {
    @Published var audioFiles: [AudioFile] = [] {
        didSet {
            // 從磁碟載入時也會經過這個 setter，但那個動作本身不該再觸發一次寫檔，
            // 所以載入期間用 isRestoringFromDisk 擋掉。
            guard !isRestoringFromDisk else { return }
            persist()
        }
    }
    @Published var selectedAudioFileID: AudioFile.ID?

    var selectedAudioFile: AudioFile? {
        audioFiles.first { $0.id == selectedAudioFileID }
    }

    private let recognitionService = SpeechRecognitionService()

    /// 進行中的轉錄工作（每個音檔一個）。
    /// 保存 Task 的目的：刪除音檔時可以取消對應的辨識，不讓已刪除的檔案繼續佔用辨識佇列。
    /// 只在主執行緒存取（startTranscription／delete 系列都在 main queue 上執行）。
    private var jobs: [AudioFile.ID: Task<Void, Never>] = [:]

    /// 上次關閉 App 時被中斷的轉錄（載入時已重設為 .pending）。
    /// 不在 init 裡立刻重啟：Store 是在 App 啟動時建立的（見 RootApp），
    /// 那時畫面還沒出現，一啟動就開始辨識只會跟畫面載入搶資源。
    /// 改由 AudioLibraryView 出現後呼叫 resumeInterruptedTranscriptions()。
    private var pendingResumeIDs: [AudioFile.ID] = []

    // MARK: - 持久化（App 重啟後還原音檔清單與轉錄結果）

    private var isRestoringFromDisk = false

    private var persistenceDirectoryURL: URL {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first!
        return base.appendingPathComponent("VoxNoteImport", isDirectory: true)
    }

    private var persistenceFileURL: URL {
        persistenceDirectoryURL.appendingPathComponent("library.json")
    }

    init() {
        loadFromDisk()
    }

    /// App 啟動時載入上次保存的音檔清單（含逐字稿）。
    /// 第一次啟動、檔案不存在，或格式對不上時，安靜地從空清單開始，不視為錯誤，
    /// 避免因為存檔格式升級或損毀就整個開不起來。
    private func loadFromDisk() {
        guard let data = try? Data(contentsOf: persistenceFileURL) else { return }
        guard var decoded = try? JSONDecoder().decode([AudioFile].self, from: data) else {
            print("⚠️ AudioLibraryStore：無法解析已存檔的音檔清單，忽略並從空清單開始")
            return
        }

        // App 上次是在轉錄途中被關閉的：那些 Task 已經不存在了，
        // 若保留 .processing 就會永遠卡住。重設為 .pending 以便重新啟動。
        var interruptedIDs: [AudioFile.ID] = []
        for i in decoded.indices where decoded[i].status == .processing {
            decoded[i].status = .pending
            interruptedIDs.append(decoded[i].id)
        }

        isRestoringFromDisk = true
        audioFiles = decoded
        isRestoringFromDisk = false

        dbg("store: restored \(decoded.count) files, interrupted=\(interruptedIDs.count)")

        // 先記下被中斷的轉錄，等音檔列表畫面出現後再重新啟動
        pendingResumeIDs = interruptedIDs
    }

    /// 重新啟動上次被中斷的轉錄。由 AudioLibraryView 出現後呼叫；只會執行一次。
    func resumeInterruptedTranscriptions() {
        let ids = pendingResumeIDs
        pendingResumeIDs.removeAll()
        guard !ids.isEmpty else { return }
        dbg("store: resuming \(ids.count) interrupted transcription(s)")
        for id in ids {
            startTranscription(for: id)
        }
    }

    /// 將目前的音檔清單（含逐字稿）寫回磁碟。
    /// 在背景執行緒編碼與寫檔，避免逐字稿內容較大時卡住主執行緒／UI。
    private func persist() {
        let snapshot = audioFiles
        let directory = persistenceDirectoryURL
        let fileURL = persistenceFileURL

        DispatchQueue.global(qos: .utility).async {
            do {
                try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
                let data = try JSONEncoder().encode(snapshot)
                try data.write(to: fileURL, options: .atomic)
                dbg("store: persisted \(snapshot.count) files, \(data.count) bytes")
            } catch {
                print("⚠️ AudioLibraryStore：儲存音檔清單失敗：\(error.localizedDescription)")
            }
        }
    }

    // MARK: - 刪除

    /// 刪除單一音檔（連同其轉錄稿與 App 內的音檔副本）。
    /// 是否要跳確認提示由呼叫端（AudioLibraryView）負責，這裡只做實際刪除。
    /// 若該檔案正在轉錄，會先取消對應的工作，避免已刪除的檔案繼續佔用辨識佇列。
    func deleteAudioFile(_ file: AudioFile) {
        DispatchQueue.main.async {
            if let job = self.jobs.removeValue(forKey: file.id) {
                dbg("store: cancelling transcription job for deleted file id=\(file.id)")
                job.cancel()
            }
            self.audioFiles.removeAll { $0.id == file.id }
            if self.selectedAudioFileID == file.id {
                self.selectedAudioFileID = nil
            }
            // 只會刪 App 自己管理的副本；舊資料指向使用者目錄的不會被動到
            AudioFileStorage.removeCopy(at: file.sourceURL)
        }
    }

    /// 清空整個音檔清單（連同所有轉錄稿與音檔副本）。
    /// 是否要跳確認提示由呼叫端（AudioLibraryView）負責，這裡只做實際刪除。
    /// 會一併取消所有進行中的轉錄工作。
    func deleteAllAudioFiles() {
        DispatchQueue.main.async {
            if !self.jobs.isEmpty {
                dbg("store: cancelling \(self.jobs.count) transcription job(s) (delete all)")
            }
            self.jobs.values.forEach { $0.cancel() }
            self.jobs.removeAll()

            self.audioFiles.removeAll()
            self.selectedAudioFileID = nil
            AudioFileStorage.removeAllCopies()
        }
    }

    // MARK: - 匯入與轉錄

    /// 對單一音檔啟動語音辨識：locale 讀取「該檔案自己」在匯入時選定的語系
    /// （見 AudioFile.locale），不再讀全域 UserDefaults，讓每個檔案的語系互相獨立。
    /// 辨識引擎（Apple Speech / Whisper）維持全域設定，因為那牽涉到隱私與功能選擇，
    /// 通常是使用者對整個 App 的一次性選擇。
    ///
    /// 整段包進 DispatchQueue.main.async ——包含開頭同步的 .status = .processing——
    /// 是為了避免這個函式剛好在 sheet dismiss 的 view-update transaction 裡被呼叫，
    /// 同步修改 @Published 屬性觸發「Publishing changes from within view updates」。
    func startTranscription(for fileID: AudioFile.ID) {
        DispatchQueue.main.async {
            dbg("startTranscription: enter id=\(fileID)")
            guard let index = self.audioFiles.firstIndex(where: { $0.id == fileID }),
                  self.audioFiles[index].status == .pending else {
                dbg("startTranscription: SKIPPED (id not found, or status != pending) id=\(fileID)")
                return
            }

            // 已經有進行中的工作就不重複啟動
            guard self.jobs[fileID] == nil else {
                dbg("startTranscription: SKIPPED (job already running) id=\(fileID)")
                return
            }

            self.audioFiles[index].status = .processing
            self.audioFiles[index].lastError = nil          // 重新轉錄時清掉上一次的失敗原因
            let audioURL = self.audioFiles[index].sourceURL
            let locale = self.audioFiles[index].locale

            let engine = SettingsView.RecognitionEngine(
                rawValue: UserDefaults.standard.string(forKey: "recognitionEngine") ?? ""
            ) ?? .appleSpeech
            dbg("startTranscription: status->processing file=\(self.audioFiles[index].displayName) locale=\(locale) engine=\(engine) url=\(audioURL.path)")

            self.jobs[fileID] = Task { @MainActor in
                // 不論成功、失敗或被取消，結束時都要把自己從 jobs 移除
                defer { self.jobs[fileID] = nil }

                do {
                    dbg("startTranscription: calling recognize()")
                    let segments = try await self.recognitionService.recognize(
                        audioURL: audioURL,
                        locale: locale,
                        engine: engine
                    )

                    // 辨識期間若被取消（例如使用者刪除了該檔案），不要寫回任何結果
                    if Task.isCancelled {
                        dbg("startTranscription: cancelled after recognize returned, discarding result id=\(fileID)")
                        return
                    }

                    guard let idx = self.audioFiles.firstIndex(where: { $0.id == fileID }) else { return }
                    self.audioFiles[idx].transcriptSegments = segments
                    self.audioFiles[idx].lastError = nil
                    self.audioFiles[idx].status = .completed
                    dbg("startTranscription: completed segments=\(segments.count) id=\(fileID)")
                } catch {
                    // 被取消不算失敗：檔案多半已被刪除，不需要也不應該再改狀態
                    if Task.isCancelled || error is CancellationError {
                        dbg("startTranscription: cancelled id=\(fileID)")
                        return
                    }

                    dbg("startTranscription: recognize() FAILED error=\(error) | \(error.localizedDescription)")
                    guard let idx = self.audioFiles.firstIndex(where: { $0.id == fileID }) else { return }
                    self.audioFiles[idx].lastError = error.localizedDescription
                    self.audioFiles[idx].status = .failed
                }
            }
        }
    }

    func appendImportedFiles(_ files: [AudioFile]) {
        DispatchQueue.main.async {
            dbg("store: appendImportedFiles count=\(files.count) \(files.map { "\($0.displayName)[locale=\($0.locale)]" })")
            self.audioFiles.append(contentsOf: files)
            files.forEach { self.startTranscription(for: $0.id) }
        }
    }
}

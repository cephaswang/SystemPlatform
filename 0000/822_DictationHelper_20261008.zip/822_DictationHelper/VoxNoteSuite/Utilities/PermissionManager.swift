import Foundation
import AppKit
import AVFoundation
import Speech
import Combine

/// 統一管理 App 所需的系統權限請求與現況查詢（無狀態，可在任何地方建立使用）
struct PermissionManager {

    enum PermissionStatus {
        case authorized
        case denied
        case notDetermined
    }

    /// 語音辨識權限現況
    var speechRecognitionStatus: PermissionStatus {
        switch SFSpeechRecognizer.authorizationStatus() {
        case .authorized:
            return .authorized
        case .denied, .restricted:
            return .denied
        case .notDetermined:
            return .notDetermined
        @unknown default:
            return .notDetermined
        }
    }

    /// 請求語音辨識權限，回傳是否取得授權
    func requestSpeechRecognitionPermission() async -> Bool {
        dbg("permission: requesting speech authorization (current rawStatus=\(SFSpeechRecognizer.authorizationStatus().rawValue))")
        return await withCheckedContinuation { continuation in
            SFSpeechRecognizer.requestAuthorization { status in
                dbg("permission: speech authorization callback rawStatus=\(status.rawValue)")
                continuation.resume(returning: status == .authorized)
            }
        }
    }

    /// 麥克風權限現況
    var microphoneStatus: PermissionStatus {
        switch AVCaptureDevice.authorizationStatus(for: .audio) {
        case .authorized:
            return .authorized
        case .denied, .restricted:
            return .denied
        case .notDetermined:
            return .notDetermined
        @unknown default:
            return .notDetermined
        }
    }

    /// 請求麥克風權限，回傳是否取得授權
    func requestMicrophonePermission() async -> Bool {
        dbg("permission: requesting microphone access")
        let granted = await AVCaptureDevice.requestAccess(for: .audio)
        dbg("permission: microphone granted=\(granted)")
        return granted
    }

    /// 提示使用者前往系統設定開啟權限（適用於使用者曾拒絕、需手動開啟的情況）
    func openSystemPrivacySettings() {
        guard let url = URL(string: "x-apple.systempreferences:com.apple.preference.security?Privacy") else { return }
        NSWorkspace.shared.open(url)
    }
}

// MARK: - 第一頁統一權限流程

/// App 第一頁載入時，依序請求所有需要的權限，並把授權狀態發布給畫面使用。
/// 順序：語音辨識 → 麥克風 → 螢幕錄製。
/// 任何一項被拒絕都不會阻擋其他功能（匯入音檔只需語音辨識；
/// 麥克風聽抄需語音辨識＋麥克風；系統聲音需語音辨識＋螢幕錄製）。
@MainActor
final class PermissionCoordinator: ObservableObject {

    @Published private(set) var speech: PermissionManager.PermissionStatus = .notDetermined
    @Published private(set) var microphone: PermissionManager.PermissionStatus = .notDetermined
    @Published private(set) var screenRecording = false
    /// 已請求過螢幕錄製但目前仍未生效（需到系統設定開啟，或授權後重新啟動 App）
    @Published private(set) var screenRecordingNeedsAttention = false

    private let manager = PermissionManager()
    private var didStartFlow = false
    private let askedScreenKey = "didRequestScreenRecording"

    init() { refresh() }

    /// 重新讀取三項權限的目前狀態（App 回到前景時也會呼叫）
    func refresh() {
        speech = manager.speechRecognitionStatus
        microphone = manager.microphoneStatus
        screenRecording = CGPreflightScreenCaptureAccess()
        screenRecordingNeedsAttention =
            !screenRecording && UserDefaults.standard.bool(forKey: askedScreenKey)
        dbg("permission: refresh speech=\(speech) mic=\(microphone) screen=\(screenRecording) needsAttention=\(screenRecordingNeedsAttention)")
    }

    /// 依序請求全部權限。整個 App 生命週期只會執行一次，
    /// 已決定（授權或拒絕）的項目不會重複跳出對話框。
    func requestAllIfNeeded() async {
        guard !didStartFlow else { return }
        didStartFlow = true
        dbg("PermissionCoordinator: requestAllIfNeeded start")

        // 1. 語音辨識
        if manager.speechRecognitionStatus == .notDetermined {
            _ = await manager.requestSpeechRecognitionPermission()
            refresh()
        }

        // 2. 麥克風
        if manager.microphoneStatus == .notDetermined {
            _ = await manager.requestMicrophonePermission()
            refresh()
        }

        // 3. 螢幕錄製：系統聲音來源需要。此請求無法 await，且重複呼叫會反覆打擾
        //    使用者，因此整個 App 只主動請求一次；之後由狀態列引導到系統設定。
        //    授權後依 ScreenCaptureKit 特性，需重新啟動 App 才會生效。
        if !CGPreflightScreenCaptureAccess(),
           !UserDefaults.standard.bool(forKey: askedScreenKey) {
            UserDefaults.standard.set(true, forKey: askedScreenKey)
            _ = CGRequestScreenCaptureAccess()
        }

        refresh()
        dbg("PermissionCoordinator: requestAllIfNeeded done")
    }

    /// 狀態列摘要文字；三項都就緒時回傳 nil
    var summary: String? {
        var issues: [String] = []
        if speech != .authorized { issues.append(L10n.t("perm.summary.speech")) }
        if microphone != .authorized { issues.append(L10n.t("perm.summary.mic")) }
        if !screenRecording { issues.append(L10n.t("perm.summary.screen")) }
        return issues.isEmpty ? nil : issues.joined(separator: L10n.t("env.separator"))
    }

    /// 開啟系統設定的指定隱私權分頁。
    /// pane：「SpeechRecognition」「Microphone」「ScreenCapture」
    func openSettings(_ pane: String) {
        guard let url = URL(string: "x-apple.systempreferences:com.apple.preference.security?Privacy_\(pane)") else { return }
        NSWorkspace.shared.open(url)
    }

    /// 使用者主動按下「前往設定」時呼叫：先再請求一次，讓 App 註冊進
    /// 「螢幕與系統音訊錄製」清單（清單中沒有 App 時，使用者無法開啟開關），
    /// 稍待片刻若仍未授權，再開啟系統設定對應分頁。
    func openScreenRecordingSettings() {
        _ = CGRequestScreenCaptureAccess()
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) { [weak self] in
            guard let self = self else { return }
            self.refresh()
            if !self.screenRecording {
                self.openSettings("ScreenCapture")
            }
        }
    }

    /// 重新啟動 App（螢幕錄製授權後需要）
    func relaunch() {
        // 不同時存在兩個實例：先啟動一個背景小程序，等目前這個 App 完全結束後，
        // 才重新開啟 App，這樣永遠只會有一個實例、一個主視窗。
        let pid = ProcessInfo.processInfo.processIdentifier
        let path = Bundle.main.bundlePath

        let helper = Process()
        helper.executableURL = URL(fileURLWithPath: "/bin/sh")
        helper.arguments = [
            "-c",
            "while kill -0 \"$1\" 2>/dev/null; do sleep 0.2; done; /usr/bin/open \"$2\"",
            "_", String(pid), path
        ]
        do {
            try helper.run()
        } catch {
            // 無法自動重啟時，請使用者手動重新開啟
            print("⚠️ 自動重新啟動失敗：\(error.localizedDescription)")
        }
        NSApp.terminate(nil)
    }
}

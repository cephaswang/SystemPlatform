import Foundation

/// 代表一個使用者匯入的音檔，及其轉錄進度狀態
struct AudioFile: Identifiable, Equatable, Codable {

    enum TranscriptionStatus: Equatable, Codable {
        case pending
        case processing
        case completed
        case failed
    }

    let id: UUID
    var sourceURL: URL
    /// 使用者實際上傳的原始檔案位置。匯入階段已不再做格式轉檔（僅接受
    /// AVFoundation 可原生讀取的 mp3／m4a／wav），因此目前恆等於 sourceURL；
    /// 保留此欄位是為了讓呼叫端（例如 ImportView 比對已匯入檔案）不需要跟著改動。
    var originalSourceURL: URL
    var displayName: String
    var durationSeconds: TimeInterval
    var status: TranscriptionStatus

    /// 這個檔案要用哪個語系辨識，例如 "zh-TW"、"en-US"。
    /// 由使用者於 ImportView 匯入當下選定，之後不會被全域設定覆蓋，
    /// 每個檔案各自獨立，互不影響。
    var locale: String

    /// 轉錄完成後的逐句結果；未完成前為空陣列
    var transcriptSegments: [TranscriptSegment] = []

    /// 最近一次轉錄失敗的原因；成功或重新轉錄時會被清空。
    /// 可選型別：舊版 library.json 沒有這個欄位時，解碼會自動得到 nil，不影響既有資料。
    var lastError: String? = nil

    /// 副檔名（不含句點），例如 "mp3"、"m4a"、"wav"
    var fileExtension: String {
        sourceURL.pathExtension.lowercased()
    }

    /// UI 顯示用的時長字串，例如 "3:05"
    var durationDescription: String {
        let totalSeconds = Int(durationSeconds.rounded())
        let minutes = totalSeconds / 60
        let seconds = totalSeconds % 60
        return String(format: "%d:%02d", minutes, seconds)
    }

    init(
        id: UUID,
        sourceURL: URL,
        originalSourceURL: URL? = nil,
        displayName: String,
        durationSeconds: TimeInterval,
        status: TranscriptionStatus,
        locale: String = "zh-TW",
        transcriptSegments: [TranscriptSegment] = [],
        lastError: String? = nil
    ) {
        self.id = id
        self.sourceURL = sourceURL
        self.originalSourceURL = originalSourceURL ?? sourceURL
        self.displayName = displayName
        self.durationSeconds = durationSeconds
        self.status = status
        self.locale = locale
        self.transcriptSegments = transcriptSegments
        self.lastError = lastError
    }

    /// ⚠️ 修改：原本只比較 id。
    /// SwiftUI 在決定「這個 View 的輸入有沒有變」時會使用 Equatable 的 ==；
    /// 只比 id 會讓它以為「status 改了、逐字稿填進來了」都沒有變化，
    /// 於是列與詳細頁不更新（之前必須靠 .id("\(id)-\(status)") 硬重建 View 的原因）。
    /// 這裡改成比對所有會顯示在畫面上的欄位。
    /// （逐字稿只比筆數，避免每次比對都走訪整份大陣列；完成時筆數必然從 0 變成 N。）
    static func == (lhs: AudioFile, rhs: AudioFile) -> Bool {
        lhs.id == rhs.id
            && lhs.status == rhs.status
            && lhs.displayName == rhs.displayName
            && lhs.durationSeconds == rhs.durationSeconds
            && lhs.locale == rhs.locale
            && lhs.sourceURL == rhs.sourceURL
            && lhs.lastError == rhs.lastError
            && lhs.transcriptSegments.count == rhs.transcriptSegments.count
    }
}
